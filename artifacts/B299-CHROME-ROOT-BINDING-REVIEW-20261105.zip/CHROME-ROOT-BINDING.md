# Chrome root identity 바인딩 — 독립 후속 단위

2026-11-05. R1 수정본 source/document-provider.mjs 및 root-identity-reader.mjs는 그대로 보존. 신규 source/chrome-root-identity.mjs와 chrome-root-identity.test.mjs만 추가.

createChromeRootIdentityReader는 기존 readRootIdentity의 bounded/abort/최소투영 구현을 재사용해 실제 API 형태를 바인딩한다. root 허가를 검사한 뒤 focurve-local v1 metadata의 installation_id 단일key를 readonly로 읽고, chrome.storage.local.get('focurve_member_auth')만 호출. absent DB/upgrade는 transaction abort, blocked/open-late/취소는 핸들 정리. getAll/cursor/새 schema/쓰기/session read/Worker 호출 없음. full auth는 기존 projection 스택으로만 전달, 외부에는 투영 결과만 반환. 원본 auth 필드/사용자값을 로그하지 않음.

검증: node --test chrome-root-identity.test.mjs. fake-indexeddb6.2.5와 Chrome storage API 대역으로 신규5/5 PASS, fail/skip0. 기존R1 20건은 변경되지 않은 코드이므로 반복하지 않음/새5와합산하지않음. 기존 local fake-indexeddb 의존성을 일시symlink로 사용 후 제거. 실제 Chrome/OS Native/b299에 접속한 시험은 아님.

미연결: 검증된 root 권한 반환과 trusted isCurrent 공급, 고정문서의 이 reader 호출 wiring, Native의 실제 단계별권한발급/소비. 이 모듈을 자동 설치하거나 기존 reader/UI에 주입하지 않음. 입력 authorization은 운영권한증명이 아니며 trusted문서호출자만 실제provider에서 수신해야함. 하위 storage API 강제취소 불가 한계는 R1과 동일.

다훈 리뷰 요청: 지정DB/key/readonly·upgrade차단·abort정리·auth투영 호환성만 확인. Windows Native provider 원문/설정이 정해지면 별도연결. b299실행/export/서비스/START/Git제출0.
