# Chrome root identity 바인딩 신규 경계 검토

BASELINE.json → source/chrome-root-identity.mjs → CHROME-ROOT-BINDING.patch → 시험/로그 순서로 확인.
신규 모듈과 시험은 기존 파일이 없는 추가파일이다. 포함된 root-identity-reader.mjs는 R1 ZIP과 byte 동일한 의존성 사본이며 이번 변경/재검토 대상 아님.

검증 재현: Node24 및 fake-indexeddb6.2.5 환경에서 ZIP 루트의 node --test chrome-root-identity.test.mjs. node_modules는 미포함. 기존 프로젝트에 잠금된 동일 의존성을 사용. 기존 실제 로그5/5 PASS, FAIL/SKIP0. 포장 시 시험 반복 없음.

실제 IndexedDB API 형태는 fake-indexeddb로 실행했고 Chrome storage는 대역이다. DB/key readonly·없는DB upgrade abort·권한 없음·회원secret 거절·취소 경계의 신규5건만 검토. 실제 Chrome/Native 인증·영속grant소비·문서wiring·b299 실행/export는 미완료/미실행.

R1 독립 기존6+추가3 통과는 사용자 전달 완료 근거로만 기록하고 이번5와합산하지 않음. 하위API 강제중단 보장없음. Native 공급/문서wiring은 Core 후속 담당 유지. 배포/제품Git제출 없음.
