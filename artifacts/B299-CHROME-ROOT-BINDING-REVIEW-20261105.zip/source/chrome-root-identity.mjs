import {readRootIdentity} from './root-identity-reader.mjs';
const fail=()=>Error('EXPORT_ROOT_READ_UNCONFIRMED');
// Internal binding only. No Native authority issuance and no auto-installation.
export function createChromeRootIdentityReader({indexedDB,chrome,isCurrent,api,origin,now=Date.now}) {
 if(typeof indexedDB?.open!=='function'||typeof chrome?.storage?.local?.get!=='function'||typeof isCurrent!=='function')throw fail();
 const metadata=({signal})=>new Promise((resolve,reject)=>{
  let db=null,tx=null,settled=false;
  const finish=(error,value)=>{if(settled)return;settled=true;signal.removeEventListener('abort',abort);if(error){try{tx?.abort();}catch{}}db?.close();error?reject(fail()):resolve(value);};
  const check=()=>{if(signal.aborted||isCurrent()!==true)throw fail();};
  const abort=()=>finish(fail());
  signal.addEventListener('abort',abort,{once:true});
  try{
   check();const request=indexedDB.open('focurve-local',1);
   // Opening an absent/new-version DB never commits schema creation.
   request.onupgradeneeded=()=>{request.transaction.abort();finish(fail());};
   request.onerror=request.onblocked=()=>finish(fail());
   request.onsuccess=()=>{
    db=request.result;if(settled){db.close();return;}
    try{
     check();if(db.version!==1||!db.objectStoreNames.contains('metadata'))throw fail();
     db.onversionchange=()=>finish(fail());
     tx=db.transaction(['metadata'],'readonly');let value;
     const q=tx.objectStore('metadata').get('installation_id');
     q.onsuccess=()=>{try{check();if(q.result?.key!=='installation_id')throw fail();value=q.result.value;}catch{finish(fail());}};
     tx.oncomplete=()=>{try{check();finish(null,value);}catch{finish(fail());}};
     tx.onabort=tx.onerror=()=>finish(fail());
    }catch{finish(fail());}
   };
  }catch{finish(fail());}
 });
 // Full auth object stays within the projection operation; never returned here.
 return async({authorization,deadlineMs,signal}={})=>readRootIdentity({authorization,deadlineMs,signal,readMetadataIdentity:metadata,
  readAuth:async({signal})=>{
   if(signal.aborted||isCurrent()!==true)throw fail();
   let result;
   try{result=await chrome.storage.local.get('focurve_member_auth');}catch{throw fail();}
   if(signal.aborted||isCurrent()!==true)throw fail();
   return result?.focurve_member_auth;
  },isCurrent,api,origin,now});
}
