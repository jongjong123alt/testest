// Diagnostic root-only projection. Never a session reader or authority issuer.
const need=(v)=>{if(!v)throw Error('EXPORT_ROOT_IDENTITY_UNCONFIRMED');};
const uuid=v=>typeof v==='string'&&/^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(v);
const equal=(a,b)=>JSON.stringify(a)===JSON.stringify(b);
export async function readRootIdentity({authorization,deadlineMs,readMetadataIdentity,readAuth,isCurrent,api,origin,now=Date.now,signal}) {
 // Capture only minimal permission fields; caller mutation cannot extend this read.
 authorization={rootReadAuthorized:authorization?.rootReadAuthorized,exportAuthorized:authorization?.exportAuthorized,notAfter:authorization?.notAfter};
 const end=authorization.notAfter;
 let retired=false;
 const controller=new AbortController();
 const check=()=>{need(!retired&&!signal?.aborted&&Number.isSafeInteger(deadlineMs)&&authorization?.rootReadAuthorized===true&&authorization?.exportAuthorized===false&&Number.isSafeInteger(end)&&end<=deadlineMs&&now()<end&&now()<deadlineMs&&isCurrent()===true);};
 async function once(){
  check();const id=await readMetadataIdentity({signal:controller.signal});check();need(uuid(id));
  let auth=await readAuth({signal:controller.signal});check();
  try {
   need(auth===null||auth===undefined||(typeof auth==='object'&&!Array.isArray(auth)&&['UNREGISTERED','REGISTERED'].includes(auth.phase)));const phase=auth?.phase??'ABSENT';need(['ABSENT','UNREGISTERED','REGISTERED'].includes(phase));
   need(!auth||(!auth.owner_user_id&&!auth.access_token&&!auth.refresh_token&&!auth.error&&auth.recovery_pending!==true));
   if(phase==='UNREGISTERED')need(!auth.installation_proof&&!auth.executor_id);
   if(phase==='REGISTERED')need(auth.executor_id===id&&/^[A-Za-z0-9_-]{32,256}$/.test(auth.installation_proof??'')&&auth.server_url===api&&auth.web_origin===origin);
   // Secrets never leave this local stack; no raw object copy/log/storage.
   return {executorId:id,owner:'GUEST:'+id,guestAuthClass:phase,authExecutorMatches:phase==='REGISTERED'?auth.executor_id===id:true,
    memberOwnerPresent:false,accessTokenPresent:false,refreshTokenPresent:false,installationProofPresent:!!auth?.installation_proof,recoveryPending:false,authErrorPresent:false,
    originMatches:phase==='REGISTERED'?auth.web_origin===origin:true,apiMatches:phase==='REGISTERED'?auth.server_url===api:true};
  }finally{auth=null;}
 }
 check();
 if(signal!==undefined)need(typeof signal.addEventListener==='function'&&typeof signal.removeEventListener==='function');
 // The upper operation terminates even if a lower API ignores AbortSignal.
 // Every resumed continuation checks retired before starting another read.
 let timer,abort;
 const work=async()=>{const a=await once();const b=await once();check();need(equal(a,b));return a;};
 try {
  return await new Promise((resolve,reject)=>{
   let settled=false;
   const finish=(error,value)=>{if(settled)return;settled=true;retired=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);if(error){controller.abort();reject(error);}else resolve(value);};
   abort=()=>finish(Error('EXPORT_ROOT_READ_ABORTED'));
   signal?.addEventListener('abort',abort,{once:true});
   if(signal?.aborted){abort();return;}
   timer=setTimeout(()=>finish(Error('EXPORT_ROOT_READ_TIMEOUT')),Math.max(0,Math.min(end,deadlineMs)-now()));
   Promise.resolve().then(()=>{check();return work();}).then(v=>finish(null,v),e=>finish(e));
  });
 } finally {retired=true;clearTimeout(timer);signal?.removeEventListener('abort',abort);}
}
