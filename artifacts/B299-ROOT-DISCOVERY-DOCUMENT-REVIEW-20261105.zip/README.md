# b299 문서측 root/discovery review

검토 진입점: BASELINE.json → ROOT-CONNECTION.patch → source/ 및 direct-native-channel.mjs → root-connection.test.mjs → tests.log → HANDOFF.md.

실행: Node24, ZIP 루트에서 node --test root-connection.test.mjs. 외부 npm 의존성 없음.
보존 로그13/13 PASS, FAIL/SKIP0. 이번 포장은 재실행이 아님. 모의 Native 응답과 주입된 metadata/auth reader 시험이다. 실제 Chrome storage/IndexedDB·C# compile/Windows ACL/등록호스트/영속 root nonce 소비 검증이 아니다.

baseline/은 전달받은 최신 원문. 새 root reader는 baseline 없음. 변경3파일은 root에 보존한 상대경로 그대로이며 diff는 baseline/source/document-provider.mjs → source/document-provider.mjs 및 baseline/direct-native-channel.mjs → direct-native-channel.mjs. 새 root reader 전체는 별도 파일/추가 diff로 포함.

unchanged-native/의 두 C# 파일은 실제 미수정 증거다. ATTEST 전용, rootReadAuthorized=false/exportAuthorized=false 및 미연결 명령 거절 유지. 실제 명령 handler·trusted 문서/preactivation source·grant provisioning·Chrome 읽기 바인딩은 미연결.

검토 범위: 문서측 단계/취소/owner/기한/최소 투영. 실제 Native authority나 전체 export 수락 아님. Shorts 담당이 연결할 기준은 trustedDocument/preactivation의 인증 원문 공급 및 root/discovery grant 발급/수명 설정이다. b299 실제 실행/export 제외. Git 제출/배포 없음.
