// Document -> nativeMessaging, never runtime.sendMessage / ordinary Worker.
// This transport does not manufacture authority, scope, or preservation receipts.
export function createDirectNativeChannel({chrome, hostName, isCurrent, now=Date.now}) {
 if(typeof chrome?.runtime?.connectNative!=='function'||!/^com\.focurve\.[a-z0-9_]+$/.test(hostName)||typeof isCurrent!=='function')throw Error('EXPORT_NATIVE_TRANSPORT_UNAVAILABLE');
 let port=null,retired=false,sequence=0,pending=null,closeResult=null;
 const fail=code=>{throw Error(code);};
 const stop=code=>{if(retired)return;retired=true;const p=pending;pending=null;if(p){clearTimeout(p.timer);p.reject(Error(code));}if(port){try{port.disconnect();}catch{}port=null;}};
 const ensure=()=>{if(retired||!isCurrent())fail('EXPORT_DOCUMENT_RETIRED');};
 return Object.freeze({
  async request(value){
   ensure();if(pending)fail('EXPORT_NATIVE_REQUEST_OVERLAP');
   if(!Number.isSafeInteger(value?.deadlineMs)||value.deadlineMs<=now()||value.deadlineMs>now()+15000)fail('EXPORT_DEADLINE_INVALID');
   if(!['ATTEST','GET_APPROVED_SCOPE','AUTHORIZE_DISCOVERY','AUTHORIZE_SELECTED','FINALIZE'].includes(value.action))fail('EXPORT_NATIVE_ACTION_REJECTED');
   if(!port){
    port=chrome.runtime.connectNative(hostName);
    port.onDisconnect.addListener(()=>{const ignored=chrome.runtime.lastError;void ignored;stop('EXPORT_NATIVE_DISCONNECTED');});
    port.onMessage.addListener(message=>{
     const p=pending;if(!p)return;
     if(!isCurrent()){stop('EXPORT_DOCUMENT_RETIRED');return;}
     if(message?.requestId!==p.id){stop('EXPORT_NATIVE_CORRELATION_REJECTED');return;}
     pending=null;clearTimeout(p.timer);
     if(now()>=p.deadline){stop('EXPORT_TIMEOUT');p.reject(Error('EXPORT_TIMEOUT'));return;}
     if(message.ok!==true){stop('EXPORT_NATIVE_DENIED');p.reject(Error('EXPORT_NATIVE_DENIED'));return;}
     p.resolve(structuredClone(message.result));
    });
   }
   ensure();const id=String(++sequence);
   return new Promise((resolve,reject)=>{
    const timer=setTimeout(()=>stop('EXPORT_TIMEOUT'),Math.max(0,value.deadlineMs-now()));
    pending={id,resolve,reject,timer,deadline:value.deadlineMs};
    try{port.postMessage({contract:'FOCURVE_GUEST_DIAGNOSTIC_TRANSPORT_1',requestId:id,...structuredClone(value)});}catch{stop('EXPORT_NATIVE_DISCONNECTED');}
   });
  },
  close(){if(!closeResult){stop('EXPORT_NATIVE_CLOSED');closeResult=Object.freeze({disconnectRequested:true,nativeExitConfirmed:false,productObligations:'HOLD_UNCHANGED'});}return closeResult;}
 });
}
