# root / identity / discovery R1 수정 검토

수정 파일2개: source/document-provider.mjs, source/root-identity-reader.mjs. 기존 direct-native-channel은 불변.
1 root Native 검증 await 후 절대deadline 및 root notAfter 재검사. confirm/discovery 경계에서도 root/결과 만료 재검사.
2 root 반환 허용6필드만 투영하고 internal cache에는 authorizationId/notAfter만 보존. nativeEvidence/preservation/추가access_token 원문을 반환하지 않음.
3 root reader의 총 예산(min권한만료,문서deadline)에 timer와 AbortSignal 적용. 상위 호출 거절 뒤 retired latch로 다음 read/투영 차단. 하위 API가 AbortSignal을 무시하면 실제 읽기는 진행할 수 있으나 완료 결과는 후속 권한/읽기 성공으로 소비하지 않음. 메모리/OS 읽기 강제중단 보장은 아님.

재현: Node24에서 node --test root-connection.test.mjs repair-boundary.test.mjs.
최종20/20 PASS, fail/skip0 = 기존13+추가7. 개발자 기존13을 이번 수정 영향회귀로 실행했으며 독립검토6건(3PASS/3FAIL)을 재실행한 것으로 표시하지 않음. 추가7 수정전1PASS/6FAIL→수정후7PASS, 원본 로그 보존. 모든 Native/read callback은 합성, 제품 인증/소비 증거 아님.

baseline-external-check.json: GitHub testest의 이전 전달 ZIP29fbb9... 원격파일과 로컬3파일 동일. 그 ZIP의 baseline이 최초 전달 ZIP2425dbc... 내 원본2파일과 정확히 일치함. repair-baseline은 수정 직전 전달본 원문. 기존 파일/원본ZIP 변경없음.

아직미연결: Native 실제root/confirm/discovery handler, trusted-document/preactivation provider,목적별grant발급/영속소비,실제Chrome 읽기바인딩. ATTEST-only Native 및 admission rootReadAuthorized/exportAuthorized=false 미변경. Windows/실제Native/Chrome/b299/export NOT_RUN.제품Git제출/배포없음.
