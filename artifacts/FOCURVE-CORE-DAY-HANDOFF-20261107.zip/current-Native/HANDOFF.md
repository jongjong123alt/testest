# b299 root/discovery 첫 로컬 구현 단위

2026-11-05. 수신 ZIP SHA-256 2425dbc0909be87c15db4940a18f5cdfb4025703dfe19b1af7b70620249b07c3 및 원본 manifest 78파일 확인. 원본을 보존하고 /workspace/b299-root-connection에서 구현.

구현: source/document-provider.mjs authorizeRootIdentity/confirmRootIdentity 추가, ROOT_VERIFIED 없이는 discovery 거절, 확인된 owner 일치, 일회 상태/취소/기한검사. source/root-identity-reader.mjs는 root 목적 허가 이후 identity metadata/auth reader를 두 차례 호출해 최소 투영만 반환. raw auth/token/proof는 반환/로그/복사하지 않음. direct-native-channel.mjs는 두 private root action 전달을 허용하되 권한을 생성하지 않음.

기존 NativeDiagnosticAdmission.cs/DiagnosticGrantStore.cs와 baseline을 source/에 그대로 보존. admission의 rootReadAuthorized=false/exportAuthorized=false 유지. 실제 Native는 ATTEST 전용 단일 요청 후 종료이므로 새 action은 현재 거절됨. 새 JS 내부 callback의 root 결과 형식은 구현 검토용이며 public Wire/공동 최종 계약 승인이 아님.

검증: node --test root-connection.test.mjs, 13/13 PASS, FAIL/SKIP0. 합성 Native callback 및 주입 read 함수. 실제 IndexedDB/Chrome storage 호출·Native grant 소비·C# compile/Windows ACL·Chrome/export 시험 아님. 기존 owner-handoff 시험은 root 단계 없는 구버전 경로이며 자동으로 새 PASS라 하지 않음. 미실행 원본 로그는 source/tests에 그대로 보존.

미완료: 실제 source-pinned Chrome metadata/auth 읽기 바인딩, Native의 authenticated trusted-document/preactivation source·목적별 root/discovery grant provisioning·같은15초 세션 처리·confirm→discovery dispatch. 관련 정확 binding/grant 필드/발급 공급을 admission 허가로 대체할 수 없으므로 임의 true 처리하지 않음. C# compiler는 이 Linux 환경에서 발견되지 않아 실제 C# 검증 미실행. HOLD J2 reader/selected/finalize는 다음 단위이며 이번 수정 없음.

현재 첫 전달 단위 전체가 완료된 것은 아니며 문서측 단계 연결만 구현·검증. Native 공급과 실제 읽기 바인딩 연결 후에야 첫 단위 종결 가능. 다음 Core 작업은 기존 Native 진입점을 재사용한 단계별 권한 handler 및 공급 계약/Windows 검증이다. 다훈에게 실제 root/discovery grant 발급 설정과 trustedDocument/preactivation evidence의 인증 source 계약을 맞춰 달라고 요청. source 내 임의 grant/모의 운영 authority를 발급하지 않음.

리뷰 필요: 다훈 Core/Native 권한 분리, 문서측 단계/취소/secret 투영·scope/owner 검토. 새 생성물은 로컬 source/diff/manifest/시험 로그로만 전달. Commit/Push/PR/배포/실제 b299 접근 없음. 71ed 재시험과 별개. HOLD/MVP_FINAL_COMPLETE=false.
