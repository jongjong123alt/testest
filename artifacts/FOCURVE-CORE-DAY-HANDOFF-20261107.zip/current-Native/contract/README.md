# 종민 Native 단계별 명령: 신뢰 원본·목적별 grant 기준

상태: 계약 대조/결정 입력. 제품 승인·배포·실제 export 권한이 아님. Native 명령 구현 담당은 종민이며 이 전달에서 공급자 코드를 수정하거나 시험을 반복하지 않았다. b299/71ed의 원본·실제 grant·binding·DB·프로필·비밀값·로그는 포함하지 않는다.

## 출처와 우선순위
- USER_REQUIRED: root 권한 → 실제 identity → discovery, provider의 GUEST owner/document/channel/권한 수명 결속, 기본 export와 분리된 HOLD 단일 선택. 설치 ID를 executor로 대입하지 않으며 총 읽기15초/최대32/유일선택/미확인 보존.
- CODE_CONSTRAINT: 동봉 v2/v3 및 현 후보가 실제 검사하는 입력/거절. 코드 존재를 공동 최종 계약 승인으로 격상하지 않는다.
- PROPOSED: startup-reference/README.md J1/J2와 아래 권고. 아직 root/discovery 실제 발급 주체·문서 인증 공급자·보존 producer가 연결되거나 승인됐다는 근거가 없다.
- received-v3는 문서 adapter 후속이다. received-v2의 Native/Core authority보다 나중 수신됐다는 이유로 그 issuer/OS/영속 공급자를 구현했다고 취급하지 않는다. current-candidate는 수신 v3의 owner 검사를 보강한 별도 후보이며 RESULT의 독립검토 대기 상태를 그대로 유지한다.

## 1. 문서 인증

| 구분 | 실제 기준/위치 |
|---|---|
| 기존 확정 요구 | 원본의 writer가 문서 열기 전에 실행되지 않도록 배제하고 읽기 전체 동안 유지해야 한다. 같은 extension origin/UUID 형태/workerAlreadyRunning=false/JS flag만으로 인증하지 않는다. sender·문서·채널 퇴역 뒤 재사용 금지. |
| 기존 v3 코드 제약 | received-v3/src/document-provider.mjs의 installGuestFailureDocumentAuthority가 trustedDocument(), verifyPreactivationEvidence(), nativeChannel.request/close를 주입받는다. createDocumentProvider는 documentId UUID·openedAt·15초 기한을 검사한다. preservationOK는 boundaryId/mode/manifest/times를 비교하지만 인증 원본을 발급하지 않는다. |
| 구현된 OS 공급 | current-candidate/NativeDiagnosticAdmission.cs: AttestPeer가 실제 Native 프로세스의 OS 부모 체인에서 SID/Chrome 실행파일 hash/PID·생성시각/프로필 명령줄·digest를 확인한다. Main은 compile-pinned diagnostic-binding hash·기한·이미지 전체 파일을 검증한다. 이는 문서ID·탭ID·채널ID 또는 writer 배제의 독립 측정이 아니다. |
| 구현된 전송 | startup-reference/direct-native-channel.mjs:createDirectNativeChannel은 connectNative 직접 포트·requestId·deadline·현재성 callback을 사용한다. 일반 Worker sendMessage를 쓰지 않는다. isCurrent의 신뢰 원본은 외부 seam이다. close는 disconnectRequested/nativeExitConfirmed=false를 반환하므로 Native 종료·권한 폐기 완료 영수증으로 쓰면 안 된다. |
| 원래 sender 검사 | received-v2/src/guest-export-authority.mjs:verifyOfficialSafetySender는 MessageSender의 exact safety/index.html·origin·top frame·tabId/documentId·비incognito와 runtime.getContexts TAB의 유일 대응을 검사한다. expectedDocumentId/profileDigest는 trusted 외부 공급이 필요하다. 직접 Native 포트에는 MessageSender가 없으므로 이 함수를 그대로 이식해 검증됐다고 표시할 수 없다. 일반 Worker를 깨워 sender를 얻는 것은 보존 조건을 위반할 수 있다. |
| 미구현/미결정 | 실제 trustedDocument 및 verifyPreactivationEvidence 생산 공급자, Native에서 문서 주장을 인증할 원본, 채널 수명에 결속된 명령별 verifier, 원본/cached Worker가 먼저 활성화되지 않는 continuous startup fence와 진단 이미지의 기존 origin 활성화 방식. 이미지 manifest에 background가 없다는 사실만으로 이전 등록 Worker 배제를 입증하지 못한다. |

### Native가 확인할 입력과 거절
- **측정된 것**: 현재 OS peer의 SID·실행파일/hash·새 PID/creation·프로필, compile-pinned 설치/이미지/sourceManifest. 경로 alias/reparse·hash/identity 불일치·기한/입력 불명확은 거절한다. 이전 product PID/grant를 승계하지 않는다.
- **문서/채널 주장**: documentId/openedAt·scope·authorizationId·boundaryId·preservation 및 명령 payload는 문서가 보냈다는 이유만으로 trusted가 아니다. Native의 실제 연결 인스턴스와 독립적으로 생성된 문서/보존 record에 대조할 수 있을 때만 수락한다. caller channelId나 page UUID를 인증 원본으로 쓰지 않는다.
- **보존 원본**: sourceManifest와 fenceEstablishedAt ≤ documentOpenedAt, 같은 설치/프로필/실행/문서·채널, 유효기한 및 실제 배제 유지 상태가 일치해야 한다. mode 이름만 검증하거나 과거 한 시점의 부재 확인으로 전체 창을 보장하지 않는다. 불명확/퇴역/포트 교체/Worker 활성화 또는 상태 확인 실패 시 권한을 닫고 원본 의무 보존.
- root reader의 IndexedDB executor/owner 투영은 허용된 root 읽기 후에만 생긴다. 이는 OS peer 인증이나 Native가 DB를 독립 측정한 증거를 대체하지 않는다.

### 종민과 맞출 선택 D1/D2 — 권고이며 미승인
D1(문서 인증):
A. **권고**: source-pinned 안전 문서의 Chrome context 관측을 Native의 실제 channel 인스턴스·fresh challenge·새 OS peer에 결속하고, Native private record에 문서 provenance를 보관해 각 단계에서 대조하는 경로를 구체화한다. trustedDocument는 실제 Chrome context에서 얻고 임의 UUID를 생성하지 않는다. 단, connectNative origin만으로 Native가 Chrome documentId를 직접 입증할 수는 없다. 안전 문서의 context 증명을 신뢰할 조건/위협모델과 검증 가능한 attestation 전달 방식을 합의해야 한다. 단순히 JS가 challenge를 되돌려줬다는 것은 문서 인증이 아니다. 이 producer가 없으면 BLOCKED.
B. 별도 기존 trusted browser producer가 authenticated MessageSender/getContexts를 Native에 전달한다. 그러나 일반 Worker startup을 배제할 수 없으면 사용 불가이며 새 producer 이름만 만들지 않는다.
verifyPreactivationEvidence는 Native의 private authoritative record를 실제로 대조하는 경로를 권고한다. 관련 Native 명령 이름/확인 응답은 아직 미정이며 현재 transport allowlist에 몰래 추가하지 않는다. 서명형 영수증을 택한다면 발급 키/검증 키/신뢰 배포도 별도 결정 대상이다. 기존 SHA-256은 무결성 hash일 뿐 서명/발급자 인증이 아니다.
D2(보존): Native/installer가 Chrome/문서 열기 전 writer 배제를 설정하고 전체 읽기 동안 유지하는 실측 producer를 먼저 특정한다. 별도 background-free 이미지 생성기는 재사용 가능하지만 기존 origin/cached Worker 활성화 배제는 미검증이다. manifest-only나 사후 flag를 완성된 fence로 선택하지 않는다. 현재 b299에 적용 가능한 정식 전달이 입증되기 전 실행하지 않는다.

## 2. 목적별 grant

| 구분 | 실제 기준/위치 |
|---|---|
| 기존 확정 요구 | root identity 권한과 session discovery/detail/export 권한 분리. 원본 읽기 전에 해당 목적 권한을 소비. 실패/불확실 소비는 재발급·재시도로 지우지 않음. 실제 owner는 root 확인 후 GUEST:<executorUUID>로 결속. |
| 구현된 admission grant | current-candidate/DiagnosticGrantStore.cs:Validate/Consume. contract FOCURVE_DIAGNOSTIC_ADMISSION_GRANT_1, 정확10필드, purpose ADMISSION_ONLY_NO_DB_OR_EXPORT, 설치/확장/profileDigest/image digest·notBefore/After≤300초 검사. 설치·프로필 바깥의 private ACL ledger에서 CreateNew/WriteThrough/Flush(true) 후 hash 확인. 원자적 소모 원시는 존재하지만 root/discovery 권한은 아니다. |
| 구현된 Main | NativeDiagnosticAdmission.Main은 ATTEST만 허용한다. 다른 명령은 DIAGNOSTIC_EXPORT_AUTHORITY_NOT_CONNECTED로 거절하며 rootReadAuthorized=false/exportAuthorized=false다. 실제 root/discovery 공급자는 없다. |
| 원래 export issuer 후보 | received-v2/src/guest-export-authority.mjs:createGuestFailureExportNativeAuthority.issue/consume는 아래10필드 export grant·5분TTL·window≤1시간·STOPPED·peer/source callbacks·메모리ISSUED→CONSUMING→CONSUMED/BURNED를 검사한다. 생산 verifyPeer/verifySource/persistConsume/randomNonce 공급·영속 issued record가 외부 seam이다. issued Map은 host 재시작 후 발급 상태 인증 수단이 아니다. |
| v3/provider 결속 | received-v3/current-candidate document-provider의 SCOPED→DISCOVERY→SELECTED→FINALIZING 흐름. getApprovedScope/authorizeDiscovery/authorizeSelected/finalize/cancel은 허용 결과를 검사하며 자체 발급자가 아니다. direct-native-channel 현재 allowlist에는 root 권한/확인 명령이 없다. |
| 미결정 | root/discovery의 실제 발급 주체·승인 입력·서버/Native 저장 위치·purpose chain/문서-channel-peer 결속의 권위 record·root 단계 삽입 계약. 현재 admission C# grant에 purpose를 ROOT로 바꾸거나 rootReadAuthorized를 true로 바꾸는 방식은 지원되지 않는다. |

### 현재 설정 형식 — 원문 소스의 제약이며 새 목적 권한 아님
1. admission의 정확10필드: contract, authorizationId, nonce, installationId, extensionId, profileDigest, sourceManifestSHA256, purpose, notBeforeUTC, notAfterUTC. binding 안의 compile-pinned admissionGrant만 소비하며 문서가 보낸 임의 grant는 받지 않는다.
2. v2 export의 정확10필드: contract, requestId, installationId, extensionId, profileDigest, sourceManifestSHA256, fromUTC, toUTC, notBeforeUTC, notAfterUTC. 이 wire에는 purpose/documentId/channelId/새 PID 필드가 없다. 기본 경로는 STOPPED만 받는다.
3. 현재 C# admission은 OS에서 현재 새 PID를 측정하고 소비 영수증에 PID/creation을 기록하지만, grant Validate가 예상 PID/creation을 따로 고정 비교하는 구현은 아니다. 문서/channel 결속도 없다. 발급 전/소비 때마다 새 peer가 맞는다는 단계별 계약은 별도로 구현해야 한다.
4. v2/v3의 grant TTL≤5분은 authority 상한이고, root/discovery/detail의 실제 읽기 예산은 최초 시작에서 **총15초**다. 단계 전환마다15초를 다시 주거나 5분 동안 DB를 허용하지 않는다. 원본 실패 구간은 최대1시간이고 현재 값을 과거 Snapshot으로 대체하지 않는다.

### 종민과 맞출 선택 G1/G2 — 권고이며 미승인
G1(발급 주체): **정식 installer/진단 Native 측의 실제 승인 검증 경로**가 issuer가 되는 방향을 권고한다. UI는 요청자, provider는 소비자이며 페이지/테스트 callback/현재 DB값은 issuer가 아니다. 기존 v2 issue 함수는 로직 후보일 뿐 생산 발급 주체가 아니다. 누가 어떤 명시 승인·소스 pin·보존/peer evidence로 목적 권한을 발급하는지 종민이 실제 함수/저장소에 매핑해 확인해야 한다. 운영 서비스 권한 갱신과 별개이며 진단 실행 승인이 자동으로 제품 실행 권한을 부여하지 않는다.
G2(형식):
A. **최소 변경 권고**: v2의10필드 envelope는 유지하고 requestId에 대응하는 Native의 인증된 영속 issued record에 purpose(ROOT_IDENTITY_ONLY/DISCOVERY), parent root receipt, actual peer(PID+creation), document/channel/boundary/source·scope·deadline·소모 상태를 고정한다. Native는 caller가 보내는 purpose가 아니라 record로 판단한다. 기존 issued Map을 이 record로 대체하는 실제 저장·무결성/인증 방식이 구현돼야 한다. 이 추가 record 형식과 단계별 소비는 제안이며 현재 구현됐다고 표시하지 않는다.
B. 새 private grant revision에 purpose/parent/document/channel/peer 필드를 명시. 명확하지만 현재 exact10필드 검사를 변경해야 하므로 Native/provider/reader 계약 revision 합의가 필요하다. 기존 admission grant를 재해석하지 않는다.

권고 stage 순서: admission peer/image 측정(읽기 권한 없음) → 별도 ROOT_IDENTITY_ONLY 발급/소비 → 고정 root 두 차례 일관 읽기 → 같은 document/channel/source/peer에서 root 확인 영수증 → 별도 discovery 발급/소비 → 같은 실제 GUEST owner의≤32 후보 유일성 → selected 일회 결속 → 기존 detail/finalize/cancel. root를 발급할 때 executor/owner를 사전 요구해 순환시키지 않고, root 확인 후 discovery record에만 실제 값을 결속한다. 이미 확정된 admission으로 root/session 읽기를 대체하지 않는다.
발급은 승인된 source/time/preservation window 안에서만, 각 단계 notAfter는 원래 절대 읽기 deadline 및 grant 만료 중 이른 값. nonce/requestId는 생산의 암호학적 난수 공급자가 발급하고 목적/부모별 영속 소모를 먼저 확정한다. 권한 실패·소모 불확실·새 PID/문서/channel/source 변경·HOLD 보존 경계 상실은 거절하고 원본/미해결 상태를 보존한다. 포트 disconnect 요청은 실제 Native exit나 기존 제품 의무 해소가 아니다.

## 남은 J1/J2와 기본 경로 차이
- J1: root 권한 뒤 실제 local metadata UUID와 guest auth 최소 투영을 읽는 것을 허용할지. Chrome storage가 auth 객체 내부 필드만 선택 조회하지 못하는 점의 허용 판정 필요. 실제 token/ownerUserId/proof 원문은 반환·로그하지 않는다. v2 identity provider는 REGISTERED만 허용하지만 J1 제안의 auth 부재/UNREGISTERED까지는 아직 합의/구현되지 않았다.
- J2: 원본 HOLD·미종료 상태 그대로, 실패 owner/executor/Snapshot/시간 참조로 유일 후보를 결속하는 별도 경로. 현재 bridge/issuer의 STOPPED 요구를 HOLD에서도 그냥 통과시키거나 설치 기록을 STOPPED로 바꾸지 않는다. 0/복수/불일치 거절, ended_at 생성 금지. 기존 기본 export는 유지한다.

## 종민 첫 확인/회신
1. 위 파일 재사용을 우선하고 새 구현을 중복하지 않는다.
2. D1/D2 문서·연속 보존의 실제 producer/검증 함수 및 미지원 조건을 특정한다.
3. G1 발급 주체와 G2 형식 선택을 확정한다(미선택 항목은 미결정).
4. 기존 담당1번 root 권한→identity→discovery의 수정 파일/diff/hash/검증부터 회신한다. Native 명령 구현은 종민 담당이며 이 채팅은 경쟁 수정하지 않는다.
권한/공동 계약의 실제 승인 기록은 이 문서가 대신하지 않는다. 새 구현/반복 시험/Native 등록/원본 export/실제 HOLD 실행은 수행하지 않았다. Shorts 재시험 후보 준비는 이 결정과 분리한다.


## 2026-11-05 Core 구체 권고안 — 공동 결정용, 미활성

원본 ZIP/README는 /workspace/reviews/native-document-grant-contract에 보존한다. 이 파일은 기존 계약안의 구현 작업본이다. 확정 J1/J2와 완료 R1/Chrome 바인딩을 재검토하지 않는다. 아래 새 함수/record는 명시적으로 제안이며 실제 구현 존재를 주장하지 않는다.

### D1 신뢰 근거 생산/문서 인증

재사용: NativeDiagnosticAdmission.AttestPeer(origin,binding)는 OS 실제부모체인의 SID/exe hash/PID+creation/profile을 측정. VerifyImage(root,pins)는 compile-pinned이미지파일집합/hash·진입점부재 검증. DiagnosticGrantStore.VerifyDirectory/NoReparse의 ACL·경로검증 원시 재사용. 이 세 근거는 실제 documentId/tabId를 제공하지 않는다.

권고 producer: 정식installer의 명시승인·전달 단계가 설치/이미지/source/profile·승인창·launch의 보호된 activation record를 만들고, 독립 trusted browser-context producer가 그 launch에서 열린 실제 안전문서를 관측해 별도 provenance record를 공급한다. 검증자는 Native이며 문서 JSON이 아닌 보호record와 실제channel/OS peer를 대조한다. 현재 installer activation record 생산/브라우저문서producer 모두 미구현이다. 파일소유권/ACL만으로 producer의 진정성이 생기지 않으므로 record 발급 경로/쓰기 주체의 위협모델도 필요하다.

제안 위치: 설치 전달코드에 activation record 생성; NativeDiagnosticAdmission의 인증입력 검증 단계에 보호record조회/peer·launch비교. root/confirm/discovery 각 단계에서 동일 문서/실제 Native connection의 퇴역 여부 확인. document-provider의 trustedDocument/verifyPreactivationEvidence는 이검증결과를소비하며 caller값으로record를생성하지 않음.

필수로결정할 공백: 독립browser-context producer가 어떤기존소스/권한으로 실제문서를관측하는지 현재자료에는없음. 일반Worker의MessageSender나getContexts를깨워사용하면보존위반가능. source-pinned문서의self getContexts/freshchallenge반환은채널possession/자기보고일뿐독립document인증이아님. NativeOS검증만으로문서id를인증했다는대체안은권고하지않음. 새보조producer가필요하면구현·신뢰배포·권한범위는공동승인후추가하고 그전root권한거절유지.

실패: record미존재/변조·다른launch/peer/document/channel·퇴역/만료·검증불명확→읽기허가없음,이미소비된nonce는유지. 영수증은보호원문조회형을권고하며해시를서명으로표시하지않음.
최소검증(계획NOT_RUN): 위조자기보고거절,같은origin다른문서거절,다른PID/creation/channel재사용거절,source/record변조거절,유효한독립source관측양성. 현재양성증거없음.

### D2 진단 이미지/정식 전달 보존

재사용 producer: prepare_diagnostic_image.prepare(source,destination,expected), 입력hash검사와새출력만생성. verifier: NativeDiagnosticAdmission.VerifyImage. 실제보장=확인한이미지에일반Worker/Core/content writer진입점없음. 보장하지않음=기존등록SW/cache정지,과거Worker재기동배제,프로필자체쓰기전체금지.

권고 절차: 승인된별도전달절차에서Chrome/이전Worker정지를확인→원본을보존하고정확이미지전달/등록전환을수행→동일확장origin/storage/DNR보존을확인→보호activation record를봉인→새OS peer를측정/결속→안전문서만열기→진단기간동안지원되는관측producer로writer배제확인. 단순시간순서제안이며현재절차구현/실제b299적용을의미하지않음. Chrome기동후이전SW활성화가일어나지않는브라우저지원근거/전환방식이없으면여기서중단. Native는Chrome프로세스존재만으로SW부재를증명할수없다.

연속보존은종료요청/검증실패시권한즉시닫음+관측미확정소비금지. 실제writer를막는enforcement와사후탐지는구분해야하며polling만으로무변경을증명하지않음. 기존정상STOPPED updater를HOLD전달기로재사용하지않고안전복구를전역disable하지않음.

대안=원본의검증된스냅샷복사본만독립읽기. 원본origin실행위험은줄지만복사/잠금/내용동일성·민감자료보호·새identity결속계약과권한이추가로필요하며기존원본진단계약을자동충족하지않으므로현재채택하지않음.

담당: 다훈설치/배포절차·전달pin/보존근거; 종민Native이미지/peer/권한수명검증. 실제허용가능전환방식과연속배제producer가정해지기전root발급BLOCKED.
최소검증계획: 변조/추가writer/image기존출력거절,기존Worker존재/재활성/연속상태상실거절,동일origin/storage/DNR보존근거,실제전달없는합성경계우선. b299실행권한은별도.

### G1/G2-A 정확 발급/소비 의미

G1 권고: installer의새명시승인단계가제한발급을요청하고Native의발급검증기가D1/D2/peer/source/시간을검증해영속issued record를생성. 페이지/UI/provider는발급자가아님. 승인입력과issuer인증은설치담당확인,record검증/저장/소비는Core담당. 현Main은ATTEST만이며진단명령연결은추가구현. 기존admission의exact10/purpose/falseflag불변.

G2-A 외부export envelope10필드유지. 기존R1의root응답/private action은문서구현검토형식으로유지하며최종Native매핑별도대조. 목적은Native보호record에서정하고callerpurpose를믿지않음.

제안내부record 필드(공개DTO아님):
- record식별/version,issuer승인참조/hash,발급requestId/암호학적nonce,purpose,parentRootReceipt(루트는없음)
- installationId/extensionId/profileDigest/sourceManifestSHA256/activation-boundary참조
- 측정peer의SID/executablehash/PID/creation;독립문서provenance참조와원래documentId/openedAt
- Native가생성한실제connection instance/retirement generation(페이지가보낸channelId아님)
- 승인scope/실패참조/허용store,notBefore/notAfter,최초combined-read-deadline
- root전identity미확정,confirm검증후executor/GUESTowner와별도rootreceipt참조
- ISSUED/CONSUMING/CONSUMED/BURNED와정확canonical요청결속,소비receipt/digest.

저장권고: 설치/프로필밖 private ACL 저장소. 현재Consume의CreateNew/배타공유/WriteThrough/Flush(true)/NoReparse를재사용하되,issued파일과일회claim을별도 record로보존. 상태를덮어써서부분파일/과거nonce를재활성화하지않음. nonce전역배타claim에purpose/record원문을결속하고부분·미확정도spent유지. root/discovery마다별도nonce. 동일 requestId다른원문은충돌. 동일원문조회는재소비가아닌저장결과조회이며현재권한필수. 디스크/ACL경합/변조/rollback의검증정책은구현/검토대상이다.

순서:
1 installer 승인·activation/source/fence보호근거확보. 실제운영발급/배포이번범위아님.
2 Native기동때실제OSpeer/image/admission전용소비확인. 읽기허가없음.
3 D1/D2 현재검증후root 목적 record발급및일회소비commit확인. root허가전metadata/auth접근금지.
4 기존R1+Chrome바인딩이같은절대15초안에서2회root최소투영. Native는독립DB관측이아닌인증reader투영확인임을유지.
5 confirm은동일peer/document/channel/source/fence와root소비원문에결속,일치시root확인receipt저장. 불일치는BURNED/의무유지.
6 discovery는rootreceipt를parent로하는새목적record와nonce를발급/소비한후확인된GUESTowner로만허용. root에owner를미리요구하지않음.
7 selected/detail/finalize는후속범위. root/discovery만으로export다운로드허가금지.

시간권고: 목적grant는기존상한이내,실제읽기는최초고정15초deadline과각grantnotAfter중최솟값. 단계/재조회/재연결로시계재설정금지. wallclock/monotonic원래예산대조,await후만료재검사. peer/document/channel/source전환/취소/중단/보존상실→현재허가폐기,nonce/저장사실은보존. host재시작시옛메모리issued상태로복구성공처리금지,원래channel퇴역이므로새권한자동승계없음.

최소검증계획: 같은nonce동시/재시작재소비거절,부분consume재사용거절,다른purpose/parent/owner/peer/document/channel/source거절,root확인없는discovery거절,15초공유/만료/유실조회/취소후저장보존,권한없는raw auth반환금지. 기존R1/Chrome PASS 반복없음. Windows ACL/실제Native 검증은Linux합성으로대체하지않음.

### 제품 병행 상태

진단D1/D2를제품M1의차단으로사용하지않는다. 별도AMVP-CORE-04의제품P1~P4에서RuntimeReportDelivery.send/authorizeScope/isCurrent,Outbox.verifyReport/verifyAck,IG04ProviderStore의provenance/membership/coverage가어떤운영source에의존하는지기록돼있다. 기존primitive의추가독립구현여지는없고새carrier/공유인수형식없이임의true연결하지않음. 제품기존계약안에서신규구현가능자료/결정이들어오면진단과독립적으로진행. 이번runtime파일수정/제품시험0.

이번선택안의함수/producer역할명은설계제안이며존재하는함수와구별했다. D1신뢰browserproducer/위협모델,D2정식전달·연속배제방식,G1/G2-A필드·순서만공동결정하면다음단계NativeDiagnosticAdmission.cs/DiagnosticGrantStore.cs를수정할수있다. 실제grant/b299적용/export승인아님.
