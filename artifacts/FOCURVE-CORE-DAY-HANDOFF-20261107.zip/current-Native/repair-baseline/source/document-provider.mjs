// Isolated integration adapter. It cannot establish a pre-activation startup fence.
// No Worker imports, chrome.runtime.sendMessage, IndexedDB, or service calls.
const reject = code => { throw new Error(code); };
const uuid = x => typeof x === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(x);
const hex = x => typeof x === 'string' && /^[0-9a-f]{64}$/.test(x);
const clone = x => structuredClone(x);
const canonical = x => JSON.stringify(x, Object.keys(x ?? {}).sort());
const same = (a,b) => JSON.stringify(a) === JSON.stringify(b);
const preservationOK = (p, id, opened, manifest, now) => p?.contract === 'R4_GUEST_EXPORT_PRESERVATION_1' && p.authorizationId === id && uuid(p.boundaryId) && ['WORKER_NOT_ACTIVATED','STARTUP_FENCED_DIAGNOSTIC'].includes(p.mode) && p.sourceManifestSHA256 === manifest && Number.isSafeInteger(p.fenceEstablishedAt) && Number.isSafeInteger(p.documentOpenedAt) && p.documentOpenedAt === opened && p.fenceEstablishedAt <= opened && opened <= now;
/**
 * The ONLY trust boundary is verifyPreactivationEvidence, implemented by a real
 * Native/installer authority that measured and fenced writers BEFORE document open.
 * No boolean, caller-authored preservation object, or late flag is sufficient.
 */
export function installGuestFailureDocumentAuthority({target, nativeChannel, verifyPreactivationEvidence, trustedDocument, sourceManifestSHA256, now=()=>Date.now()}) {
  if (!target || typeof nativeChannel?.request !== 'function' || typeof nativeChannel?.close !== 'function' || typeof verifyPreactivationEvidence !== 'function' || typeof trustedDocument !== 'function' || !hex(sourceManifestSHA256)) reject('EXPORT_ADAPTER_NOT_READY');
  if (Object.prototype.hasOwnProperty.call(target,'FocurveGuestFailureExportAuthority')) reject('EXPORT_ADAPTER_ALREADY_PRESENT');
  const authority=Object.freeze({
    createDocumentProvider({deadlineMs}) {
      if (!Number.isSafeInteger(deadlineMs) || deadlineMs <= now() || deadlineMs > now()+15000) reject('EXPORT_DEADLINE_INVALID');
      const doc=clone(trustedDocument());
      if (!doc || !uuid(doc.documentId) || !Number.isSafeInteger(doc.openedAt) || doc.openedAt > now() || doc.openedAt > deadlineMs) reject('EXPORT_DOCUMENT_UNVERIFIED');
      let state='NEW', authorization=null, approved=null, selected=null, rootAuthorization=null, rootIdentity=null;
      const alive=()=>{if (now() >= deadlineMs || state==='CLOSED') reject('EXPORT_DEADLINE_OR_CLOSED');};
      const request=async (action, payload)=>{alive(); const r=await nativeChannel.request({action, document:clone(doc), deadlineMs, payload:clone(payload)}); alive(); return r;};
      const close=async ()=>{if(state==='CLOSED')return;state='CLOSED';await nativeChannel.close({document:clone(doc),authorizationId:authorization?.authorizationId ?? null});};
      return Object.freeze({
        async getApprovedScope() {
          if(state!=='NEW')reject('EXPORT_SEQUENCE_REJECTED');
          const r=await request('GET_APPROVED_SCOPE',{});
          if(!r?.scope || !r?.nativeEvidence)reject('EXPORT_NATIVE_EVIDENCE_MISSING');
          if(await verifyPreactivationEvidence({evidence:clone(r.nativeEvidence),document:clone(doc),sourceManifestSHA256,phase:'SCOPE'})!==true)reject('EXPORT_PREACTIVATION_UNPROVEN');
          alive();if(state!=='NEW')reject('EXPORT_SEQUENCE_REJECTED');approved=clone(r.scope);state='SCOPED';return {scope:clone(approved)};
        },
        async authorizeRootIdentity(scope) {
          if(state!=='SCOPED'||!same(scope,approved))reject('EXPORT_SEQUENCE_REJECTED');
          state='ROOT_PENDING';
          try {
            const r=await request('AUTHORIZE_ROOT_IDENTITY',{scope});
            if(r?.authorized!==true||r.rootReadAuthorized!==true||r.exportAuthorized!==false||!uuid(r.authorizationId)||!same(r.scope,approved)||!Number.isSafeInteger(r.notAfter)||r.notAfter<=now()||r.notAfter>deadlineMs||!preservationOK(r.preservation,r.authorizationId,doc.openedAt,sourceManifestSHA256,now()))reject('EXPORT_ROOT_UNCONFIRMED');
            if(await verifyPreactivationEvidence({evidence:clone(r.nativeEvidence),document:clone(doc),sourceManifestSHA256,phase:'ROOT',authorizationId:r.authorizationId})!==true)reject('EXPORT_PREACTIVATION_UNPROVEN');
            alive();if(state!=='ROOT_PENDING')reject('EXPORT_SEQUENCE_REJECTED');
            rootAuthorization=clone(r);state='ROOT_AUTHORIZED';
            return clone(r);
          }catch(e){if(state!=='CLOSED')state='FAILED';throw e;}
        },
        async confirmRootIdentity({rootAuthorizationId,identityProjection}) {
          if(state!=='ROOT_AUTHORIZED'||rootAuthorizationId!==rootAuthorization.authorizationId||now()>=rootAuthorization.notAfter)reject('EXPORT_SEQUENCE_REJECTED');
          // One shot, including uncertain/failed attempts. Never return raw auth.
          state='ROOT_CONFIRMING';
          try {
            const p=clone(identityProjection);
            if(!p||Object.keys(p).sort().join(',')!==['executorId','owner','guestAuthClass','authExecutorMatches','memberOwnerPresent','accessTokenPresent','refreshTokenPresent','installationProofPresent','recoveryPending','authErrorPresent','originMatches','apiMatches'].sort().join(',')||!['ABSENT','UNREGISTERED','REGISTERED'].includes(p.guestAuthClass)||['memberOwnerPresent','accessTokenPresent','refreshTokenPresent','recoveryPending','authErrorPresent'].some(k=>p[k]!==false)||['authExecutorMatches','originMatches','apiMatches'].some(k=>p[k]!==true)||typeof p.installationProofPresent!=='boolean'||(p.guestAuthClass==='REGISTERED')!==p.installationProofPresent||!uuid(p?.executorId)||p.owner!=='GUEST:'+p.executorId)reject('EXPORT_ROOT_IDENTITY_REJECTED');
            const r=await request('CONFIRM_ROOT_IDENTITY',{rootAuthorizationId,identityProjection:p});
            if(r?.authorized!==true||r.rootAuthorizationId!==rootAuthorizationId||r.owner!==p.owner||r.executorId!==p.executorId||r.exportAuthorized!==false)reject('EXPORT_ROOT_IDENTITY_REJECTED');
            if(await verifyPreactivationEvidence({evidence:clone(r.nativeEvidence),document:clone(doc),sourceManifestSHA256,phase:'ROOT_CONFIRMED',authorizationId:rootAuthorizationId})!==true)reject('EXPORT_PREACTIVATION_UNPROVEN');
            alive();if(state!=='ROOT_CONFIRMING')reject('EXPORT_SEQUENCE_REJECTED');
            rootIdentity={owner:p.owner,executorId:p.executorId};state='ROOT_VERIFIED';return clone(rootIdentity);
          }catch(e){if(state!=='CLOSED')state='FAILED';throw e;}
        },
        async authorizeDiscovery(scope) {
          if(state!=='ROOT_VERIFIED'||now()>=rootAuthorization.notAfter||!same(scope,approved))reject('EXPORT_SEQUENCE_REJECTED');
          state='DISCOVERY_PENDING';
          const r=await request('AUTHORIZE_DISCOVERY',{scope});
          if(r?.owner!==rootIdentity.owner||r?.contract!=='R4_GUEST_FAILURE_DISCOVERY_AUTHORIZATION_1'||typeof r.owner!=='string'||!r.owner.startsWith('GUEST:')||!uuid(r.owner.slice(6))||r.authorized!==true||!uuid(r.authorizationId)||!same(r.scope,scope)||!Number.isSafeInteger(r.notAfter)||r.notAfter<=now()||r.notAfter>now()+300000||!preservationOK(r.preservation,r.authorizationId,doc.openedAt,sourceManifestSHA256,now())||!r.nativeEvidence)reject('EXPORT_AUTHORIZATION_UNCONFIRMED');
          if(await verifyPreactivationEvidence({evidence:clone(r.nativeEvidence),document:clone(doc),sourceManifestSHA256,phase:'DISCOVERY',authorizationId:r.authorizationId,preservation:clone(r.preservation)})!==true)reject('EXPORT_PREACTIVATION_UNPROVEN');
          alive();if(state!=='DISCOVERY_PENDING')reject('EXPORT_SEQUENCE_REJECTED');authorization=clone(r);state='DISCOVERY';return clone({contract:r.contract,authorized:true,authorizationId:r.authorizationId,scope:r.scope,owner:r.owner,notAfter:r.notAfter,preservation:r.preservation});
        },
        async authorizeSelected({authorizationId,scope}) {
          if(!authorization||authorizationId!==authorization.authorizationId||!['DISCOVERY','SELECTED'].includes(state)||now()>=authorization.notAfter)reject('EXPORT_SELECTION_REJECTED');
          if(scope?.executorId!==authorization.owner.slice(6))reject('EXPORT_SELECTION_OWNER_REJECTED');
          if(selected && !same(selected,scope))reject('EXPORT_SELECTION_REUSED');
          const r=await request('AUTHORIZE_SELECTED',{authorizationId,scope});
          if(r?.contract!=='R4_GUEST_FAILURE_SELECTED_AUTHORIZATION_1'||r.authorized!==true||r.authorizationId!==authorizationId||!same(r.scope,scope))reject('EXPORT_SELECTION_UNCONFIRMED');
          selected=clone(scope);state='SELECTED';return clone(r);
        },
        async finalize({authorizationId,artifactSHA256}) {
          if(state!=='SELECTED'||authorizationId!==authorization?.authorizationId||!hex(artifactSHA256)||now()>=authorization.notAfter)reject('EXPORT_FINALIZE_REJECTED');
          // Mark spent before any asynchronous work, including failures.
          state='FINALIZING';
          try {const r=await request('FINALIZE',{authorizationId,artifactSHA256});
            if(r?.contract!=='R4_GUEST_FAILURE_EXPORT_RECEIPT_1'||r.authorized!==true||r.authorizationId!==authorizationId||r.artifactSHA256!==artifactSHA256||!r.nativeReceipt)reject('EXPORT_RECEIPT_UNCONFIRMED');
            if(await verifyPreactivationEvidence({evidence:clone(r.nativeReceipt),document:clone(doc),sourceManifestSHA256,phase:'FINALIZE',authorizationId})!==true)reject('EXPORT_RECEIPT_UNVERIFIED');
            state='FINALIZED';return clone({contract:r.contract,authorized:true,authorizationId,artifactSHA256});
          }catch(e){state='FAILED';throw e;}
        },
        async cancel({authorizationId}) {if(authorization && authorizationId!==authorization.authorizationId)reject('EXPORT_CANCEL_ID_MISMATCH');await close();return {closed:true};}
      });
    }
  });
  Object.defineProperty(target,'FocurveGuestFailureExportAuthority',{value:authority,writable:false,configurable:false,enumerable:false});
  return authority;
}
