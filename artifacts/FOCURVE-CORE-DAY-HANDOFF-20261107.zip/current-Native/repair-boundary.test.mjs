import test from 'node:test';import assert from 'node:assert/strict';
const prefix=process.env.REPAIR_BASELINE?'./repair-baseline/':'./';
const {installGuestFailureDocumentAuthority}=await import(prefix+'source/document-provider.mjs');
const {readRootIdentity}=await import(prefix+'source/root-identity-reader.mjs');
const id='12345678-1234-4123-8123-123456789abc',hash='a'.repeat(64);
function fixture({expire=false,extra=false}={}){let t=100;const target={};let reply;
 installGuestFailureDocumentAuthority({target,sourceManifestSHA256:hash,now:()=>t,trustedDocument:()=>({documentId:id,openedAt:90}),verifyPreactivationEvidence:async q=>{if(q.phase==='ROOT'&&expire)t=151;return true;},nativeChannel:{close:async()=>{},request:async q=>{
 if(q.action==='GET_APPROVED_SCOPE')return {scope:{installationId:'b'.repeat(32)},nativeEvidence:{}};
 reply={authorized:true,rootReadAuthorized:true,exportAuthorized:false,authorizationId:id,notAfter:150,scope:{installationId:'b'.repeat(32)},nativeEvidence:{access_token:'evidence-secret'},preservation:{contract:'R4_GUEST_EXPORT_PRESERVATION_1',authorizationId:id,boundaryId:id,mode:'STARTUP_FENCED_DIAGNOSTIC',sourceManifestSHA256:hash,fenceEstablishedAt:89,documentOpenedAt:90},...(extra?{access_token:'root-secret'}:{})};return reply;}}});return target.FocurveGuestFailureExportAuthority.createDocumentProvider({deadlineMs:200});}
async function root(p){const {scope}=await p.getApprovedScope();return p.authorizeRootIdentity(scope);}
function reader(options={}){const end=Date.now()+50;return readRootIdentity({authorization:{rootReadAuthorized:true,exportAuthorized:false,notAfter:end},deadlineMs:end,readMetadataIdentity:async()=>id,readAuth:async()=>null,isCurrent:()=>true,api:'api',origin:'origin',...options});}
async function boundedReject(p,pattern){let timer;try{await assert.rejects(Promise.race([p,new Promise((_,reject)=>{timer=setTimeout(()=>reject(Error('TEST_UPPER_NOT_TERMINATED')),300);})]),pattern);}finally{clearTimeout(timer);}}
test('R1 verifier await crossing notAfter is rejected',async()=>assert.rejects(root(fixture({expire:true})),/EXPIRED/));
test('R2 root reply strictly projects fields and hides evidence/secrets',async()=>{const r=await root(fixture({extra:true}));assert(!JSON.stringify(r).includes('secret'));assert.deepEqual(Object.keys(r).sort(),['authorized','rootReadAuthorized','exportAuthorized','authorizationId','scope','notAfter'].sort());});
test('R3 nonresponding metadata upper operation times out',async()=>boundedReject(reader({readMetadataIdentity:()=>new Promise(()=>{})}),/READ_TIMEOUT/));
test('R4 nonresponding auth upper operation times out',async()=>boundedReject(reader({readAuth:()=>new Promise(()=>{})}),/READ_TIMEOUT/));
test('R5 abort terminates upper call and late metadata cannot start auth',async()=>{let release,auth=0;const controller=new AbortController();const pending=reader({signal:controller.signal,readMetadataIdentity:()=>new Promise(r=>release=r),readAuth:async()=>{auth++;return null;}});await Promise.resolve();await Promise.resolve();controller.abort();await boundedReject(pending,/READ_ABORTED/);release?.(id);await new Promise(r=>setTimeout(r,0));assert.equal(auth,0);});
test('R6 preaborted signal starts no read',async()=>{let n=0;const c=new AbortController();c.abort();await assert.rejects(reader({signal:c.signal,readMetadataIdentity:async()=>{n++;return id;}}));assert.equal(n,0);});
test('R7 normal projection remains valid',async()=>{const r=await reader();assert.equal(r.owner,'GUEST:'+id);});
