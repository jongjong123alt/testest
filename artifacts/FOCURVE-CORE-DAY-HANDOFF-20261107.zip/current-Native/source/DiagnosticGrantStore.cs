// Admission-only durable grant consumption. Never authorizes IndexedDB/export,
// renews a product grant, clears HOLD, or infers the guest executor from install ID.
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Security.AccessControl;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;

public static class DiagnosticGrantStore {
 static void Need(bool ok,string code){NativeLinkHost.Need(ok,code);}
 static string Text(Dictionary<string,object> value,string key){Need(value!=null&&value.ContainsKey(key)&&value[key] is string,"DIAGNOSTIC_GRANT_SHAPE_REJECTED");return (string)value[key];}
 static DateTimeOffset Timestamp(string value){DateTimeOffset result;
  Need(DateTimeOffset.TryParseExact(value,new[]{"yyyy-MM-dd'T'HH:mm:ss.fff'Z'","yyyy-MM-dd'T'HH:mm:ss'Z'"},CultureInfo.InvariantCulture,DateTimeStyles.AssumeUniversal|DateTimeStyles.AdjustToUniversal,out result),"DIAGNOSTIC_GRANT_TIME_REJECTED");return result;}
 static void NoReparse(string path){for(string p=Path.GetFullPath(path);p!=null;p=Path.GetDirectoryName(p))Need((File.GetAttributes(p)&FileAttributes.ReparsePoint)==0,"DIAGNOSTIC_LEDGER_REPARSE_REJECTED");}
 public static string ManifestDigest(Dictionary<string,object> pins){
  Need(pins!=null&&pins.Count>0,"DIAGNOSTIC_PINS_MISSING");var keys=new List<string>(pins.Keys);keys.Sort(StringComparer.Ordinal);var text=new StringBuilder();
  foreach(var key in keys){Need(Regex.IsMatch(key,"^[A-Za-z0-9_./-]+$")&&!key.Contains("..")&&pins[key] is string&&Regex.IsMatch((string)pins[key],"^[a-f0-9]{64}$"),"DIAGNOSTIC_PINS_REJECTED");text.Append(key).Append(':').Append((string)pins[key]).Append('\n');}
  return NativeLinkHost.Hash(Encoding.UTF8.GetBytes(text.ToString()));
 }
 public static void Validate(Dictionary<string,object> grant,Dictionary<string,object> binding,Dictionary<string,object> peer,DateTimeOffset now){
  Need(grant!=null&&grant.Count==10,"DIAGNOSTIC_GRANT_SHAPE_REJECTED");
  Guid id;Need(Text(grant,"contract")=="FOCURVE_DIAGNOSTIC_ADMISSION_GRANT_1"&&Guid.TryParseExact(Text(grant,"authorizationId"),"D",out id)&&id!=Guid.Empty&&Regex.IsMatch(Text(grant,"nonce"),"^[a-f0-9]{64}$")&&Text(grant,"purpose")=="ADMISSION_ONLY_NO_DB_OR_EXPORT","DIAGNOSTIC_GRANT_SCOPE_REJECTED");
  Need(Text(grant,"installationId")==Text(binding,"installationId")&&Regex.IsMatch(Text(grant,"installationId"),"^[a-f0-9]{32}$")&&Text(grant,"extensionId")==Text(binding,"extensionId")&&Regex.IsMatch(Text(grant,"extensionId"),"^[a-p]{32}$")&&Text(grant,"profileDigest")==Text(peer,"profileDigest")&&Text(grant,"profileDigest")==Text(binding,"profileDigest")&&Text(grant,"sourceManifestSHA256")==ManifestDigest(binding["imagePins"] as Dictionary<string,object>),"DIAGNOSTIC_GRANT_BINDING_REJECTED");
  var start=Timestamp(Text(grant,"notBeforeUTC"));var end=Timestamp(Text(grant,"notAfterUTC"));
  Need(start<=now&&now<end&&end>start&&(end-start).TotalSeconds<=300,"DIAGNOSTIC_GRANT_EXPIRED");
 }
 static void VerifyDirectory(string root){
  NoReparse(root);Need(Directory.Exists(root),"DIAGNOSTIC_LEDGER_UNAVAILABLE");
  string sid=WindowsIdentity.GetCurrent().User.Value;var acl=Directory.GetAccessControl(root,AccessControlSections.Owner|AccessControlSections.Access);
  Need(acl.GetOwner(typeof(SecurityIdentifier)).Value==sid&&acl.AreAccessRulesProtected,"DIAGNOSTIC_LEDGER_ACL_REJECTED");
  bool ownerWrite=false;
  foreach(FileSystemAccessRule rule in acl.GetAccessRules(true,true,typeof(SecurityIdentifier))){
   if(rule.AccessControlType!=AccessControlType.Allow)continue;
   string identity=rule.IdentityReference.Value;
   Need(identity==sid||identity=="S-1-5-18","DIAGNOSTIC_LEDGER_ACL_REJECTED");
   if(identity==sid&&(rule.FileSystemRights&FileSystemRights.WriteData)!=0)ownerWrite=true;
  }
  Need(ownerWrite,"DIAGNOSTIC_LEDGER_ACL_REJECTED");
 }
 public static Dictionary<string,object> Consume(string root,Dictionary<string,object> grant,Dictionary<string,object> binding,Dictionary<string,object> peer,DateTimeOffset now){
  Validate(grant,binding,peer,now);root=Path.GetFullPath(root);VerifyDirectory(root);
  string installation=Path.GetFullPath(Text(binding,"installationPath")).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
  string profile=Path.GetFullPath(Text(binding,"profile")).TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
  string ledger=root.TrimEnd(Path.DirectorySeparatorChar)+Path.DirectorySeparatorChar;
  Need(!ledger.StartsWith(installation,StringComparison.OrdinalIgnoreCase)&&!ledger.StartsWith(profile,StringComparison.OrdinalIgnoreCase),"DIAGNOSTIC_LEDGER_LOCATION_REJECTED");
  // O_EXCL equivalent, shared across independent Native processes. Nonce is
  // global within this private ledger, not only within one host's memory.
  string target=Path.Combine(root,Text(grant,"nonce")+".spent");
  var receipt=new Dictionary<string,object>{{"contract","FOCURVE_DIAGNOSTIC_ADMISSION_CONSUMPTION_1"},{"authorizationId",grant["authorizationId"]},{"installationId",grant["installationId"]},{"extensionId",grant["extensionId"]},{"profileDigest",grant["profileDigest"]},{"sourceManifestSHA256",grant["sourceManifestSHA256"]},{"pid",peer["pid"]},{"createdMs",peer["createdMs"]},{"consumedAtUTC",now.ToUniversalTime().ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'")},{"exportAuthorized",false}};
  byte[] framed=NativeLinkHost.Frame(receipt);
  // FileStream.Flush(true) reaches the OS disk flush. Any incomplete file remains
  // spent after failure. Never delete, overwrite, or retry an uncertain consume.
  using(var file=new FileStream(target,FileMode.CreateNew,FileAccess.Write,FileShare.None,4096,FileOptions.WriteThrough)){
   file.Write(framed,0,framed.Length);file.Flush(true);
  }
  NoReparse(target);VerifyDirectory(root);
  Need(NativeLinkHost.Hash(File.ReadAllBytes(target))==NativeLinkHost.Hash(framed),"DIAGNOSTIC_CONSUMPTION_UNCONFIRMED");
  return new Dictionary<string,object>{{"contract","FOCURVE_DIAGNOSTIC_ADMISSION_CONSUMPTION_1"},{"authorizationId",grant["authorizationId"]},{"receiptSHA256",NativeLinkHost.Hash(framed)},{"persisted",true},{"exportAuthorized",false}};
 }
}
