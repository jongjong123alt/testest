// Separate diagnostic executable candidate. Not a branch of the service host.
// Build alongside the unchanged NativeLinkHost.cs, selecting this Main explicitly.
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Management;
using System.Security.Principal;
using System.Text;
using System.Text.RegularExpressions;

public static class NativeDiagnosticAdmission {
 static void Need(bool value,string code){NativeLinkHost.Need(value,code);}
 static string Text(Dictionary<string,object> value,string key){Need(value.ContainsKey(key)&&value[key] is string,"DIAGNOSTIC_BINDING_INCOMPLETE");return (string)value[key];}
 static void NoReparse(string path){for(var p=Path.GetFullPath(path);p!=null;p=Path.GetDirectoryName(p)){Need((File.GetAttributes(p)&FileAttributes.ReparsePoint)==0,"DIAGNOSTIC_REPARSE_REJECTED");}}
 public static void VerifyImage(string root,Dictionary<string,object> pins){
  root=Path.GetFullPath(root);NoReparse(root);Need(pins!=null&&pins.Count>0,"DIAGNOSTIC_PINS_MISSING");
  // Recursion checks every directory before descent; do not follow a junction.
  var seen=new HashSet<string>(StringComparer.OrdinalIgnoreCase);
  var pending=new Stack<string>();pending.Push(root);
  while(pending.Count>0){var dir=pending.Pop();NoReparse(dir);foreach(var sub in Directory.GetDirectories(dir)){NoReparse(sub);pending.Push(sub);}foreach(var file in Directory.GetFiles(dir)){
   NoReparse(file);string name=file.Substring(root.Length+1).Replace('\\','/');seen.Add(name);
   Need(pins.ContainsKey(name)&&pins[name] is string&&Regex.IsMatch((string)pins[name],"^[a-f0-9]{64}$")&&NativeLinkHost.Hash(File.ReadAllBytes(file))==(string)pins[name],"DIAGNOSTIC_IMAGE_CHANGED");
  }}
  Need(seen.Count==pins.Count,"DIAGNOSTIC_IMAGE_CHANGED");
  var manifest=NativeLinkHost.Object(File.ReadAllBytes(Path.Combine(root,"manifest.json")));
  foreach(string key in new[]{"background","content_scripts","externally_connectable","sandbox","devtools_page"})Need(!manifest.ContainsKey(key),"DIAGNOSTIC_WRITER_ENTRY_PRESENT");
  Need(!Directory.Exists(Path.Combine(root,"background"))&&!Directory.Exists(Path.Combine(root,"a1"))&&!Directory.Exists(Path.Combine(root,"member-a1")),"DIAGNOSTIC_WRITER_SOURCE_PRESENT");
 }
 // New PID is read from this Native process's actual OS ancestry. An old service
 // grant/PID is never copied, accepted or renewed by this executable.
 public static Dictionary<string,object> AttestPeer(string origin,Dictionary<string,object> binding){
  string sid=WindowsIdentity.GetCurrent().User.Value;
  Need(origin=="chrome-extension://"+Text(binding,"extensionId")+"/"&&sid==Text(binding,"userSid"),"DIAGNOSTIC_PEER_REJECTED");
  int pid=Process.GetCurrentProcess().Id;
  for(int depth=0;depth<16&&pid>0;depth++){
   int parent=0;bool found=false;
   using(var search=new ManagementObjectSearcher("SELECT ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine FROM Win32_Process WHERE ProcessId="+pid))
   using(var rows=search.Get())foreach(ManagementObject row in rows){
    found=true;parent=Convert.ToInt32(row["ParentProcessId"]);
    string exe=row["ExecutablePath"] as string;
    if(exe!=null&&String.Equals(Path.GetFullPath(exe),Path.GetFullPath(Text(binding,"chromeExecutable")),StringComparison.OrdinalIgnoreCase)){
     NoReparse(exe);Need(NativeLinkHost.Hash(File.ReadAllBytes(exe))==Text(binding,"chromeExecutableSHA256"),"DIAGNOSTIC_CHROME_CHANGED");
     var created=ManagementDateTimeConverter.ToDateTime((string)row["CreationDate"]).ToUniversalTime();
     long ms=(long)(created-new DateTime(1970,1,1,0,0,0,DateTimeKind.Utc)).TotalMilliseconds;
     var check=new Dictionary<string,object>(binding);check["chromePID"]=pid;check["chromeCreatedMs"]=ms;
     Need(NativeLinkHost.PeerMatches(origin,sid,pid,ms,exe,row["CommandLine"] as string??"",check),"DIAGNOSTIC_PROFILE_REJECTED");
     NoReparse(Text(binding,"profile"));
     string profile=Path.GetFullPath(Text(binding,"profile")).TrimEnd(Path.DirectorySeparatorChar).ToLowerInvariant();
     Need(NativeLinkHost.Hash(Encoding.UTF8.GetBytes(profile))==Text(binding,"profileDigest"),"DIAGNOSTIC_PROFILE_DIGEST_REJECTED");
     return new Dictionary<string,object>{{"pid",pid},{"createdMs",ms},{"profileDigest",Text(binding,"profileDigest")}};
    }
   }
   Need(found&&parent!=pid,"DIAGNOSTIC_PEER_REJECTED");pid=parent;
  }
  throw new InvalidOperationException("DIAGNOSTIC_PEER_REJECTED");
 }
 public static int Main(string[] args){
  try{
   Need(args.Length>=1&&args.Length<=2,"DIAGNOSTIC_ARGUMENT_REJECTED");
   Need(args.Length==1||Regex.IsMatch(args[1],"^--parent-window=[0-9]+$"),"DIAGNOSTIC_ARGUMENT_REJECTED");
   string directory=Path.GetDirectoryName(typeof(NativeDiagnosticAdmission).Assembly.Location);
   byte[] raw=File.ReadAllBytes(Path.Combine(directory,"diagnostic-binding.json"));
   Need(NativeLinkHost.Hash(raw)==NativeDiagnosticBuild.BindingSHA256,"DIAGNOSTIC_BINDING_CHANGED");
   var b=NativeLinkHost.Object(raw);
   Need(Text(b,"contract")=="FOCURVE_DIAGNOSTIC_ADMISSION_1","DIAGNOSTIC_BINDING_REJECTED");
   var now=DateTimeOffset.UtcNow;var start=DateTimeOffset.Parse(Text(b,"notBeforeUTC"));var end=DateTimeOffset.Parse(Text(b,"notAfterUTC"));
   Need(start<=now&&now<end&&(end-start).TotalSeconds<=300,"DIAGNOSTIC_EXPIRED");
   var peer=AttestPeer(args[0],b);
   VerifyImage(Text(b,"diagnosticImage"),b["imagePins"] as Dictionary<string,object>);
   var read=System.Threading.Tasks.Task.Factory.StartNew(()=>NativeLinkHost.ReadFrame(Console.OpenStandardInput()));
   Need(read.Wait(TimeSpan.FromSeconds(5)),"DIAGNOSTIC_REQUEST_TIMEOUT");
   var q=NativeLinkHost.Object(read.Result);
   Need(Text(q,"contract")=="FOCURVE_GUEST_DIAGNOSTIC_TRANSPORT_1"&&Text(q,"action")=="ATTEST","DIAGNOSTIC_EXPORT_AUTHORITY_NOT_CONNECTED");
   Need(q.Count==4&&q.ContainsKey("deadlineMs")&&Regex.IsMatch(Text(q,"requestId"),"^[1-9][0-9]{0,7}$"),"DIAGNOSTIC_REQUEST_REJECTED");
   double deadline=Convert.ToDouble(q["deadlineMs"]);double at=(DateTimeOffset.UtcNow-new DateTimeOffset(1970,1,1,0,0,0,TimeSpan.Zero)).TotalMilliseconds;
   Need(!Double.IsNaN(deadline)&&!Double.IsInfinity(deadline)&&deadline==Math.Floor(deadline)&&at<deadline&&deadline<=at+15000,"DIAGNOSTIC_REQUEST_EXPIRED");
   Need(DateTimeOffset.UtcNow<end,"DIAGNOSTIC_EXPIRED");
   // Only the compile-pinned, purpose-restricted grant can reach the private
   // ledger. No grant supplied by the document is accepted. Peer/image/time
   // admission above must succeed first. Uncertain consumption stays burned.
   Need(b.ContainsKey("admissionGrant"),"DIAGNOSTIC_GRANT_REQUIRED");
   var consumption=DiagnosticGrantStore.Consume(Text(b,"grantLedger"),b["admissionGrant"] as Dictionary<string,object>,b,peer,DateTimeOffset.UtcNow);
   Need(DateTimeOffset.UtcNow<end,"DIAGNOSTIC_EXPIRED");
   DiagnosticGrantStore.Validate(b["admissionGrant"] as Dictionary<string,object>,b,peer,DateTimeOffset.UtcNow);
   at=(DateTimeOffset.UtcNow-new DateTimeOffset(1970,1,1,0,0,0,TimeSpan.Zero)).TotalMilliseconds;
   Need(at<deadline,"DIAGNOSTIC_REQUEST_EXPIRED");
   // This is admission evidence only. It cannot authorize IndexedDB or export.
   var result=new Dictionary<string,object>{{"contract","FOCURVE_DIAGNOSTIC_ADMISSION_EVIDENCE_1"},{"peer",peer},{"consumption",consumption},{"workerEntrypoint",null},{"rootReadAuthorized",false},{"exportAuthorized",false},{"holdUnchanged",true}};
   var reply=new Dictionary<string,object>{{"requestId",Text(q,"requestId")},{"ok",true},{"result",result}};
   byte[] frame=NativeLinkHost.Frame(reply);var output=Console.OpenStandardOutput();output.Write(frame,0,frame.Length);output.Flush();return 0;
  }catch(Exception e){Console.Error.WriteLine(e is InvalidOperationException?e.Message:"DIAGNOSTIC_ADMISSION_UNCONFIRMED");return 1;}
 }
}
