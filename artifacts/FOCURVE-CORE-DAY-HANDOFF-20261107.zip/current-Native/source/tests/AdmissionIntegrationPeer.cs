// Synthetic parent executable with --user-data-dir. Never Chrome or a registered host.
using System;using System.IO;using System.Diagnostics;using System.Collections.Generic;using System.Security.AccessControl;using System.Security.Principal;
public static class AdmissionIntegrationPeer {
 static Dictionary<string,object> Call(string host,bool expectSuccess){
  var psi=new ProcessStartInfo(host,"chrome-extension://"+new string('a',32)+"/"){UseShellExecute=false,CreateNoWindow=true,RedirectStandardInput=true,RedirectStandardOutput=true,RedirectStandardError=true};
  using(var child=Process.Start(psi)){
   double epoch=(DateTimeOffset.UtcNow-new DateTimeOffset(1970,1,1,0,0,0,TimeSpan.Zero)).TotalMilliseconds;
   var q=new Dictionary<string,object>{{"contract","FOCURVE_GUEST_DIAGNOSTIC_TRANSPORT_1"},{"requestId","1"},{"action","ATTEST"},{"deadlineMs",Math.Floor(epoch)+10000}};
   byte[] frame=NativeLinkHost.Frame(q);child.StandardInput.BaseStream.Write(frame,0,frame.Length);child.StandardInput.Close();
   byte[] output;using(var stream=new MemoryStream()){child.StandardOutput.BaseStream.CopyTo(stream);output=stream.ToArray();}
   string error=child.StandardError.ReadToEnd();child.WaitForExit();
   if(!expectSuccess){if(child.ExitCode==0||output.Length!=0)throw new Exception("REPLAY_WAS_NOT_REJECTED");return null;}
   if(child.ExitCode!=0)throw new Exception("SYNTHETIC_ADMISSION_FAILED_"+error.Trim());
   return NativeLinkHost.Object(NativeLinkHost.ReadFrame(new MemoryStream(output)));
  }
 }
 static int Run(string[] args){
  if(args[0]=="--provision"){
   var sid=WindowsIdentity.GetCurrent().User;var acl=new DirectorySecurity();acl.SetAccessRuleProtection(true,false);acl.SetOwner(sid);acl.AddAccessRule(new FileSystemAccessRule(sid,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));Directory.SetAccessControl(args[1],acl);Console.WriteLine(sid.Value);return 0;
  }
  var reply=Call(args[1],true);var result=(Dictionary<string,object>)reply["result"];var receipt=(Dictionary<string,object>)result["consumption"];
  if((bool)result["exportAuthorized"]||(bool)result["rootReadAuthorized"]||!(bool)receipt["persisted"])throw new Exception("CAPABILITY_ESCALATION");
  string[] files=Directory.GetFiles(args[2],"*.spent");if(files.Length!=1)throw new Exception("CONSUMPTION_COUNT");string hash=NativeLinkHost.Hash(File.ReadAllBytes(files[0]));
  Call(args[1],false);if(hash!=NativeLinkHost.Hash(File.ReadAllBytes(files[0])))throw new Exception("REPLAY_OVERWROTE_RECEIPT");
  Console.WriteLine("PASS full admission Main -> real OS synthetic parent -> pinned image -> private durable consume -> framed reply; second host process replay denied; DB/export false");return 0;
 }
 public static int Main(string[] args){try{return Run(args);}catch(Exception e){Console.Error.WriteLine(e.GetType().Name+":"+e.Message);return 2;}}
}
