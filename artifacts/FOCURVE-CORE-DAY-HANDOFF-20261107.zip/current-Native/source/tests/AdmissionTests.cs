using System;using System.IO;using System.Collections.Generic;using System.Security.Principal;using System.Diagnostics;using System.Text;
public static class AdmissionTests {
 static int count;static void OK(bool x){if(!x)throw new Exception("ASSERTION_FAILED");count++;}
 static void Deny(Action a,string code){try{a();}catch(InvalidOperationException e){OK(e.Message==code);return;}throw new Exception("EXPECTED_DENIAL");}
 public static int Main(string[] args){string root=Path.Combine(Path.GetTempPath(),"focurve-admission-fixture-"+Guid.NewGuid());Directory.CreateDirectory(root);try{
  string manifest=Path.Combine(root,"manifest.json");File.WriteAllText(manifest,"{\"manifest_version\":3,\"name\":\"fixture\"}");
  var pins=new Dictionary<string,object>{{"manifest.json",NativeLinkHost.Hash(File.ReadAllBytes(manifest))}};
  NativeDiagnosticAdmission.VerifyImage(root,pins);OK(true);
  File.WriteAllText(Path.Combine(root,"extra.pyc"),"extra");Deny(()=>NativeDiagnosticAdmission.VerifyImage(root,pins),"DIAGNOSTIC_IMAGE_CHANGED");File.Delete(Path.Combine(root,"extra.pyc"));
  File.WriteAllText(manifest,"{\"background\":{\"service_worker\":\"writer.js\"}}");pins["manifest.json"]=NativeLinkHost.Hash(File.ReadAllBytes(manifest));Deny(()=>NativeDiagnosticAdmission.VerifyImage(root,pins),"DIAGNOSTIC_WRITER_ENTRY_PRESENT");
  File.WriteAllText(manifest,"{}");pins["manifest.json"]=NativeLinkHost.Hash(File.ReadAllBytes(manifest));Directory.CreateDirectory(Path.Combine(root,"background"));Deny(()=>NativeDiagnosticAdmission.VerifyImage(root,pins),"DIAGNOSTIC_WRITER_SOURCE_PRESENT");Directory.Delete(Path.Combine(root,"background"));
  var b=new Dictionary<string,object>{{"extensionId",new string('a',32)},{"userSid",WindowsIdentity.GetCurrent().User.Value},{"chromeExecutable",Path.Combine(root,"never-chrome.exe")}};
  Deny(()=>NativeDiagnosticAdmission.AttestPeer("chrome-extension://"+new string('b',32)+"/",b),"DIAGNOSTIC_PEER_REJECTED");
  // Real OS ancestry query for this test process. No Chrome/Native installation.
  Deny(()=>NativeDiagnosticAdmission.AttestPeer("chrome-extension://"+new string('a',32)+"/",b),"DIAGNOSTIC_PEER_REJECTED");
  // Synthetic executable, genuine OS PID/creation/path/command line. This is
  // not Chrome success and never reads or starts a product installation.
  string profile=Path.GetFullPath(args[0].Substring("--user-data-dir=".Length));
  b["profile"]=profile;b["profileDigest"]=NativeLinkHost.Hash(Encoding.UTF8.GetBytes(profile.TrimEnd(Path.DirectorySeparatorChar).ToLowerInvariant()));
  string exe=Process.GetCurrentProcess().MainModule.FileName;b["chromeExecutable"]=exe;b["chromeExecutableSHA256"]=NativeLinkHost.Hash(File.ReadAllBytes(exe));
  var peer=NativeDiagnosticAdmission.AttestPeer("chrome-extension://"+new string('a',32)+"/",b);OK(Convert.ToInt32(peer["pid"])==Process.GetCurrentProcess().Id);OK(Convert.ToInt64(peer["createdMs"])>0);
  b["profileDigest"]=new string('0',64);Deny(()=>NativeDiagnosticAdmission.AttestPeer("chrome-extension://"+new string('a',32)+"/",b),"DIAGNOSTIC_PROFILE_DIGEST_REJECTED");
  b["chromeExecutableSHA256"]=new string('0',64);Deny(()=>NativeDiagnosticAdmission.AttestPeer("chrome-extension://"+new string('a',32)+"/",b),"DIAGNOSTIC_CHROME_CHANGED");
  Console.WriteLine("PASS "+count+" admission checks; actual OS synthetic peer; Chrome positive NOT_RUN");return 0;
 }finally{Directory.Delete(root,true);}}
}
