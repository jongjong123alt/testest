using System;using System.IO;using System.Collections.Generic;using System.Security.AccessControl;using System.Security.Principal;using System.Diagnostics;
public static class GrantTests {
 static int count;static void Check(bool ok){if(!ok)throw new Exception("ASSERTION_FAILED_"+count);count++;}
 static string Stamp(DateTimeOffset t){return t.ToString("yyyy-MM-dd'T'HH:mm:ss.fff'Z'");}
 static Dictionary<string,object> Binding(string root){return new Dictionary<string,object>{{"installationId",new string('b',32)},{"extensionId",new string('a',32)},{"profileDigest",new string('c',64)},{"installationPath",Path.Combine(root,"installation")},{"profile",Path.Combine(root,"profile")},{"imagePins",new Dictionary<string,object>{{"manifest.json",new string('d',64)}}}};}
 static Dictionary<string,object> Peer(){return new Dictionary<string,object>{{"pid",1234},{"createdMs",987654L},{"profileDigest",new string('c',64)}};}
 static Dictionary<string,object> Grant(Dictionary<string,object> b,string nonce,DateTimeOffset now){return new Dictionary<string,object>{{"contract","FOCURVE_DIAGNOSTIC_ADMISSION_GRANT_1"},{"authorizationId","abcdefab-1234-4123-8123-abcdefabcdef"},{"nonce",nonce},{"installationId",b["installationId"]},{"extensionId",b["extensionId"]},{"profileDigest",b["profileDigest"]},{"sourceManifestSHA256",DiagnosticGrantStore.ManifestDigest(b["imagePins"] as Dictionary<string,object>)},{"purpose","ADMISSION_ONLY_NO_DB_OR_EXPORT"},{"notBeforeUTC",Stamp(now.AddSeconds(-10))},{"notAfterUTC",Stamp(now.AddSeconds(200))}};}
 static void Secure(string path){Directory.CreateDirectory(path);var sid=WindowsIdentity.GetCurrent().User;var acl=new DirectorySecurity();acl.SetAccessRuleProtection(true,false);acl.SetOwner(sid);acl.AddAccessRule(new FileSystemAccessRule(sid,FileSystemRights.FullControl,InheritanceFlags.ContainerInherit|InheritanceFlags.ObjectInherit,PropagationFlags.None,AccessControlType.Allow));Directory.SetAccessControl(path,acl);}
 static void Reject(Action action,string code){try{action();}catch(InvalidOperationException e){Check(e.Message==code);return;}throw new Exception("EXPECTED_REJECTION");}
 static Process Child(string root,string ledger,string nonce){var psi=new ProcessStartInfo(Process.GetCurrentProcess().MainModule.FileName,"--consume \""+root+"\" \""+ledger+"\" "+nonce){UseShellExecute=false,CreateNoWindow=true,RedirectStandardOutput=true,RedirectStandardError=true};return Process.Start(psi);}
 public static int Main(string[] args){
  if(args.Length==4&&args[0]=="--consume"){try{var b=Binding(args[1]);DiagnosticGrantStore.Consume(args[2],Grant(b,args[3],DateTimeOffset.UtcNow),b,Peer(),DateTimeOffset.UtcNow);return 0;}catch(IOException){return 12;}catch{return 13;}}
  string root=Path.Combine(Path.GetTempPath(),"focurve-grant-test-"+Guid.NewGuid());Directory.CreateDirectory(root);string ledger=Path.Combine(root,"private-grants");Secure(ledger);
  try{
   var now=DateTimeOffset.UtcNow;var b=Binding(root);var peer=Peer();var g=Grant(b,new string('1',64),now);
   var receipt=DiagnosticGrantStore.Consume(ledger,g,b,peer,now);Check((bool)receipt["persisted"]&&!(bool)receipt["exportAuthorized"]);
   string spent=Path.Combine(ledger,new string('1',64)+".spent");string hash=NativeLinkHost.Hash(File.ReadAllBytes(spent));
   using(var child=Child(root,ledger,new string('1',64))){child.WaitForExit();Check(child.ExitCode==12);}Check(hash==NativeLinkHost.Hash(File.ReadAllBytes(spent)));
   using(var a=Child(root,ledger,new string('2',64)))using(var c=Child(root,ledger,new string('2',64))){a.WaitForExit();c.WaitForExit();Check(a.ExitCode+c.ExitCode==12&&(a.ExitCode==0||c.ExitCode==0));}
   string partial=Path.Combine(ledger,new string('3',64)+".spent");File.WriteAllBytes(partial,new byte[0]);using(var child=Child(root,ledger,new string('3',64))){child.WaitForExit();Check(child.ExitCode==12);}Check(new FileInfo(partial).Length==0);
   int prior=Directory.GetFiles(ledger).Length;
   var expired=Grant(b,new string('4',64),now);expired["notAfterUTC"]=Stamp(now);Reject(()=>DiagnosticGrantStore.Consume(ledger,expired,b,peer,now),"DIAGNOSTIC_GRANT_EXPIRED");
   var future=Grant(b,new string('4',64),now);future["notBeforeUTC"]=Stamp(now.AddSeconds(1));Reject(()=>DiagnosticGrantStore.Consume(ledger,future,b,peer,now),"DIAGNOSTIC_GRANT_EXPIRED");
   var bad=Grant(b,new string('4',64),now);bad["installationId"]=new string('a',32);Reject(()=>DiagnosticGrantStore.Consume(ledger,bad,b,peer,now),"DIAGNOSTIC_GRANT_BINDING_REJECTED");
   bad=Grant(b,new string('4',64),now);bad["purpose"]="EXPORT";Reject(()=>DiagnosticGrantStore.Consume(ledger,bad,b,peer,now),"DIAGNOSTIC_GRANT_SCOPE_REJECTED");
   bad=Grant(b,new string('4',64),now);bad["sourceManifestSHA256"]=new string('0',64);Reject(()=>DiagnosticGrantStore.Consume(ledger,bad,b,peer,now),"DIAGNOSTIC_GRANT_BINDING_REJECTED");
   bad=Grant(b,new string('4',64),now);bad["notAfterUTC"]="tomorrow";Reject(()=>DiagnosticGrantStore.Consume(ledger,bad,b,peer,now),"DIAGNOSTIC_GRANT_TIME_REJECTED");
   string insecure=Path.Combine(root,"insecure");Directory.CreateDirectory(insecure);Reject(()=>DiagnosticGrantStore.Consume(insecure,Grant(b,new string('4',64),now),b,peer,now),"DIAGNOSTIC_LEDGER_ACL_REJECTED");
   Secure((string)b["installationPath"]);Reject(()=>DiagnosticGrantStore.Consume((string)b["installationPath"],Grant(b,new string('4',64),now),b,peer,now),"DIAGNOSTIC_LEDGER_LOCATION_REJECTED");
   Check(Directory.GetFiles(ledger).Length==prior);Console.WriteLine("PASS "+count+" durable grant checks; temporary Windows ledger and independent child processes only");return 0;
  }finally{Directory.Delete(root,true);}
 }
}
