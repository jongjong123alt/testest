public static class NativeLinkBuild {public const string BindingSHA256="TEST_BUILD_NO_PRODUCTION_BINDING";}
public static class NativeDiagnosticBuild {public const string BindingSHA256="TEST_BUILD_NO_PRODUCTION_BINDING";}
