import test from 'node:test';import assert from 'node:assert/strict';
const {installGuestFailureDocumentAuthority}=await import(process.env.PROVIDER_SOURCE??'../document-provider.mjs');
const id='12345678-1234-4123-8123-123456789abc',executor='abcdefab-1234-4123-8123-abcdefabcdef',other='abcdefab-1234-4123-8123-000000000000',hash='a'.repeat(64),now=100000;
const scope={installationId:'b'.repeat(32),extensionId:'a'.repeat(32),profileInstance:'c'.repeat(32),origin:'https://localhost:30917',fromMs:1,toMs:90000};
function fixture(owner){let selectedCalls=0;const target={};installGuestFailureDocumentAuthority({target,sourceManifestSHA256:hash,now:()=>now,trustedDocument:()=>({documentId:id,openedAt:now-1}),verifyPreactivationEvidence:async()=>true,nativeChannel:{close:async()=>{},request:async q=>{
 if(q.action==='GET_APPROVED_SCOPE')return {scope,nativeEvidence:{fixture:true}};
 if(q.action==='AUTHORIZE_DISCOVERY')return {contract:'R4_GUEST_FAILURE_DISCOVERY_AUTHORIZATION_1',authorized:true,authorizationId:id,owner,scope,notAfter:now+10000,nativeEvidence:{fixture:true},preservation:{contract:'R4_GUEST_EXPORT_PRESERVATION_1',authorizationId:id,boundaryId:id,mode:'STARTUP_FENCED_DIAGNOSTIC',sourceManifestSHA256:hash,fenceEstablishedAt:now-2,documentOpenedAt:now-1}};
 if(q.action==='AUTHORIZE_SELECTED'){selectedCalls++;return {contract:'R4_GUEST_FAILURE_SELECTED_AUTHORIZATION_1',authorized:true,authorizationId:id,scope:q.payload.scope};}
 throw Error('UNEXPECTED_FIXTURE_ACTION');}}});return {provider:target.FocurveGuestFailureExportAuthority.createDocumentProvider({deadlineMs:now+15000}),get selectedCalls(){return selectedCalls}};}
async function discovery(f){await f.provider.getApprovedScope();return f.provider.authorizeDiscovery(scope);}
test('verified Native owner reaches reader without installation UUID substitution',async()=>{const f=fixture('GUEST:'+executor),r=await discovery(f);assert.equal(r.owner,'GUEST:'+executor);assert.notEqual(r.owner,'GUEST:'+scope.installationId);await f.provider.authorizeSelected({authorizationId:id,scope:{executorId:executor}});assert.equal(f.selectedCalls,1);});
test('missing owner is denied before reader DB access',async()=>{await assert.rejects(discovery(fixture(undefined)),/AUTHORIZATION_UNCONFIRMED/);});
test('member or malformed owner is not a guest approval',async()=>{for(const owner of ['MEMBER:1','GUEST:'+scope.installationId])await assert.rejects(discovery(fixture(owner)),/AUTHORIZATION_UNCONFIRMED/);});
test('another executor cannot be selected using the approved owner',async()=>{const f=fixture('GUEST:'+executor);await discovery(f);await assert.rejects(f.provider.authorizeSelected({authorizationId:id,scope:{executorId:other}}),/SELECTION_OWNER_REJECTED/);assert.equal(f.selectedCalls,0);});
