"""Compile and run only temporary, unregistered synthetic executables. No Chrome."""
import datetime,hashlib,json,subprocess,tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
CSC=Path(r'C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def compile_exe(output,main,files):
 subprocess.run([str(CSC),'/nologo','/r:System.Management.dll','/r:System.Web.Extensions.dll','/main:'+main,'/out:'+str(output),*[str(f) for f in files]],check=True)
with tempfile.TemporaryDirectory(prefix='focurve-admission-integration-') as tmp:
 root=Path(tmp);profile=root/'profile';profile.mkdir();image=root/'image';image.mkdir();ledger=root/'private-grants';ledger.mkdir()
 dependency=[ROOT/'NativeLinkHost.baseline.cs']
 parent=root/'SyntheticPeer.exe'
 compile_exe(parent,'AdmissionIntegrationPeer',dependency+[ROOT/'tests/TestBuild.cs',ROOT/'tests/AdmissionIntegrationPeer.cs'])
 # Test-only ACL setup in the existing synthetic executable; no shell module.
 sid=subprocess.check_output([str(parent),'--provision',str(ledger)],text=True).strip()
 (image/'manifest.json').write_text('{"manifest_version":3,"name":"synthetic-only"}',encoding='utf-8')
 pins={'manifest.json':sha(image/'manifest.json')}
 source=hashlib.sha256(('manifest.json:'+pins['manifest.json']+'\n').encode()).hexdigest()
 digest=hashlib.sha256(str(profile.resolve()).rstrip('\\').lower().encode('utf-8')).hexdigest()
 now=datetime.datetime.now(datetime.timezone.utc)
 stamp=lambda x:x.isoformat(timespec='milliseconds').replace('+00:00','Z')
 start=stamp(now-datetime.timedelta(seconds=1));end=stamp(now+datetime.timedelta(seconds=200))
 grant={'contract':'FOCURVE_DIAGNOSTIC_ADMISSION_GRANT_1','authorizationId':'abcdefab-1234-4123-8123-abcdefabcdef','nonce':'1'*64,'installationId':'b'*32,'extensionId':'a'*32,'profileDigest':digest,'sourceManifestSHA256':source,'purpose':'ADMISSION_ONLY_NO_DB_OR_EXPORT','notBeforeUTC':start,'notAfterUTC':end}
 binding={'contract':'FOCURVE_DIAGNOSTIC_ADMISSION_1','notBeforeUTC':start,'notAfterUTC':end,'installationId':'b'*32,'extensionId':'a'*32,'userSid':sid,'chromeExecutable':str(parent),'chromeExecutableSHA256':sha(parent),'profile':str(profile),'profileDigest':digest,'installationPath':str(root/'untouched-installation'),'diagnosticImage':str(image),'imagePins':pins,'grantLedger':str(ledger),'admissionGrant':grant}
 bfile=root/'diagnostic-binding.json';bfile.write_text(json.dumps(binding),encoding='utf-8')
 build=root/'Build.cs';build.write_text('public static class NativeLinkBuild {public const string BindingSHA256="NOT_A_SERVICE_BUILD";}\npublic static class NativeDiagnosticBuild {public const string BindingSHA256="'+sha(bfile)+'";}\n',encoding='utf-8')
 host=root/'SyntheticDiagnostic.exe'
 compile_exe(host,'NativeDiagnosticAdmission',dependency+[ROOT/'NativeDiagnosticAdmission.cs',ROOT/'DiagnosticGrantStore.cs',build])
 subprocess.run([str(parent),'--user-data-dir='+str(profile),str(host),str(ledger)],check=True)
