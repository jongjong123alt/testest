# IG04 Core 내부 provider 저장부 — 로컬 검토 단위

2026-11-03 / 윤종민 / 시작 ed8755a597973922d02bd675e80b00c410dfdaf4 (#88). 격리 worktree /workspace/focurve-ig04-provider-local, detached HEAD. Commit/Push/PR 없음. 기존 작업 보존.

기준: 기존 AMVP-CORE-04·#88 admission, IG04 P2-CURRENTNESS manifest 87b07a2d746b8ccccd2d4e95a0265c1f5e37c0091b0410d172ae4f2b09b3d84a, provider 인계 자료. 공개 Schema/Wire/API는 추가하지 않음. P2 seam을 제품 API로 확정하지 않음.

## 구현

extension/src/ig04-provider-store.js: IG04ProviderStore. 기존 A1Store.atomic과 실행 DB metadata 재사용. A1Store 자체/DB version/Registry/admission 변경 없음.

- initialize/transition: 현재 A1 owner-fence 결속, 고정 lifetime UUID와 증가-only revision. 한 수명에서 A->B->A도 revision 증가, revoke 후 같은 id 재활성화 금지. 전이 기록 보관 및 DB 저장 소실/복구 검증은 실제 공급 연결 조건.
- register/finalizeIdentity/lookup: caller 입력을 await 전에 복사, 원본 불변 등록·동일 원문 재등록·충돌 거절. null identity 확정은 버전 CAS, 조회 결과에 기대 권한 수명 결속. 원본의 실제 Content 출처·여섯 필드 검증은 신뢰 guard 연결 전까지 미제공. 임의 입력을 검증된 원본으로 사용하지 않음.
- close/queryClosure: 현재 authority/fence와 원본 버전 재검사, closure 내부 기록과 대상 원본 closedBy를 같은 transaction에 저장. 동일 요청/원문 결과 재사용, 다른 원문 및 다른 요청의 동일 대상 재소비 거절. query는 현재 권한을 다시 확인. 기존 DB oncomplete 이후 반환. 내부 저장 결과이며 공개 ACK/CleanupGrant/terminal proof 아님.
- 모든 호출 guard 기본 거절, strict true 요구, Promise 거절. guard는 동일 tx의 읽은 rows를 전달받는 신뢰 내부 함수. 실제 native I/O를 tx 안에서 await할 수 없음. 테스트 true guard는 합성 대역이고 운영 인증이 아님.

## HOLD 범위

- 운영 M1 source·credential, 실제 인증된 synchronous guard와 native 후검사.
- owner/document/instance/Worker/channel/takeover 전이 전체와 transition/revoke hook 연결. 자동 등록·listener·START 없음. 기존 A1 UUID와 RC2 epoch를 변환하지 않음.
- 새 Worker/권한 갱신 시 기존 의무의 cleanup-only 인수와 새 수명 연결. 현재는 owner fence 변경 후 기존 row 접근 거절; 자동 이전하지 않음.
- Content 원본 record provenance 등록, 완료/ACK 소비 callback와 최종 현재성 확인.
- plan0/watch 공통 자원 closure와 scope별 전체 RELEASE. close는 비어 있지 않은 local record 집합만 다루며 watch 종료/예약 terminal을 인증하지 않음.
- 기록/예산 상한·압축·저장 손상/rollback 정책 및 실제 전이 coverage 검증. runtime에 연결하지 않은 로컬 모듈이며 제품 활성화 전에 완료해야 함.

## 검증

node --test extension/tests/ig04-provider-store.test.mjs extension/tests/additional-ig04-admission.test.mjs extension/tests/additional-ig04-lifetime.test.mjs

56/56 PASS (신규 9 + 기존 47), 실패/skip 0. fake-indexeddb + 실제 createMemberDB/A1Store를 사용하는 합성 저장 시험. ABA 증가 revision, 권한 변경, identity 확정 CAS, abort 동시 rollback, 재생성된 provider 객체의 재조회, 중복 소비 및 기본 거절 검증. OS Worker 재시작·실제 IndexedDB 영속 장애·M1·제품 ABA 전체 안전성은 미검증. node syntax와 git diff whitespace 통과. 기존 P2 fixture 변경/재실행 없음.

신규 파일은 Core 내부 수명·의무 저장 경계를 추가하므로 다훈의 Core/통합 검토와 지민의 Content 원본/복원 경계 검토가 필요. Git 제출은 별도 조율한다. M1 BLOCKED/실제 제품 연결 HOLD/MVP_FINAL_COMPLETE=false 유지.
