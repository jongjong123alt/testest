"""Source-only reproduction. Does not execute product code, tests or Git."""
import argparse,hashlib,json,zipfile
from pathlib import Path,PurePosixPath
p=argparse.ArgumentParser();p.add_argument('--target',required=True);args=p.parse_args()
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text())
for name,digest in manifest.items():
 relative=PurePosixPath(name)
 if relative.is_absolute() or '..' in relative.parts:raise SystemExit('Unsafe manifest path')
 if hashlib.sha256((root/name).read_bytes()).hexdigest()!=digest:raise SystemExit('Hash mismatch: '+name)
target=Path(args.target).resolve()
if target.exists():raise SystemExit('Target must NOT exist; use a new independent directory')
with zipfile.ZipFile(root/'baseline/ed8755a597973922d02bd675e80b00c410dfdaf4.zip') as z:
 for info in z.infolist():
  rel=PurePosixPath(info.filename)
  if rel.is_absolute() or '..' in rel.parts:raise SystemExit('Unsafe baseline path')
 target.mkdir(parents=True)
 for info in z.infolist():
  if info.is_dir():continue
  dest=target/info.filename;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(z.read(info))
for source in (root/'current').rglob('*'):
 if source.is_file():
  dest=target/source.relative_to(root/'current');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(source.read_bytes())
print('Source-only restore complete; no .git, node_modules, credentials, test or product execution. Read the handoff card before any next action.')
