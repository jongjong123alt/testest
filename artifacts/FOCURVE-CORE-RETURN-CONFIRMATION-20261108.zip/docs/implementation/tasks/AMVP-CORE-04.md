# AMVP-CORE-04 — Core DNR 소유권·복원

## 2026-11-02 IG04 — 검증 대기 취소/만료 후속 단위

- 담당 윤종민, branch `feature/additional-mvp-ig04-verification-lifetime`, 시작/선행 PR86 `fc36d5ba3c41a7aa73e064322e6878775dfe23ef`. 기존 PR86 source/branch와 Content 계보를 보존한 별도 후속이다.
- issued/native/Registry 검증이 끝나지 않을 때 기존 expiresAt·요청 abort·명시적 invalidate로 대기를 종료한다. 늦은 성공/거절의 후속 실행·gate pin 차단, 개별취소/전체폐기 분리, monotonic 잔여 예산·잘못된 clock 거절, 최초 오류 보존을 구현했다. 새 ACK/TTL/Wire/DB·실제 정책 활성화 없음.
- 기존 3반례 base0/3→수정3/3. 최종 신규15+기존 admission32+Registry15=62/62·전체Extension1026/1026·계약6/6 PASS(fail/skip0), PR87 실제receiver 합성/IDB 호환1/1 PASS. 모의 issued/native/authority로 제품 수용 NOT_RUN. 집합 중복 합산 금지, 중간 구현/fixture 실패도 근거 문서에 보존.
- 상태: 구현·로컬검증 완료/새PR·리뷰 대기. 원래 PR86의 검증된 내용과 이번 후속 scope를 구분하고 새CI·다훈/지민 확인 후 통합한다. 실제 영속 예약·ACK/proof/cleanup·Worker 연결은 공동합의 대기이며 임의 구현하지 않는다. 상세 [검증 수명](../evidence/AMVP-CORE-04-ig04-verification-lifetime.md).

## 2026-11-02 IG04 — 발급 문맥/plan 사전 검증 단위

- 담당 윤종민, branch `feature/additional-mvp-ig04-admission`, 시작 integration `831069805eb0f86fc526b1f0f92e0b4a01656172`. Content `8f454c93`/gate3abe4504/#83 계보를 읽기 기준으로 보존한다.
- 내부 IG04PlanAdmission은 기존 A1 digest·DocumentControlRegistry 조회와 RC2 BindingScope/FocusRef를 재사용한다. context/plan 복사·동결·hash 검사, strict issued/native provider와 동기 current/deadline, await 이후 권한/문서 epoch·gate instance 검사를 구현했다. source 신규1/시험 신규1/선택 browser probe1/CI1/기록이다.
- 이번 범위는 영속 예약 전 admission이며 저장·Content용 ACK·CleanupGrant·DOM 효과·Report·scoped RELEASE/terminal 증거를 발급하지 않는다. 기존 stage를 per-target ACK로 대용하지 않고 실제 listener/START를 활성화하지 않는다. #76/78/80/84·기존 다른 worktree/제품 소스를 보존한다.
- 신규32+Registry15=47/47, 전체Extension1011/1011·계약6/6 PASS(fail/skip0). actual Content8f454c93 + Chromium151 실제IDB 호환1/1에서 예약ACK 없음→DOM효과0·의무보존 확인. 발급/native는 모의이며 제품 MV3/Server 수용 NOT_RUN. 겹치는 집합 합산 금지. 최초 fixture 실패1건과 수정도 근거 문서에 보존했다.
- 상태: 로컬 구현·검증 완료, PR/담당 리뷰 대기. 새 CI 결과는 별도 확인한다. 다음은 공동 ACK/증거 매핑 합의 후 실제 예약 원자 저장/조회 caller 연결. 상세 API·명령·미완료는 [IG04 사전 검증](../evidence/AMVP-CORE-04-ig04-admission.md).

## 2026-11-01 PR68 — PR59 병합 후 3공유파일 충돌 해결

- 새 결합 workflow 로컬 검증: DNR138/138·SiteController/loop69/69·인증33/33·계약6/6, syntax·수동3파일 whitespace PASS. 기존 #68 제품/시험4/4 및 최신 통합+원래 #68의 Extension 전체325/325 blob 동일성 확인. 각 시험 집합을 중복 합산하지 않으며 전체/실제 Chrome 시험을 새로 실행했다고 보고하지 않는다.

- 담당 윤종민. 기존 검토 HEAD `cd92cc11e81c53598ba7a80ee41ceeea2c3a2dad`와 최신 통합 `3569911dde9ec71d86c3b1e36f631c34e2411d53`를 부모로 보존하는 merge 동기화다. 선행 PR59의 merge `3f31f75e8be65996af3b1fb94a846b0df2d7c085`를 포함한다.
- 수동 해결은 CI·본 카드·통합현황 3파일만이다. #59/#68 trigger·시험과 #70 SiteController/CAS·인증·계약·syntax 명령을 모두 유지한다. 문서 양측 원문의 줄별 중복 횟수까지 보존했으며 아래 기록은 당시 이력이다.
- 제품·시험은 승인 통합 원본과 기존 #68 blob을 보존한다. 합성 후보 workflow를 검증하고 새 HEAD·checkout SHA·CI를 PR에 남긴 뒤 다훈·지민 재확인을 받는다. 이전 Approve를 새 HEAD로 소급하지 않으며 실제 MV3/Server 수용·자동 병합은 하지 않는다.

## 2026-11-01 PR68 최신 통합 최소 동기화

- 동기화 후 검증: owner/잠금/cleanup + #70 CAS 관련 188/188, 전체 Extension 905/905, 계약6/6, Chromium 실제 IndexedDB/Web Lock 2/2, bundle 원본 일치·syntax/diff PASS. DNR·권한/문맥은 모의이며 제품 MV3/Server 수용은 미검증 유지. 집합 중복 합산 금지.

- 기준 통합 `4e6ff6ced95b96f362f2fbf088aa192e17278529`(#70 승인·병합), 기존 검토 HEAD `38eae392bffbd966ef146dcf07017a40cc08de74`를 부모로 보존하는 merge 동기화다.
- 충돌한 CI·본 작업카드·통합현황 3파일을 양쪽 경로/시험/기록이 남도록 정리했다. 기존 제품·시험 blob과 #70 통합 제품·시험 blob 동일성을 검사하며 구현/검사 조건을 바꾸지 않는다.
- 원래 owner/잠금/cleanup 및 #70 journal CAS의 영향 회귀·최신 CI 후 새 HEAD로 재리뷰한다. 실제 MV3·Server 제품 수용/신규 공유 정책 활성화·PR 병합은 수행하지 않는다. 결과·blob 대조는 해당 PR에 기록한다. 아래 날짜별 기록은 원문을 보존한 이력이다.

## 2026-11-01 구형 GuestSession DNR 연결 착수

- 담당 윤종민, `feature/additional-mvp-legacy-guest-dnr`, 시작 `10ab6026f1cf7d244a75ee529830afb8bcf6b8c8`. PR59는 OPEN/리뷰 없음으로 보존하고, 기존 병합55 gate에만 의존하는 별도 worktree에서 진행한다.
- 기존 계획의 남은 legacy writer 중 GuestSession의 add/remove만 공통 gate에 연결한다. SiteController·PR59 소스/HEAD·공용 계약·Member/Content/Server는 변경하지 않는다. 신규 공유 정책/전체 coverage는 활성화하지 않는다.
- 현재 owner/executor/Guest auth·Root idle·AuthStore token, 실제 규칙 및 동일 DB snapshot을 검사한다. 잠금 대기 중 대상 변경 후 복구가 새 세션을 덮어쓰지 않도록 legacy SessionDB.save에 내부 scope precondition을 추가한다. 저장 schema/버전은 불변이다.
- 상태: 구현·검증 진행 중. 저장 실패 cleanup·권한 변경·기한·다른 owner/실행 규칙 보존과 기존 회귀를 자동 검증하고 별도 PR/담당 리뷰를 요청한다.

### 구형 GuestSession 단위 구현·검증 종료

- classic add/remove를 기존55 gate에 결속했다. 신규 add의 현재 인증/owner/기한/token·final DB route/snapshot/rules 검사, removal-only의 exact footprint 검증을 분리해 기존 정당한 cleanup을 유지했다. SessionDB.save의 내부 scope/create precondition으로 대기 중 current handoff 후 old recovery가 새 세션을 덮지 못한다. 저장 schema/DB version/공용 계약은 불변이다.
- 신규18/18·기존 session-core19/19·DNR96/96·전체 Extension882/882·계약6/6 PASS(fail/skip0). Chromium151 실제 IDB/Web Lock scope handoff1/1·syntax/diff PASS. 중복 합산 금지. PR59 미병합19시험 대신 본18시험을 포함한 별도 기반이므로883과 직접 증감 비교하지 않는다.
- 모의 DNR/owner/auth·fake-IDB 모델과 실제 Chromium 저장/잠금의 범위를 구분한다. 초기 fixture/저장 실패 주입 위치를 바로잡고 실패 로그를 보존했다. [구형 Guest writer 설명](../evidence/AMVP-CORE-04-legacy-guest-dnr.md).
- 구현·로컬 검증 완료, 별도 PR/최신 CI·담당 리뷰 대기. 원래59/다른 worktree·Member/A1/Content/Server 소스를 보존했다. SiteController 및 전체 writer coverage·SITE_TIME 실제 실행·Report/ACK·제품 수용은 후속이다.
## 2026-11-01 PR59 최신 통합 최소 동기화

- 동기화 후 검증: owner/잠금/cleanup + #70 CAS 관련 189/189, 전체 Extension 906/906, 계약6/6, Chromium 실제 IndexedDB/Web Lock 3/3, bundle 원본 일치·syntax/diff PASS. DNR·권한/문맥은 모의이며 제품 MV3/Server 수용은 미검증 유지. 집합 중복 합산 금지.

- 기준 통합 `4e6ff6ced95b96f362f2fbf088aa192e17278529`(#70 승인·병합), 기존 검토 HEAD `e64c140ebf8effedd9358f037a86cc8240ae96f4`를 부모로 보존하는 merge 동기화다.
- 충돌한 CI·본 작업카드·통합현황 3파일을 양쪽 경로/시험/기록이 남도록 정리했다. 기존 제품·시험 blob과 #70 통합 제품·시험 blob 동일성을 검사하며 구현/검사 조건을 바꾸지 않는다.
- 원래 owner/잠금/cleanup 및 #70 journal CAS의 영향 회귀·최신 CI 후 새 HEAD로 재리뷰한다. 실제 MV3·Server 제품 수용/신규 공유 정책 활성화·PR 병합은 수행하지 않는다. 결과·blob 대조는 해당 PR에 기록한다. 아래 날짜별 기록은 원문을 보존한 이력이다.

## 2026-10-31 Guest A1 DNR writer 연결 착수

- 담당 윤종민, 브랜치 `feature/additional-mvp-guest-dnr-fence`, 시작 기준 `24327d1bd8615a2274a6dead43f23b71cc06b64e`(#55 수정본 승인·병합). 별도 worktree에서 기존 다른 Core 작업/리뷰/미커밋 변경을 보존한다.
- 범위: Guest A1의 초기 add·UNKNOWN 복구 add·suspend remove·finish remove를 기존 공통 DNR gate/Root 원장에 연결한다. 현재 Guest owner/executor·인증 guest 허용 상태·AuthStore token·최종 DB fence/END/NR·DOM 기한을 대조하고 자기 cleanup은 보존한다.
- 회원 경로는 재작성하지 않는다. 구 GuestSession/SiteController·전체 writer coverage true·SITE_TIME 발급/Report/Server/Content/공용 계약 변경은 제외한다. Guest START가 이미 Auth.serial을 보유하므로 잠금 안에서 status/guardGuestStart를 중첩하지 않는 로컬 auth.load 경계를 검증한다.
- 상태: 구현·검증 진행 중. 끝나면 영향 자동 회귀·제품 미검증·새 HEAD/PR 및 담당 리뷰 요청을 기록한다. 실제 MV3 확장 로드는 현재 환경의 관리 정책으로 미검증이며 이를 우회하지 않는다.

### 이번 Guest actor 단위 구현·검증 종료

- 기존 Member gate와 정확히 같은 객체/Root 원장을 쓰는 `FocurveDnrWriter` 별칭을 추가하고 Guest보다 먼저 로드했다. 현재 Guest 네 쓰기 경로는 입력 동결·current owner/Guest auth·Root idle·AuthStore token·최종 DB fence/END/NR/DOM 검사 후 동기 dispatch한다. `auth.load()`만 사용해 이미 보유한 MemberAuth serial을 중첩하지 않는다.
- 신규19/19, DNR97/97, 전체 Extension883/883, 계약6/6 PASS(fail/skip0). Chromium151 실제 IDB/Web Lock의 Guest/Member END 비차단2/2, 생성 bundle 일치·syntax/diff PASS. 시험 집합은 겹치며 합산하지 않는다. DNR/identity/Content는 모의이고 실제 제품 수용은 미검증이다.
- fixture GENERAL+BLOCK/VM fetch 미주입의 준비 오류를 바로잡고 실패 기록을 보존했다. 제품 Snapshot·인증·복원 조건을 완화하지 않았다. 상세 [Guest writer 연결](../evidence/AMVP-CORE-04-guest-dnr-writer.md).
- 이번 단위 코드/검증 완료, PR 게시·다훈/지민 최신 HEAD 리뷰 필요. Core 전체는 부분 구현이다. 기존 다른 worktree·Member 소스/공용 계약/Server·Content는 보존했다. 구 GuestSession/SiteController 등 남은 writer, 실제 issued binding/SITE_TIME/Report/ACK·제품 수용은 후속이다.
## 2026-11-01 SiteController DNR guard 착수

- 담당 윤종민, `feature/additional-mvp-site-controller-dnr`, 시작 `10ab6026f1cf7d244a75ee529830afb8bcf6b8c8`. PR59/68은 OPEN/리뷰 대기로 보존하고 독립 worktree에서 병합55 gate에만 의존한다.
- 기존 계획의 SiteController add/remove/rollback·MemberExecutionLoop cleanup을 공통 gate/영속 footprint 검증에 연결한다. MemberJournalStore에 내부 CAS 저장·readonly footprint callback을 추가하며 DB version/schema/공용 계약은 바꾸지 않는다. auth 토큰·현재 명령/owner·기한을 마지막 dispatch에 결속한다.
- Scope는 기존 source와 생성 classic Member bundle·시험/CI/기록이다. A1/Member Core·Content/Server·미병합59/68 source·신규 공유 정책/전체 writer coverage 활성화는 제외한다. 상태: 구현·검증 진행 중.

### SiteController 단위 구현·검증 종료

- add/remove/rollback/loop cleanup에 기존55 gate와 readonly 영속 footprint 검증을 연결했다. 신규 add는 auth token·현재 로컬 owner/private command/기한을 final snapshot에 결속한다. 기존 Server 검사는 유지하며 잠금 안에서는 auth.load만 사용해 Auth.serial/HTTP 중첩을 피한다.
- MemberJournalStore 내부 CAS로 초기 생성·APPLIED·rollback·RELEASE pending/final의 원래 journal을 확인하고, 늦은 old actor가 새 operation을 덮지 못하게 한다. 저장 schema/DB version/공용 Wire·기존 control namespace 의미는 불변이다. 기존 생성기에서 classic Member bundle만 재생성했다.
- 신규23/23·DNR101/101·기존 SiteController/loop/runtime69/69·전체887/887·계약6/6 PASS(fail/skip0). Chromium151 실제 IDB/Web Lock CAS 보존1/1·bundle 일치·syntax/diff PASS. 집합 중복 합산 금지. 인증 큐 보유 중 생성 Member APPLY 완료, native/저장 실패 cleanup, invalid Snapshot RELEASE 등 포함. 실제 DNR/Server 권한/Content는 모의이며 제품 수용은 미검증이다.
- 구현·로컬 검증 완료, 별도 PR/최신 CI·담당 리뷰 필요. [SiteController 설명](../evidence/AMVP-CORE-04-site-controller-dnr.md). PR59/68/다른 worktree 보존. 통합 coverage·issued binding/SITE_TIME/Report·제품 수용은 후속이며 전체 guard/정책을 활성화하지 않았다.

## 2026-10-31 PR55 P2 수정·재리뷰 준비

- 시작 `b11dcc582de625152039ad42d3baabe5dc5f52dc`, 같은 `feature/additional-mvp-legacy-dnr-fence`/PR55에서 독립 리뷰 `5722433929`의 current owner 반례만 수정한다. 기존 로컬 변경 없음과 원격 HEAD 일치를 확인했다.
- 실제 잠금 queue + Member tick에서 owner/executor/identity 실패 3가지 모두 수정 전 무권한 dispatch가 발생함을 재현했다. 잠금 안에서 신규 add의 현재 owner/executor를 다시 검증하고, AuthStore 저장 시작/완료 token을 최종 동기 dispatch에 결속했다. removal-only는 기존 자기 journal·물리 rule·DB fence 검사를 유지해 정당한 이전 owner cleanup을 보존한다.
- 새 반례/보존 7/7, writer29/29, DNR78/78, DNR+인증/재인증111/111, Member/Core/인증 영향24파일287/287, 계약6/6 PASS(중복 포함, 합산 금지). Chromium 실제 IDB/Web Lock END 비차단1/1, 생성 bundle 일치·syntax/whitespace PASS. 전체 Extension857은 수정 전 결과로 이번 전수 회귀 결과가 아니다.
- 시험의 DNR/identity/Content는 모의다. 실제 MV3·Windows Chrome·전체 writer/제품 적용·Report/ACK는 미검증 유지. 재현·코드/영향/로그/내부 token의 한계는 [Member writer 설명의 P2 수정 절](../evidence/AMVP-CORE-04-member-dnr-writer.md)에 기록했다.
- 상태: 수정·영향 검증 완료, 같은 PR55에 게시 후 최신 HEAD 재리뷰 필요. 기존 Content Approve를 새 HEAD로 승격하지 않고 다훈·지민의 변경 범위 확인을 요청한다. 병합/후속 actor 개발은 이번 수정에 섞지 않는다.

## 2026-10-31 Member A1 실제 DNR writer 연결 단위

- PR53 f29532c는 다훈·지민 승인 후9e37b37로 통합됐음을 확인했다. 최신 통합 `9e37b37fefb2238f259c6a1bba400eee6955d085`에서 별도 `feature/additional-mvp-legacy-dnr-fence`를 시작했다. 기존 focurve-core 미커밋 변경·PR46/48·승인된 증거 조회 소스를 보존한다.
- 호출 지점을 조사해 Member A1/Guest A1/구 GuestSession/SiteController로 나뉨을 확인했다. 이번 첫 PR은 현재 제품 Member A1 네 쓰기 경로만 연결하며, 전부 한 번에 수정하거나 전체 guard를 true로 바꾸지 않는다.
- `additional-dnr-legacy-writer.js`와 생성 Worker bundle, service-worker/Member bootstrap 주입. Member Core의 초기 적용·UNKNOWN 복구·suspend·finish가 동일 DNR Web Lock에서 기존 runtime claim을 보호한다. 현재 실행 DB의 동일 snapshot에서 마지막 owner/END/fence/기한을 확인하고 Native dispatch한다. Chrome 응답이 DB transaction을 붙잡지 않는다.
- 기존 RootAuthority DB의 metadata 원장을 재사용하며 새 DB version/migration·공용 Wire/Report·Server/Content·관측 모듈은 변경하지 않는다. 다른 DB coordinator나 Guest/이전 writer의 보호/제품 활성화를 자동 승인하지 않는다.
- 신규22건에서 원장 보호/잠금 대기/실제 Member 네 경로/배포 flags/Native 대기 중 END intent/입력 동결/RootAuthority metadata 보존을 검증했다. 초기 6건은 DNR 없는 fixture 선택 오류였으며 DNR 생성 fixture로 바로잡았다. 자세한 API·잠금 순서·범위: [Member writer 연결](../evidence/AMVP-CORE-04-member-dnr-writer.md).
- 최종 로컬 검증: 신규22/22·DNR71/71·전체 Extension857/857(fail0/skip0), 계약6/6·syntax/whitespace PASS. 실제 Chromium151 IndexedDB/Web Lock 기반 Chrome 응답 대기 중 END commit 시험1/1 PASS. DNR/실행 신원은 모의다. 생성 Member/guard bundle 일치 검증을 포함한다.
- 상태: 이번 Member actor 연결 단위 구현·로컬 검증 완료, PR 제출/최신 원격 CI·다훈·지민 리뷰 후 다음 actor로 진행한다. 실제 MV3 DNR·전체 legacy writer 결속·issued binding/RuntimeReport 생산·전송은 미완료다. 원래 미커밋 변경과 다른 PR은 보존한다.

## 2026-10-31 SITE_TIME 증거 결속·조회 단위

- 담당 윤종민, `feature/additional-mvp-site-time-evidence`, 시작 기준 `467fe18b176ccd571813d04229e8ee69f19a00d2`. 원래 focurve-core의 미커밋 변경과 PR46/48을 보존하고 별도 작업 공간을 사용했다. 현재 열린 Core PR/통합 코드를 조회하여 정책/version/operation→DNR claim 원본 조회가 없음을 확인했다.
- 사용자 최신 요청: 기존 DNR·관측 코드를 재사용하고 SITE_TIME 한 정책의 원본 증거부터 구현. Server 수신·검증·Receipt·DB·Web은 다훈 담당, 전송/collector/clock을 이번 단위에 섞지 않는다.
- 구현 `extension/src/additional-dnr-site-time-evidence.js`: `SiteTimeDnrEvidence.register({context,policy,claims})`, `read(context)`. 기존 coordinator Lock/store/inventory를 사용하며 DNR 설치·삭제·자동 채택/새 Receipt·RuntimeReport 발행은 하지 않는다. 기존 DNR/관측 생산 파일 수정 없음.
- 원문 context와 정책/version/hash·claim store+id/owner/generation/epoch/hash를 영속 결속, 최초 등록 관측과 현재 관측/미해결 cleanup·관련 실제 RELEASE Receipt를 조회한다. 잘못된 semantic hash의 RELEASED 표시는 해제 증거로 사용하지 않는다. 다른 owner 공유 규칙과 자기 의무 해제를 구분한다.
- 주입할 실제 issued binding verifier 및 전체 writer guard가 없으면 기본 거절한다. true 시험 provider는 SYNTHETIC이고 현재 제품 provider 구현/연결 완료가 아니다. 단일 operation/정책 범위이며 새 공용 메시지 계약을 만들지 않는다.
- API·입출력·불변 조건·다훈 연결 시 주의사항: [원본 증거 설명](../evidence/AMVP-CORE-04-site-time-evidence.md). 등록 원문 정책 버전과 실제 RELEASE operation을 Server 삭제 버전/Receipt로 임의 바꾸지 않는다.
- 로컬 검증: 신규25/25, 기존 DNR 포함49/49, 전체 Extension835/835(fail0/skip0), 계약6/6 PASS. 통합 기반과 미병합 PR46/48 기반의 시험 수는 다르며 합산하지 않는다. Chromium151 실제 IndexedDB/Web Lock 재열기 시험1/1 PASS, DNR/발급 source는 모의다.
- 실제 MV3 DNR은 임의 확장 로드 관리 정책으로 worker timeout; 정책 변경 없이 미검증으로 남겼다. 실제 Windows/제품 Worker·네트워크 차단·강제 종료/원본 권한 전환·전체 정책 수용은 미검증이다.
- 상태: 이 내부 모듈 단위 구현/로컬 검증 완료, 제출 전 syntax/whitespace·최신 원격 CI와 담당 재리뷰 필요. Core 전체는 부분 구현이다. 다음은 실제 issued binding/writer 연결 검증이며 그 뒤 Report 생산/전달 계약을 맞춘다. Server 연동이나 제품 활성화·자동 병합은 하지 않는다.

- 담당: 윤종민 / 브랜치: feature/additional-mvp-core
- 시작 기준: da1c70b2b2052dece581353f81cd5eb6c604e4b1 (PR24 병합 및 Web/Server 통합 포함)
- 계약: AMVP-CONTRACT-20261029-RC2, PR24 승인 a10fcb02927eec49561c62417b6a0d7a63e64cde
- 기준 명세: docs/design/additional-mvp-contracts/03_Wire_D06_복원.md의 C-04 Session/Dynamic DNR, 06_인계_승인.md의 AMVP-CORE-04.
- 상태: 진행 중. inventory에 이어 durable sidecar·writer epoch·own-claim RELEASE/복구 모듈 구현. 제품 Worker 연결은 대기.
- 이유: 기존 Guest/Member는 SESSION만 직접 제어하고 계약 참조 모델은 Python fake banks다. 둘을 복제하지 않고 신규 coordinator의 양 저장소 관측 경계를 먼저 구현한다.
- 제품 코드: extension/src/additional-dnr-inventory.js. 기존 canonical digest 재사용, 승인 DnrClaim 필드와 결속.
- 이번 완료 조건: store+id 분리, 전체 rule hash 대조, 공유 owner/세대 의무 보존, 유실/조회실패/변조 구분, 미관리 규칙 자동 채택 금지, 읽기 중 입력 변조 방지.
- 안전 경계: 관측은 두 store의 원자 snapshot이 아니며 삭제 허가·RELEASED·SESSION_STORE_RESET 증거가 아니다. 기존 Worker에는 아직 연결하지 않으며 DNR 쓰기/서비스/설치를 변경하지 않는다.
- 다음 단위: 기존 Guest/Member 등 모든 DNR writer를 동일 guard에 결속하고 제품 Worker 연결. 이후 실제 확장 Chrome 수용 시험.
- 미검증: 실제 Chrome, writer 경쟁/원자 저장, quota·실제 해제, DOM/Content, 제품 전체 통합. 이 카드의 테스트 통과로 기능 완료를 선언하지 않는다.

## 2026-10-30 이번 단위 종료

- 읽기 전용 inventory 구현 및 API 모의 회귀 9/9 PASS (Node v24.19.0, `cd extension && node --test tests/additional-dnr-inventory.test.mjs`). 기존 Python fake coordinator 복제가 아닌 실제 JS 모듈의 두 Chrome getter 호출 경계 시험이다. 브라우저는 모의 객체다.
- 승인 계약의 legacy 경계·canonical hash 시험 6/6 PASS (`node --test contracts/additional-mvp/rc1/tests/legacy-boundary.test.mjs`). 신규 모듈이 재사용하는 digest 및 구 actor 거절 경계를 확인했다.
- 승인 manifest 52/52 불변, 새 모듈 syntax·git diff whitespace 검사 PASS. 계약 전체265/SQL54는 변경하지 않아 재실행하지 않았고 이번 실행 수로 보고하지 않는다.
- 원래 /workspace/capstone-project의 지침 미커밋 변경과 index 보존. 작업 경로 /workspace/focurve-core, 기존 원격 Core 브랜치에서 시작해 최신 통합 기준으로 ff-only 반영.
- Commit/Push 및 실제 Worker 활성화는 하지 않았다. 이번 단위 완료이며 AMVP-CORE-04 전체는 진행 중이다.

## 2026-10-30 저장·해제·복구 단위 종료

- `extension/src/additional-dnr-store.js`: 기존 실행 DB의 metadata transaction을 재사용해 `amvp_journal_v1:dnr` sidecar 저장. 기존 Journal1.1 변경 없음. 원장 구조/claim/operation 상태 불일치 시 거절.
- `extension/src/additional-dnr-coordinator.js`: Web Lock 직렬화와 영속 writer epoch, 검증된 기존 규칙의 claim 예약, 해제 intent 선저장, SESSION/DYNAMIC 별 자기 claim 해제, 사후 재조회와 receipt 저장, 동일 operation 재시도 구현. 다른 owner·generation 및 미관리 규칙을 보존한다.
- 저장 실패나 양 저장소 부분 실패 시 PREPARED/IN_DOUBT 의무를 남긴다. receipt 저장 실패 후 새 store/coordinator로 복구하며 이전 writer를 거절한다. 종료 generation의 재채택과 진행 중 규칙의 타 owner 채택도 거절한다.
- 활성화 조건: `assertWritersGuarded`와 `verifyAdoption`은 내부 신뢰 경계이며 기본 거절. 시험의 true callback은 제품 안전성 증거가 아니다. 기존 writer 전체 결속이 아직 없으므로 제품 Worker에 연결하거나 신규 정책을 활성화하지 않았다.
- 자동 시험: inventory 9 + coordinator/store 15 = **24/24 PASS**. `cd extension && node --test tests/additional-dnr-*.test.mjs`. fake-indexeddb + Chrome DNR 모의 객체, Node 실제 Web Lock으로 저장 장애·부분 실패·공유 소유권·중복/충돌·epoch 경쟁·손상 원장을 검사했다.
- 기존 계약 Node **6/6 PASS**: `node --test contracts/additional-mvp/rc1/tests/legacy-boundary.test.mjs`. `cd extension && npm run check` 및 `git diff --check` PASS.
- 추가 실제 기반 검사: 격리된 Linux Chromium 151 페이지에서 실제 IndexedDB 재열기 후 epoch 유지, reducer 오류 시 rollback, 실제 Web Lock을 통한 startWriter 성공 확인. 실제 확장 DNR/API·Windows·Worker 강제 종료 시험은 아니다.
- 환경: npm 기본 cache 쓰기 실패 후 `/tmp/focurve-core-npm-cache`로 `npm ci --ignore-scripts --no-audit --no-fund` 성공. package/lock 변경 없음.
- 남은 범위: 기존 writer guard 결속, 제품 Worker 연동, 신규 정책 APPLY/예약 연계, 실제 DNR quota·브라우저 재시작·Windows 통합 검증. DOM/Content 구현은 이번 범위 밖이다.
- 종료 현황: 이번 저장·해제·복구 모듈 단위 완료, **AMVP-CORE-04 전체는 부분 구현**. 전체 추가 MVP 완료율은 산정하지 않는다. Commit/Push 미실행.

## 첫 기능 PR 준비

- DNR 모듈3개·시험2개·본 작업카드·전용 CI만 첫 PR에 포함. TIME-05 및 통합현황 로컬 수정은 후속 변경으로 보존.
- 대상 브랜치: integration/additional-mvp-20261029. 자동 병합/제품 활성화 요청이 아니라 기반 모듈 리뷰 범위다.
- 제출 전 DNR24/24·기존 계약6/6·npm run check 재실행 PASS. GitHub CI는 Ubuntu/Windows Node24에서 동일 모의 시험 수행; Windows 실제 Chrome 수용 시험을 뜻하지 않는다.
- 미완료: legacy writer guard 전체 결속, Worker 진입점 연결, 실제 DNR·quota·브라우저 재시작 수용. 기존 API·DB·Content 구현은 이번 PR에 포함하지 않는다.


## 2026-11-03 IG04 provider 내부 저장부 로컬 단위

- 윤종민 / 시작 #88 ed8755a5 / 격리 detached worktree focurve-ig04-provider-local. 기존 A1Store.atomic 재사용한 권한 revision·원본 버전·local closure 원자 저장 모듈 및 시험 추가.
- 신규9+기존47=56/56 합성 PASS. 실제 인증/전이 hook/Content callback·watch plan0·운영 ACK는 HOLD. 전체 ABA 안전성/제품 연결 완료 아님. Git 제출/병합 없음.
- 상세: [구현·검증·미완료](../evidence/AMVP-CORE-04-ig04-provider-local.md).


## 2026-11-05 Native 진단 / 추가 MVP 제품 연결 공동 결정·차단 위치

이번 단위는 기존 계약·소스 대조와 작업카드 정리. 진단 결정을 제품의 일괄 중단 사유로 사용하지 않는다. 기존 내부 모듈을 재작성하지 않으며 아래 운영 연결의 미결정 의미를 실제 함수별로 확인했다. 신규 보고서 없음. 이번 새 runtime 코드 수정/시험0.

### 확정 사항 — 다시 결정하지 않음

- 진단 J1: root nonce 소비 후 최소 identity/auth 투영 허용, raw auth/token 외부반환금지. J2: 별도HOLD 경로의 RUNNING/ENDING/UNKNOWN·고정실패참조·유일선택,기본ENDED경로유지. 총15초. R1 및 Chrome바인딩 독립PASS 종료,하위API 강제취소/실제Chrome보장은아님.
- 제품 P4: Core 1A/2A/3A/4A 조건부 선택과 공급①~⑤, Content 대응방향 유지. L/P 독립보존·원본version/CAS·cutoff membership·소비직전현재성·plan0공통의무보존은확정원칙. 새public오류/DTO를임의발명하지않음. 승인된원칙자체는재선택대상아님.

### 진단 결정 D1 — 실제 문서 인증 producer

질문: 일반Worker를깨우지않고어떤producer가실제Chrome document provenance를Native에인증할것인가?
선택: A source-pinned안전문서context+Native실제channel/peer에검증가능attestation결속(권고/조건부), B 별도trusted browser producer(일반Worker배제가증명될때만).
확정: origin/PID/sourcehash/challenge echo/임의UUID만으로문서인증불가.
담당: 다훈Shorts/설치 전달 + 종민Native검증; 지민에게진단구현전가없음.
파일/완료: NativeDiagnosticAdmission.cs 및 document-provider.mjs의 trustedDocument/verifyPreactivationEvidence. 실제producer/신뢰원문/퇴역검출의결속과위조·다른문서·channel교체거절검증이완료조건. 현재Native는ATTEST만,다른명령거절.

### 진단 결정 D2 — 연속 writer 배제

질문: 기존origin/cachedWorker를문서열기전부터읽기종료까지어떤주체가배제·확인할것인가?
선택: installer/Native가확보·유지하는보존경계(권고); manifest-only/사후flag/일회부재확인은선택불가.
담당: 다훈전달/진단이미지 + 종민Native상태검증.
파일/완료: prepare_diagnostic_image.py·NativeDiagnosticAdmission.cs·direct-native-channel.mjs의생명주기. 기존storage/DNR/프로필보존과정지·변경·문서퇴역시거절근거가필요. 실제b299실행승인은별도.

### 진단 결정 G — 발급/목적record

질문: 종민선택 G1 installer명시승인발급 / Native소비분리와 G2-A 기존envelope+Native보호영속purpose record를공동계약으로채택하는가?
확정: admissionGrant 재해석금지,UI는issuer아님,root확인후에만GUEST owner를discovery에결속,총15초를단계마다갱신금지.
대안: G2-B 새privategrantrevision(추가형식변경필요); 권고G2-A. 운영비밀/실제grant발급요청아님.
담당: 다훈승인/전달정책 + 종민Native발급/소비구현.
파일/완료: DiagnosticGrantStore.cs·NativeDiagnosticAdmission.cs 단계별issued/consumption/불확실보존 및동일목적재사용·restart·다른peer거절. D1/D2없는권한을모의true로발급하지않음.

### 제품 결정 P1 — 호출 및 인증 carrier

질문: 실제 M1 owner_binding_id/epoch/executor/capability/frozen proof를기존Worker의어느보호carrier에서받으며현재성을어떻게동기로검증할것인가?
선택: 기존회원focus권한공급과원문을재사용하는인증호출문맥(권고); body flag·MEMBER:<id>를owner_binding UUID로대입하는안은거절.
확정: 정책선택/인증/현재성·동기strict true는유지. currentSync라는운영공급자구현은미확인, #88 isCurrent는주입seam만구현.
담당: 다훈ServerM1 + 종민Worker/provider + 다훈현재Content연결담당.
파일/완료: additional-ig04-admission.js open/verifyContext/verifyPlan에 verifyIssued/verifyNative/isCurrent 실제공급; 원래scope/hash/native/권한전이·만료·ABA재사용거절근거. M1운영carrier없으면새effect연결불가.

### 제품 결정 P2 — provenance 등록/조회

질문: 이미합의한L/P/instance/gate관계를인증등록하는정확callback과그확인결과를어떻게전달하는가?
권고: 2A Core실행DB보호원문·version. caller원문/hash재구성은대안아님. 등록확인은reserveACK/APPLIED아님.
담당: 종민원장/Native아닌제품guard + 다훈Content producer/consumer.
파일/완료: ig04-provider-store.js register/finalizeIdentity/lookup/close 및 #87 gate등록/wiring. exactidentity·원래plan/provenance·현재authority 검증guard연결,다른L/owner/instance위조및source유실거절. 현재guard기본false라완료아님.

### 제품 결정 P3 — cutoff/round 재조회

질문: cutoff 고정목록/round의인증참조·version선택·폐기/조회결과의정확형식을어떻게결속하는가?
확정: 1A,대상고정·기존hash완료만허용·새dispatch차단·version전진. 겹치는이전미확정요청이있으면새소비거절/동일원문조회; 새correlation으로새예약/receipt발급금지.
권고: 같은실행DB에고정membership/round와최종소비CAS보존. 다른DB를연속호출해원자적이라고하지않음.
담당: 종민Core + 다훈Content callback/관측.
파일/완료: ig04-provider-store.js finalizeIdentity/close/queryClosure에 membership/round·currentversion검사추가및#87후속소비wiring. T2/T3/T4의원문·유실·stale소비거절검증;형식확정전NOT_RUN.

### 제품 결정 P4 — coverage/remaining

질문: local/watch공통/예약별coverage와listener/scan/callback/input검증의증거가어떤정확관측·결과형식으로대조되는가?
확정: 4A round,local quiescence≠watchclosure≠예약terminal≠전체RELEASE. plan0/부분인수로공통의무닫지않음.
권고: 같은실행DB에서의무종류별범위보존,공통writer는정확predicate/전체수락범위로만종료. 나머지remaining유지.
담당: 종민공통원장/guard + 다훈Content관측/독립통합.
파일/완료: ig04-provider-store.js close(현재빈목록거절)와미구현watch/round단위,#87 quiescenceSnapshot·cleanup-only facade. 실제자원정리/ownclaim/scan0/미확인reserve accounting검증. 새로운writer/후보를합의전만들지않음.

### 제품 독립 연결 조사 — 진단과 별개로 확인한 실제 차단

- additional-runtime-report-producer.js RuntimeReportProducer.produce: authorizeScope/verifyEvidence 기본false. 실제issued/effect/evidence source없음. 생산원장모듈은완료,생산caller연결은P1이필요.
- additional-runtime-report-replay.js RuntimeReportReplay.replay/authorize: 생산원장→outbox 재전달모듈완료(#80). 같은owner_binding_id/executor의authorizeScope운영source필요. 이미있는연결을재작성하지않음.
- additional-runtime-report-outbox.js batch/enqueue/acknowledge: 영속보존·항목ACK모듈은#76병합. authorizeScope/verifyReport/verifyAck는운영인증provider필요. true대역/HTTP200으로ACK인증대체금지.
- additional-runtime-report-delivery.js RuntimeReportDelivery.deliver: send(body,{signal,isCurrent})·authorizeScope·isCurrent 주입미연결. RPT-01 POST /api/v1/amvp/reports/batch와E인증/capability요구는이미확정. 새로결정할것은실제carrier위치와응답provenance 결속뿐. 기존 member-auth.credentials()의 owner_key/executor/token은owner_binding_id/capability/frozen권한을공급하지않아그대로연결불가. 401/refresh후권한전이·최종IO직전재검사와실제BatchAck검증경계필요.
- Worker startup/정책START에이모듈을등록하면위authority공백을회피할수없음. source와auth경계없이재시도timer/새RPC부터만드는것은안전한독립단위가아님.
- resource/closure는내부CAS모듈구현완료. 실제연결은위P2/P3/P4의guard/provenance/membership/coverage에직접의존. 더작은기존계약내독립영속단위는이미구현되어있어같은기능중복구현하지않음.

### 현재 수정과 다음 전달의 정확 범위

현재runtime추가수정0,이작업카드와기존통합현황만수정. 진단의미확정producer는제품P1과별개이며그것만기다리며제품조사를멈추지않았음. 독립구현가능한새단위는이번확인에서발견하지못함.
제품다음수정후전달파일은 (1) 기존Worker의검증된carrier공급/wiring, additional-runtime-report-delivery.js/send연결시험, outbox verifyAck인증연결시험; 또는 (2) ig04-provider-store.js의provenance/membership/coverage guard와 해당시험. 둘다해당P1/P2~P4결정근거확보후에만착수. 이미있는delivery/replay/outbox기능자체를다시작성하지않음.
진단다음전달파일은 NativeDiagnosticAdmission.cs/DiagnosticGrantStore.cs 및현재문서provider wiring·영향시험. D1/D2/G결정전권한허용구현은없음. 파일수정완료/시험PASS를미리주장하지않음.
R1/Chrome바인딩PASS는유지. 이번새검증은정적소스/호출경계확인뿐. 실제활성화/b299/export/제품Git제출없음.


### 2026-11-05 진단 구체 권고안 보완

기존 Native 계약 작업본 /workspace/b299-root-connection/contract/README.md에 D1/D2/G1/G2-A의 producer·verifier·기존함수·새내부record 제안·실패·최소검증계획을추가. 원본 계약 ZIP은불변. OSpeer/source검사를독립document인증으로격상하지않음. 실제browser-context attestation producer/연속writer배제전달경로는없는구현이며명시함. R1/Chrome바인딩 재검토·시험0. 제품P1~P4와별도병행조사결과유지,진단대기때문에제품을일괄중단하지않음. 새runtime수정0/실제발급·b299·export없음.


## 2026-11-05 IG04-P1-REVIEW-20261105-R1 Core·Native 담당 판정

대상manifest c0cdb4a01a5d652813db610b75997da6daf3788b380a331f4d6bab3201313918. 동봉manifest+3파일SHA일치확인. 동일원문 ADDITIONAL-RUNTIME-BRIDGES-20261029.md의D1~D5표와625행이후절 및동봉CORE카드164행이후대조. #88 ed8755a5는코드기준이며문서commit아님. Server조사6e724854와구별. 기존합의/시험재실행없음. 이회신은Core담당경계판정,공동최종승인/활성화아님.

D1 binding lifecycle — 수정.
대체문구: Server는binding 발급·종료와정수epoch 비재사용의authoritative writer를제공하고,권한종료/보안철회가효력을갖는transaction경계를명시한다. Core는그전이의관측/문서·operation 수명퇴역을담당한다. 보안철회를cleanup성공까지무조건지연하지않는다. 신규APPLY권한종료와원래oldscope정당cleanup권한을분리하며,철회로cleanup권한도미확정이면의무를보존하고동작을거절한다. 동일binding의A→B→A재활성화나epoch재사용을허용하지않고A1 UUID fence를정수epoch로변환하지않는다.
이유: 기존표의종료/무효화순서만으로는보안철회와oldcleanup을어느쪽부터처리하는지정해지지않음. 정당한복원의무를삭제하거나서버철회를의무종료때까지늦추면안됨.
착수조건: 다훈이 MemberAuth/MemberAccounts/AmvpBridgeSupport.binding와연결할실제writer/transaction·전이표·재조회상태를정하고,종민이RootAuthority/issuer전이hook으로매핑. writer구현은현재없음. auth/계정전환·disconnect·중복ACTIVE·재발급/철회음성검증필요(계획NOT_RUN).

D2 registry·Receipt — 수정.
대체문구: artifact/stream/feature/profile/hash·발급승인·만료/철회는지정된authoritative registry producer가공급한다. Native/Core는고정패키지나설치의실측원문을공급할수있지만registry승인/현재capability를스스로발급하거나hash로추론하지않는다. Server verifiedSelection은인증reader의현재원문을검증하고recordVerified에서불변Receipt를명시commit한다. Receipt재조회와현재capability/epoch/revocation재검사는분리한다. 조회실패·UNKNOWN·철회/만료는신규발급/효과소비금지,이미저장된Receipt/의무유지.
이유: 표의종민패키지/Native원문공급이registry issuer/운영capability발급으로확대되면안됨. 2회동일조회는미관측전이/ABA나즉시철회를증명하지않음.
착수조건: 실제registry producer/승인원문과인증reader/revocation source지정,Server prepared source/Bean연결. Native가존재/지원하지않는artifact승인을가장하지않음. 현재생산공급없음.

D3 prepared focus — 추가 근거 필요.
기존prepared source의목표의미(START/APPLY_POLICY 없는immutable 원문/명시수명)는수용. 실제 MemberExecution.start가부작용을만드는기존함수이므로준비조회대용사용금지.
필요근거: 준비원문을최초만드는writer/transaction과유일참조,회원/설치/binding/epoch·desired revision·Snapshot/Attachment 결속,취소/설정변경/계정전환/만료/실제START전환시준비권한종료·중복조회규칙. 현재자료는producer없음을명시하므로존재한다고수락불가.
대체문구제안: prepared 조회는이미명시적으로생성된준비원문만읽고없으면미확정/거절. 준비생성은명령/session STARTING/APPLY_POLICY 발행을유발하지않는별도승인된전이로정의. 실제START와의소비/권한전환은다른원문/수명으로명시. route/schema나session가짜행을여기서새로확정하지않음.
담당다훈Serverwriter/AmvpPreparedFrozenFocusProof·AmvpFocusAttachments,종민prepared issuer검증. writer선택후무부작용생성/조회/폐기시험필요(NOT_RUN).

D4 carrier→issuer — 수용(기존경로재사용·책임방향).
수용범위: 설치bound Serverorigin/E인증의온라인재조회는Worker 내부에서수행; credential은Content/Web으로내보내지않음. 기존MemberA1Adapter/protocol의원문재검증패턴을재사용하고Core 단일issuer가추가권한원문과native scope를별도로검증·등록한다. 401/refresh후oldbinding/current를다시검사하고미확정·원문충돌/유실은효과차단·권한있는동일원문조회.
구현전명세에필요한정확조건: 입력은Server인증원문참조/bytes·ownerbinding/epoch·Receipt현재성·prepared focus·원래command/Snapshot,Core인증native document/generation/A1fence의결속. 등록결과는보호원문의내부operation/hash참조와조회확인이지APPLY_ACK가아님. 동일원문등록재조회/다른원문동일ID충돌을분리. A1commandfingerprint와RC2semantic hash는서로대체하지않고각계약의원문/검증법으로독립대조. 실패/UNKNOWN을재발급허가로쓰지않음.
미확정signature/public반환형을이번수용으로발명하지않음. 실제carrier생산호출/issuer등록경로아직없음. D1~D3의원문/기한/원문조회확인형식을정하면권한검증·내부등록준비만먼저착수가능. Listener/DOM/reserve/Report성공소비를열지않으면D5실효성/후속P2~P4완료와분리검증가능. 위조owner/epoch/원문·만료·refresh전환·유실/중복등록시험부터(NOT_RUN).

D5 currentness·철회 — 추가 근거 필요.
강한currentSync를완화하지않는다는문구는수용하지만현재구현이그보장을제공한다는판정은불가. Native/Worker의로컬revision만으로원격Server철회나그전달전에발생한DOM효과를선형화할수없음. OS프로세스확인은Native document권한·원격철회측정이아님.
필요근거: 어떤권한전이의효력시점을어느집행경계가강제하는지,Server전이부터Content효과까지의선형화/봉쇄,문서/BFCache/port퇴역·다른Worker인수시current검사·소비CAS 결속. 기존strong보장을달성할수없으면ACK철회/lease 등은의미변경으로별도명시승인전도입금지. callback두번동일/비재사용revision만으로즉시원격철회보장PASS라고하지않음.
대체문구: currentSync는검증된현재권한수명에대한로컬엄격검사일뿐원격권한즉시철회보장을자동포함하지않는다. 요구된강한현재성은별도집행근거로충족되거나,정확한효력시점/허용구간을공동변경승인하기전까지실제효과활성화HOLD.
담당종민Core/Native전이·현재성집행,다훈Server효력/철회writer,지민Content소비/복원영향. 실제source없는성공provider구현불가.

최종: D1수정/D2수정/D3추가근거/D4수용/D5추가근거. 수정안방향을합의한뒤D1~D3의원본공급과D4정확내부등록/조회입출력을고정하면준비등록코드부터착수가능. D5는실제효과개방의차단으로별도유지하며모든준비작업을무조건막는것은아님. provenance/cutoff/coverage/closure등P2~P4완료를의미하지않음. 원본ZIP/manifest/제품/공용Schema변경없음. 시험0/실제활성화0/M1BLOCKED/MVP_FINAL_COMPLETE=false.


## 2026-11-05 P1 U1~U3 로컬 무효과 구현 착수
담당 윤종민, detached #88 ed8755a597973922d02bd675e80b00c410dfdaf4. 기존 provider-store 소스/시험 미커밋 보존. R3 manifest5396b1b6ae62717a87520a617b92ce36c755a93fd4f2a722002317aa11de44f2 + scoped delta9ab05116568319332d5485a7cc23634a4b5f1d5eeb3e49d05e35dcb9e31e6450 + 사용자 최종 null 정정(인증된 저장 부재만null,auth/network/미확정reject)을 구현 기준으로 고정. U1 인증 reader/U2 검증/U3 준비 CAS·재조회·trusted 관측만 새 내부 모듈/시험으로 구현. Server S1/S3·Content U4·runtime wiring 수정0, Git게시0. C2/C5·효과 HOLD 유지.

### P1 U1~U3 무효과 구현·단위 검증 종료
- 새 코드 extension/src/ig04-p1-preparation.js: IG04P1Preparation.readP1Source/verifyP1Preparation/registerP1Preparation/queryP1Preparation/hasCurrentP1Observation. 기존 MemberExecutionClient.credentials/request만 주입 재사용, loop/getLoop·startup wiring0. U2 서비스 전용 weak-map 검증 핸들, 독립 A1 command/RC2 semantic digest, 원문/요청/native scope 대조. U3 기존 A1Store.atomic 및 IG04ProviderStore의 authority/보호 source 원본·version을 CAS 시 재검증, preparation namespace만 추가. 기존 source 원장 생성/수명 관리는 재사용하며 이 모듈이 선언만으로 authority/source를 생성·복구하지 않음.
- trusted 관측: 인증 Server 조회 원문은 비공개 verifier의 5번째 인수로 전달, 저장용 불변 source와 분리. current capture/isCurrent/verifyAttempt/verifySource/verifyNative 기본 거절, 실제 adapter 없음. 등록 결과는 실행 불가 준비 기록. 현재401은 이 서비스의 정확 requestLifetime만 폐기하고 원래 오류 전파, 폐기된 늦은401은 새수명 변경0. 상위 인증 handler 연동은 후속.
- 기존 source 등록 API IG04ProviderStore.register에 의해 보호된 sourceLocalId/원문과 sourceVersion 및 동일 authority token/A1 fence가 필요. 미존재/closedBy/version변경은 거절. 실제 Server source importer/native/current provider는 미연결이며 합성 성공만 존재함. 등록/query 중 auth/network 실패 reject, 인증되고 보호 scope가 확인된 등록 부재만null. commit 후 현재성 실패는 저장 보존/reject, 새 인증 수명 재조회 후 별도 관측 제공. 동기 hasCurrentP1Observation은 U4 trusted composition 연결점이며 U4 구현/receiver/listener를 변경하지 않음.
- 검증: Node v24.19.0, fake-indexeddb6.2.5, node --test extension/tests/ig04-p1-preparation.test.mjs (repo root 기준). 최종35 PASS / FAIL0 / SKIP0, syntax PASS. 기존 시험 수 재합산/제품·Content 시험 반복0. 모의 인증/Native/current provider·격리 fake-IDB, 실제 HTTP Server/Chrome/Native/Worker 재시작·원격철회 강제성 시험 아님. real MemberExecutionClient는 mock fetch에 연결해 GET·토큰 비노출·abort 오류 전파만 검증. lower API 강제 취소 보장 아님.
- 검증 범위: 정상·기본거절·불완전 binding·source/native 위조·두 hash·기한/monotonic·401/refresh 토큰 전이·늦은 성공/401·수명/version/fence 전이·동시 중복/충돌·rollback·commit 후실패·인증 재조회·복원/closure 의무 미변경. 기존 provider 소스/시험2파일 바이트 동일성 유지.
- 수정 파일: 신규 module/test + 본 카드·통합현황 append. Server/Content/manifest/공용Wire/기존제품wiring 수정0. C2/C5·실제 issuer/권한/효과·provenance/cutoff/coverage/closure 미해결, M1/P1 BLOCKED/MVP_FINAL_COMPLETE=false. Commit/Push/PR/외부Git게시0. 로컬 소스/시험/패치/해시/로그ZIP을 제출한다.


### 2026-11-05 P1 U3/U4 소비 관측 R1 필수 결함 수정
독립 지적2건 수락: query가 native 검증을 생략, 인증 source 거절 뒤 기존 관측이 유효하게 남음. 제출 원본 module d95482ac96e97cb07224acfbafdaa45e49a8a31b59fb956d105eb9ec4b4f399e·시험82fdc4bafdf788c469483f5ad88ad1ffb9f99b994fb9ed1b808e4779de26f480 보존. 수정전 새2반례0PASS/2FAIL 재현, 수정후2/2PASS. 최종필요영향15/15PASS(신규9+직접영향기존6,FAIL/SKIP0), 원래35/35/독립4건과합산하지않음. 제품/Content 전체시험재실행0.
queryP1Preparation는 현재 source 조회 뒤 verifyP1Preparation(U2)의 native/hash/current 최종검사를 거쳐서만 소비 관측을 생성. #sourceVerified는 trusted verifier의 nontrue/비401 exception에서 캡처한 authorityId+token+binding 수명의 소비근거를 무효화. #check는 해당수명의 기존read/verified/관측 재사용 거절. native negative도같이거절. 현재401은기존requestLifetime 폐기를유지. 같은 SessionDB객체를공유한서비스는 known-rejection cache공유, 다른authoritytoken/binding은보존. 단순새requestID/true재시도는부활불가; 기존보호authority전이후새token의인증조회만새관측가능. 원문등록/복원/claim/watch/예약의무삭제0. 공개signature/DTO/U4수정0.
이cache는현재Worker·공유SessionDB객체에한정된동기관측보호다. 별도Worker/OS재시작/별도DBwrapper를가로지르는영속철회provider를구현했다고주장하지않음. 실제인증provider는해당수명의폐기를유지해야함. 이미관측한철회의공백을수정했으며C5미전달철회문제로회피하지않음. C2/C5·실제권한/효과HOLD. module/test·카드/통합현황append외변경0, Git게시0. 로그/정확diff/해시/의존성은로컬R1인계ZIP으로고정.


### P1 R3 최종 합의 원문과 관측 R1 코드 대조
사용자전달 P1-R3-AGREED-LOCAL-FILES.zip SHA4bc37fac2285b62e5a2aefde0b3094fe2eb054f2ab37800a90e32f3882b850c7, final rawSHA1f2defe78c0cd2f89d1c6308c42e95024eb9cd4434af2b654955532e23c4d829 확인. 파일5/5hash/길이 및 LFhash일치, R3기준원문동일, scoped→final 두diff zero-fuzz적용시final내용동일. 중간null-only미적용/누적카드덮어쓰기0. U1~U3 signature·확정binding·불변Stored/별도trusted관측·인증된부재만null/실패reject·로컬CAS/원격비원자·기존의무보존 대조상추가코드불일치없음. Server Observation/PreparationLookupKey/policyHandle/expectedOwnerState는Server및향후sourceReader adapter경계이며Core/U4 Stored wrapper나자가선언권한으로승격하지않음. 실제Server adapter는미연결,없음을구현완료로기록하지않음.
관측R1 module df97ab399b1d88fa5dea8da42774550f448579507347149591b8b7dba4b33bb0·시험c48cc0a4bd1ea1952cda444eeb8bb21b8780a0c7507df47d6e0d89e9827a7b2a 그대로보존. 로컬2반례해소/관련15PASS는이전근거재사용,이번동작시험0/새runtime수정0. 독립재검토회신전2결함최종종료로표시하지않음. C2/C5·운영권한/효과HOLD,Git게시0.


### 2026-11-06 Core 관측 R1 독립 종료·Core→U4 연결 인계
사용자전달 독립재검토9/9PASS로두필수결함종료. 직접재실행으로표시하지않고기존로컬15와합산하지않음. 보장은동일Worker/동일SessionDB범위,C5미해결. source df97ab399b1d88fa5dea8da42774550f448579507347149591b8b7dba4b33bb0/test c48cc0a4bd1ea1952cda444eeb8bb21b8780a0c7507df47d6e0d89e9827a7b2a 유지.
실제Core동기검증함수 IG04P1Preparation.hasCurrentP1Observation(trusted,exactAttempt,stored)->boolean. 이를동일Core서비스의private메서드소유문맥으로호출해야함(떼어낸unbound메서드금지). trusted는최초capture와동일한opaque객체,exactAttempt는원래요청원문/digest/source/version의동결사본,stored는해당서비스register/query가반환한정확한객체. JSON/structuredClone/복사객체·다른서비스결과는WeakMap인증실패. sessionDB공유만으로다른서비스결과인증이생기지않음.
U4trusted composition에Core가소유한동기closure를주입하는기존의미만사용,네번째U4인수/permission필드/인증관측직렬화추가없음. U4는원래consumeExpectation(등록참조/version/source/instance/generation/attempt/revision)대조와최종검사후동기갱신,Core검사만으로전체U4기대값대조를생략하지않음. 같은JS문맥의로컬합성연결시험에서원본객체를전달할수있으나실제Worker→Content메시지는함수/WeakMapidentity를전달하지못하므로생산채널완료로표시금지.
현재지민U4소스/시험/기준ZIP미수신. private callback슬롯/입출력추정수정안함. ZIP수신후정확baseline/guard/시험/diff/의존성/hash/log대조및최소Core결과연결시험진행. 생산검증기/현재성/철회/다른결과거절·원문/의무보존만확인. 이번runtime수정/시험0,Server/Content변경0/Git게시0.


### 2026-11-06 Server→Core source adapter·보호attempt 결속
사용자승인 무효과범위. 원격 codex/server-p1-local-noeffect 코드66c28ebd21086d31c657e979ee74f8bdd5308666의 AmvpP1ServerConnection/AmvpP1Preparation/AttemptMappingTest를읽기고정(통합/계약승인SHA와구별). 실제Java readAttemptSource→readOwnedSource→referenceForSource는생성digest를Server보호journal에서얻음. Core조회attemptdigest를생성ByReference.expectedDigest에대입하지않는다. 새공개route/Bean/HTTP계약없음. 실제인증transport미제공시기본거절.
변경: ig04-p1-preparation의sourceRef를UUID문자열이아닌{id,version}으로대조, exactAttempt.original.sourceRef와기대version일치필수. capture의attemptLocalId/attemptVersion을동일Core CAS에서보호원문과검증, sourceLocalId/sourceVersion·registration CAS revision·owner epoch와구분. 비401인증reader실패는캡처authority관측을fail-closed로거절하여기존관측소비불가,401은requestLifetime폐기유지. 관측R1의query native재검증/기지철회차단유지.
신규 ig04-p1-server-source.js: IG04P1ServerSourceAdapter.openAttempt/forContext, p1Utf8Sha256. 기존IG04ProviderStore.lookup으로보호attempt/version/closedBy및A1fence검증, canonical(original)UTF8digest및 original.sourceRef확인. verifyAttempt/verifySource는이인증캐시·원문과hash검증이며운영truecallback없음. sourceReader는trusted readAuthenticatedSource seam만호출하고없는경로거절. 실제Server SourceRead.sourceRef/sourceVersion/raw/rawSha256/expiresAt/bindingId/ownerEpoch/executorId를정규화. full PreparationOriginal필드/owner/binding/기한/canonicalJSON/UTF8hash 대조,중첩settings-onlyhash거절. 실제설정원문은실행Snapshot/FocusRef/Control/권한으로승격하지않음.
검증: 최종Core단위44+새adapter19=63/63PASS,FAIL/SKIP0. 실서비스/운영DB/Java코드실행아닌고정Java serialization형식의합성인증reader+fake-IDB 연결. 실제Coreadapter/class와CAS실행, Native는모의. 모든수치를과거R1독립9/로컬15/원래35와합산하지않음. 첫Core참조대조43/44에서기존negative설정시험이동일DB의거절latch를공유해다음대조를오염시킨시험격리문제를확인,각negativecase에독립fixture배정후통과. 거절latch를완화하지않음. 실제MemberE인증transport/Server직접호출·native운영provider는NOT_RUN.
추가소스4파일(module기존수정+adapter신규+기존시험수정+adapter시험신규),기존provider소스/시험불변. U4는sourceRef{id,version}및exactAttempt.original.sourceRef대조영향만지민에게인계;U4세인수/Stored반환/별도trusted관측유지. Server/Content/실행loop/wiring/공용Wire수정0. Source등록원본importer·auth readAttemptSource 전달transport·기한/current실제provider미연결. 필요한인계는그인증호출함수/소유문맥/고정소스·실제Server반환fixture이며본문/자기선언digest로대체불가. C2/C5·실제권한/효과HOLD/Git게시0.


### 2026-11-06 생성/읽기 digest 분리·read 인증 seam 공급
기존Coreadapter에 authenticate(action,trusted,exactAttempt)->Promise<void> 구현, action='read'만허용. guarded IG04ProviderStore.lookup으로현재보호원문/recordVersion/closedBy·authority/A1fence확인후 original.sourceRef의{id,version}/canonicalbytes/읽기digest대조,private요청수명결속생성. openAttempt는호환wrapper만유지. forContext가auth함수및동기verifyAttempt/reader를공급. checkedExact/caller선언digest만으로통과불가. 실패한보호재인증도캡처수명의이전소비근거를거절하며저장삭제0.
verifySource(trusted,source,attempt)->Promise<boolean> 정확3인자로공급. 제4/5인자caller관측을인증근거로받지않고private lastRead의실제인증source조회기록·fulloriginal/hash/binding/sourceRef/version·현재수명과대조. source생성이력은Server보호journal을복원하는기존private readAttemptSource/readOwnedSource/referenceForSource 경로가공급해야하며단순hash/JSON검증이그인증을대체하지않음. 생성requestDigest와Core읽기digest는서로다르며대입/새wire필드추가없음.
관련adapter24/24PASS(기존19+신규5,실제Coreclass/fake-IDB+합성인증Serverreader),FAIL/SKIP0. 원래Core44/전체제품·Content/Server시험미반복,기존63/R1독립9와합산안함. 현재repo에사용자언급readSource({sourceRef,expectedBinding,get}) helper원문은없으며그구현/인수형식을추정해새생산함수로중복작성하지않음. 지금공급하는auth/verify3 seam은기존class의privatecomposition으로연결가능. 실제get/인증transport/Server보호lookup의정확함수·소유문맥·현재SourceRead반환샘플이필요,없으면거절. 추가생성digest인수또는callerprooffield불필요. U4세인수/Stored반환변경0,listener/권한/효과활성화/Git게시0.


### 2026-11-06 Server→Core→U4 실제 코드 연결 공급 경계 확인
기존승인범위의새정리: 원격브랜치목록과codex/ig04-content-receiver의전체tree0a1b5e7e07ee3cfd47fe7a8ca495b3044ac5e6ca(비잘림)를읽기확인했으나U4준비소비자/시험공급없음. 수신attachments/reviews에도U4인계ZIP없음. 기존#87receiver를U4로대체/추정작성안함. #111승인과실제Core연결은구분.
Server소유부족파일: runtime-server/.../AmvpP1ServerConnection.java의readAttemptSource(HttpServletRequest,UUID,ExactAttempt,UUID,long) 또는readOwnedSource를실제인증문맥으로호출하고Core private readAuthenticatedSource(client,credential,query)에매핑하는시험용bridge/dispatcher. 현재#111은private미등록class뿐이며HTTProute/Bean/호출연결없음. query={executor,readAttempt:{requestId,original},reference,expectedSourceVersion},반환Promise<{sourceRef,sourceVersion,raw,rawSha256,expiresAt,bindingId,ownerEpoch,executorId}|null>,auth/조회실패reject. 이반환만으로예외허용/운영권한발급아님. 기존E인증HTTP200/401시험의entry를재사용가능하나정확파일/호출법/소유문맥/동일sourceRef실반환fixture가필요. 외부생성digest필드추가불필요,Server보호journal에서복원.
Core현재공급: ig04-p1-server-source.js의authenticate(read,trusted,exactAttempt),forContext의verifyAttempt/sourceReader/verifySource(정확3인자),ig04-p1-preparation.js의실제read/verify/register/query/hasCurrentP1Observation. guarded providerStore의capture/current/attemptRecord와보호source importer·native운영source는기본거절그대로. 동일입력보호attempt/source원문을소유한문맥이필요하며없으면checkedExact/hash/truecallback으로채우지않음. 실제get bridge부재상태에서별도모의성공pipeline추가안함.
Content소유부족파일: receiver와분리된consumeP1Preparation(trusted,consumeExpectation,stored)->boolean guard와시험의정확baseline+원문+직접의존+diff/hash/기존logZIP,최종검사슬롯명/호출법. 같은JS문맥시험에서Core동일서비스·동일opaque trusted·동결ExactAttempt·그서비스가반환한정확Stored객체로Core동기검증closure를공급. clone/serializedStored는다른객체이므로기존Core약식객체동일성보장으로실제Worker→Content생산채널이연결됐다고기록하지않음. U4추가인수/권한proof필드발명없음.
다음시험은두실제공급물수신후동일sourceRef/{version}/읽기attempt/immutableStored로정상접수·검증기부재·현재성실패·기지철회·다른등록결과·수명전환·저장/복원의무보존만실행. 현재실연결시험NOT_RUN,추가runtime수정0/새시험0. 기존adapter24와Core/R1/Server개별PASS재사용,제품/Content전체재실행없음. 실제운영공급없는성공을만들지않음. C2/C5·권한/효과HOLD,Git게시0.


### 2026-11-06 실제Core동기검증자 U4 공급
사용자전달 U4 Promise거절수정 독립3/3PASS 검토종료를기록. 해당U4단위/다른VM Promise·strict반례재실행0. Core실제함수 hasCurrentP1Observation(trusted,exactAttempt,stored)->boolean 유지. 새 createP1ObservationVerifier(trusted,exactAttempt)->(stored=>boolean)는동일서비스/opaque객체/동결원래attempt/캡처requestLifetime·localrevision에고정하여기존hasCurrent함수에위임. 누락보호current provider는생성시거절,근거없는stored/복사/다른서비스결과·기지철회·수명변경은false. 새생산Wire/권한필드/U4인수추가없음.
새공급경계5/5PASS:실제Core콜백정상/다른결과,수명전환후fresh결과로old callback갱신금지,source거절·원문보존,늦은native응답퇴역,provider부재. Node/fake-IDB/합성auth/native/current source로Core코드를직접검증한것이며실제U4연결시험아님. 이전U4독립3/Core기존24/63/R1독립9와합산하지않음. 지민U4원문/기준·호출슬롯미수신이므로소비자코드추정수정/실연결PASS없음.
공급위치: 준비서비스를소유한trusted composition에서authenticate(read)성공후get/register/query전 verifier=core.createP1ObservationVerifier(trusted,exactAttempt) 생성,동일요청의정확stored객체를U4trusted검사슬롯에서verify(stored)로검사. 마지막await이후U4자체consumeExpectation/source/instance/revision검사와동기갱신사이await금지유지. 객체/함수직렬화로실제Worker→Content생산채널구현이라주장하지않음.
미연결: protectedattempt/source importer와운영capture/isCurrent/native원본provider, #111 readAttemptSource 인증get/transport, U4소스/슬롯. source없는경로는기본거절. 서버조회Private SourceRead·Core로컬CAS비원자/C2/C5/HOLD유지. 기존Content/Server/효과wiring/Git게시수정0. 정확소스·기준·diff·hash·새5건log·호출예시를local ZIP으로준비.


### 2026-11-06 실제Core→검토U4 로컬 연결8건
사용자첨부IG04-U4-rejection-review.zip SHAbdf5c6bb62a6de8bff6edad9d30f319539fb7cb6e596034a3adcaf8350cfe440 다운로드/동봉7파일SHA일치. 실제guard SHA130e526bb9b3beb6af0a22cca76a119d389bd07a69191851dda6b531c1f2a48b,imports없음. 최초묶음미수신이어도이번최소연결런타임의존누락없음. 최신guard를extension/tests/fixtures/ig04-u4-reviewed-consumption-guard.mjs에바이트동일복사(제품Content파일수정아님). 원본ZIP/before/after단위로그보존,기존Promise단위/독립3PASS재실행0.
정확callback위치:createP1ConsumptionGuard(verifyCurrentPreparation)의생성자인수,guard내verifyCurrentPreparation(trusted,consumeExpectation,stored)호출. 새 tests/ig04-p1-core-u4-connection.test.mjs는실제IG04P1Preparation/createP1ObservationVerifier/hasCurrentP1Observation,실제sourceAdapter/guardedproviderStore/동일SessionDB와위검토guard를import. callback은원래trusted객체/동결ExactAttempt와consumeExpectation원문대조후실제Coreverify(stored)===true요구. 로컬fixture는consumeExpectation에원래동결ExactAttempt를사용하며새공유DTO정의아님. U4 public3인수/strictboolean/Promise거절코드변경0.
신규연결8/8PASS,FAIL/SKIP0:정상등록/재조회접수,복사/직렬화/변조stored·위조문맥거절,다른서비스거절,수명전환후old callback/fresh결과거절,확인된source거절,native거절,늦은응답,검증기/transport/native부재거절. 모든접수/거절에서metadata저장원문과local/watch/reservation/cleanup_pending fixture의무변경없음확인. 운영HTTP/native/current공급은합성외부fixture로명시,실제Core검증함수는대역아님. fixture의보호guard/native대조는원문/소유/fence/대상/수명검사이며운영빈provider를true로설치하지않음. 실제Server인증/Worker→Content브리지/C5/제품E2E성공아님. 기존Core/U4/제품단위시험재실행/수치합산없음.
Core제품소스a4e258437deb0061be4f41f9ec3d2d59e180c7ca184f222dc953f903b3d51b81/adaptere0679480655083ecfe71fdc3f0bd33216bebbf364108821ee95c6ac7b7faacae 그대로. 새connectiontest+검토guardfixture·카드append만변경. Server/Content제품코드/wiring/Git게시0,운영권한/효과/C2/C5HOLD. 실제Serverget/보호provider미연결은별도차단으로남김.


### 2026-11-06 전달본 불일치 해소·최신4파일 통합묶음
기존ZIP69baf472는authenticateread미포함/verifySource5인자인이전adapter로확인. 최신소스2(a4e25843/e0679480)·시험2(28425e21/c16c70a0) 및component별기준/diff/해시/기존log24·5·8을 P1-CORE-LATEST-READ-AUTH-U4-HANDOFF-20261106.zip SHA72d0cc00653ba733b1e55a00863d4e0ef38e554ab20f66e80fd0b2ca13b0a687으로통합. 최신authenticate read/정확verifySource3인자/실제Core동기검증factory모두포함. 포장중동작시험0,기존수치재합산0.
U4실제로컬확보위치 /workspace/reviews/p1-u4-rejection-input/guard.mjs, 원본ZIP /workspace/attachments/9ec1d4dd-6992-4e1d-a8f6-c3f11bac517b/IG04-U4-rejection-review.zip. 안정적인전달사본 /workspace/reviews/p1-core-latest-combined/handoff/inputs/IG04-U4-rejection-review.zip,추출원문 inputs/u4-original/. ZIP bdf5c6bb62a6de8bff6edad9d30f319539fb7cb6e596034a3adcaf8350cfe440/guard130e526b... 그대로검증. 다른사람PC경로나원격tree로대체안함. 이미로컬실제Core/U48PASS근거확보,기존Promise단위재실행없음.
첨부Server묶음server-core-read-handoff-20261106.zip SHA2ec143b48416b230acd13623abf04d245b6538e88aaf4b32c90ee9d0df8d52db 실제수신 /workspace/reviews/server-core-read-handoff-20261106, manifest110/110일치/sourceJava3는#111과LF정규화동일. source·인증소유문맥·기존fixture자료없다는옛차단은해소되었음. 실제운영get/HTTProute/권한source wiring미구현은묶음READ-FIRST에명시되어별도HOLD. historical reference-core를최신구현으로덮어쓰지않음. Git게시·runtime수정·새시험0/C2·C5·권한효과HOLD.


### 2026-11-06 #111 병합 확인 후 Core/U4 인증·현재성 추가 경계
원격PR API로#111 MERGED/merge bcf9cc129c718c6d2df73141d06137ae91be11e6/head66c28ebd 확인. 비활성Server병합을운영get/권한공급성공으로확대하지않음. 최신Core a4e25843/sourceadapter e0679480/U4guard130e526b 동일성유지. 기존실제Core→U4로컬8/8PASS재사용/재실행0.
직접누락되었던current인증401·현재성provider미확인2사건만추가,선택실행2/2PASS(FAIL/SKIP0). 전자는원래401오류동일성/reject및이전stored접수false,후자는current검증false에서접수/query거절을확인. 두사건모두전후모든metadata원문·기존local/watch/reservation/cleanup의무동일. 외부Server/native/auth는기존로컬fixture이며실제Core/U4코드를실행한localnoeffect시험,운영HTTP인증성공아님. 새testfixture의availability switch는운영provider가아닌음성사건재현용.
기존8과추가2를같은실행10PASS로표시하지않음. 신규test2+카드append만변경,Core/U4제품소스/Server/wiring변경0. 기존U4Promise단위/Core전체/제품/Content/Server시험미반복. 실제Worker→Content bridge·Server인증get/source생성/운영Native/current권한공급미연결,C2/C5·권한효과HOLD/Git게시0.


### 2026-11-06 공개 preparation read delta Core 담당 판정
첨부 public-read-contract.delta.diff SHA150916ae69564b22377cfc9bb0ac499b9fc0f55bdd920b70ebafa172e399901e 일치. 기존 Core request/adapter 변경 경계만 대조, 제품/HTTP/DB 시험0, 코드/route/Git 변경0. Core 담당으로 POST /api/v1/amvp/preparation-sources/read·E bearer 전용·exact4 요청/readAttempt2·canonical original/ref/version 결속·생성 digest Server 보호 journal 복원·SourceRead8/full-original UTF8 hash 방향 수용. client baseUrl=/api/v1에는 /amvp/preparation-sources/read를 전달. 기존 query는 그대로 JSON화 가능, token은 Content로 전달하지 않음.
정상 인증된 own-scope 저장 부재의 200 application/json null 안을 Core 선택(404안 미선택). U1은 해당 null을 SOURCE_ABSENT로 거절, U3 로컬 등록 부재 null과 별도. 일반404/인증/통신/UNKNOWN/손상은 reject. 401status 원본 보존·현 requestLifetime 종료·refresh 자동 재발행 없음·늦은 응답 새 수명 분리. Server SOURCE_CONFLICT를 일률 변환하지 않도록 실패 원인 분류가 필요하다는 원문 유지.
필수 문구 수정1: 다른 owner의 존재정보 비공개와 foreign reference403/부재200null은 관측상 구분 가능해 충돌. 403은 body.executor와 인증executor 불일치 등 target 존재에 의존하지 않는 경계로 한정. 인증 owner/executor로 scoped된 lookup에서 foreign reference와 missing reference는 동일 부재 응답으로 처리. private lookup이 이 인증된 scoped 부재를 반환할 때만200null, 일반403/404 catch-to-null 금지. Server 담당 변경분 합의 필요, 첨부 원문 덮어쓰기 없음.
구현 게이트: MemberExecutionClient.request는 비2xx를 status와 함께 throw하고 성공 JSON만 반환하므로 adapter에서 status/Content-Type 원본을 확인할 수 없음. 공개 응답의 exact200/application-json/8keys(or null)을 강제할 endpoint 전용 transport 검증 필요. 현재 #map은 추가 키를 엄격 거절하지 않으므로 무수정 연결 완료로 판단하지 않음. 공통 client 기본 동작을 완화하지 않는 명시 응답검증 hook 또는 endpoint 전용 transport로 합의 후 구현. 승인 path 미설정 network0 유지.
U4는 공개 SourceRead/null/error를 직접 받지 않고 기존 StoredPreparationRegistration+별도 trusted 관측을 받으므로 Core 측에서 3인수/동기boolean/복원의무 변경 불필요. Content 본인 승인을 대신하지 않음. Core wire 검토 의견만이며 공동 채택/route등록/DB·HTTP실행/운영권한 활성화 아님. C2/C5·실제효과HOLD/MVP_FINAL_COMPLETE=false.


### 2026-11-06 preparation read endpoint 전용 HTTP 상태 검증
담당 Core 종민, detached baseline ed8755a597973922d02bd675e80b00c410dfdaf4 + 기존 미커밋 공급본 기준. 사용자 승인 status 최소 보완 및 기존 strict 응답 요청 적용. MemberExecutionClient.request(path,credentials,body,headers={},options={})의 선택형 expectedStatus/expectedContentType 옵션을 추가. 기존 4인자 호출은 전체 2xx 허용 동작 유지, non2xx(status 포함)/인증 header/timeout/AbortController/credentials omit/redirect error/no-store 변경 없음.
ig04-p1-server-source.js의 readP1PreparationSourceHttp(client,credential,query)는 기존 제안 path /amvp/preparation-sources/read에 canonical query를 POST하고 options={expectedStatus:200,expectedContentType:'application/json'}를 전달. 정확 200만 JSON 검사로 넘기고 201/202/204 거절. 정확 SourceRead 8keys 또는 JSON null만 허용, adapter #map도 추가 키 거절. 타입/hash/owner/ref/version/수명 검증은 기존 adapter 유지. helper는 명시적 readAuthenticatedSource 주입용이며 자동 route/Worker wiring/호출/권한발급 없음. Server 담당은 같은 query/SourceRead 반환을 유지하면 되며 서버 소유 파일 수정0. 인증된 범위 밖/없는 ref 동일 부재 처리의 Server 구현은 이번 Core 코드로 보장하지 않음.
검증 별도 실행: endpoint wire 모의fetch 15/15, adapter 영향 선택5/5, 실제 Core+실제client+helper의 모의fetch 연결3/3 = 이번 비중복23 PASS / FAIL0 / SKIP0. 201/202 재조회 거절 후 이전 관측 false·기존 metadata 행 보존 확인. 기존 Core→U4 8/8+추가2/2 및 전체 제품/Content/Server시험 재실행0. 실제 DB/HTTP 실행/운영 인증/Worker bridge 검증 아님. 의존성 Node/fake-IDB 현재 환경 사용, 과거 실행 전체 바이트 동일성 미확인 유지.
전달: /workspace/reviews/P1-CORE-ENDPOINT-STRICT-STATUS-20261106.zip (소스·직전 원문·증분diff·로그·해시·기존 supplier ZIP 포함). C2/C5·운영권한·효과활성화 HOLD/MVP_FINAL_COMPLETE=false 유지. Git commit/push/PR0.


### 2026-11-06 endpoint 상태 옵션의 기존 공통 client 영향 보충
직전 endpoint 전용 status 옵션 변경이 공통 MemberExecutionClient.request에 위치하므로, 아직 실행하지 않은 기존 호출 경계만 선택 검증. member-execution-client.test.mjs의 commit 선행 POST/응답 유실 동일원문 재시도/403·409·422 격리와401·429·503 pending/command 응답 중 owner 전환/native fetch receiver 5건 선택실행 5PASS FAIL0 SKIP0. 실제IDB는 fake-indexeddb6.2.5, fetch는 모의이며 실제DB·HTTP실행 아님. endpoint23건 및Core→U4 8+2재실행0, 수치별도보존. 제품·시험소스변경0,문서append/보충ZIP만추가. C2/C5/운영권한·효과/Git제품게시 HOLD 유지. 다음 실행 전제는 Server의 동일wire 반영 정확 소스/tree/hash와 transport 검증 후보 결속 및 실제DB/HTTP 별도승인.

## 2026-11-06 하루 대행 인계 — 최신 정정 기준 (UTC 13:30 이후 대조)

이 절은 과거 누적 기록보다 현재 상태 판정에 우선한다. 신규 제품 보고서/계약 revision을 만들지 않고 실제 소스·작업공간·원격 PR을 대조한 인계다. 시험·빌드 재실행 없음. 추정 진척률/100% 완료 선언 없음. 인계 패키지의 MANIFEST.json과 원문을 확인하고 다른 날짜 ZIP을 무순서로 덮어쓰지 않는다.

### 1. 담당·전체 현황과 정정

| 범위 | 구현·Git 상태 | 실제 연결/검증·남은 최소 작업 |
|---|---|---|
| Core 기본 실행/정책·A1 | 기존 회원/비회원 Core 및 serial/Registry/복원 경로 구현. 통합의 실행 코드는 부분 제품 검증과 개별 PR 근거를 구분 | 추가 MVP의 일반 생산 loop/issued carrier/currentSync를 모두 연결한 상태가 아님. source 없는 신규 효과는 거절 |
| DNR 소유·journal | #55/#59/#68/#70 병합, #53 SITE_TIME 증거 등록 병합 | Chrome Native·Content 전체 수용과 별개. 기존 소유/fence/CAS/외부 rule 보존을 우회하지 않음. #92 증거 snapshot CAS 보강은 OPEN |
| 시간·전경·idle·관측 원장 | #38 관측 staging, #43 예약 pure helper 병합. #89/#90 복구/수명, #84 시간창, #91 보수한도 OPEN·APPROVED | 관측≠확정 측정. 운영 clock/boot anchor·day allocation·segment/reservation 원본·권한 carrier·Worker wiring·강제종료/공백·한도 해제 실제 수용 미완료 |
| 예약 claim | #46 OPEN f0c2d6bc211a40413c7e084892cef0a355b06dd0, MemberA1Adapter.claimSchedule/dispatchScheduleClaim | core.verifyScheduledDeadline가 실제 공급되지 않으면 POST 전 거절 유지. Server occurrence Actor는 다훈 담당. 같은 occurrence는 GET-only 회복, 새 claim/START로 대체 금지 |
| 예약 고정 종료 | #48 OPEN 46771453ab96f227c049e601d87daeb15ec85e04, member-a1/schedule-deadline.mjs ScheduleDeadline | verifyScheduledAdmission 기본 false. arm→ENDING 선저장→기존 endIntent/finish→실제 release 확인 부품. 명령 전 deadline gate/실제 alarm·startup·new boot/Server Actor/수용 미연결; #46 readiness를 자동 구현한 것 아님 |
| 정책 사유·한도 합성 | #94 OPEN, #91 OPEN, #84 OPEN | 판정 함수는 권한·실제 DNR 적용·확정 사용량 생성기가 아님. 원본/현재성 공급과 생산 caller 필요 |
| RPT-01 원장·outbox·ACK | #76 MERGED. #78 producer/#80 replay/#98 delivery OPEN·APPROVED | produce authorizeScope/verifyEvidence, outbox verifyReport/verifyAck, replay authorizeScope, delivery send/authorizeScope/isCurrent 운영 공급 미연결. bearer owner_key만으로 owner_binding_id/capability 권한 대체 금지. Server API/ACK 저장은 다훈 담당 |
| IG04 admission/Registry | #86/#88 admission/대기수명, #96 Registry 복구 OPEN·APPROVED | verifyIssued/verifyNative/isCurrent 운영 공급 별도. admission은 reserve commit/ACK/DOM 효과가 아님 |
| IG04 provider-store | 미커밋 ig04-provider-store.js/시험, 내부 저장·transaction/CAS 및 null→identity/closure 재조회 구현, 독립 저장 경계 수락 근거 있음 | guard 기본 거절. 실제 provenance·cutoff membership·coverage·watch 공통 원장/최종 소비/운영 ACK 미연결. 내부 closure는 DOM 복원/예약 terminal/watch_closed/전체 RELEASE 증거가 아님 |
| P1 U1~U3 | #88 detached + 미커밋. 인증 read seam/verifySource3/U1~U3/동기 관측/endpoint exact200 helper 구현·로컬 검증 | 운영 protected attempt/source importer·capture/isCurrent/native·Server 실제 endpoint 연결은 별도. 현재 sourceRef 공개 DTO는 실행 Snapshot/FocusRef/APPLY 권한 아님 |
| U4/Content | 지민 구현, reviewed guard 수신 및 실제 Core 동일 heap 연결 8+2 근거 있음 | Core 담당이 Content 파일 중복 수정하지 않음. Worker→Content 직렬화 bridge/복원 원장 실제 인수·ACK 소비는 미완료. Hash/WeakMap 객체를 메시지로 보내 인증할 수 없음 |
| Native 진단 | #100 설치 도구 MERGED. 별도 문서 root→identity→discovery, R1, Chrome root reader 로컬 구현; R1/Chrome 독립 검토 종료 | 실제 Native Main은 ATTEST-only, admission grant만 존재. 문서 인증/연속 writer 배제 producer/목적별 G1·G2-A root/discovery record·handler/wiring 미연결. b299 export/일반 재개/서비스/START 승인 없음 |
| 일시정지/재개 authority | 기존 정책 기능/해제 경로는 있으나 추가 MVP의 provenance·native/issued carrier 기반 실제 authority 공급 완료 근거 없음 | Server 상태·RootAuthority·Native binding·Core scope를 실제로 검증한 입력 필요. UI 지시는 다훈, DOM 적용·복원은 지민, Core 권한 검증은 종민. 운영 공급 미확인을 완성으로 기록하지 않음 |

Git 현재 대조: integration=bcf9cc129c718c6d2df73141d06137ae91be11e6, tree=709d19a87ebf7cf727dd8ca1bbdd0a527fcf76f7. #46/#48/#78/#80/#84/#86/#88/#89/#90/#91/#92/#94/#96/#98은 OPEN이며 reviewDecision=APPROVED. 이는 모든 담당 승인/CI/충돌/병합 준비를 보장하지 않는다. #76·#111은 병합. #105/#106/#87 Content는 OPEN, #83 CHANGES_REQUESTED. 옛 '다음 PR 통합 완료'로 읽지 않는다. 각 PR 최신 원격 상태는 실행 직전 재조회한다.

담당 정정: Server·DB/API·인증 HTTP·capability/registry 승인 공급·설치 배포·통합/merge는 다훈. Content DOM/receiver/U4/ClaimLedger 관측/복원은 지민(변경된 실제 배정은 다훈이 최종 확인). Core/Worker 내부 권한·순번·원장/CAS·DNR·Native handler는 종민. Native 승인/보존 공급은 다훈과 공동 경계. 내일 대행해도 다훈 작성분의 독립 Core 승인을 다훈이 대신 만들 수 없다.

### 2. 실제 작업공간·파일과 ZIP 적용 순서

활성 작업공간 /workspace/focurve-ig04-provider-local, detached HEAD/baseline ed8755a597973922d02bd675e80b00c410dfdaf4 (#88). 이 SHA에는 최신 P1/provider-store 파일이 들어 있지 않다. 새 product commit/branch/PR은 없음. Main /workspace/capstone-project는 work/1cddbbd0f1e4a1945337f5da5f17662aaad45633의 옛 main이며 최신 integration checkout이 아니다.
현재 dirty: 기존 카드/통합현황, member-execution-client.js 수정; provider-store/P1 준비/source-adapter 소스3, 해당 시험/provider시험/endpoint시험/Core-U4시험, 검토 guard fixture, 기존 evidence md untracked. 정확 목록·index SHA·파일 해시는 인계 패키지 workspace inventory/active snapshot 참조.
활성 파일은 archive의 current/가 최종 원문이다. core-new-files.diff 등 과거 component diff를 현재 원문 위에 다시 적용하지 않는다. 신규 모듈의 import 의존 a1/contract.mjs, member-a1/{db,store,contract,domain,d1,p1,schema}, contracts/additional-mvp/rc1/schema.json, server-time.js 및 package lock은 재현 baseline archive/공급 ZIP에 포함. U4 guard는 fixtures의 바이트 동일 사본이며 제품 Content 소스가 아니다.
최신 전달 순서:
1 P1-CORE-LATEST-READ-AUTH-U4-HANDOFF-20261106.zip SHA72d0cc00653ba733b1e55a00863d4e0ef38e554ab20f66e80fd0b2ca13b0a687 — 당시 auth/read3/supplier/Core-U4 8 묶음.
2 P1-CORE-U4-LOCAL-CONNECTION-FOLLOWUP-20261106.zip SHAca874d90e43f4180381dd0a9d2a629ff1c1aad106849b702836ba1400f787c9d — connection 시험만 2건 추가, 제품 소스 불변; 8+2 별도 실행.
3 P1-CORE-ENDPOINT-STRICT-STATUS-20261106.zip SHA040fbbaf8aaa24a0bfcac4190bc23fac47933201313b587956348f9987b0b203 — client 옵션·adapter helper/strict8·관련 시험이 1보다 최신. after 원문이 권위; before는 직전 작업본.
4 P1-CORE-SHARED-CLIENT-IMPACT-20261106.zip SHA1a2df021ea7ebc1934e4a3ca6b41c63ee6889d618ba1cc10c64c2299552d36c1 — 소스 변경 없는 기존 호출 영향5 로그.
이번 하루 인계 ZIP current/는 위 조합+최신 문서·보존 파일을 직접 제공한다. 과거69baf472 adapter는 authenticate(read) 없고 verifySource5인자라 사용 금지. supplier d5b70426는 endpoint 보완 이전; 최신 ZIP으로 덮어쓰기 금지.
기존 provider-store 검토 ZIP/Native 문서·R1·Chrome ZIP/P3/P4 기준은 inputs/에 보존한다. Native의 HANDOFF/manifest는 단계별 시점 기록이므로 현재 확정 상태는 본 절과 current-Native/원문 해시를 함께 본다.

과거 보존 작업공간: focurve-core의 adapter 초안/시험·bundle은 #46 이후 원문으로 덮어쓰지 않고 historical/에 격리. core-candidate-20261102 / core-seven-candidate / core-seven-final에는 staged 변경 23/31/31개가 남아 있음; 후보 통합 초안일 뿐 현재 integration이 아님. reset/clean/stash/pop/cherry-pick 금지, staged/unstaged diff·after bytes·상태를 보존. 깨끗한 기능 브랜치는 workspace inventory에 전체 HEAD/branch 기록. 공유 .git/worktrees index를 복사해 다른 기계에 설치하지 않는다.

### 3. 실제 composition·입출력·순서

생산 자동 wiring은 현재 없음. 실제 클래스와 조합 위치는 extension/tests/ig04-p1-core-u4-connection.test.mjs의 fixture/register/bind 및 ig04-p1-server-source.test.mjs의 setup({http:true}); 시험의 credential/native/capture가 합성이라는 점을 지우지 않는다.
순서(운영 실행 지시가 아닌 경계 설명):
1 실제 보호 provider가 같은 A1Store/SessionDB에서 authority token/A1 fence, 원래 read exactAttempt·version/sourceRef를 준비해야 함. IG04ProviderStore guard는 기본 false; 시험 fixture initialize/register를 운영 발급기로 복제하지 않는다.
2 trusted는 보호된 opaque 객체. capture(trusted)는 authorityId/token{lifetime_ref,revision}/requestLifetime/revision/sourceLocalId/sourceVersion/attemptLocalId/attemptVersion/nativeScope/binding{owner_key,executor_id,binding_id,epoch}/deadline를 반환. isCurrent는 동기 strict true여야 함. UUID fence와 정수epoch 혼용 금지.
3 IG04P1ServerSourceAdapter({providerStore,capture,isCurrent,attemptRecord,readAuthenticatedSource,now}) 생성. attemptRecord는 인증된 원래 localId/version만 조회. await adapter.authenticate('read',trusted,exactAttempt)로 보호 lookup/hash/ref/version/원문 검증; 동작은 Promise<void>. 실패는 reject, caller digest만으로 인증하지 않음.
4 seams=adapter.forContext(trusted)는 authenticate/verifyAttempt/sourceReader/verifySource를 공급. verifySource(trusted,source,attempt)는 정확3인자와 private lastRead 인증조회 기록을 사용.
5 IG04P1Preparation({store,client,...seams,capture,isCurrent,verifyNative,now,monotonic}) 생성. 실제 endpoint helper readP1PreparationSourceHttp(client,credential,query)를 readAuthenticatedSource로 명시 주입 가능하지만 현재 자동 설치 없음. client는 MemberExecutionClient, baseUrl은 /api/v1까지만; 경로 /amvp/preparation-sources/read, 기존 E bearer. 새 auth/get 운영 provider 없는 경로는 거절.
6 readP1Source(trusted,exactAttempt,expectedBinding,sourceRef)->검증된 source handle. query={executor,readAttempt:{requestId,original:canonical JSON문자열},reference:UUID,expectedSourceVersion}. sourceRef={id:preparationUUID,version:creation.savedRevision}; settingsVersion/Core registration version과 별개. Server가 생성 digest를 보호 journal에서 복원; 읽기 digest 대입 금지. 정확200/JSON/SourceRead8 또는 null만 wire 경계 통과. U1 null은 거절. 인증·통신·404·조회 미확정은 reject, current401은 원래 수명 종료/자동 refresh 재발행 없음.
7 보호된 원본 importer가 sourceLocalId 원문을 실제 IG04ProviderStore.register로 등록·commit 확인해야 U3 CAS가 통과. 이 importer의 실제 보호 권한/등록 연결은 미공급. read 성공만으로 source metadata를 신뢰 선언해 넣지 않는다.
8 verifyP1Preparation(trusted,exactAttempt,sourceRead,nativeScopeOriginal,expectedAttempt)->private verified handle. registerP1Preparation(trusted,exactAttempt,verified,expectedVersion=0)->StoredRegistration. 같은 DB 최종 txn에서 원래 attempt/source/version/fence 검사; 원격 current 조회와 로컬 CAS는 비원자. commit 후 현재성 실패는 저장 보존/소비 거절.
9 queryP1Preparation(trusted,exactAttempt)는 인증 source+native를 새로 검사. 인증된 local 등록 부재만 null. 저장 행만으로 관측 생성 금지. createP1ObservationVerifier(trusted,exactAttempt)->동기 stored=>boolean; 또는 원래 서비스.hasCurrentP1Observation(trusted,exactAttempt,stored). 동일 서비스·opaque trusted·동결 원래 exactAttempt·그 서비스가 반환한 stored 객체를 그대로 사용. clone/JSON/타서비스/타수명/철회 관측은 거절.
10 U4 createP1ConsumptionGuard(callback)->consume(trusted,consumeExpectation,stored), callback은 원래 기대값 대조 뒤 실제 Core 동기 검증을 strict true로 검사. 새 await/listener/adapter/정책loop/DOM 없음. test bind는 consumeExpectation=원래 동결 exactAttempt를 쓰는 로컬 예시이지 공개 DTO 확정 아님. WeakMap/private 관측을 직렬화한 Worker→Content bridge는 아직 없음.

이미 수신: #111 exact 소스·Java fixture·인증 소유문맥 handoff(2ec143...); 지민 U4 수정 ZIP bdf5c6bb62a6de8bff6edad9d30f319539fb7cb6e596034a3adcaf8350cfe440; 보충5시험 ZIP a3444c09c1ea684690b667bac1424b854690b3243b48315e0cd633827f7fb1bb. 같은 자료 재요청 금지. 추가 필요한 것은 403/scoped부재/strict endpoint까지 반영한 최신 Server 실제 코드·고정tree/hash/route·composition이며 사용자 보고의 Server 모의8PASS를 실제HTTP로 승격하지 않음.

### 4. 재현·build·검증 재사용

관측 환경: Node v24.19.0(프로젝트 >=24 <25), Python3.12.14, Java21.0.12.1, npm 존재. Maven 실행파일 없음(저장소 wrapper 유무는 해당 Server 작업본에서 확인); dotnet/csc/mcs 없음. Chromium executable 존재하지만 이번 인계 실행0. fake-indexeddb6.2.5(기존 lock), jsdom27.4.0. 로컬 node_modules는 재현자료가 아니며 패키지 lock을 기준으로 격리 복사에서 npm ci --ignore-scripts. 기존 전체 node_modules를 artifact로 동봉하지 않는다.
복원은 새 독립 디렉터리에서 baseline #88 추출 후 current/를 overlay(기존 index/다른 작업폴더에는 적용 금지). 실제 최신 integration에 올리는 것은 이 단순 overlay와 별개인 diff 대조/계약·독립검토 작업. 인계 검증 자체는 hash·파일/기준 대조만 실행했다.
필요 시 아래 명령은 격리된 복사에서만 사용; 기존 PASS 재현을 인계 조건으로 반복할 필요 없음.
- npm --prefix extension ci --ignore-scripts (개발 의존 설치, 제품 실행 아님)
- cd extension && node --test tests/ig04-p1-endpoint-status.test.mjs (기존 endpoint15)
- node --test --test-name-pattern='endpoint composition:' tests/ig04-p1-server-source.test.mjs (기존 composition3)
- node --test --test-name-pattern='follow-up:' tests/ig04-p1-core-u4-connection.test.mjs (기존 추가2)
- node --test tests/ig04-provider-store.test.mjs (provider 소스 변경 때만; 기존56은 provider9+admission47 묶음이며 이 파일 단독56으로 주장 금지)
- git diff --check는 Git 작업본에서만; extracted 재현폴더는 Git이 없으므로 무조건 명령 성공을 기대하지 않는다.
기존 근거: provider56 제출/독립 저장 경계PASS, Core 관측R1 독립9PASS(전달근거), 당시 Core44+adapter19=63, 이후 adapter24/supplier5는 별도 시점이며 합산 금지. 실제Core→U4 8+추가2 별도, 지민5 보충은 다른 작성자 근거, 현재 endpoint15+adapter영향5+composition3=해당23PASS, 공통client 영향5 별도. 과거 FAIL/변경 전 반례·SKIP 로그도 보존. 실행 당시 전체의존 hash/fakeIDB 바이트 동일성 미확인은 현재 파일 대조로 해소하지 않음.
생성기/산출물: scripts/build-member-worker.js의 bundleMemberWorker는 src/server-time,site-rules,member-journal-store,site-controller,member-execution-client,member-access,member-execution-loop→background/member-execution.js. scripts/build-a1.mjs buildA1→a1/content.bundle.js,background/a1-core.bundle.js. scripts/build-member-a1.mjs buildMemberA1→member-a1/content.bundle.js,background/member-a1-core.bundle.js,integration/member-a1-adapter.bundle.js. 입력 목록은 생성기 원문이 권위. scripts/build-a0.mjs도 기존도구 필요할 때만 해당원문 확인. 일반 build는 파일을 덮어쓰므로 현 실패/공유 working tree에서 실행 금지.
현재 endpoint 수정은 ESM src에만 있고 background/member-execution.js는 재생성하지 않았음. P1 모듈은 기존 worker bundler의 modules 목록에 없으며 이름 추가로 자동 활성화 금지. 제품 배포가 필요하면 별도 승인/정확 candidate 기준 생성·protected hash 영향·기존 legacy 검사를 대조해야 함. Native는 실제 Windows/.NET 컴파일·ACL·PID 시험이 필요하지만 여기 C# compile PASS 근거 없음. 기존 제출 Windows 합성15/10/1과 직접 로컬검증은 구분.
다음 최소 검증: 최신 Server source와 위 동일 query/SourceRead/오류/현재성 결속을 정적으로 고정→승인된 무효과 composition의 변경 경계만 모의 테스트→별도 승인받은 격리 실제DB/HTTP 후보에서 정확200/201·202/401/scoped부재/잘못된ref·version/유실·늦은응답/저장·의무보존 확인. 현재 실제DB/HTTP 사례 NOT_RUN. 운영 true stub, generic404→null, 관측 clone 재사용, callback 뒤 await로 수명검사 우회 금지.

### 5. 실행 자원·중단·복구·권한 횟수

관측한 이 컨테이너 PID namespace에는 Chrome/Native/mysql/mariadb/java/node 제품 프로세스 없음. listener 0.0.0.0:1040은 용도/소유 미확인 환경 서비스이므로 종료·재사용하지 않는다. git 프로세스 일부는 zombie(Zs); 직접 kill/lock 삭제하지 않음. dockerd/containerd·Codex 환경 프로세스는 제품 자원이 아님. 공유 .git/codex-index-refresh.lock 존재; index.lock으로 단정/삭제/강제복구 금지. 실제 Windows PC/설치/프로필/b299/datadir/nonce ledger·미해소 원장은 이 환경에서 접근 불가, 실행 중/종료/정리 완료라고 말하지 않는다. /tmp/codex-daemon-1000은 권한 거절로 미열람; 더 넓은 권한을 얻어 조사할 이유 없음.
이번 인계 실제 제품 실행 사용0. 과거 승인별 사용 횟수/기한/잔여를 증명하는 운영 승인 ledger는 여기 없으므로 숫자 추정 금지. 새 PC/새 PID/새 token에 과거 권한 자동 승계 불가. 명시적으로 허용된 범위는 로컬 무효과 구현·변경 영향 검증/ZIP 전달/요청받은 정확 PR리뷰이며 실제DB·HTTP/Chrome/Native/START/b299/export/Git제품게시·merge/env/pin/수동workflow실행은 별도 승인 필요. 내일은 상대 날짜이므로 실제 수행 시 승인 시점/범위/대상hash·격리자원을 다시 확인한다.
정상 종료는 자신이 새 승인으로 시작한 프로세스/격리자원에만 기존 runbook의 stop 절차 적용. 현재 정리 대상 제품프로세스 없음. 실패 시 UNKNOWN/HOLD·nonce 소비 미확정·ENDING·cleanup_pending/outbox/closure 원문을 보존; 완료로 조작/TTL연장/최근행추정/ended_at 생성/DB 삭제/설정초기화 금지. b299에는 일반 Chrome 재개 기능을 적용하지 않는다. 별도진단도 합의/새승인 전 실행 금지.
공유 수정주의: AMVP-CORE-04.md·AMVP-TIME-05.md·통합현황.md·additional-core-dnr.yml·member-execution-client.js·member-a1-adapter.mjs/생성bundle·Registry·.git/index/worktree index·원본프로필/DB·legacy外部root/pin은 여러작업이 참조. 대행 중 역할별 파일 소유를 먼저 알리고 원래 working tree/index를 건드리지 않는다. conflicts는 양쪽 작업/실패/미완료를 보존.

### 6. 미결정과 가능한 다음 작업

- C2(권한/registry 승인 생산자): 누가 어떤 보호 원문으로 실제 발급을 승인하는지/Receipt registry의 authoritative producer·현재capability 결속. 권고는 기존 Server authenticated source/registry 재사용, Native가 hash로 승인 창조 금지. 다훈 Server·설치 + 종민 Core/Native + 소비 영향 지민. 미결정이어도 무효과 원문 검증/반환 mapping·기본거절 구현은 가능, 실행권한 발급 불가.
- C5(강한 철회): 원격 철회 효력 시점부터 local 효과까지 어떤 집행 경계가 보장하는지. 동기 currentSync/Worker-local latch는 미전달 원격철회 해결 아님. 권고는 실제 authoritative 전이·집행 결속 입증; lease/유예를 임의 도입하지 않음. Server/Core/Content 공동 의미 결정. 무효과 현재성·이미 관측한 철회 처리는 구현/검증 완료 범위 재사용.
- P2 provenance: local_plan_id != identity.plan_id 허용 원본을 watch/context/instance/gate/version과 인증 결속; cutoff 뒤 null→identity는 정해진 membership/원래원문 범위에서만. provider-store의 guard 연결은 종민, producer/callback은 지민, 원문/호출 계약 조율은 다훈. 원래ID/hash 덮어쓰기·P3 checker 동일ID 조건 임시완화 금지.
- P3 cutoff/round: 인증된 고정membership/관측round 수명·동일원문재조회·새correlation 처리·최종CAS 정확형식 미확정. 권고는 같은 실행DB+target별 CAS, 미확정 이전요청 새소비 거절/재조회. Core+Content/통합 공동 결정 필요. 기존 공유 checker/우선 fixture NOT_RUN 계획을 운영검증 PASS로 바꾸지 않음.
- P4 coverage/closure: local/watch공통/예약terminal/전체RELEASE의 coverage·remaining 구분. constructor listener/scan/callback/input 잔여도 원장 보존. 진행scan0+예약scan0 합의 유지, fenced callback 예외 없음. Core guard/원장과 Content 실제 증거·callback 공동 확정 후 연결. source/proof가 없으면 close 거절.
- 진단 D1: Native가 문서 context를 무엇으로 인증할지. 문서 자기선언/UUID/origin/challenge echo만으로 충분하지 않음. Native private record·실측peer/newPID·독립문서provenance 결속 권고. 다훈 전달·설치/producer, 종민 Native 검증.
- 진단 D2: Worker 열리기 전부터 끝까지 writer 배제를 누가 연속보장할지. 기존 background-free 진단이미지 재사용 권고이나 cachedWorker/기존origin 배제는 manifest로만 입증 못함. installer/Native producer와 정식 전달 필요. 다훈+종민 공동. b299 원본 위험 있으면 실행불가.
- 진단 G1/G2-A: installer 명시승인·Native 목적별 영속record를 기존envelope와 분리해 발급/소비하는 권고, 제안이지 최종 승인이 아님. root identity 이전 GUEST owner 선가정 금지, admission은DB/export권한 아님. NativeDiagnosticAdmission.cs/DiagnosticGrantStore.cs 구현은 해당생산자/신뢰경계 결정 후. 15초절대기한·목적별nonce/미확정소비보존·동일새PID/channel 결속 필수.
비밀 공급: 계정별 정식 로그인/승인된 credential provider 또는 관리자 환경의 secret/variable 주입만 사용. token/private key/실제 root/grant/nonce/auth storage/프로필/DB를 ZIP·채팅·PR에 넣지 않음. 현재 Codex의 임시 GitHub 로그인 설정/환경 token은 인계하지 않는다. 다훈은 본인 GitHub 권한·독립 reviewer·실제 실행시 job token API 권한을 각각 확인; 본인작성PR 자기Approve 불가.

### 7. Legacy·리뷰와 내일 순서

#109 정확 efd128f4ac2fb31f3905730e52be9cd79d78e796/parent22b4e5e7950b922f89c7e831fd3d35d96f7b23bf/treebf444338a8fb2f62a1272968a6c83f7b97b0367b에 Core APPROVED 5800157200. Manifest4507bcf3d2ff53778765dd0953602de050844ce93ed5efe7844988d9e402b97f,353file/53build+bundle 정합. 원격 4workflow성공/Ubuntu·Windows contract실패,각legacy17은제출근거;상세log403으로직접재확인못함. 승인≠실패해소/병합/실행허가.
#115 정확784e936c2189f6c824b86ff149da211808bdf415/parentbd018fa9b129827544fe0930d6a854538ddbbf6c/tree41248e120975fef3e596336746d2327d426aace8은 Core CHANGES_REQUESTED 5800662350로 이미 검토종료. enabled=true일 때 operational_approval의 WORKFLOW_EXECUTION_NOT_GRANTED를 authorize/workflow가 검사하지 않음. 기존syntheticfixture+해당문구+기타권한충족에서authorize ACCEPT,root.enabled=false면거절. 외부pin bypass나실제실행관측 아님. 조치: 실행승인전enabled=false 유지 또는 독립적으로강제되는실행승인경계/외부root를유일실행승인으로보는정확발급계약보완. 아직Approve아님. 새HEAD면변경분만재검토. operatorkorean-kdh/229868807의ID/write확인은사용자전달근거,dispatch/jobtoken권한미확인·관리자pinUNKNOWN 유지.
#112/#113/#114는원격MERGED. #114의enabled=false는현재develop반영분, #115 enabled=true는OPEN후보라는점을분리. 컨트롤SHA와workflowSHA는외부root에정확pin할값이며승인없는root를여기서생성하지않음. 부트스트랩mainworkflow는항상exit1. 실제developworkflow는roothash/enabled/workflowSHA를checkout전검사→정확controlcheckout→launcher/trustpin검사→candidatecheckout→현재GitHub승인/부모/tree/전체checkout/tooling검사→실행전후재검사 순서. 현재설정/pin/실행완료를보장하는자료없음.
내일 시작순서/완료조건:
1 인계 ZIP hash·MANIFEST·APPLY-ORDER 검증, 본인 새복사에서만 current 원문확보. baseline/#88와현재integration 구분, 원본index/실패증거 보존. 완료=파일/기준/역할일치,시험재실행불필요.
2 다훈 보유 최신Server wire source/tree/hash/route·composition을 고정하고 Core helper/query/SourceRead/401·null/strict200 대조. 이미있는#111자료/U4 ZIP재요청안함. 완료=정확동일wire·인증/현재성/실패경계명시,불일치만수정;미공급이면그위치만기록.
3 기존승인 무효과범위에서해당수정의로컬변경영향만검증. 운영provider없는부분은기본거절. 완료=정확source/hash/log와저장·원래의무보존,모의/실제구분. 실제DB/HTTP는후속후보/승인전NOT_RUN.
4 #115는이미필수리뷰완료. 독립실행승인계약또는수정후보를다훈이준비해해당변경만비작성자검토요청. #109 legacy17을임의완화하지않음. #46등미병합CorePR을일괄merge하지않고원래통합순서/변경영향조건을따름.
5 P2~P4/진단미결정은기존선택질문과담당원문만대조. 새공유의미/실제발급/운영provider를대행자가단독확정하지않음.
독립리뷰: 지민은 Content 소비/복원·U4 영향 중 담당가능범위만 요청할 후보이며 내일 가용성은 미확인. 다른 비작성자 Core/Native reviewer의 지정/권한/가용성은 미확인. 다훈 대행작성 Core/Native의 독립판정은 적격리뷰어가없으면종민복귀까지대기,자기승인/대리서명/이전SHA승계금지. 자동CI도독립리뷰대체아님.
이전 PASS 재사용은정확소스·영향없는의존/시험조건·범위동일일때만. DB·HTTP실행,제품Git게시·PR/merge,환경·pin·수동workflow·권한발급·효과활성화는본인대행승인으로확대하지않는다. 전달용ZIP만testest게시허용을유지.


### 2026-11-07 한도 중단 후 인계 재개 확인
재개 시점 원격 재조회: #109 efd128f4ac2fb31f3905730e52be9cd79d78e796 OPEN/APPROVED, #115 784e936c2189f6c824b86ff149da211808bdf415 OPEN/CHANGES_REQUESTED 유지, integration bcf9cc129c718c6d2df73141d06137ae91be11e6 유지. 제품시험·build 반복0. 포장 전 실제 신규 빈폴더에 source-only 복원하여 current13파일 바이트 및 상대import19파일 누락0 확인. 이 검증은 dependency 설치나 제품실행이 아니다. 기존 실행시점 fakeIDB/전체의존 동일성 미확인 유지. 실행PC/b299/실제grant/pin/권한/승인잔여는 미확인, 기존HOLD유지. 최종 전달ZIP은 FOCURVE-CORE-DAY-HANDOFF-20261107.zip이며 11/06 스냅샷·과거로그를 보존하고 이번재개상태를 추가한 인계묶음이다. Git제품게시/새보고서/소스수정없음.


### 2026-11-07 대행 후속 — 인증 Server 재사용 연결 단위, C2/C5·Native 경계 정정

이 절은 기존 카드의 Core 전용 로컬 사본에만 추가했다. 공유 복원본/Server 카드/index는 불변이며 Server 담당 합의·공동 의미·적격 비작성자 승인 모두 대기다. 새로운 보고서/공개 API/Schema/운영 발급 승인 아님. 앞선 CHANGE-RECORD.json의 C5 이분법 질문은 아래 경계 구분으로 대체한다. helper 확장은 중단한다. 수명 결속기 7/7은 같은 heap의 합성 공급자 로컬 무효과 근거로만 재사용하며 운영 연결 성과로 계산하지 않는다.

#### 기준과 현존 생산자 — 회원 인증 ≠ capability 승인

기존 Server 카드 ADDITIONAL-RUNTIME-BRIDGES-20261029.md의 R2 Core 판정 C1/C2/C4/C5 및 R3 후속 문구를 재사용한다. C1은 Server 단일 lifecycle transaction·epoch 비재사용·보안철회 commit 효력과 cleanup 분리, old scope cleanup의 현재 caller/정확 대상 별도 인증이다. C2의 registry A는 방향 권고였으며 승인자·승인 근거·등록/철회 자격은 미선택이다. C5 S 강제 집행과 C 의미 변경은 둘 다 미채택이며 반복 조회/local latch/ACK를 즉시 철회로 쓰지 않는다. 이번 사용자 지시에 따라 강한 요구를 유지하고 의미 변경안을 제안하지 않는다.

MemberAuth.identity는 현재 회원/설치의 인증 주체를 제공한다. 그 결과로 capability 승인자를 만들지 않는다. AmvpP1ServerConnection의 authenticated 서비스/PolicySource.resolve와 preparation read는 설정·소유·준비 원문 경로이며 CapabilitySource와 자동 연결되지 않는다. AmvpPreparedCapabilitySource는 주입된 authority.verifiedSelection을 읽고 검증하는 어댑터다. recordVerified는 승인된 selection을 amvp_capability_receipts에 불변 저장하는 명시 writer이며 발급/승인/철회 주체가 아니다. verifiedSelection 읽기는 Receipt를 발급하지 않는다. 실제 authoritative registry producer·운영 authority 주입/승인자·서명/관리자 신뢰 경로는 확인되지 않았다.

C2에서 지금 공동 지정할 입력은 (1) 승인 권한을 갖는 실제 조직/역할/주체, (2) artifact/license/feature/profile 승인 근거, (3) 누가 어떤 인증으로 등록·철회를 수행할 수 있는지, (4) 보호 원문 위치·변경 이력·효력 기준이다. 권고는 Server가 이 승인 source의 소유·인증 reader를 맡고 Core가 소비 검증/보호 저장을 맡는 기존 분담이다. 회원 로그인·GitHub 리뷰·Native 실측 중 어느 하나도 이 자격을 자동 충족하지 않는다. 승인자 이름·registry 테이블·새 필드/서명 형식은 미지정 상태를 유지한다.

#### 다음 실제 Server→Core 연결 단위 — 구현 제안, 공급/합의 전 기본 거절

목표는 승인 주체가 실제로 공급한 보호 원문을 기존 인증 경로로 조회하고, Core 원래 요청과 같은 A1Store에 결속해 무효과 준비 등록까지 연결하는 것이다. 운영 issuer/START/APPLY/최종 소비를 이 단위에 포함하지 않는다. 기존 SourceRead는 capability 승인 봉투가 아니며 8필드에 승인 필드를 덧붙이지 않는다.

| 순서/담당 | 정확한 기존 입력 → 반환/책임 | 미공급 및 완료 조건 |
|---|---|---|
| A. 승인 원문 생산/Server 책임, 실제 승인 주체 공동 지정 | 승인 주체가 검증한 artifact hash·stream/feature/profile/license 범위와 등록/철회 자격·효력의 보호 원문. 이것은 아직 고정 DTO/함수가 아니다. Server가 실제 source와 인증 reader를 제시해야 함 | 로그인 principal로 자기 승인 금지. 권한 없는 등록/철회·승인 부재/UNKNOWN은 비성공. 생산자·원문 위치·검증 호출 근거가 명시돼야 종료 |
| B. 기존 capability 어댑터/Server | CapabilitySource.verifiedSelection(Identity principal, Binding binding, String stream) → 기존 strict CapabilitySelection. verifyContentProfiles(Binding, JsonNode content, ObjectNode selection) → 정상 종료 또는 reject. authority reader는 CURRENT·artifact/license/feature/profile·철회를 검사 | CapabilitySelection의 negotiation_id/executor_id/result/capability_receipt_id/verified_artifact_sha256/verification_ref/selected/expires_at/selected_feature_ids/owner_binding_id/owner_epoch를 유지. 새 approved=true/임의 issuer 없음. 실 authority 공급 없이 성공 반환 금지 |
| C. 명시 Receipt 저장/Server | AmvpPreparedCapabilitySource.recordVerified(principal,binding,stream) → selection. 기존 owner lock/write transaction·불변 Receipt·마지막 authority 재조회 뒤 commit. verifiedSelection은 같은 저장 Receipt와 재조회 일치를 확인하는 읽기 | reader가 receipt 생성/TTL 갱신하지 않음. 기존 동일 두 번 관측은 ABA/철회 fence 증명 아님. capability Receipt와 Core P1 registration/실제 APPLY ACK는 별개 |
| D. 준비 생성·기존 인증 조회/Server | createPreparation(trusted,executor,ExactAttempt,expectedBinding,settingsVersion,policyHandle) → 기존 StoredPreparation. 기존 E bearer 조회 query={executor,readAttempt:{requestId,original},reference,expectedSourceVersion} → 정확 SourceRead 8필드 또는 인증된 scoped 부재 null | PolicySource는 승인 원문과 정책/기한 결속을 누가 어떻게 확인하는지 Server 담당이 공급할 책임. B/C가 D를 승인한다는 연결은 현재 없음. 200 source 성공 ≠ capability 승인. 현재 endpoint/오류·원문 hash/version 의미는 불변 |
| E. capability 인증 관측 전달/Server↔Core 공동 경계 | B/C의 현재 인증 selection과 D의 preparation/원래 request/binding/epoch/artifact/scope를 어느 기존 인증 carrier와 보호 원문으로 결속할지 정확 함수·원문·책임을 함께 확정 | 현재 P1 SourceRead에는 capability/철회 revision 증거가 없다. 이를 있다고 가정하지 않음. 별도 인증 reader 주입 또는 승인된 기존 보호 원문 참조안 중 선택; 기존 8필드 변형·새 public DTO 단독 확정 금지 |
| F. Core 보호 결속/Core | 실제 opaque trusted에 연결된 capture/isCurrent와 원래 requestId/sourceRef·승인 관측·nativeScope를 준비한 뒤 기존 importer.saveReadAttempt/restoreReadAttempt → adapter.authenticate('read') → U1/U2 → importer source 보호 저장 → 기존 U3 register/query | guard는 같은 A1 metadata transaction의 owner/token/fence·원문별 승인·수명을 검사. token/lifetime_ref와 revision, server sourceRef.version/local sourceVersion/settingsVersion을 분리. 기존 저장·importer·client·검증자 재작성 없음. 실제 upstream 승인/native/current 부재는 거절 |

Server에 맞출 정확한 질문: B의 authority를 실제로 생산하는 승인 주체/등록·철회 인증 경로는 무엇인가? D의 PolicySource.resolve(opaqueHandle,Identity)와 E의 Core 인증 관측을 어떤 보호 원문에 결속할 것인가? 권고는 기존 CapabilitySource/recordVerified 재사용 + 기존 SourceRead 불변 + 별도 명시 인증 reader 경계다. 대안은 기존 보호 준비 원문에 대한 서버 내부 참조 결속이지만 현재 원문 형식에는 그 증거가 없으므로 공유 변경 영향/승인이 선행해야 한다. 반환에 없는 승인·revision을 Core가 추정하지 않는다. E가 확정되기 전 새 helper/가짜 registry 구현은 하지 않는다.

#### C5 — 효력 이후 신규 동작 차단과 기존 효과 정리 분리

1. 신규 발급/적용/최종 소비 차단: Server의 authoritative 철회 commit(기존 C1 보안철회 기준) 이후 old scope로 새로운 권한 발급·새 적용·마지막 소비가 허용되지 않아야 한다. Server 발급 transaction만 직렬화해도 Core 로컬 CAS→Worker/Content 실제 소비 사이 공백은 남는다. 현재 인증 조회 뒤 local CAS, hasCurrentP1Observation, U4 동기 검사와 local latch는 이미 전달된 철회/수명만 거절하며 전파 전 공백을 닫지 않는다. 최종 소비의 정확한 실행 지점·효력 순서와 집행 소유가 부족하다.
2. 이미 적용된 효과의 중단/cleanup/복원: 보안철회 commit은 cleanup 완료/RELEASED/복원 terminal이 아니다. 적용 중 효과에 대한 새 실행 중단과 기존 DNR/DOM/watch/reservation/outbox 의무를 보존하고, 현재 caller·정확한 과거 대상 scope의 별도 cleanup 자격을 검사해야 한다. 폐쇄 binding/과거 Grant로 정리를 승인하지 않는다. 실제 effect writer 배제·Content 복원·DNR release 재조회·durable coverage/remaining/closure/terminal 증거는 별도 미연결이다. 원장 삭제/강제 CLEAR/성공 ACK 소급 생성 금지.

강한 요구를 유지하는 구현 대안(모두 공동 미채택):
- S1: 실제 최종 발급/적용/소비를 authoritative 철회와 같은 직렬화 집행 경계로 보내고, 실제 효과 수행까지 그 순서를 유지하는 경로를 입증한다. 단순 온라인 허가 응답 뒤 로컬 실행은 여전히 gap이므로 충분하지 않다. Server가 허가를 결정하고 Core/Content 집행이 같은 순서를 보장할 수 있는지부터 검증할 최소 설계가 필요하다.
- S2: 실제 모든 writer/최종 소비자를 fence하고 in-flight 작업을 정리/퇴역한 뒤 authoritative 효력 전이를 직렬화하는 프로토콜을 검토한다. 불가용 executor·유실·재시작 시 완료를 기다리거나 활성화를 거절해야 하며 기존 즉시 commit 효력 시점을 임의로 늦추지 않는다. C1 효력과 양립하는지 공동 검토가 필요하고 단순 ACK를 강제 배제로 취급하지 않는다.
- S1/S2가 성립하지 않는 현재에는 운영 활성화 HOLD가 유일하게 주장 가능한 상태다. polling/TTL/lease/관측 후 차단으로 요구를 낮추지 않는다. 지금 선택할 질문은 보장 약화 여부가 아니라 '어느 실제 writer/최종 소비를 어떤 authoritative 철회 순서와 동일하게 강제할 수 있는가, 실패·불가용 시 무슨 경계가 실행을 막는가'다.

이미 적용된 효과 정리의 완료 조건은 신규 소비 차단과 별도로 확정한다. 정리의 권한·소유·재시도·증거/terminal이 공급되기 전 cleanup 완료나 강한 철회 전체 PASS로 표시하지 않는다.

#### Native — P1 공급과 진단 root/discovery는 다른 경로

| 경로/생산자 | 증명 가능한 항목 | 별도 부족 항목/기존 소비 위치 |
|---|---|---|
| installer/Native private record | 신뢰가 성립한 발급·ACL·실측 경로에 한해 pinned image/artifact, 설치/프로필 바인딩, 목적/기한/nonce와 소비 이력. 현재 NativeDiagnosticAdmission/DiagnosticGrantStore의 ATTEST·ADMISSION_ONLY_NO_DB_OR_EXPORT 범위 | 설치 기록만으로 현재 브라우저 document의 독립 출처나 전 기간 writer 배제를 증명하지 않음. 실제 발급/Windows ACL/PID 시험도 이번에 미실행 |
| 독립 browser-context provenance 생산자 | 문서가 주장한 UUID/origin/시간/challenge echo와 독립적으로 실제 browser/profile/origin/document/context 및 채널·peer·새 PID를 결속해야 함 | trustedDocument() 운영 생산자 미공급. 문서 자기선언/설치 기록으로 대신하지 않음. Native 문서 인증 완료 아님 |
| 연속 writer 배제 생산자 | 문서 열기 전부터 종료까지 실제 Worker/background/cached worker/기존 origin writer 배제와 중단/실패 증거를 생산해야 함 | verifyPreactivationEvidence 운영 생산자 미공급. background-free manifest나 최초 snapshot만으로 연속 배제 아님. installer/Native와 browser 경계 공동 책임 |
| P1 제품 Native 공급/Core·Native | verifyNative(trusted,nativeScopeOriginal,snapshot,exactAttempt)가 원래 attempt/owner/executor/binding/epoch/요청 수명·대상 scope와 인증된 Native 관측을 검증 | ATTEST/admission 결과를 capability 승인/배포권한/P1 검증 성공으로 변환 금지. 운영 Native 원문 공급/검증 연결 없음 |
| 진단 root/discovery/설치·Native | 목적별 root/discovery grant, 같은 제한 세션의 문서 provenance/보존·writer 배제, root confirm→discovery 순서 | document-provider.mjs의 trustedDocument/verifyPreactivationEvidence, NativeDiagnosticAdmission.Main handler 및 목적별 grant 생산이 별도 필요. Main ATTEST-only 유지. P1 승인 source와 공유 권한으로 합치지 않음 |

#### 담당별 변경 파일과 단위 종료 조건

- Server 담당만 수정: AmvpPreparedCapabilitySource.java/AmvpBridgeSupport.java의 기존 주입 경계, 실제 승인 authority reader/writer(현재 부재, 파일명·저장소 형식 미확정), AmvpP1ServerConnection.java의 PolicySource 연결 및 필요 시 기존 인증 composition. 실제 등록·철회 자격/원문 공급과 E 경계 합의가 먼저다. Server·DB·HTTP 파일을 이 채팅에서 수정하지 않는다.
- Core 대행: 승인 source/인증 관측이 공급된 후 실제 private composition·guard 연결 후보(현재 미작성), 필요하면 member-a1/authority.mjs·additional-ig04-admission.js의 해당 경계만 담당 조율 후 변경. 기존 ig04-provider-store.js/ig04-p1-preparation.js/ig04-p1-server-source.js/client/importer는 원문 재사용 우선, 바꿀 확인된 결함은 현재 없음. bound-lifecycle helper 확장/자동 Worker wiring 없음.
- Native 대행: 생산자 계약이 공급된 뒤 NativeDiagnosticAdmission.cs/DiagnosticGrantStore.cs 및 document-provider.mjs/direct-native-channel.mjs의 필요한 handler/검증 연결만. 설치 측 writer·browser-context 생산자는 해당 담당 소유이며 미공급. P1 Native와 진단 grant의 권한을 합치지 않는다.
- Content 지민: 실제 최종 소비/fence·이미 적용 효과 중단/복원·cleanup/coverage/terminal 경계가 변할 때 해당 파일만 요청한다. 기존 U4 3인수/동기 boolean 유지; 이번 코드·시험 변경 없음. Shorts는 별도 담당이다.

다음 무효과 연결 단위 종료 조건: A/E 실제 입력·반환·소유와 승인 근거를 한 후보에 고정 → 기존 인증 reader/Receipt와 원래 preparation/request/binding/epoch/scope의 검증 가능한 결속 → 같은 Core 저장/CAS·재조회에서 권한 없는 등록/철회·부재/UNKNOWN·원문 충돌·만료/철회·owner 전환·늦은 결과 거절 및 원문/cleanup 의무 보존. 새로 연결된 경계만 관련 검증하며 기존 시험을 반복/합산하지 않는다. 운영 producer가 대역이면 로컬 무효과 근거로만 기록하고 제품 연결 완료로 표시하지 않는다. C5 실제 효과·복원 수용은 후속 별도 완료 조건이다.

이번 변경은 본 기존 카드 로컬 사본의 후속 절과 이전 CHANGE-RECORD 정정뿐이다. 새로운 제품 코드/시험/실제 실행/권한 발급/Git 게시/활성화 없음. 공동 의미·Server 경계 조율·적격 비작성자 독립 승인 PENDING, C2/C5 HOLD, M1 BLOCKED, 제품 수용 NOT_RUN, MVP_FINAL_COMPLETE=false.


### 2026-11-07 protected-source-supply 변경 범위 독립 기술 검토 접수

사용자 전달 REVIEW-RESULT.json을 직접 읽고 importer 소스/시험 2파일과 patch hash를 해당 검토 기록에 대조해 모두 일치 확인했다. 경로 표기의 dahun.codex는 실제 존재하는 dahun\.codex 경로로 확인했다. 정확 근거: C:/Users/dahun/.codex/visualizations/2026/10/30/01a18bb7-1814-7ff3-a90d-ce2857c0a7c8/pr99-review/protected-original-importer-review/REVIEW-RESULT.json.

제출 14/14 PASS와 독립 기술 검토 5/5 PASS는 별도 실행·범위로 재사용하고 합산하지 않는다. 독립 5건은 승인 throw rollback, attempt guard 중 revision 전이 rollback, commit 뒤 requestLifetime 변경 시 원문/의무 보존, 동일 owner의 fence epoch 변경 시 restore 거절, 같은 승인 attempt의 idempotent save다. 기존 의존12 동일성은 독립 검토 기록의 근거이며 이번에 시험/검토를 재실행하지 않았다. mock endpoint/credential/approval/currentness/native·fakeIndexedDB 한계를 유지하고 실제 importer DB/HTTP/Worker/Native/효과/복원 수용 PASS로 확대하지 않는다.

이 결과는 PASS_SCOPED_INDEPENDENT_TECHNICAL_NOT_FORMAL_CORE_NONAUTHOR_APPROVAL이며 정식 Core 적격 비작성자 담당 승인은 별도 PENDING이다. importer 재작성/helper 확장 없음.

Server에 동일 C2 후보 대조 요청이 전달됐다는 사용자 지시를 접수했다. 회신에서는 실제 승인 생산 원문, CapabilitySource.verifiedSelection/verifyContentProfiles, recordVerified commit, preparation PolicySource 및 Core 보호 관측 결속의 실제 입력/반환 차이만 반영한다. 공급되지 않은 registry/승인자/carrier를 구현 완료로 추정하지 않는다. 사람의 선택은 실제 승인 주체·등록/철회 자격과 보호 원문/reader 결속 중 회신 후에도 남은 항목만 한 질문 묶음으로 요청한다.

C2 무효과 연결 합의와 C5 신규 발급/적용/최종 소비 강제 차단 및 기존 효과 중단/cleanup/복원 조건은 별개다. C2 방향 선택/로컬 PASS가 C5 해소나 운영 발급·실제 활성화를 승인하지 않는다. C2/C5 HOLD, M1 BLOCKED, 제품 수용 NOT_RUN, MVP_FINAL_COMPLETE=false 유지.


### 2026-11-07 C2와 독립 병행 — 기존 RPT replay→delivery 호출부 연결

현재 원격 read-only 대조: #46 f0c2d6bc/#48 46771453/#78 6bddd0c1/#80 62c02aac/#98 505e9738 모두 OPEN. 정확 HEAD는 기존 CHANGE-RECORD.json runtime_report_connection에 고정. 승인/CI/병합 준비를 추정하지 않음. #78/#80/#98 현재 source와 인계 references 원문 LF 일치. 과거 patch 일괄 적용 없음.

후보 비교: 예약 claimSchedule/dispatchScheduleClaim의 core.verifyScheduledDeadline 미공급 시 POST 전 거절, ScheduleDeadline.arm의 verifyScheduledAdmission 기본 false 유지. enforce/check/onAlarm의 ENDING 선저장·finish/RELEASE 부품은 있으나 실제 alarm/startup/new-boot/명령 전 gate·Server occurrence actor는 별도 효과/소유 경계. #89 현재 변경 파일/패치의 AdditionalObservationJournal.recover/start/append는 원문·epoch·의무·snapshot CAS 복구, #90은 idle/foreground callback 수명 격리이며 실제 Worker/clock/day allocation 공급자가 아님. #84 시간창과 #91 calculateConservativeBudget은 판정 함수로 collector/boot anchor·확정 debit/gap/day/reservation 생산·저장이 남음. 이들을 true/정상사용량/DNR 허가로 대체하지 않는다.

선정 문제: #78 producer journal만 있고 outbox가 비어 있으면 기존 #98 delivery는 replay를 호출하지 않아 제출0으로 끝남. 기존 #80 replay/outbox/#98 부품을 재사용하고 새 helper 없이 기존 delivery caller만 연결했다.

충돌 조율: 「FOCURVE — Web·Server·DB·UI 통합 및 회귀」에 정확 범위를 통지했고 담당이 delivery/replay 수정 없음을 회신. Core 전용 사본의 extension/src/additional-runtime-report-delivery.js만 수정. optional replay=null 지정 시 RuntimeReportReplay·동일 outbox 객체를 요구. authorize/current → replay 완료 → authorize/current 재검사 → 기존 batch/send/ACK 순서. 미지정 기존 직접 delivery 불변. 부분 replay 실패/취소 시 batch/send 없음; 이미 handoff된 원문/의무 저장을 rollback했다고 주장하지 않는다. 기존 producer/replay/outbox/client/P1 helper/importer·공유 Worker/DB/index/Server/Content/Shorts 불변. 운영 auth/current/send/ACK provenance 부재는 기본 거절.

완료 조건/검증: 변경 전 선택1건 FAIL(실제producer2건이지만 제출0/기대2). 변경 후 새 연결7/7 PASS: 실제 producer/replay/outbox/delivery 연결, 부분 replay 실패 전송0·prefix/원문 보존, 재생성 후 응답유실 동일 batch bytes 재사용, replay 중 권한변경 차단, 다른 outbox 주입 거절, 기본권한 부재 거절, stop 후 handoff commit 보존/전송0. 기존 delivery 영향4건 별도4/4 PASS(기본거절/빈outbox/ACK commit/유실재조회). 기존 전체24/실HTTP 시험 미실행. Node24.19.0·fake-indexeddb6.2.5; auth/evidence/current/send/ACK 합성. 구문/공백 PASS. 7과4는 별도 실행이며 과거PASS/제품수용과 합산하지 않는다.

정확 source/patch/hash/기준 및 로그는 CHANGE-RECORD.json runtime_report_connection, baseline-runtime-report/delivery-connection.diff, runtime-report-connection-tests.log, runtime-report-delivery-impact.log에 연결. local composition 연결 단위 완료이며 실제 Worker wiring/Server/clock/DNR/효과 제품수용 NOT_RUN. 독립 담당 승인은 PENDING이고 로컬 구현 가능/완료와 별개.

C2 별도 회신: Server 전달 사용자 선택은 김다훈 승인/철회 책임·Server 내부writer·SQL 원문/전이이력/current revision·Receipt 불변·SourceRead8 불변+preparation 연관+별도 인증reader 방향. 운영 writer 인증은 미확정/기본거절. 실제 private reader 입력/반환 공급 전 Core provider/importer/client/U4 변경 없음. C5 해소로 취급하지 않음. 실제 DB/HTTP/Chrome/Native·Git 게시·운영권한/효과활성화 없음. C2/C5 운영HOLD, M1 BLOCKED, MVP_FINAL_COMPLETE=false.


### 2026-11-07 RPT replay 연결 기술 검토 종료·다음 Worker/인증/provenance 경계

사용자 전달 runtime-report-delivery-connection-review/REVIEW-RESULT.json 직접 확인. 실제 경로는 C:/Users/dahun/.codex/visualizations/2026/10/30/01a18bb7-1814-7ff3-a90d-ce2857c0a7c8/pr99-review/runtime-report-delivery-connection-review/REVIEW-RESULT.json. candidate/baseline/patch/test 및 producer/replay/outbox3 의존 원문 hash 모두 검토 기록과 일치. 제출 연결7/7·기존 영향4/4·독립 기술3/3은 별도 실행 근거이며 합산/재실행 없음. 독립3건은 replay 후 재인증 거절, replay timeout 뒤 늦은 완료의 전송 차단, ACK 저장 실패 후 동일 body 재전달·원문 보존이다. 로컬 변경 범위 기술 검토 CLOSED_PASS. 정식 Core 적격 비작성자 담당 승인 PENDING은 별도 유지. importer/수명helper/RPT 모듈 재작성·확장 없음.

기존 Worker caller 대조: background/member-execution-runtime.js의 getLoop는 MemberAuthRuntime.credentials/status와 MemberExecutionClient/MemberExecutionLoop를 생성하고 tick은 기존 command/effect loop를 진행한다. src/member-execution-loop.js의 saveReport는 기존 command/session ExecutionReport를 control row에 먼저 저장한 뒤 client.enqueue하고 tick의 회복 경로가 row.reports를 재enqueue한다. MemberExecutionClient.flush/deliver는 /executors/{executor}/reports의 기존 ExecutionReport 및 {result,desired_revision} ACK를 사용한다. 이 경로는 RPT-01 ReportBatch/BatchAck와 형식·원장·의미가 다르며 대체/혼용하지 않는다. scripts/build-member-worker.js modules 목록과 export에는 RPT producer/replay/outbox/delivery가 없다. Schema 문자열이 생성 bundle에 있다는 것만으로 caller/wiring 존재를 주장하지 않음. RPT reader를 얻으려고 getLoop/tick을 켜지 않는다.

| 정확한 미연결 함수/호출부 | 필요한 실제 입력·공급 | 담당/다음 수정 경계 |
|---|---|---|
| RuntimeReportProducer.produce({generation,report})의 authorizeScope/verifyEvidence | durable source의 안정 report_id, generation, operation/package/runtime_execution ID, runtime revision·owner_binding/executor·상태/사유·observed_at·evidence 원문, 현재 issued/effect/전이·predecessor 근거. hash만으로 실제 효과 인정 금지 | Core는 기존 issued/DNR evidence 원장으로부터 실제 source mapping을 공급. Server의 발급 원문/검증 경계와 맞춤 필요. 원본 observation producer 미공급 시 produce 거절 |
| RuntimeReportReplay.authorizeScope 및 RuntimeReportOutbox.authorizeScope/verifyReport | report의 owner_binding_id/executor_id와 실제 현재 binding/epoch·RUNTIME_REPORT capability·발급/효과 원문 결속. bearer MEMBER:user만으로 binding 승인 금지 | Core 보호 composition/guard, 인증 binding/capability reader는 Server 공급. 현재 신규 공개 DTO/임의registry/true provider 없음 |
| RuntimeReportDelivery.send(body,{signal,isCurrent}) | 기존 canonical batch bytes를 변경하지 않는 인증 transport, E credential 및 실제 RPT scope 결속, credential/capability await 뒤 실제 IO 직전 isCurrent 재검사, 원래 응답과 요청의 인증 결속. 취소/유실 뒤 원문/batch 보존 | Core transport composition와 Server 인증 carrier 책임. 기존 client.request('/amvp/reports/batch',credential,body)는 저수준 후보일 뿐 report 권한/current/응답 provenance를 생성하지 않음. client.request의 자체 timeout/AbortController와 delivery signal/current 계약 연결도 미제공. 단순 path 교체로 완료하지 않음 |
| RuntimeReportOutbox.verifyAck(owner,batch,ack) | 같은 인증 요청/서버·owner/binding 수명에 결속된 BatchAck provenance. 기존 batch_id·item_id·payload_sha256/항목 status 대조는 필요하지만 인증 source 자체가 아님. raw message/caller의 ack를 신뢰하지 않음 | Core 인증 transport가 보호한 원래 response 관측을 validator에 제공해야 함. Server는 실제 committed 항목별 응답 경로 책임. API 성공/Report ACK는 APPLIED/RELEASED/cleanup 완료 증거 아님 |
| AmvpReportApi.batch → AmvpReportReceiver.EvidenceVerifier.verify(principal,binding,report,issuedPackage,predecessor) | 실제 operation/execution/current epoch·합법 전이·fresh observation·evidence_sha256 뒤의 원문. 삭제된 SITE_TIME는 이전 claim/version/footprint의 정확 release 근거 필요 | Server 담당의 EvidenceVerifier/CapabilitySource 주입. 현 API는 공급자 부재 503 CAPABILITY_NOT_VERIFIED 및 property 조건 유지. Bean/HTTP/DB는 이 채팅에서 변경/실행하지 않음 |
| Worker의 RPT caller 및 번들 공급 | 위 provider를 공급받은 전용 trusted composition, 어느 원래 producer commit/명시 recovery 시점에 단일 deliver를 호출할지, 같은 store/owner/boot 수명과 stop·재시작 책임 | Core Worker 담당·공유 Worker/Shorts/통합 소유자 사전 조율 후 해당 caller/bundler만 수정. 현재 getLoop/tick/기존 report loop에 임의 접속 금지. 공급자 없는 현재는 미연결/기본거절 |

다음 최소 작업은 실제 RPT evidence source/검증자와 인증 binding/capability reader 입력·반환 공급을 맞춘 뒤 기존 delivery의 send/verifyAck 주입을 같은 후보에서 연결하는 것이다. 현재 확인한 Worker/전송/provenance 경계에는 공급자 없이 의미를 보존한 추가 코드 연결 단위가 없으므로 가짜 양성/provider/helper를 추가하지 않았다. 이는 RPT 다음 경계의 차단이며 Core 전체 개발 대기 판정은 아니다. 완료된 로컬 replay 연결을 다시 구현/시험하지 않는다.

새 소스/시험 실행/Worker·인증 HTTP/DB/Chrome/Native/Git 게시/권한·효과 활성화0. 공동 의미와 정식 담당 승인 PENDING, C2 공급 준비와 C5 신규 발급/적용/최종소비 차단·기존 효과 cleanup/복원 수용은 별개. 운영HOLD, M1 BLOCKED, 제품수용 NOT_RUN, MVP_FINAL_COMPLETE=false.


### 2026-11-07 Server C2 private reader 후보 입력·반환 대조

c2-registry-candidate/RESULT.json·CORE-READER-CANDIDATE.json·AmvpC2Registry.java를 읽고 소스4파일/reader hash 모두 일치 확인. Server의 직접 reflection/assertion15PASS는 Memory repo/auth/source/SQL 대역의 별도 제출 근거이며 Core 연결/실DB/HTTP PASS가 아니다. 재실행/Server 코드 수정 없음. 기존 strict CapabilitySelection required11필드는 현재 schema와 일치한다.

| 실제 입력/반환 차이 | Core 연결 조건·담당 |
|---|---|
| readPreparationApproval(trusted,executor,reference,expectedVersion,stream)는 Core readAttempt를 인수로 받지 않음 | executor/ref/version은 기존 capture.binding.executor_id·동결 exactAttempt.sourceRef에서 취함. 별도 carrier가 반환을 원래 readAttempt/요청수명·목적stream에 인증 결속해야 함. IG-04 feature를 stream으로 쓰지 않음. Server carrier 공급·Core 보호 composition 책임 |
| 실제 Observation 필드는 preparationLink가 아닌 preparation이며 Link 타입 | approval/approvalRevision/approvalOriginal/approvalSha256/selectionJson/preparation/observedAt/expiresAt의8필드. SourceRead8과 합치지 않음. 일반 JSON을 인증 관측으로 수용하지 않음 |
| approvalOriginal owner는 user 문자열, Core owner_key는 MEMBER:user | executor/binding/epoch와 capture의 executor_id/binding_id/epoch도 대조. 전체 canonical 원문 UTF8 hash와 strict selection11필드 동일성 및 목적stream/feature를 검증해야 함. approvalRevision은 별도 registry revision이며 원문에 임의 추가해 재hash하지 않음 |
| Link는 preparation/version/hash 및 생성 request/digest를 결속 | preparation/sourceVersion/sourceSha256는 인증 SourceRead.sourceRef/sourceVersion/rawSha256. creationRequest/creationDigest는 raw의 Server 생성 requestId/requestDigest와 대조, Core readAttempt digest로 대체 금지. Link approval/revision/hash는 Observation, receipt/selectionSha256는 불변 selection/Receipt에 결속. settingsVersion/Core local row/CAS와 별개. JS 소비 숫자는 safe-integer 범위 필수 |
| observedAt과 expiresAt은 별도 인증 조회 관측/최소기한 | 준비·승인 최소 기한 외 새 TTL/갱신 없음. observedAt/반복 조회/SQL lock은 remote-current lease나 C5 즉시집행 보장 아님. evidence 원문/hash/범위 후보는 실제 artifact/license/profile 검증 생산 완료가 아님 |
| bindInTransaction은 preparation owner transaction의 enlisted write 전제 | recordVerified·Link 저장이 실제 알려진 transaction에 결속돼야 함. 현재 standalone readOwnedSource의 own transaction을 그대로 주입해 동일 transaction이라고 주장할 수 없음. 실제 PreparationReader·MemberReader·WriterAuthority·Profiles 및 enlistment adapter는 Server 미공급/기본거절 |
| private 승인 reader 부재/철회/stale/UNKNOWN reject | 기존 SourceRead 인증 scoped 부재200null 및 U3 local 등록 부재null과 별개. 새 공개 status/null/route/DTO를 채택하지 않음 |

다음 최소 공급은 Server의 실제 preparation transaction enlistment adapter와 별도 인증 reader carrier·응답 provenance/현재revision 입력이다. 이를 받은 뒤 Core는 기존 trusted/exactAttempt/수명에 Observation을 보호 결속하고 IG04ProviderStore.guard에 원문별 승인 입력으로 연결한다. guard의 동기 metadata transaction 안에는 remote await를 넣지 않으며 사전 인증 관측의 출처·수명·local fence 검사 범위를 명시한다. 이것으로 전파 전 C5를 보장하지 않는다. 현재는 새 helper/검증자/DTO나 importer/client/U4/capture shape 변경 없음.

남은 사람의 선택은 운영 WriterAuthority의 실제 인증 수단·principal/APPROVE·REVOKE 자격·신뢰 provisioning이다. 김다훈 승인/철회 책임 선택은 재질문하지 않는다. carrier/transaction adapter는 우선 담당 구현 공급 항목이다. source 코드의 responsible 문자열만으로 운영 writer 인증을 완료 처리하지 않는다. 공동 의미·정식 비작성자 승인 PENDING, C2 inactive 후보와 C5 강한집행/cleanup 조건은 별개. 실제 실행/발급/활성화0, M1 BLOCKED, MVP_FINAL_COMPLETE=false.


### 2026-11-07 C2 safe-integer 증분 접수

Server 최신 RESULT와 소스4/reader hash 일치 확인. Registry e8724810332e6ebe39e3562ef5fb6068ab4373c2a0e6573996728a92960680e3가 현재 기준. source/expectedVersion과 source expiry millis에 양수·MAX_VERSION 범위 검사를 추가한 경계만 확인했다. 이전15단계 RESULT/diff는 stage-15pass-RESULT.json·stage-before-safeinteger.diff에 보존됨. 최신16PASS는 같은 Server Memory/auth/source/SQL 대역 direct reflection harness 최종 단계 근거이며 이전15와 합산하지 않고 Core 재실행0. reader hash/입력·반환·SourceRead8/client/importer/U4 불변. 실제 carrier/preparation enlistment adapter 미공급·운영 writer 인증 선택/적격 비작성자 승인 대기·C5 HOLD 유지. 제품코드/시험/실제실행/발급/활성화 변경0.


### 2026-11-07 RPT Server 5인자 EvidenceVerifier와 실제 Core 저장 위치 대조

Server 담당 전달: POST /api/v1/amvp/reports/batch → AmvpReportApi.batch → AmvpReportReceiver.batch의 항목별 재인증/REQUIRES_NEW receive → 현재 binding/RUNTIME_REPORT capability → amvp_packages 원문/hash → EvidenceVerifier.verify(principal,binding,report,issuedPackage,predecessor) → VerifiedReport(affectedPolicies). 실제 issued/effect/현재generation·epoch·claim 원문 lookup provider는 Server에도 미공급. 새 Wire 없이 가능한 최소 mapping을 기존 Core 원문에서만 확인했다.

Core의 현존 원본 위치:
- member-a1/authority.mjs RootAuthority.current/claim/released: metadata member:root-authority의 authority/owner_key/executor/session/epoch/phase. 이것은 기존 session/root 의무이며 RC2 report의 owner_binding/issued operation/package/current generation 증명이 아니다. epoch UUID를 owner_epoch 정수로 바꾸거나 승인 registry로 사용 금지.
- src/additional-dnr-site-time-evidence.js SiteTimeDnrEvidence.register/read: 같은 coordinator DB metadata amvp_journal_v1:site-time-dnr-evidence, operation_id로 intent.context/정책버전/hash/claim원문과 registration snapshot을 조회. 입력 context는 operation_id/owner_binding_id/executor_id/runtime_execution_id/package_id/runtime_revision/generation 정확7개. verifyBinding은 실제 issued/package/current owner lookup을 요구하며 기본 false. 현재 운영 공급 없으므로 기존 저장행이나 report 식별자로 권한을 만들 수 없음.
- SiteTimeDnrEvidence.read(context) 반환은 local_only:true, runtime_report:false, policy_id/version/hash·intent hash·registration 및 current snapshot이다. current snapshot은 기존 DNR store journal/claim/operation/SESSION·DYNAMIC 실제 관측을 읽는다. read/snapshot 호출 자체가 DNR getter 경계를 건드리므로 이번에는 실행하지 않고 소스만 대조했다. physical RELEASE는 해당 owner/generation·기존 semantic hash·관련 claims와 receipt/current footprint를 함께 대조하며 다른 owner 공유 rule 존재를 삭제완료와 혼동하지 않음.

5인자 mapping의 남은 차이:
1 principal/binding: 실제 E 인증/현재 owner binding/epoch는 Server가 제공. Core RootAuthority나 bearer owner_key로 대체 불가.
2 report: producer의 stable report_id/generation·상태/observed_at/evidence hash가 어떤 원래 durable 관측 원문을 참조하는지 mapping이 필요. 기존 evidence read는 실행할 때마다 current snapshot을 새로 관측하므로 과거 report.evidence_sha256의 불변 원문 lookup으로 바로 사용할 수 없다. operation_id/runtime_execution_id만으로 관측시점/generation을 추정하지 않는다.
3 issuedPackage: Server amvp_packages의 실제 issued 원문/hash와 Core의 verifyBinding이 확인한 command/package/정책버전·operation/current generation 원문을 연결해야 함. 현 SiteTimeDnrEvidence의 intent는 기대 claim/정책 보관이며 스스로 issued authority를 발급하지 않는다. 현재 두 계층 모두 그 신뢰 producer/인증 lookup 미공급.
4 predecessor: producer의 이전 generation/report와 Server의 기존 confirmed report/predecessor chain을 동일 namespace/원문으로 대조할 입력 공급이 필요. sequence/hash 일치만으로 합법 효과 전이/측정 현재성을 증명하지 않음.
5 affectedPolicies: 검증된 SITE_TIME policy_id/version/claim/해제원문에서 Server verifier가 도출해야 함. replacement package에서 빠진 ID를 RELEASE로 추정 금지. SITE_TIME 모듈을 다른 정책·Content 효과의 전체 증명으로 사용하지 않음.

따라서 새 공개 Wire 없이 private trusted lookup을 쓰는 방향은 후보지만 지금 실제 source가 공급됐다는 판정은 불가. 최소 공급은 Core issued/current source + 원래 report 관측과 불변 evidence lookup + Server가 인증/검증할 경로다. Core DNR evidence/helper를 새로 만들거나 live snapshot을 과거 report로 소급 고정하지 않는다. 공급 후에만 기존 verifyEvidence/verifyReport와 Server EvidenceVerifier의 해당 경계를 연결한다.

ACK 경계는 Server 전달 그대로 유지: BatchAck(batch_id,items[item_id,payload_sha256,status,error_code])이며 detached signature/전체 batch hash/owner_epoch 봉투는 없다. 항목 commit 뒤 ACK 생성, duplicate는 기존 CONFIRMED/hash 확인, terminal Receipt 불변. 뒤항목 SQL실패 HTTP503도 앞항목commit을 지우지 않음. 항목 재인증/capability Failure는 HTTP200 내 REJECTED error_code일 수 있어 초기401/공급자부재503과 구분한다. Core transport는 원래 인증요청/body/scope/응답 provenance를 private하게 결속해야 하며 HTTP200을 전체 성공으로 처리하지 않는다. 외부 signal/current의 실제 IO 직전 결속은 client.request에 아직 없고 공급자 없이 true stub/서명 ACK 형식 창조로 메우지 않는다.

이번 추가는 기존 카드 경계 대조만. 소스수정/시험/Chrome·DNR getter/DB/HTTP/Worker 실행/Git/권한/효과0. 완료한 replay 로컬 검토는 CLOSED_PASS 유지, 정식 Core 담당 승인 PENDING, C2 운영공급/C5 별도HOLD.


### 2026-11-07 원래 registration snapshot 보호 lookup — 기존 원문 재사용

사용자 지정 Core issued/current·원래 관측 불변evidence 경계에서 기존 저장 원문을 재사용한 최소 단위. SiteTimeDnrEvidence.register는 기존 coordinator DB metadata amvp_journal_v1:site-time-dnr-evidence의 entries에 intent(context7·정책·claim), intent_sha256, registration(snapshot 당시 원문), entry_sha256을 이미 저장한다. AdditionalDnrStore의 현재 claims/operations state 및 member-a1 P1 proof/root records는 과거 RC2 report의 issued/current·관측 timestamp를 대체하지 않는다. 기존 저장에 없는 evidence를 소급 생산하지 않음.

구현은 Core 전용 extension/src/additional-dnr-site-time-evidence.js에 readRegisteredSnapshot(exactContext7,expectedEvidenceSha256) 추가뿐이다. 기존 register/read/snapshot 저장 형식·생산시점은 불변, 별도 DB/원문/승인/원장/모듈 추가 없음. coordinator.exclusive 아래 기존 operation entry를 조회→checkedEntry hash→정확 context 대조→등록 snapshot self-hash 대조→기존 verifyBinding(authorize)→최종 readonly transaction의 complete entry 동일성 검사→정확 stored.registration 사본 반환. 기존 policy/effect verifier·ACK/delivery를 다시 만들지 않았고 snapshot()/DNR getter·Chrome/Native/HTTP 호출 없음. 부재/hash불일치/미공급 verifyBinding/원문변경은 거절, 저장/repair/새report 생산0. issued/current 운영producer는 여전히 verifyBinding 기본false다.

정확 입력/반환(서버와 동일 후보):
- exactContext7={operation_id,owner_binding_id,executor_id,runtime_execution_id,package_id,runtime_revision,generation}. UUID5개와 양수safe integer revision/generation. generation은 RuntimeReport Wire에 없으므로 caller JSON이 아니라 실제 issued/current trusted resolver에서 공급해야 한다.
- expectedEvidenceSha256은 기존 registration.snapshot_sha256과 동일한 self-hash, 즉 snapshot_sha256 필드를 제외한 registration의 canonical hash다. 전체 반환 object canonical bytes의 hash와 구분한다. RuntimeReport.evidence_sha256이 이 self-hash를 가리킨다고 이번에 새로 확정하지 않는다. 정확 report 당시 원문/hash mapping이 없으면 해당 report 검증 불가 유지.
- 반환은 기존 stored.registration 객체 그대로: writer_epoch/journal_sha256/stores/claims/operations/unmanaged_rule_keys/snapshot_sha256. 새 timestamp/report_id/proof/승인 필드는 넣지 않는다. Server 전달 raw가 필요하면 그 객체 그대로 canonical serialize한 전체 raw와 그 별도 바이트 hash를 구분하며 새 public DTO/route로 채택하지 않는다.
- 등록 snapshot은 pre-effect일 수도 있고 observed_at이 없다. 따라서 MATCH/등록행 존재/hash일치만으로 report의 APPLIED/RELEASED·freshness·관측시점을 승인하지 않는다. 원래 등록 시점 state와 report 요구가 맞는지는 실제 source producer/검증 계약이 필요하다. 새 live read를 과거 registration로 교체/백필하지 않는다.

변경 전 선택1 FAIL은 해당 lookup 함수 부재. 변경 후 새8/8 PASS: 새 DNR조회 금지 상태의 정확 원문조회·수정된 반환사본이 DB에 영향없음, 부재시 저장/repair0, context7 및 hash 불일치 거절, 기본 issued/current verifier 부재 거절, 저장원문 변조, await중 durable행변경 최종읽기CAS 거절, caller변조 방어, entryhash를 다시 계산해도 snapshot hash 불일치 거절. 초기6PASS/1FAIL은 invalid hash의 동기throw에 비동기 assert.rejects를 잘못 쓴 assertion 문제이며 assert.throws로 수정, 원로그 보존. 기존 영향3/3 PASS는 pre-effect등록/기존post-effect read/operation 불변성만 별도 선택실행. 새8·기존영향3·과거시험 합산 안함. Node24.19.0/fakeIDB6.2.5·모의 DNR/issued-current/writercoverage. 실제 DB/HTTP/Chrome/Native/Worker/효과는 NOT_RUN. 구문/공백 PASS.

변경경계 조율: Server는 evidence파일 병행수정 없음을 회신했고, 「추가 MVP 기능별 통합 및 회귀」도 직접 충돌 없음 확인. shared source/index/Worker/legacy는 수정하지 않음. 정확source/test/baseline/patch/hash/log는 기존 CHANGE-RECORD.json registered_snapshot_lookup 및 baseline-site-time-evidence/registered-snapshot.diff에 연결했다.

다음 설계 차이와 권고: (1) existing registration에 없는 report 관측시각·report_id/issued原文 결속을 임의 추가하지 않는다. 별도 실제 effect observation commit 시점에 canonical observation·stable reference·issued/current version을 함께 보호 저장해야 한다면 이는 새 내부 원문/생산시점 변경이므로 Server와 같은 후보에서 해당 필드·소유/실패보존만 먼저 정한다. 권고는 기존 실제 effect writer가 원래 commit한 observation을 재사용하고 report는 그 immutable reference만 소비하는 방식. 과거 기록이 없으면 backfill하지 않는다. (2) 운영 verifyBinding은 실제 issued/package/current generation/owner fence producer가 공급해야 하며 저장된 intent나 RootAuthority만으로 true를 만들지 않는다. (3) Server 인증 reader는 이 함수의 정확 context7/self-hash와 원래 요청/응답 수명·현재 principal/binding/RUNTIME_REPORT capability를 결속한다. source없음/UNKNOWN은 reject. report state/freshness 검증으로 승격하지 않는다.

이 최소 단위는 기존 등록 원문의 보호lookup 완료이며 issued/current 생산·전체 RPT evidence 공급 완료가 아니다. 정식 Core 비작성자 승인 PENDING, C2 운영발급·C5 강한집행/cleanup/실효과활성화와 별개. 실제 실행/Git게시/권한/효과0, MVP_FINAL_COMPLETE=false.


### 2026-11-07 RPT protected-read Server 후보 입력·반환 대조

기준 rpt-protected-read-candidate/RESULT.json·AmvpRegisteredReportEvidenceRead.java. 후보source/test2파일과 참조Core lookup hash 일치 확인. Server11PASS는 인증/SQL/issued-current/channel/registration 대역의 별도 reflection 근거, 실제Core호출/통신 없음. Core8/영향3 및 기존7/4/독립3 재실행0.

입력·반환 차이만 고정:
- Server ReadSession.readRegisteredSnapshot(exactContextJson,expectedSnapshotSha256)는 canonical context 문자열→canonical registration 문자열이다. 실제 Core 함수는 context7 객체→stored.registration 객체다. 아직 없는 authenticated channel adapter가 canonical JSON·정확7키·UUID/safe integer를 파싱해 같은 peer의 실제 Core 함수를 호출하고 반환 그대로 canonical serialize해야 한다. 단순 JSON 왕복은 인증/권한이 아니며 peer/channel 보호 경계가 전제다.
- 기대hash는 기존 snapshot_sha256 제외 self-hash이며 Server가 같은 방식으로 검사한다. 반환raw전체 hash는 fullOriginalSha256로 분리하므로 호환. root7keys 동일. canonicalOriginal은 정확 기존registration이고 새 evidence원문/보고시각/proof가 아니다. RPT.evidence_sha256와 동일시하지 않음.
- query requestSha256는 principal/binding/epoch/capability/report/package/predecessor/context/selfhash/deadline의 기존 원문 결속용이다. Core lookup은 context+hash만 받으므로 나머지 query·opaque lifetime·요청수명 인증 결속/현재성은 실제 channel/IssuedCurrentSource 책임이다. 문자열hash echo만으로 충족하지 않는다.
- validUntil은 등록snapshot에 없는 외부 trusted issued/current 요청수명이고 generation도 report JSON에서 만들지 않는다. 이 공급자는 현재 없다. Core verifyBinding의 issued/current 검증과 Server source.requireCurrent는 각각 실제 producer가 필요하며 기본거절 유지.
- 기존 MemberExecutionClient는 Core→Server 요청 경로이며 Server Java→실제 Worker/메모리의 protected lookup 역방향 채널을 제공하지 않는다. 따라서 현 signature는 private 준비 seam이며 실제topology 아님. 기존 인증 channel이 없으면 별도 인증 전달/등록 경계의 소유·원문·수명·실패보존 합의가 먼저다. 새 공개 endpoint/서명/업로드형식을 단독 도입하지 않음.
- Server forRequest/Lookup.read는 transaction/현재binding 검사를 요구한다. 원격IO를 실제로 붙일 때 lock/transaction을 어느 경계까지 유지할지 Server가 명시해야 하며 local DB와 Core 사이 원자성/C5를 추정하지 않는다. bounded deadline/timeout·유실·peer재기동/소유변경 후 결과소비거절·close 책임을 같은 후보에서 고정해야 한다. 현재 실행/성능검증을 설계선택 전 요구하지 않음.

판정: self-hash/root형식·Core reference 입력은 호환하는 비활성 후보. raw문자열↔객체 변환은 실제인증 adapter 공급시 수행할 얇은 연결이며 현재 임의helper를 만들지 않음. RegisteredSnapshotRead는 EvidenceVerifier/VerifiedReport가 아니므로 report상태/시각/실제효과 검증으로 승격 불가. 운영peer/channel·issued/current/원래report관측 생산·정식비작성자승인 대기. 코드/시험/실제실행/Git/발급/활성화0, C5 HOLD.


2026-11-07 RPT protected-read 준비단위 최종정정: Server 최신 RESULT의source/test hash 일치. correlation Query는 canonical context 문자열 유지, 실제 ReadSession.readRegisteredSnapshot 입력은 detached exactContext7 ObjectNode로 바뀌어 Core 객체입력과 정합. 앞 절 문자열 변환 차이는 이전단계 이력이며 이 변경으로 해소됨. 변경전11과 변경후11은 별도 단계로 보존/비합산, Core코드·시험변경0. 정확 최종source hash는 CHANGE-RECORD.json registered_snapshot_lookup.server_adapter_comparison. 준비단위 종료, 실제 issued/current lifetime·authenticated peer/channel·RPT 원문/effect mapping·정식비작성자승인은 여전히 미공급/대기이며 C5/운영HOLD 불변.


### 2026-11-07 Core→Server 선전달 우선안 — 실제 효과 원문 생산 후보(공동 결정 전)

조회 준비단위는 종료한 그대로 유지, 객체변환/lookup 시험 반복0. 사용자 전달 Core→Server 원문 선전달 우선안은 계약 정리에 전달된 방향이며 새 업로드 Wire/producer 인증/운영 활성화 승인으로 읽지 않는다. 기존 효과코드 지점만 확인했고 아래 공유 차이를 설계선택 전에 실제완료 증거로 막지 않는다.

| 실제 코드 지점 | 지금 얻는 원문과 실제 저장 | 부족한 RPT 원문/금지한 대체 |
|---|---|---|
| additional-dnr-coordinator.js adopt: verifyAdoption → inspectAdditionalDnr → MATCH → store.mutate claims.push | claim의 owner_binding/generation/writer_epoch/rule store+id/hash 및 기대rule·현재관측. metadata amvp_journal_v1:dnr에 claim 저장 | ADOPTED는 규칙을 설치한 실행의 증명이 아니며 이미 존재하는 규칙의 검증된 소유 채택이다. 당시 전체 observed/시각/RC2 issued operation/package는 보존되지 않음. ADOPTED를 새 APPLIED report로 변환 금지 |
| releaseOwner: PREPARED intent 선저장 → 기존 DNR mutation → after=inspectAdditionalDnr → checkObservation(after,true) → store.mutate claims RELEASED + intent RELEASED | 기존 operation.id/hash/정확claim set과 owner/generation; 같은 commit에서 해제의무 discharge. hash는 {operation:RELEASE,owner_binding_id,generation}의 기존 semantic hash | before/after 관측 원문·관측시각·report_id·RC2 issued/package/현재epoch 원문이 영속보존되지 않음. 재시작시 현재관측으로 과거 RELEASE의 시각/관측을 생성 금지. DNR operation.id가 RC2 report.operation_id와 같다는 계약 없음 |
| member-a1/registry.mjs issue(b,m)와 handle의 COMPLETE_OPERATION | 실제 command fingerprint·operation record, response의 정확scope/operation/result_state 및 effect/coverage/release 근거 검증. op.first_response, binding.current_effect/current_coverage/release_evidence, A1_WRITE_RECEIPT를 동일 metadata transaction에 저장 | op 정상결과64/일반receipt128 한계에서 first_response가 RESULT_EVICTED/null 가능. 현재 binding 근거는 후속관측으로 교체됨. RC2 owner_binding/package/runtime operation과 자동대응하지 않음. 축출된원문 복원/성공증거 소급생성 금지 |
| member-a1/core.mjs dispatch: registry.issue → 정확문서 sendMessage → 응답schema/request 검사; verifyNative/dnrVerified·commit_fence | A1 문서/owner/generation과 Root commit의 현재 native/DNR 대조 지점. 응답 ACK는 단계별 의미 | ACK/정확문서응답만으로 모든 효과/RC2 package승인/Server가검증할 producer신원 성립 안함. Content 증거의 생산·인증 의미 변경은 지민 담당 |
| member-execution-loop.js saveReport/apply·cleanup 완료뒤 호출; MemberJournalStore.save/load | 기존 control row.reports 및 journal에 command/session/desired_revision/result/observed_at·intervals 원문을 저장한 뒤 enqueue | 기존 ExecutionReport는 별도 endpoint/authority와 기록이다. RC2 RuntimeReport.evidence_sha256/issued provenance로 변환하거나 새report observed_at으로 재사용 금지 |
| SiteTimeDnrEvidence.register / readRegisteredSnapshot | 기대intent·등록시점snapshot·selfhash를 이미보호저장/조회 | pre-effect일 수 있고 observed_at/report_id가 없음. 실제 효과 원문 생산 대체 아님 |

권고 첫 최소 추가 기록은 SITE_TIME RELEASE 한 경계다. producer는 실제 releaseOwner의 after 관측검사 성공 시점이며, 같은 writer lock/owner fence 아래 기존 claim/intent RELEASED commit과 불변 관측 레코드를 같은 metadata transaction에 기록하는 안을 우선한다. 기존등록snapshot/과거RELEASED행에 backfill하지 않음. 다른 policy/DOM효과/APPLY까지 일반화하지 않는다. 새 원문 형식/생산시점/RC2 operation mapping이 필요한 만큼 이 절은 구현전 공동선택 후보이고 아직 source 코드를 바꾸지 않았다.

필요 최소 필드 후보(새 public DTO가 아닌 내부 공동검토):
- identity: 고정 observation_id(기존 durable 의도에서 유일하게예약), source kind/schema revision, 기존 DNR release operation.id+semantic hash와 정확claim set 참조. RC2 report.operation_id를 새로 발명/동일시하지 않음.
- issued 결속: 기존 승인된 RC2 owner_binding/executor/runtime_execution/package/runtime_revision/operation 원문 또는 안정ref+hash, 당시 generation/owner epoch와 local writer/owner fence. trusted issued/current resolver가 제공해야 하며 caller report JSON에서 복원하지 않음. Server가 가진 amvp_packages·실제 issued command 원문에 대응해야 함. 현재 stable resolver/mapping은 부재.
- observation: 실제 before/after 관측의 기존canonical 투영(SESSION/DYNAMIC 조회상태, rule store/id/hash, 각claim 비교·공유owner footprint·RELEASE/cleanup검사결과, 관련journal revision/hash). URL·token·채널credential 원문은 포함하지 않음. 원래관측 byte/hash를 보존하고 재조회결과로 교체하지 않음.
- time: producer가 검사한 바로 그 관측의 boot/monotonic anchor와 원래 observed_at/clock quality 및 당시 검증source ref. 현재 trusted clock/anchor 미공급이면 시각·freshness는 UNKNOWN, Date.now()만으로 확정측정/Server신뢰를 만들지 않음.
- report binding: 관측 hash와 원문 ref를 durable report production 원문에 결속하고 report_id/epoch/seq는 기존 producer가 동일원문으로 할당. 관측을 report보다 먼저commit할 경우 관측ID→report입력의 영속handoff를 보존하고 hash/operation충돌은 거절. 실제report 원문 생성 전 임의reportID/seq를 effect writer가발급하지 않음. RPT evidence_sha256은 승인된관측canonical원문의hash인지 별도명시하며 registration self-hash와동일시하지 않음.

부분실패/재시작 후보:
- DNR mutation전 기존PREPARED와정확claim set을보존. 관측commit 실패면 PREPARED/IN_DOUBT·cleanup의무를남기고 성공report를생성하지않음. 실제효과가이미발생했어도 영속증거가없으면그실행보고검증불가/UNKNOWN이다.
- after 관측→로컬commit 사이 writer/fence/authority변경은거절. 실제browser동작과IDB를원자화했다고주장하지않음. 관측레코드와기존의무완료를같은IDBcommit에묶어 부분성공표시를줄인다.
- observation commit후 report 생성/선전달 실패는 원래관측과의무를보존. 재시작은같은 observation/ref·report원문으로회복, 새관측으로옛hash를채우지않음. 선전달응답유실은동일원문재조회/재전달로만회복, receipt/ACK조작없음.
- 기존RELEASED이지만관측원문없는과거행은그대로보존하고당시증거부재로표시. 새시점회복관측이필요하면별개 observation_id/시각/실행문맥이며과거report증거가아님.

Server가 Core자기주장 이외에 검증할 근거와 미공급:
1 기존 E인증은계정/설치주체일뿐측정producer실행의증명아님. Server의실제issued package/command/operation/owner epoch·scope·기한 원문과 observation의안정ref/hash를독립대조해야함. 현재Core issued/current resolver/RC2→DNR mapping이없음.
2 source hash와canonical본문은무결성/동일성을검사할뿐진실성증명이아님. Server가누가그관측을생산했는지검증할 authenticated producer/installation/profile/approved artifact/channel·요청수명source가필요. 현재peer/channel/그신뢰provisioning은없음. 임의서명키·서명 DTO를창조하지않음.
3 실제Chrome DNR관측은Core가브라우저API로관측한source다. Server가브라우저효과를독립실측하는경로는현재없다. 인증된producer의검증된행위/원래issued명령과관측을허용할trust model을공동선택해야하며자기보고를독립효과증명으로과장하지않음. Native ATTEST·설치기록도실제DNR효과/현재capability를증명하지않음.
4 현재auth source/predecessor/효과전이·freshness 검증을하는Server EvidenceVerifier는구현공급미완료. 원문선전달용저장/인증/재조회/retention·실패보존도아직공유계약미정. 원문접수ACK를효과APPLIED/RELEASED ACK로사용하지않음.

지금 같은후보로 결정할 최소사항: (A) 첫생산범위를 SITE_TIME RELEASE의실제사후관측+로컬해제commit으로정할지, (B) 기존Server issued 원문→Core release operation/claim/generation을인증결속할실제producer/원문ref, (C) Server가관측을받아들이는producer 신뢰경계와선전달원문/보존·재시도범위. 권고 A를좁게채택하고 B/C는기존인증/원장source재사용방향으로정하되없으면기본거절. 이공유선택이이루어지기전에는새원문쓰기/위조양성fixture로제품생산자완료를만들지않음. source/codepoints·원문/실패의설계선택에미래실행PASS를전제하지않음.

담당파일(선택후영향만): Core additional-dnr-coordinator.js/AdditionalDnrStore의releasecommit·기존RPTproducer의durablehandoff 및실제issued/current guard. legacy/sharedwriter의기존소유자와재조율후전용후보에서수정. Server는기존RPT후보의인증원문선전달·보호저장/조회·EvidenceVerifier5인자source연결. Content/A1Registry/ACK/delivery는첫SITE_TIME RELEASE단위에서수정하지않음. 현코드형식내독립구현은기존registration보호lookup까지완료되어있고, 효과생산에추가필요한변경은이새공유원문/생산시점선택이므로지금중복helper를추가하지않음. 정식비작성자승인대기, 실제Worker/HTTP/DB/Git/권한/효과활성화0, C5/HOLD불변.


같은 후보 hash 결속 보충（2026-11-07）: effect 원문 hash 확정 → report.evidence_sha256 참조 → report payload hash 확정 → 별도 association 순서로 제한하고 effect 원문에 report payload hash를 다시 넣는 순환은 만들지 않는다.


### 2026-11-07 SITE_TIME RELEASE 격리 구현 후보 — 실제관측·동일commit·차단된 report 인계

사용자 첫범위 선택에 따라 같은 최소계약 후보(section 2401, 정확sectionhash는 release-candidate/RESULT.json)를 적용한 격리후보를 release-candidate/에 준비했다. 이폴더는기존Core전용폴더 안의별도사본으로parent원문/공유복원본/index/worktree/branch 불변. source2개 AdditionalDnrCoordinator/AdditionalDnrStore와신규관련test1개만수정. recordReleaseObservations 기본false; 실제제품Worker/번들/서비스/HTTP와연결없음. 새로운sidecar원문/field/status는공동DRAFT이며정식승인아님.

실제연결: 기존 releaseOwner의정확owner/generation·writerlock/fence·PREPARED·DNR수정·after inspect/checkObservation 재사용. 후보opt-in에서그실행의before/after allowlist관측과원래DNRoperation/semantic hash/정확claimrefs를불변원문으로만든뒤, 최종동기metadata reducer에서전체원래journal동일성·기존fence/intent검사후 관측sidecar+차단handoff+기존claims/intent RELEASED를동일transaction에commit한다. raw rule/URL/credential없음. IDB와브라우저mutation을원자화했다고주장하지않음.

공급부재의분리: 최소계약후보0-4에따라보고issued/clock/provenance가없어도실제cleanupscope의물리관측저장·기존로컬해제commit은가능하다. 원문 issued_relation/reason/producer_ref/registration_ref는null, clock observed_at/anchor/source/quality도null. Date.now/registration/newcurrent로보충하지않음. 별도handoff는 BLOCKED_UNASSOCIATED/report:null 및구체missing원인. 이것은보고성공이아닌localphysical원문보존이다. 실제권한provider없는Report 생성/전송경로는없음. default OFF에서는기존cleanup경로/return의미그대로이며새sidecar없음.

원문identity는실제로commit된관측의UUID/version1이다. raw에 report_id/report payload/selfhash를넣지않고effecthash=SHA256(UTF8 canonical raw)로별도보관. 이hash를report.evidence_sha256에쓰는공유mapping·stable report input/seq/association·선전달은미선택이라구현하지않았다. 기존producer/ACK/verifier/delivery 재작성없음. 인계대기identity+rawhash만같은commit에보존, 이후report/handoff실패가있어도로컬RELEASED/원문을삭제하거나가짜미완료로되돌리지않음. 부족한관측원문을나중에수정해issued/time을채우는API없음.

저장/복구: readReleaseRecord(operationId)는후보INTERNAL역사조회로rawcanonical/hash·sidecar/handoff결속을검사하고그대로반환한다. 보고승인/현재권한아님. metadata abort시관측/handoff/claim discharge 모두rollback되고기존 PREPARED/IN_DOUBT·정확claim/cleanup의무보존. 실제DNR은이미변했을수있으므로성공report없음. commit응답유실이면기존catch가확정RELEASED를되돌리지않고새객체로같은원문을조회, 동일operation재호출은기존DUPLICATE로끝나새관측없음. 과거RELEASED·원문부재는null 그대로이며재호출/복구로백필안함. IN_DOUBT의후속실제회복관측은원래실패시각증거가아닌별개관측identity이며이후보는모든report를차단하므로옛report증거로승격없음. 상세회복→report연결조건은공동미결정.

검증: 새10/10PASS(모의실제흐름 원자저장/nullable출처·보고차단, defaultOFF, 저장abort, commit응답유실/동일원문재생성없는회복, 양store부분실패, 공유owner규칙보존, 옛RELEASED백필금지, async관측후journal/fence변경거절, sidecar충돌보존, 변조lookup거절). 기존coordinator/store영향15/15PASS를별도실행: 원래owner/공유규칙/legacy보존/의무/중복/쓰기실패/writer교체회귀. 기존lookup/ACK/delivery/Server시험은미반복. Node24.19.0+fakeIDB6.2.5+Node WebLock, DNR/권한은모의fixture이며실제DNR/Chrome/Worker/HTTP실행아님. syntax/whitespacePASS. parent원문/의존11파일불변확인.

기준source/hash/patch/두실행log/계약sectionhash는 release-candidate/RESULT.json, BASELINE.json, release-observation-candidate.diff. 필요한선택만유지: 실제issued/clock/producer신뢰원문·이유/세대mapping의정확형식, DNR→RC2 operation의보호관계, report evidencehash/안정association·재시작조건, Server선전달commit/query·trust/보존. 미래완료시험을이선택의선행조건으로요구하지않음. 정식Core비작성자승인PENDING, C2/C5운영HOLD·M1 BLOCKED·제품수용NOT_RUN·MVP_FINAL_COMPLETE=false.

### 2026-11-07 후속 연결 — RuntimePackage 원문 보호 intake / coordinated FocusControl 격리 후보

범위: 다훈 대행 로컬 무효과. 공유 association/Server ingress/Shorts/Worker 변경 없음. 기존 RELEASE 저장·association·gate·source adapter 및 종료된 검토 재사용, 재시험/재작성 없음. 해당 source 4개 SHA 불변 확인. 아래 후보는 제품 caller에 활성화하지 않았으며 정식 Core 비작성자 승인 PENDING이다.

- RPT 선행 원문: 기존 Server AmvpPolicyPublisher.publish → amvp_packages/outbox/current 및 AmvpRuntimeBridgeApi.current의 실제 RuntimePackage 생산/조회 계약을 재사용. release-candidate/source-supply-candidate/package-intake/runtime-package-intake.mjs에서 기존 MemberExecutionClient GET → 기존 IG04ProviderStore.register 보호 저장 → 같은 authority/fence/sourceLocalId로 역사 조회까지 연결했다. full-policy verifyPackage/current/credential 공급 없으면 거절. 동일 원문 멱등, 충돌 보존, transaction rollback, commit 응답 유실 후 원문 조회, commit 이후 current 유실 검증: 10/10 PASS(Node/fakeIDB/모의 전송). 원문은 기존 JSON envelope이며 새 HTTP Wire/원문 schema/현재성 lease를 만들지 않았다. 이것은 RELEASE issued operation/세대/reason/관측 clock/producer 공급 완료가 아니다. package omission·등록·새 현재 관측으로 과거 RELEASE 증거를 만들지 않으며 report gate는 차단 유지.
- 일시정지·재개: 기존 일반 MemberApi와 A1 adapter는 pause_resume 미구현/422, popup은 상태조회·END만 있고, Web FocusSessions/useCadenceControl은 CADENCE 경로다. 일반 session pause 지원으로 바꾸지 않았다. 기존 RC2 FocusControl/FocusRef/FocusState 계약에 한정한 pause-resume-candidate/focus-control.mjs는 승인된 RUNNING의 보호 채택 → PAUSING → 해제 검증 후 PAUSED → 동일 frozen snapshot/attachment로 RESUMING → 적용 검증 후 RUNNING을 저장한다. END intent는 pending RESUME보다 우선해 오래된 응답의 RUNNING 복귀를 막고 이후 END 해제를 직렬화한다. 정지 시간 제외, boot 단절/미확정 구간은 UNKNOWN으로 보존하며 confirmed_ms를 부풀리지 않는다. 실제 execute 결과의 evidence/hash/clock과 상태를 같은 완료 transaction에 저장한다. receipt/ACK를 발명하지 않음. 16/16 PASS(Node/fakeIDB/합성 admission·clock·effect); 저장 실패/응답 유실·재시작·불변 원문 변조·END 경합 포함. 실제 focus-only executor/current/clock/검증 공급 및 caller는 아직 미연결. 실행 중 executor 정지·cross-Worker writer 배제는 이 로컬 직렬화만으로 보장하지 않는다.
- 담당 경계: Server 담당에게 일반 session/CADENCE 구분과 AmvpCadenceControl의 END 허용 이전상태가 RUNNING/PAUSED/UNKNOWN뿐인 차이를 전달했다. PAUSING/RESUMING END admission 및 실제 Authority.inspect/verify 공급, actor completion→기존 Receipt 입력 매핑은 Server와 맞춰야 한다. 공유 파일을 대신 수정하지 않았다. 별도 통합 담당에 중복 여부 질의했고 명시적 소유 회신은 미수신; 독립 신규 후보 파일만 작성했다.
- 예약: MemberA1Adapter.claimSchedule/dispatchScheduleClaim의 core.verifyScheduledDeadline, ScheduleDeadline.arm의 verifyScheduledAdmission 실제 공급이 차단점이다. Core는 occurrence admission/기한·alarm/startup/newboot/pre-command 연결, Server는 같은 occurrence/current issued 원문 책임. 기존 GET-only 복구/ENDING·release 검사를 재사용하고 새 claim으로 실패를 대체하지 않는다.
- 성인 제한: adult-domain.mjs inspectAdultDomain의 matchCatalog 신뢰 공급 부재가 차단점. Core가 승인 catalog/version/checksum/last-valid·profile/artifact에 결속된 matcher와 정책 실행을 공급해야 한다. 미공급은 FAILED 유지. 실제 DOM 변경이 없어 Content 작업을 추가하지 않았다.

다음 최소 연결/필요 결정: Server와 동일 후보에서 (1) 실제 RELEASE operation/owner epoch/generation→보호 원문 참조 mapping의 생산 주체, (2) 신뢰 clock/reason 생산 주체, (3) producer 설치/profile/artifact 식별과 등록·철회 검증 설정을 한 묶음으로 지정. 권고는 기존 Server 보호 원장/인증 검증 책임을 재사용하되 회원 인증과 capability/producer 승인을 분리하고 없는 등록부·승인자는 지정 전까지 미공급으로 남기는 것. 대안은 보고 차단 유지 또는 별도 신뢰 발급 체계를 공동 합의 후 도입(등록·철회·보존 책임과 파일 증가). 전자는 구현된 package 보호 저장만 사용할 수 있고 실제 RPT는 불가; 후자는 인증된 producer 보고를 허용할 근거가 추가되지만 Server 독립 Chrome 실측/C5 즉시철회 보장은 생기지 않는다. 선택 후 Core package composition/source 소비와 Server Authority/EvidenceVerifier·producer 검증 공급만 변경하며 기존 association/ingress 공유 파일은 담당 조율 전 변경하지 않는다. C5 신규 발급·적용·최종 소비 차단과 이미 적용된 효과 중단·cleanup·복원 의무는 별도 유지한다.

근거: 두 후보 RESULT.json에 정확 파일 SHA/시험 log/미공급 입력 기록. 새 시험 최신 합계는 16 및 10이며 중간 실행 수를 누적하지 않음. 실제 Worker/HTTP/DB/Native/DNR/설치/권한/효과/Git 게시 NOT_RUN. 제품 연결 PARTIAL, 운영 활성화 OFF, 정식 비작성자/공동 의미 승인 PENDING.

### 2026-11-07 후속 실행 경합 수정 — END 저장 후 미시작 RESUME 차단

완료 변경: 전용 pause-resume-candidate/focus-control.mjs perform에서 EXECUTE 승인/clock await 이후, 최종 보호 row의 동일 PENDING operation·END intent·scope·frozen 검사를 기존 staged 순서 안에서 실행기 호출 시작과 결속했다. effect Promise 대기는 staged 밖이므로 이미 시작된 효과 도중에도 END intent 저장이 가능하다. 기존 코드는 승인/clock 검사 대기 중 END가 저장돼도 RESUME 실행기를 호출하고 나중에 결과만 폐기하는 반례2개였다. 이제 미시작 RESUME를 호출 전에 폐기하고 END 해제만 호출한다. 단일 actor 인스턴스 경계이며 이미 시작한 효과 중단·cross-Worker fencing/cleanup 보장을 만들지 않았다. 해제 확인→PAUSED·동일 frozen 재개·정지시간 제외·END 우선 유지.

검증: 기존16/16 결과는 RESULT-16-reused.json/기존 log로 보존·재사용. 새 경합2개 변경전 FAIL(RESUME,END 호출)→변경후2/2PASS(END만 호출). 변경 영향9/9PASS: 해제확인/동일정책재개·정지시간/END paused·inflight/멱등/commit abort·응답유실/current·clock 단절. 최신18 전체실행이라고 표시하지 않는다. Node/fakeIDB/합성effect만 사용, syntax·whitespace PASS. 수정 source/test·원본·patch·log SHA는 기존 pause-resume-candidate/RESULT.json. 기존 adapter/package intake/association 시험 미반복, 관련 원문 hash 불변.

RPT 실제 연결 차단점 재확인(전면 재조사 없음): AmvpPolicyPublisher.publish/current·RuntimeBridgeApi.current는 RuntimePackage 원문 생산/조회이며 RELEASE issued writer가 아니다. AmvpDeletedPolicyRelease.targets는 이전 policy/package를 대조하고 project는 RPT_STATE 결과 projection을 저장한다. 둘 다 release operation 발급/관측 clock/producer 인증 원문을 생산하지 않는다. 따라서 기존 createReleaseEvidenceSupply의 readIssuedCurrent·readClock·verifyProducer에 연결할 실source가 현재 확인되지 않았다. releaseObservationRecord는 원래 nullable 기록을 그대로 보존한다. 이전 기록 enrich/backfill·현재scan 대체·가짜 issued/clock/reason/producer 생성 없음; 실제 공급 연결 완료라고 주장하지 않는다. Server 담당에 새 실제 산출물 유무/정확 함수만 요청했고 회신 전 공유 파일 변경 없음.

남은 사람 입력은 R2 자체 재선택이 아니라 다음 한 묶음: 실제 producer 등록/철회 승인 주체(이름/역할), 허용 installation/executor/profile/artifact의 보호 기준 원문 위치·revision, RELEASE issued operation/owner epoch/generation·reason의 발급 writer, 원관측 UTC/monotonic/boot를 검증할 clock source의 실제 소유자를 지정해야 한다. 권고는 Server 기존 보호 원장/인증 담당이 이 공급 책임을 소유하고 실제 승인 주체·기준을 명시한 뒤 Core가 보호 ref를 소비하는 방식이다. 현재 회원 인증만으로 승인 주체를 자동 지정하지 않는다. 대안1 미공급/defaultdeny 유지(기존 물리cleanup/복원 지속, RPT 불가); 대안2 별도 신뢰체계 도입 합의(발급/등록/철회/보존 신규 책임 필요). 선택 후 수정 대상은 Server의 실제 source 생산/보호 저장 및 EvidenceVerifier/Authority 공급 composition, Core의 해당 original 생산·보호 조회→기존 release-evidence-supply 소비 연결이다. 새 Wire·registry·서명자 이름을 지금 확정하지 않음. 인증된producer 보고 수용과 Server 독립Chrome실측 구분, C5 신규발급·적용·최종소비 차단과 이미적용효과 중단/cleanup/복원은 별도 강한요구 유지.

예약/성인 제한: 통합 담당 회신상 현재 별도 진행 담당/새 산출물 확인 안됨(팀 전체 무작업 확정 아님). 이전 verifyScheduledDeadline/verifyScheduledAdmission 및 trusted matchCatalog 공급 차단과 책임은 그대로이며 새 helper/Content 코드 없음. 다음 최소 작업은 Server 실제 source 회신분을 대조해 원문 ref/반환 차이만 연결하거나, focus-only executor/Authority 공급 산출물 도착 시 기존 actor를 실제 caller에 연결하는 것. 공유 association/ingress/Shorts 무수정. 실제 Native/DNR/Worker/DBHTTP/설치/Git/권한/효과 NOT_RUN, 로컬후보만 수정. 정식 비작성자 승인 PENDING, 운영 활성화 OFF.


### 2026-11-07 독립 지적 수정: 최종 dispatch 기한 / 예약 deadline caller 연결

pause/resume 독립 CHANGES_REQUIRED(1PASS/1FAIL)는 보존. 최종 frozenOriginal await 뒤 기존 sample로 신뢰 시계를 다시 읽어 execute_before 도달/초과면 execute 호출 전 거절한다. END/PENDING/scope/frozen/current/권한 검사와 staged 호출 시작 순서는 유지, effect 대기는 staged 밖이다. 기존16/16·지난 반례2/회귀9는 별도 재사용. 이번 신규 기한3건(4999ms 정상1회, 5000/6000ms RESUME0회)+영향11건=14/14PASS. 독립 반례 작성자 재실행2/2PASS는 독립 재승인이 아니다. source/test/hash/final-clock.diff/log는 pause-resume-candidate/RESULT.json. 같은 독립 담당에게 변경분 재확인 요청, 정식 Core 비작성자 승인 PENDING.

예약: Server 담당이 Core 해당 파일 동시편집 없음·새 운영source 없음으로 회신. 쓰기 가능한 전용 경로 C:/Users/dahun/.codex/visualizations/2026/11/07/01a1b409-a851-73e0-b67e-0138fe0253e3/schedule-connection/ 에 PR46 adapter·PR48 ScheduleDeadline과 필요한 의존5파일만 복원. 기존 adapter tickInnerBody에서 명령 조회 전·APPLY 소비 전에 저장된 deadline을 기존 check/enforce에 연결. 기한 만료는 ENDING 저장→기존 endIntent/finish→RELEASE 확인→기존 offlineEndInner로 위임, 같은 session의 오래된 APPLY를 소비하지 않는다. 다른 session은 기존 인증 경로로 진행. 새 boot/scope 손상/cleanup 실패는 조회·APPLY 전 거절하며 의무 보존. 7/7PASS(Node/fakeIDB·합성 승인 bundle·모의 alarm/cleanup). 신규 arm/claim/ONCE 시작 권한은 추가하지 않음. verifyScheduledDeadline/verifyScheduledAdmission 실제 공급과 startup/alarm 실제 wiring은 미연결. 원모듈 재작성 없음. RESULT/BASELINE/connection.diff/전후log에 근거.

다음 최소 작업: pause 변경분 독립 재확인, 예약 후보 담당 영향검토, 실제 FocusControl caller/Authority/focus-only executor·예약 clock/admission 공급. Server는 RPT issued/clock/reason/producer·Core→Content 인증 carrier·Native grant/closure 새 생산자 없음으로 명시 회신. catalog·확정 debit/재시작 불확정 구간 해소 source도 기존 미공급 유지, 새 helper 없음. 사람 입력은 기존 묶음의 실제 승인 주체/등록·철회 책임과 허용 installation/profile/artifact의 보호 기준 원문. 기존 보호 Server 공급을 권고, 대안은 보고·새 효과 거절 유지 또는 별도 신뢰체계 공동 합의. C2/C5 강한 요구와 cleanup/복원 의무 유지. 공유 association/Server/Shorts/Content·index 불변, 실제 Worker/Native/DNR/HTTP/DB/설치/권한/효과/Git NOT_RUN, 활성화 OFF.


### 2026-11-08 popup→Worker→coordinated actor caller 격리 연결

소유 조율: Server 담당이 popup/member-execution-ui.js와 background/member-execution-runtime.js/member-execution.js 미편집으로 회신. 공유 원문/Shorts 설치/패키지/Server/Content는 변경하지 않고 쓰기 가능한 전용 focus-caller-connection 경로에 기존 popup·runtime 2소스만 복원 수정. 경로는 C:/Users/dahun/.codex/visualizations/2026/11/07/01a1b409-a851-73e0-b67e-0138fe0253e3/focus-caller-connection/ . generated member-execution.js/bundle은 수정하지 않음.

실제 로컬 호출 연결: popup action/session 요청→기존 Worker onMessage의 extension/popup sender·request 검증→보호 issued resolver의 정확 action/session 원문→검토된 FocusControlActor.submit→기존 저장/시간/효과 검증→popup coordinated state event. UI가 envelope/clock/capability를 공급하거나 일반 legacy 세션 RUNNING/RELEASED로 변환하지 않는다. missing source/current 변화/원문 action·session 대체/기한 도달은 거절. popup에서 RESUME 대기 중 END는 전달하고 이전 응답은 최신 END 화면 상태를 덮지 않는다. 원래 disabled 제어를 임의 활성화하지 않는다.

검증: Node VM에서 복원한 popup/Worker script와 실제 검토 actor/fakeIDB를 함께 실행한 신규 caller 7/7PASS. issuer/current/clock/effect는 합성 fixture, 실제 Worker/Chrome/DNR/HTTP/Native 아님. syntax PASS. 첫 mock onMessageExternal 누락 실패는 first-missing-mock.log로 보존 후 mock만 수정. 검토된 actor b1812295 source 불변; 독립 final-clock-recheck PASS2/2 원문 확인, 기존16/14/adapter/package/association 시험 미반복. 원문·diff·SHA·log는 기존후보 RESULT/BASELINE/caller.diff.

상태: caller 로컬후보 구현 PASS, 새 caller 독립 기술검토 PENDING, 정식 Core 비작성자승인 PENDING, 실제수용 NOT_RUN, Git NOT_RUN. 실제 popup HTML에는 coordinated 제어요소가 없고 시험은 합성 DOM요소를 썼다. Worker coordinatedFocus composition/resolveIssued·실권한/clock/focus executor와 Server completion receipt 공급도 미구현이므로 사용자 흐름 완료가 아니다. 운영 활성화 OFF/defaultdeny. 다음 최소공급은 Server AmvpCadenceControl.command가 저장한 amvp_focus_controls 원문/FOCUS_CONTROL outbox를 owner/executor/epoch·version/generation·기한/frozen에 결속해 보호 조회하는 함수/반환이다. POST202의 pending state를 승인 원문으로 쓰지 않음. 해당 기존 조회 생산경로 존재 여부와 정확 반환을 Server 소유자에게 요청했다. 새 공유 Wire 결정 없이 이를 가정해 추가 adapter를 만들지 않는다.

다른 기능 경계: 예약은 이전 PR46→PR48 deadline caller 7/7 후보를 재사용(로컬PASS/검토PENDING/실수용·Git NOT_RUN), actor ONCE admission/clock·startup/alarm 공급 남음. 한도는 관측journal과 보수산식 존재, 신뢰 측정·확정 debit/day ledger 및 재시작 불확정 해소 생산자 미공급으로 제품완료 아님. 성인제한은 승인 catalog/version/checksum/last-valid matcher와 policy 실행 공급 부재, FAILED 유지. RPT는 RELEASE issued/currentgeneration·clock/reason·producer 공급과 Core→Content 인증 carrier/Native 목적별grant·영속closure 실제 공급이 아직 없다는 Server 회신을 재사용, 새 공급 성공/과거null백필 없음. Content 변경 필요 입력이 생기지 않아 지민에게 변경 요청 없음. C2/C5 신규발급·적용·최종소비 차단과 기존 효과 cleanup/복원 의무는 별도 유지. 사람 입력은 기존 묶음의 승인주체/등록철회 책임·허용 identity/profile/artifact 보호 기준 원문, 권고 기존 Server 보호 공급 재사용, 대안 차단 유지 또는 별도 신뢰체계 공동합의(책임·보존·발급코드 증가). shared 원문·index 무수정.

### 2026-11-08 caller 독립 지적 P2-FOCUS-UI-LATE-SUCCESS-AFTER-UNLINK 수정

기존 CHANGES_REQUIRED·독립1PASS/1FAIL 보존. focus-caller-connection의 popup 사본만 수정: 매 link 알림에서 UI epoch/session/요청 세대를 폐기하고, focus 성공·오류 및 기존 STATE/END 응답 소비 직전에 연결·패널·epoch·session·최신 요청을 검사한다. unlink→다른 계정 relink가 같은 session을 표시해도 이전 성공 게시 불가. 늦은 STATE가 session을 되살리거나 늦은 오류가 새 상태를 덮지 않음. 저장된 actor 원문·결과·cleanup/복원 의무는 불변, Worker/actor·HTML/권한 API 미수정.

수정전 동일독립 실패 재현(ui-lifetime-before.log), 수정후 동일스크립트 작성자 재실행2/2PASS(독립재승인 아님). 신규 unlink/relink·lateerror·lateSTATE3/3PASS, 직접 정상호출/END우선 영향2/2PASS. 기존7·actor/예약 검증 반복 없음. NodeVM/fakeIDB/합성actor공급; 실제Worker/브라우저/효과 아님. 정확 hash·변경분은 기존 RESULT.json/ui-lifetime.diff, 원본before-ui-lifetime.js 보존. 같은 기술검토 담당에게 변경분 재확인 요청. 제품PARTIAL/defaultdeny·운영OFF·정식Core비작성자승인PENDING·실제수용/Git NOT_RUN 유지.

### 2026-11-08 야간 로컬 연결 — 검토 caller 한 후보 / 실제 JS composition·예약 wake

독립 actor b1812295·UI cbd4516(수명 독립4/4)·Server readIssued2fe73e04(보고된 독립3/3) 재사용, 재시험하지 않음. 같은 focus-caller-connection RESULT.ui_contract에 selector/action/request/event/소유 JS를 고정. UI 전용 extension-popup-figma/.local/night-20261108-focus-controls/ 및 HTML/CSS 미수정. 원 caller 두 patch와 현재 변경을 combined-caller.diff로 한 후보에 고정, 원본·이전 실패·원 review 보존.

기존 Worker JS에 installCoordinatedFocus 실제 구현: 기존 MemberExecutionClient의 인증 현재 FocusState GET→operation_id locator→내부-only readIssued 반환{issued,frozen,generation,currentVersion}→동일 owner/fence의 기존 IG04ProviderStore.atomic 보호원문 저장→그대로 기존 actor.submit 소비. UI request_id는 correlation만, operation_id로 쓰지 않음. expected_version=v 원문 불변/currentVersion=v+1 정확비교, frozen/generation/owner scope·credential·로컬수명 재검사. 보호commit 실패시 효과 없음, 응답유실 뒤 같은 원문으로 회복, commit뒤current유실은 원문보존/소비거절. retire 뒤 이전 ambient공급으로 fallback 금지. 실제readIssued 전송 미공급은 GET전부터 거절. production에 authority.initialize/발급/clock생성 없음. NodeVM·실제 old client/provider/actor·fakeIDB·합성E/clock/effect·모의fetch 신규8PASS+별도postcommit1PASS(중복합계 아님), 직접영향4PASS. 실제HTTP/Worker 시험 아님.

예약 기존 PR46→PR48 deadline caller7 불변 재사용. 같은 Worker에 installScheduledExecution으로 기존 adapter를 연결하고 onStartup/고정종료alarm/periodicwake가 저장된deadline check/enforce를 실제호출. 이미동작중 legacyloop 교체는거절. 정확현재session alarm만소비, 새boot·current상실·retire는 의무보존·거절/내부오류상태, cleanup종료확인→기존offlineEnd 흐름 유지. NodeVM·실제기존adapter/deadline·fakeIDB·모의alarm/cleanup 신규5/5PASS. 중간 periodic 시험은 listener promise 미반환으로 관측이 앞선 실패를 보존(schedule-periodic-return-before.log), listener가 기존 tick promise를 반환하도록 수정후 확인. 최초4건을5와누적하지않음. ONCE 신규발급/verifyScheduledDeadline/admission·boot재검증은 여전히실공급없음, defaultdeny.

정확 source/test/diff/log/hash는 기존 focus-caller-connection/RESULT.json의 files/night_connection. 변경검토최소입력은 reviewed f65db9a2 runtime 원본 + composition.delta.diff + schedule-hooks.delta.diff와신규시험, UI/actor/Server검토는재사용. 새Worker변경 기술검토PENDING·정식Core비작성자승인PENDING·로컬구현PASS·제품PARTIAL·실제수용/Git NOT_RUN·운영OFF. 공통원본/index/Shorts설치·패키지·모든실제실행 미접근/미변경.

다음실연결 차단함수: Server 내부 readIssued의 E전송/실Authority·현재성 생산자가 없어 Worker readIssued 공급 없음. 사용자action을새Server command로발급하는 POST 연결도이consumer단위에서는없음(기존POST pendingACK는권한아님). popup HTML제어는UI소유, 실제focus-only executor/clock/receipt소비 미공급. 예약clock/ONCE/admission, 한도확정debit/day·재시작gap해소, 성인승인catalog·matcher, RPT RELEASE issued/reason/clock/producer, Native 목적grant/문서 provenance·인증Core→Content·영속closure 실공급도없는상태. 없는증거/권한생성·과거null백필·새도우미추가로통과시키지않음. 승인주체/등록철회책임·허용identity/profile/artifact 기준은기존한묶음결정: 기존Server보호공급재사용권고, 대안차단유지또는별도신뢰체계공동합의. C5 신규발급·적용·최종소비차단과기존효과cleanup/복원은별도강한요구유지. PAUSING/RESUMING Server END 거절을우회하지않음. 04:25까지자동재실행/배경지속약속없음.

### 2026-11-08 05시 이후 로컬 합친 후보 — 실제 UI/Java private→Core→UI

정확 격리경로: C:/Users/dahun/.codex/visualizations/2026/11/07/01a1b409-a851-73e0-b67e-0138fe0253e3/focus-combined-20261108/ . INPUTS.json으로 야간 Worker dd5cc548·actor b1812295·UI JS cbd4516·UI 담당 HTML/CSS·Server current-issued manifest b02e6cd5의 원문을 복사 고정. 원소유 source 24개 최종불변 확인. source-only/MANIFEST.json(83459c37584607d0c46066a4e9d60f3d030de9cd8a7eff739643c653d2194577)에 제품/의존24·시험전용3과 적용검토순서를 고정. classes·로그·합성export·설치본·권한·node_modules는 source-only에서 제외. 실제 적용/Git 없음.

추가 Core JS는2개뿐. 실제제어요소가있는 popup에서 기존 상태확인 버튼이 일반회원loop만조회해session을못얻던 경계를 MEMBER_FOCUS_STATE→trusted capture session→기존actor.status 보호조회→기존UIevent로 연결. 일반DOM에는 기존일반세션조회유지. 두번째 실제Java 교차언어반례는 canonical정렬된frozen.focus_ref와동일명령ref가키순서만달라JSON.stringify비교에서거절되던문제. 기존 Core canonical을composition필수인자로재사용해구조동일성을비교하고입력원문·owner/generation/frozen/version검사는유지. UI/Server 원문수정·새HTTPwire·pendingACK승격·HTML활성화 없음. 정확변경 runtimebee14be215752265665cba4a1eeb1d6051386c53575f77331da73cdd438880e3, popupJS409f6b09e85c8c9a43d01873e40046b2eb5f10d5fd7763f6bfa6206b67ae8aed, core-assembly.delta.diffdded6c9d9f73f7b6f2371f4736d57c76db0f18017fe9a044819185245c10ae3d.

Java actual E identity/current locator/locked private source/GET state를기존recordingSQL·가짜tx·Authority fixture로호출해private4필드및locator state를JSON으로내보낸뒤, Node가해당원문을그대로기존client→Workercomposition→보호store→검토actor→실제jsdom HTML표시로소비. 이JSON파일은교차언어시험입출력이지운영전송wire가아니다. 신규8/8PASS: 정상PAUSE→PAUSED→같은frozenRESUME→PAUSE→END/정지시간제외, 중복effect1회, 늦은UI응답, version/generation부정, 실JavaPAUSING/RESUMING END409→UI미확인·ENDED없음, 실전송미공급거절, 권한상실상태조회거절, 늦은새상태응답차단. 실Java읽기/거절write0. actor의END우선과Serverpending END거절을같은보장으로하지않음; Server가거절하면CoreENDintent/성공cleanup을만들지않고기존실행·의무보존. 제품소스아닌시험fixture의nullable cadence deadline누락실패/키순서거절원본로그보존. 변경두JS syntaxPASS. 기존UI8/actor·UI수명4/Server검토와예약·기존시험미반복. Java21/Node/jsdom/fakeIDB·합성E/capability/clock/effect·모의fetch/SQL만, DBHTTP/Worker/브라우저/Native실행없음.

로컬결합구현PASS/새Core변경기술검토PENDING/정식Core비작성자승인PENDING/실제품수용·Git NOT_RUN/운영OFF. 다음최소실환경조건은내부-only readCurrent의브라우저E전송공동wire·새사용자action발급POST연결, 실제capability/Authority/clock/focus-only executor/receipt·trustedUIgate 공급이다. 현GET state/POST pendingACK를private4필드/효과승인으로간주하지않음. currentVersion=v+1/expected_version=v와request_id!=operation_id유지. 승인기준·공개wire부재는defaultdeny. Shorts·설치/HOLD/프로필·공유index·다른담당source 미변경. 만료야간창을실행승인으로재사용하지않음.

최종입력대조: Core private readIssued callback에 {sessionId,operationId,action}을전달해Server bridge.readCurrent(existing E request,sessionId,action)과맞춤. operationId는Core쪽기대locator이며Server가잠근현재operation과정확비교, request_id대체없음. 이인수정합성추가후같은통합8건만영향재확인PASS(신규수누적없음), 최종 RESULT SHA256 131f2451e4d7d9fe5cee3695e026cb47da5ab25d9b83388e27dea5a9ecda7fcc.

최신UI entry/popup 진입점·presentation/중복방지loader 고정본도같은후보에반영완료. UI HTML/CSS/표시/loader는원문그대로이며Core UI JS만최종overlay. 실제defer리소스로드→Core1회→Worker/Java원문/actor/UI의최종통합9/9PASS(tests/combined-entry.log). 이전단계8건을9와합산하지않음. loader반복삽입에도Core로드1회/실제제어호출1회. UI기존DOM8/entry영향4는재사용. 최신 RESULT SHA 957e99c90c93bf74cc299cce072240c36c486a28e5288a2e167f5d48e55bf2cc, source-only manifest 83459c37584607d0c46066a4e9d60f3d030de9cd8a7eff739643c653d2194577.

### 2026-11-08 합친 후보 독립 지적 — 이전 STATE가 새 제어를 덮는 경합 수정

기존 focus-combined-review CHANGES_REQUIRED(정상1PASS/경합1FAIL)와957e99c9 RESULT/83459c37 manifest를보존. 변경은같은격리후보Core popupJS만. 제어요청시작에서이전STATE 요청순서·제어세대를폐기하고STATE 성공/오류/정리소비직전같은연결·세션·제어세대·최신요청을검사. 제어대기중상태조회는보류, 제어완료후정상최신조회는허용. member연결변경도제어세대무효화. 이전STATE최종처리가버튼상태를바꾸지못하게하고제어종료뒤현재UI상태조회만복구. 기존PAUSE/RESUME/END우선·권한·기한·수명검사·레코드/cleanup의무·actor/Worker/Server/UI소유원문은변경없음.

동일늦은RUNNING STATE 반례변경전FAIL(persisted PAUSED그대로)→후PASS. 새경합/오류/후속정상조회/RESUME·END/같은session unlink-relink 5PASS(4건+별도1건), 직접unlink·END거절·loader영향4PASS. 기존통합9/actor/UI/Server 전체반복없음, syntaxPASS. Node/jsdom/fakeIDB·기존오프라인Javafixture만, 실제Worker/브라우저/서비스/권한/Git/효과0. 기존before-popup409f6b09 보존, before RESULT/manifest는tests/에보존, state-control-order.delta.diff/최신RESULT에정확hash·원본관계·검토입력고정. source-only같은제품24·시험4로갱신. 새변경분독립재확인PENDING/정식Core비작성자승인PENDING·운영OFF·제품PARTIAL 유지. 관리채팅에반환할정확입력은 focus-combined-20261108/RESULT.json와state-control-order.delta.diff 및tests/state-control-order.test.mjs/전후log이다.

### 2026-11-08 06:14 재개 — 최종동일성 고정 / 다음 실제생산 경계

d381 popup은main/source-only/manifest 모두이미일치. manifest d74ef41c 불변, 제품·의존24/시험4와실제파일집합정확일치·폐기source/클래스/로그혼입0 확인. 소스·manifest 재생성/동일시험0. state-order-recheck 독립4PASS 원문과현재popup·delta동일성확인해기존RESULT의기술재검토대기를해소, 정식Core비작성자승인은별도PENDING. 새재검토요청안함. Java currentVersion(v+1)/issued.expected_version(v)/operationlocator/privateEbridge/최신HTML진입점은동일원문으로기존통합9/Java→JS근거재사용. 운영publicWire/Authority미공급/defaultdeny·제품PARTIAL·실수용/Git NOT_RUN 유지.

다음독립단위를소유source에서좁혀대조: (1) AdditionalTimeRuntime.capture→AdditionalObservationJournal.append/recover는관측·RESTART_UNCONFIRMED까지만생산하고 calculateConservativeBudget가요구하는검증된정책/설치/day의debit/provisional 원장은생산하지않는다. calibrated ClockedUsageSegment·day배분/원장writer·재시작gap해소proof공급이없어관측을사용0/확정debit로변환불가. (2) inspectAdultDomain(host,policy,matchCatalog)는승인catalog artifact/version/hash/profile/last-valid 생산자가없어FAILED. callback만추가한consumer를또만들지않음. (3) IG04ProviderStore.close/queryClosure·기존P1Native.lease/guard는실authority/fence·purpose-boundproof/정확RELEASE가필요하고일반화할grant·독립문서provenance·oldscopeCleanupGrant/terminalproof가없다. 기존목적grant를다른기능으로간주하거나inactiveauthority검사를완화하지않음. 확정운영생산자없는경계에새권한/증거를주입해로컬성공을만들지않았고이번재개에새제품코드/시험추가는없다.

정확입력/담당/다음수정파일·사람결정권고/대안/보장차이는기존RESULT.next_existing_connection_boundaries/human_choice_bundle에추가. 권고는사람이실승인주체·registry등록철회자격/허용identity·profile·artifact/catalog 및실clock생산자를지정한뒤기존Server보호공급책임을재사용하는것. 대안defaultdeny·의무보존지속또는별도신뢰발급체계공동합의. 회원E인증≠capability승인, 로컬현재성≠C5원격즉시철회. 실제생산자/공동시간배분·신뢰원문없는코드확장을중지하고다음실입력에서재개. 기존예약startup/alarm5·deadline7/actor/UI/Server검증반복0. Shorts·설치·프로필·원장/잠금·공유index/소유source 미변경, 실제실행/Git0.

## 2026-11-08 역인계 수신·기준 확인 — 종민 복귀

첨부 FOCURVE-CORE-RETURN-HANDOFF-20261108.zip SHA256 26e9eacfa8d31621b135bd27af88bab96a8a6a78b95adb9fe75fa8998740615b 일치. READ-FIRST→core/APPLY-ORDER→MANIFEST/DELTA/COPY/PATH/OMISSIONS/Server·실행 경계 순서로 확인. PACKAGE-MANIFEST 1064파일의 크기·hash·파일집합 일치. final key sources10 SHA 일치, portable 상대import 누락0(정적 경로 확인만). 시험/빌드/DBHTTP/Chrome/Native 재실행0. 문서가 아닌 첨부 원문 명령을 실행 승인으로 채택하지 않음.
원본 a79808a8 ZIP current 파일13 중 제품·시험11개 SHA는 역인계 baseline metadata와 일치. 문서2개는 historical workspace hash와 ZIP최종문서hash 불일치: AMVP-CORE-04 실제457c437200c79979e7c049a8e03d63f21c639239c267329078993d311f6b35ac(선언5d2eba9c...), 통합현황 실제cccc20a48d7ef1ac0e53030aefa1ea39f6cc91906ef03f39f9b800898cf87e63(선언40b37eaf...). 이는 원본ZIPcurrent와 이전workspace metadata의 차이로 정정 기록, 소스변조/누락으로 확대하지 않음. 원본ZIP의 실제문서바이트와 반환된최신문서 모두 보존. 제출manifest1064 불일치0과 구분.

### 인수 범위·소유
원래 /workspace/focurve-ig04-provider-local 및 index 보존, /workspace/focurve-core-return-20261108에 source-only 격리 접수. restored-original/은 원래 a79808a8 baseline+#88 미커밋 원문이며 최신제품이 아님. candidates/core-local, candidates/schedule-connection, candidates/focus-combined를 각각 최종후보 layout 그대로 복사. portable/은 경로이동된시험/fixture 미실행사본. 과거 snapshots/before/실패popup cbd4516·409f6b09/별도Shorts미검토후보 자동적용0. Server Java/공유popup HTML·CSS·presentation·loader를 다른담당실제workspace에반영0.
focus 최종 popup d381bb15d35d857d6c77331fb494804ed1fc424b87e0b25dcfe1c935a0b9e595 / Worker bee14be215752265665cba4a1eeb1d6051386c53575f77331da73cdd438880e3 / actor b1812295fedf95d881fb31d64ea295e4ed5e72f6c626434541a59a7d0984cba0을 기준으로 수신. 이번수락은 후속작업의 source기준·Core/Native 소유인수이며 전체코드의 정식독립승인/제품수용/운영권한발급/실행승계 아님. 다훈은 Shorts·설치·Web/Server/DB 계속담당, 지민 Content·DOM복원 유지. 이번 실제제품수정파일0,독립수신검토및#116정식리뷰만수행.
쓰기중지 원문은2026-11-08T10:05:33.638990+09:00(전달문10:05:34반올림) 확인. Core운영Native신규source없음, 기존문서R1/Chrome바인딩이후grant/authproducer미공급유지. OMISSIONS의 local lifetime7 standalone log와 RPT pre-fix failure full log2건은 메타데이터·시험소스만존재, 출력재생성/재시험0. 실행당시의존바이트동일성·정식적격Core비작성자승인은기존미확인/대기그대로.

### 1. 회원 BLOCK·END·복원·재진입 관측 판정
추가DNR 경로에 쓸 수 있는 내부부품은 존재한다.
- SiteTimeDnrEvidence.read(context)→current(snapshot(intent)): context와policy/claim 원문을대조하고실제DNR스토어를다시읽음. current.stores의SESSION/DYNAMIC.status=OBSERVED와 claims[].identity_matches/comparison/actual_rule_sha256/restore_state/live_footprint_matches/other_live_claim_ids/cleanup_pending, operations[].state/scope_verified/claim_ids, snapshot_sha256를제공.
- current.claims[].release_footprint_verified는 소유claim RELEASED+같은owner/generation scope RELEASE operation과 실제DNR결과를함께요구. 비공유는MISSING,다른살아있는동일hash소유자가있으면MATCH를유지한다. 전부빈DNR이어야성공이라는판정아님. 외부/다른소유규칙은보존.
- readRegisteredSnapshot(context,expectedEvidenceSha256)는등록시저장원문조회일뿐현재효과아님. self_hash와전체raw_hash혼용금지.
- AdditionalDnrCoordinator.releaseOwner(epoch,{operationId,ownerBindingId,generation})는검증전후관측후소유claims만해제. recordReleaseObservations=false기본. 별도합의·운영wiring없이true로바꾸지않음.
- 옵션을명시선택한경우에만 RELEASED원장commit과 candidate:dnr-release-observation:<operationId> 및 :handoff가동일metadata transaction에남음. AdditionalDnrStore.readReleaseRecord(operationId)는hash/원문/관계를검사해재조회. 옛RELEASED관측없으면null,응답유실뒤과거관측백필금지. 이원문은issued_relation/reason/clock/producer_ref가null인DRAFT이며 BLOCKED_UNASSOCIATED/report:null 상태다. 보고권한·RPT_ACK/저장영수증/실제DOM복원증거로승격금지.

회원기존A1 코드에도 MemberCore.dnrVerified(state)와finish()의 실제getSessionRules/자기rulehash대조·소유rule제거후재조회, binding RELEASE검증·미해소/cleanup검사·journal.observed RELEASED 저장이있다. 그러나 이내부상태를외부수용collector로묶는운영export가제공된것은아니다. #88기준소스와실제93e설치패키지의동일성도이번에확인하지않음. 추가DNR sidecar를기존회원실행이미사용하는것으로가정하지않는다.
회원existing_export_adapters.py는safety_end의release_ack/command_id/member_id와safety_restore의owned_baseline_restored/evidence_ref를명시None으로남긴다. 따라서 현재자료만으로완결된실제회원BLOCK→END→원래정책복원→재진입성공영수증은없다. APPLIED ACK·STATE RUNNING·DNR규칙존재/부재·gate CLEAR·서비스정상종료만으로이항목을성공처리하지않는다.
최소추가연결: 선택된정확회원패키지의기존protected원문(session/owner/executor/policySnapshot/command/generation·소유rule참조)와Chrome의현재관측을읽기전용으로결속해기존collector의빈칸을채우는공급이다. 실제BLOCK은해당URL의실제접근/안내와same navigation/document·선택policy를함께관측,END는같은command/세션해제와잔여의무확인,복원은원래소유baseline과다른소유규칙/정책보존대조,재진입은실제문서접근가능을새로확인해야한다. 단순DNRhash만으로브라우저접근성공/실패를인정하지않음. 공개DTO/새현재성증거를임의발명하지않고기존필드의인증원본mapping부터공동확정.
담당: 종민Core(정확source의read-only관측/세션·규칙·operation결속), 다훈설치·회원실행/공식export획득·촬영·실제재진입, 지민은해당실행에Content변경/미해소binding이있을때그범위복원근거만공급. 없던IG04효과를필수로추가하지않음. DEV_MEMBER_EXECUTION_STATE는현재코드에서tick()을호출하므로read-only관측API로사용금지; 관측채집이일반Worker복구/정책재적용을유발하지않는경계가먼저필요.

### 2. 첫 실제 연결 단위와 Server에 필요한 입력
로컬완료인installCoordinatedFocus/actor/U4/기존보호저장을재작성하지않는다. 다음Core단위는 candidates/focus-combined/extension/background/member-execution-runtime.js의readIssued seam에 기존E인증transport를연결하고최종소비직전현재성/원문scope를유지하는일이다. 실제수정대상예약은이Worker파일과동일후보tests/combined.test.mjs의변경영향시험으로한정. 아직runtime수정없음,주소/실패의미미확정상태에서실제새adapter·공개route를추정구현하지않음. popup/actor/U4/Server파일은이번단위에중복수정하지않는다.
기존Core callback입력={sessionId,operationId,action}, 결과={issued,frozen,generation,currentVersion}. operationId는원래보호operation대조값이며UI request_id와다름. Server공급은AmvpCadenceIssuedBridge.readCurrent(기존E HttpServletRequest,session,action)→control.readCurrentIssued의보호locked currentoperation이다. 클라이언트가보낸ID/digest를발급원본으로신뢰하지않는다. issued.command.expected_version=v불변,pending currentVersion=v+1. owner_binding_id/executor_id/owner_epoch/generation/frozen/command.focus_ref/operation/action/execute_before를정확대조;쿠키fallback/새권한발급/POST202대체없음.
이미받은Server소스/fixture/b02e6cd5 manifest는재요청안함. 실제연결선행공급은(1)private readCurrent를외부E인증client에서어떤기존method/path·strict요청으로호출할지정확최소wire차이,(2)그entry의고정소스·hash및인증owner/executor/현재성·action선택문맥,(3)같은request수명/만료·401·조회실패·미발급시반환정책이다. 현재Java는private GET/noquery/no body임;공개route/Bean/operatingproducer없음을명시하므로Server의비활성wrapper와공유호출계약합의필요. P1 SourceRead의200null합의를focus issued부재로확대하지않는다. missing/expiry/currentfail은소비거절,원문/의무보존. payload·운영credential·실제grant전달요청아님.
운영authority/clock/focus executor는위transport와별도미공급. syntheticfixture {} snapshot/expired시각를운영공급으로쓰지않음. PAUSING/RESUMING에서Server END거절은현공동계약차이로남기고actor END우선시험을Server END지원으로확대하지않음. RELEASE generation/issued mapping·trusted clock/reason/producer도별도, C2/C5 그대로HOLD. 현재단위완료조건은정확기존호출과소비의연결·인증/current실패거절·저장/의무보존의변경영향근거이며실제HTTP/Native/제품수용은따로승인·검증해야한다.

### 3. #116 기존정식요청 리뷰 종료 및Legacy 최신상태
#116 exact HEAD da6bb8a0045d7c128d2b683e86a19d38f47e26af/tree0b7c89977b025235d5b3a82d7fdf6d640b49498d,4파일Gitblob/SHA가역인계게시근거와일치. 완료항목제외·실패선택보존·known batch첫 GET실패/불완전뒤정확batch재조회잠금·owner전환/늦은응답·현재401거절을변경원문/기존시험과대조. 필수결함없어APPROVED등록: https://github.com/kdu-sw-capstone/capstone-project/pull/116#pullrequestreview-5816200645 . 기존개발자/독립근거재사용,최신15원격checks SUCCESS확인;제품시험반복0/수치재합산0. 실제가져오기·계정A/B·Worker재시작수용및merge승인아님. 미확인batch응답유실을완료로처리하지않음.
#115 원격CLOSED/unmerged및기존CHANGES_REQUESTED 유지확인. develop trust enabled=false/NOT_GRANTED 확인. #109 efd128f OPEN/APPROVED 그대로,양쪽legacy17실패는첨부기존로그근거유지/CI반복없음. 원격환경/rootpin/operator jobtoken권한을조회·설정하지않고UNKNOWN 유지. source-only root경계후속후보를승인하지않음.
Shorts18f의보존정지성공은서비스한정이며END미호출/복원미확인을해소하지않음. 회원93e설치성공과CONNECT실패·미실행hardening을분리,기존실행승인/사용횟수/기한승계0. 이환경에서다른PC프로세스/DB/profile/locks/HOLD의현재상태를추정하지않는다.
