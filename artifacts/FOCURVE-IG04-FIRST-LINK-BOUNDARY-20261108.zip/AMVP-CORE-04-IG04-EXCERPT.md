## 2026-11-08 IG04 단일 기능 Core→Content 연결 착수

이번 최신 지시로 우선순위를 IG04 단일 기능 연결로 조정한다. 직전 focus readIssued의 미공급 계약·소스는 대기 상태로 보존하며 병행 제품수정을 시작하지 않는다.


사용자 지시로 첫 대상 IG-04만 고정. Content 기준 0a1b5e7e07ee3cfd47fe7a8ca495b3044ac5e6ca의 extension/content 전체를 Git object에서 별도읽기사본으로 확보. Content 제품/시험 파일수정0, Shorts/Server/기존Worker제품파일수정0. 원래 #83/#87 선행관계를단독cherry-pick으로분리하지않고참고전체tree의content를사용한다. 새 작업공간 /workspace/focurve-ig04-first-link-20261108, Core 역인계26e9eacf 후보원문을재사용. 이작업은기존readIssued공유계약이나운영권한을임의확정하지않는다.

### 현재 실제 공급 가능 범위
- P1→U4: IG04P1Preparation.createP1ObservationVerifier/hasCurrentP1Observation, bindP1LocalLifecycle와검토guard를동일heap·동일서비스/원래trusted/동결exactAttempt/정확stored객체로공급가능. 복사·직렬화/다른서비스·수명/관측된철회거절은기존근거재사용. 이것은준비결과의로컬접수이며APPLY/watch/예약/Native권한이아니다. 실제운영trusted/capture/current/native source는아직없다. Worker→Content 메시지로WeakMap객체·함수를직렬화해인증할수없다.
- IG04입력: 기존 IG04PlanAdmission.open/verifyContext/getGeneration/verifyPlan의Registry·issued/native·현재성재검증재사용가능. 입력context.scope15필드+operation_id/semantic_sha256, features=[{feature_id:'IG-04',enabled:true,required:true}] 그대로. verifyPlan의성공은영속reservation ACK가아니며현재provider없는open은거절. 실제Worker instance·native document/URL/generation 채널결속·운영verifyInput은별도미연결.
- 예약: Content reserve(plan,{signal,transport})는각동적요소를실제숨기기전 Core영속예약commit/최종권한재검사후정확plan_id만받는기존gate. ACK미확정/유실/취소/만료는효과거절과의무보존. 현재admission/store부품만으로운영예약ACK를발급했다고표시하지않는다. Core issuer/native 검증·영속예약/재조회/정확송신문맥결속의공급이남음.
- 해제: receiver.release(원래context,authorization)/completeReservation(원래context,identity,opaqueProof), verifyRelease/verifyCompletion을재사용. APPLY권한과old-scope cleanup권한을분리. 로컬복원≠영속terminal/watch종료≠전체RELEASE. 실제CleanupGrant/terminal proof/영속완료ACK/watch 종료provider는미공급, cleanup_pending을임의삭제하지않음.
- 문서전환: 새URL/문서/generation/Worker는원래권한으로자동재승인하지않음. 현재receiver의authorizeNavigation=false와pagehide/Worker전환퇴역유지. 새발급/채널재검증은새권한원문이있을때만. 기존scope/proof를새문서에복사하지않음. Native scope와generation 신뢰생산은Core/Chrome·Native책임이며Server의페이지자기선언으로대체하지않는다.

### 이번에 확인한 추가 연결 필수사항
#87 최신receiver는7개기존콜백이외에 prepareResources(authorization,{context,features,transport})의동기strict true 확인이listener설치전필수다. prepareResources가Promise면해당대기동안pagehide/BFCache를보호하지못하므로RESOURCE_LIFETIME_REVALIDATION_REQUIRED로거절한다. 따라서Core가영속watch 준비를미리완료하고인증된동일watch/receiver/Worker/문서수명에결속된결과를Content가동기로소비하는경로가필요하다. 임의true callback/발급되지않은watch_ref로통과시키지않는다. 현재quiescenceSnapshot은local_startup/local_lifetime/진행scan·예약scan0등로컬근거이며watch_ref/cutoff/영속종료완료를직접생산하지않는다. 기존공유계약의watch검증·종료콜백결속을실제생산자와맞춰야한다.

역인계에보호importer 구현이있다고기록돼있으나 manifest전체1064파일과소스검색결과 실제 protected-original-importer.mjs 및대응개발자시험은없고기술검토JSON/독립시험의C:/절대import만있다. 이는추가로발견한소스공급누락이며기존OMISSIONS의미저장로그2건과별도다. 재구현하지않고아래정확2파일만다훈에게요청:
protected-original-importer.mjs SHA dc3d68bb9830de55fbb0a44fafcbf6b5bed6711ddbdb541615847a6521e106c4
protected-original-importer.test.mjs SHA 624a37cc6646105735829f190663bf5c08788a737c7d17b74ca51be42243acea
기존개발자14/기술5 PASS근거는이미있어반복요청/재시험안함. 받기전운영importer공급완료/실제연결PASS로기록하지않는다. 앞선패키지무결성1064PASS는'선언된파일이손상없이전달됨'범위이며이소스부재를해소하지않음.

### 신규 연결 검증
Core소유 새시험 ig04-u4-receiver-boundary.test.mjs와기존Core-U4 fixture의원래setup prefix를재사용한 ig04-link-reused-fixture.mjs만추가. Core제품/U4guard/Content #87 원문수정0. 합성 auth/native/IndexedDB/문서·EventTarget fixture에실제Core/U4/receiver JS를연결. 기존8+2·Content단위전체반복0.
새3/3PASS FAIL0 SKIP0: U4접수가receiver APPLY/예약권한아님, 기존7seam모두있어도prepareResources부재시차단, 비동기준비반환은동기watch권한으로소비불가/이전Core저장·의무보존/RELEASE오용거절. APPLY검증자/현재성/cleanup검증은false,예약provider는throw하는음성fixture로만구성했고운영부재를true성공으로대체하지않음. 실제DOM효과/브라우저/HTTP/DB/Worker메시지/Native검증아님. 첫실행은새시험의상대import한단계오류로module-load FAIL1(제품미실행),테스트경로만정정후3PASS;첫로그보존. newPositiveApply/restore제품성공을주장하지않음.

### Server에 필요한 입력과 다음 단위
이미받은P1조회/SourceRead/FOCUS private issued자료는재요청하지않음. 필요한것은IG04효과를실제로허용하는운영발급원문/생산자:
1. 인증된owner_binding_id/executor/owner_epoch 및현재runtime/package/frozen focus와IG-04 feature/profile/artifact 승인registry/capability 원문. 준비Attachment/P1접수/login을APPLY허가로승격하지않음.
2. 실제issued operation의원문·semantic hash·허용scope/기한/세대·현재권한조회·철회전이의소유entry/반환/실패정책. Core가native document/URL/Worker/receiver수명에결속하고검증할수있어야함. Server가native문서증거를직접창조할필요없음. C2/C5와새발급차단·기존cleanup보존을분리.
3. 전달누락importer2파일과정확고정소스(위hash),부족한직접의존만. 기존로그/시험은재사용.
Core는issued/native검증→동일원문영속watch준비→Content동기자원소비→verifyInput→각plan admission→영속예약commit후ACK→실제적용관측→scopedRELEASE/cleanup→복원확인→영속terminal/watch종료의순서로연결. 운영issuer/준비/ACK/Grant/proof가미공급인단계를건너뛰거나새publicDTO를임의작성하지않는다.
다음수정소유는Core의운영provider·준비/예약/해제facade 연결;Content consumer수정은지민담당. 이번변경은Core소유시험2개·카드/원문전달자료뿐이다. 최초실제Worker START/END·제한/복원은후속정확후보와승인대상,SPA/BFCache·다른owner보존·실패cleanup은그뒤영향확장. C2/C5/M1운영BLOCKED·실제권한·효과·제품Git게시HOLD/MVP_FINAL_COMPLETE=false 유지. 전달용ZIP만testest게시.
