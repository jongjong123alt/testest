IG04 Core→U4→Content receiver first boundary handoff / 2026-11-08

This is not a working APPLY/END candidate or operating authorization. Content files are unchanged exact Git objects at #87 HEAD 0a1b5e7e07ee3cfd47fe7a8ca495b3044ac5e6ca. Core product sources and reviewed U4 guard are unchanged received files. Only two Core-owned test/fixture files and handoff records are new.

New selected same-heap boundary test: 3 PASS / FAIL0 / SKIP0, using existing Core fixture with synthetic authenticated/native source plus fakeIndexedDB and a Node document/EventTarget double. No Chrome/Worker transport/real DB/HTTP/Native/actual DOM effects. Existing 8+2 Core-U4 and Content unit suites not rerun. The initial module import path typo failed loading once; before-import-path.log retained, corrected test path only, no product fix.

Reproduction only if needed after a change: in this extracted core/extension, npm ci --ignore-scripts then node --test tests/ig04-u4-receiver-boundary.test.mjs. Uses original lock fake-indexeddb6.2.5, Node24. No automatic script or production startup. External modules are fake-indexeddb and Node built-ins. No node_modules shipped.

Findings:
1 P1/U4 registration acceptance supplies no Content APPLY/watch/reservation authority.
2 Latest receiver additionally requires synchronous prepareResources before listener installation. Async ACK cannot safely install the first listener; a previously committed, authenticated watch preparation must be consumed synchronously under exact receiver/Worker/document lifetime. Do not add a true callback.
3 Exact protected-original-importer.mjs dc3d68bb9830de55fbb0a44fafcbf6b5bed6711ddbdb541615847a6521e106c4 and developer test624a37cc6646105735829f190663bf5c08788a737c7d17b74ca51be42243acea are NOT in the return ZIP, despite review references. Request those two original files and missing direct dependencies only; do not recreate importer or repeat its existing14/5 tests.

Actual Core readiness: createP1ObservationVerifier/hasCurrentP1Observation and bound local lifecycle can be supplied in one trusted heap, but operating trusted/capture/current/native source is absent. IG04PlanAdmission validates issued/native/current scope but does not commit reservations or emit ACK. Runtime Worker instance, document/generation binding, durable reserve/lookup, CleanupGrant, completion proof and watch closure providers remain unconnected. Original fields/strict true/synchronous isCurrent are unchanged. SPA/document/BFCache authority is not automatically renewed.

Server input needed: authoritative IG04 feature/profile/artifact approval + owner/executor/binding/epoch/runtime/frozen reference; exact issued operation/semantic hash/scope/expiry/current-revocation source/entry and failure meaning. No login/private preparation/source hash/Attachment can replace APPLY rights. Core/Native provides real document/URL/generation/Worker binding, not Server body declarations. Old-source cleanup and revocation admission remain separate. Existing received Server sources/fixtures are reused, not re-requested.

Next ownership: Jongmin Core provider/watch/reservation/release facade; Jimin Content consumers. Do not edit Content source, shared Server/UI or Shorts. C2/C5 and M1 operating BLOCKED; actual START/END/effects/rights/product Git remain HOLD. ZIP distribution to testest only is authorized.
