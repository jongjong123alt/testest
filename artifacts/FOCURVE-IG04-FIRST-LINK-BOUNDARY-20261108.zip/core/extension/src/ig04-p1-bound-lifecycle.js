import {canonical} from '../a1/contract.mjs';
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const copy=x=>freeze(structuredClone(x));
const same=(a,b)=>canonical(a)===canonical(b);
const strict=x=>{if(x&&typeof x.then==='function')Promise.resolve(x).catch(()=>{});return x===true;};

// Inactive local wrapper ONLY. Upstream functions must belong to the trusted
// same-heap composition. This neither authenticates messages nor issues rights.
// No metadata writes, authority initialization, Native dispatch, or C5 promise.
export function bindP1LocalLifecycle({trusted,exactAttempt,capture,isCurrent,verifyNative,
  now=Date.now,monotonic=()=>performance.now()}={}) {
  if(!trusted||typeof trusted!=='object'||!exactAttempt||typeof capture!=='function'
    ||typeof isCurrent!=='function')throw Error('P1_LIFECYCLE_PROVIDER_REQUIRED');
  const snapshot=copy(capture(trusted)),attempt=copy(exactAttempt);
  const start=monotonic(),wall=now();
  if(!snapshot||!Number.isSafeInteger(snapshot.deadline)||!Number.isSafeInteger(wall)
    ||!Number.isFinite(start)||wall>=snapshot.deadline)throw Error('P1_LIFECYCLE_INVALID');
  const end=start+(snapshot.deadline-wall);
  let retired=false,lastMono=start;
  function check(t,c,a) {
    if(retired||t!==trusted)return false;
    try {
      const w=now(),m=monotonic();
      if(!Number.isSafeInteger(w)||!Number.isFinite(m)||m<lastMono||m>=end
        ||w>=snapshot.deadline||!same(c,snapshot)||!same(a,attempt)
        ||!same(capture(trusted),snapshot)||!strict(isCurrent(trusted,snapshot,attempt))) {
        retired=true;return false;
      }
      lastMono=m;return true;
    } catch {retired=true;return false;}
  }
  if(!check(trusted,snapshot,attempt))throw Error('P1_LIFECYCLE_UNCONFIRMED');
  return Object.freeze({
    capture:t=>check(t,snapshot,attempt)?snapshot:null,
    isCurrent:check,
    retire:()=>{retired=true;},
    verifyNative:async(t,n,c,a)=>{
      if(!check(t,c,a)||!same(n,snapshot.nativeScope)||typeof verifyNative!=='function')return false;
      try {
        const result=await verifyNative(t,copy(n),snapshot,attempt);
        if(result!==true){retired=true;return false;}
        return check(t,c,a);
      } catch(error){retired=true;throw error;}
    }
  });
}
