import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory} from 'fake-indexeddb';
import {createMemberDB} from '../member-a1/db.mjs';
import {A1Store} from '../member-a1/store.mjs';
import {canonical} from '../a1/contract.mjs';
import {IG04ProviderStore} from '../src/ig04-provider-store.js';
import {IG04P1Preparation} from '../src/ig04-p1-preparation.js';
import {IG04P1ServerSourceAdapter,p1Utf8Sha256} from '../src/ig04-p1-server-source.js';
import {createP1ConsumptionGuard} from './fixtures/ig04-u4-reviewed-consumption-guard.mjs';
const uid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const same=(a,b)=>canonical(a)===canonical(b);
const copy=structuredClone;
const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};
const deferred=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};

// Local integration fixture only: real Core/adapter/store/U4 modules, synthetic
// external source/native records. No operating provider is replaced by allow.
async function fixture({missingTransport=false,missingNative=false}={}){
 const db=createMemberDB(new IDBFactory(),'u4-real-core-'+crypto.randomUUID()),store=new A1Store(db);
 const binding={owner_key:'MEMBER:1',executor_id:uid(1),binding_id:uid(2),epoch:9};
 const sourceRef={id:uid(3),version:1},original={sourceRef};
 const attempt=freeze({requestId:uid(4),sourceRef,sourceVersion:1,original,bytes:canonical(original),digest:await p1Utf8Sha256(canonical(original))});
 const native=freeze({document:'local-fixture-document',generation:2,attempt:'native-attempt',channel:'fixture-channel'});
 const originalSource={reference:sourceRef.id,executor:uid(1),user:'1',requestId:uid(5),requestDigest:await p1Utf8Sha256('protected creation original'),
  binding:{bindingId:uid(2),epoch:9},snapshot:{format:'AMVP_P1_SETTINGS_SOURCE_1',bytes:canonical({settings:[]}),settingsVersion:7},
  policyId:'LOCAL_TEST_ONLY',createdAt:'2026-11-06T00:00:00Z',expiresAt:'2026-11-06T00:05:00Z'};
 const raw=canonical(originalSource),response={sourceRef:sourceRef.id,sourceVersion:1,raw,rawSha256:await p1Utf8Sha256(raw),expiresAt:Date.parse(originalSource.expiresAt),bindingId:uid(2),ownerEpoch:9,executorId:uid(1)};
 const state={now:Date.parse('2026-11-06T00:01:00Z'),sourceError:null,nativeActive:true,currentAvailable:true};
 await store.atomic((tx,done)=>{const md=tx.objectStore('metadata');md.put({key:'a1:owner-fence',epoch:'local-a1-fence',owner_context:'MEMBER:1',transitioning:false});
  md.put({key:'local-fixture:native',scope:native,active:true});
  md.put({key:'local-fixture:existing-obligations',local:['restore-original'],watch:['pagehide-listener'],reservations:['pending-terminal'],cleanup_pending:true});done(null);});
 const allowedOriginals=new Map([['protected-attempt',attempt]]);
 const providerStore=new IG04ProviderStore(store,{guard:(action,input,rows)=>{
  const fence=rows.find(x=>x.key==='a1:owner-fence');if(fence?.owner_context!=='MEMBER:1'||fence.epoch!=='local-a1-fence'||fence.transitioning)return false;
  if(action==='initialize')return input.id==='authority'&&same(input.binding,{scope:native});
  if(action==='register')return input.id==='authority'&&allowedOriginals.has(input.localId)&&same(input.original,allowedOriginals.get(input.localId));
  if(action==='lookup')return input.id==='authority'&&input.localId==='protected-attempt';
  return false;
 }});
 const token=await providerStore.initialize('authority',{scope:native});
 await providerStore.register('authority',token,'protected-attempt',attempt);
 const trusted=Object.freeze({}),context={authorityId:'authority',token,requestLifetime:'request-A',revision:1,sourceLocalId:'protected-source',sourceVersion:1,
  attemptLocalId:'protected-attempt',attemptVersion:1,nativeScope:native,binding,deadline:state.now+120000};
 const capture=t=>t===trusted?copy(context):null;
 const isCurrent=(t,c,a)=>state.currentAvailable&&t===trusted&&same(c,context)&&same(a,attempt);
 const client={credentials:async()=>({owner_key:'MEMBER:1',executor_id:uid(1),access_token:'LOCAL_FIXTURE_ONLY'}),request:async()=>{throw Error('NO_PRODUCTION_ROUTE');}};
 const adapter=new IG04P1ServerSourceAdapter({providerStore,capture,isCurrent,attemptRecord:()=>({localId:'protected-attempt',version:1}),now:()=>state.now,
  readAuthenticatedSource:missingTransport?undefined:async(c,credential,query)=>{
   if(c!==client||credential.owner_key!=='MEMBER:1'||credential.executor_id!==uid(1)||query.reference!==sourceRef.id||query.expectedSourceVersion!==1||query.readAttempt.original!==attempt.bytes)throw Error('FIXTURE_AUTH_REJECTED');
   if(state.sourceError)throw state.sourceError;return copy(response);
  }});
 await adapter.authenticate('read',trusted,attempt);
 const options={store,client,capture,isCurrent,...adapter.forContext(trusted),now:()=>state.now,
  verifyNative:missingNative?undefined:async(t,n,c,a)=>{
   const record=await store.read('local-fixture:native');
   return t===trusted&&state.nativeActive&&record?.active===true&&same(record.scope,n)&&same(n,native)&&isCurrent(t,c,a);
  }};
 const core=new IG04P1Preparation(options);
 const rows=()=>db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result);});
 async function register(){
  const source=await core.readP1Source(trusted,attempt,binding,sourceRef);
  const handle=await core.verifyP1Preparation(trusted,attempt,source,native,attempt);
  allowedOriginals.set('protected-source',source);await providerStore.register('authority',token,'protected-source',source);
  return core.registerP1Preparation(trusted,attempt,handle,0);
 }
 function bind(owner=core){
  const verify=owner.createP1ObservationVerifier(trusted,attempt);
  // The reviewed guard treats consumeExpectation as opaque. For this local
  // fixture it is the original frozen ExactAttempt, not a new public DTO.
  return createP1ConsumptionGuard((t,expected,stored)=>
   t===trusted&&expected!=null&&Object.isFrozen(expected)&&same(expected,attempt)&&verify(stored)===true);
 }
 return {db,store,providerStore,trusted,attempt,binding,native,context,state,core,adapter,options,register,bind,rows};
}

export {fixture};
