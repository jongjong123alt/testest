import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture} from './ig04-link-reused-fixture.mjs';
import {IG04ContentReceiver} from '../../../content-reference/extension/content/ig04-receiver.mjs';
const uid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
class Events extends EventTarget {
 listeners=new Set();
 addEventListener(type,fn,...rest){super.addEventListener(type,fn,...rest);this.listeners.add(type);}
 removeEventListener(type,fn,...rest){super.removeEventListener(type,fn,...rest);this.listeners.delete(type);}
}
// Receiver's existing structural scope, explicitly synthetic and NOT derived
// from a P1 preparation/sourceRef. All APPLY providers below deny; no true stub.
function receiverFixture(){
 const win=new Events();win.navigation=new Events();
 const document={location:new URL('https://www.instagram.com/p/local/'),defaultView:win};win.document=document;
 const context={scope:{owner_binding_id:uid(1),binding_id:uid(2),generation:1,owner_epoch:1,executor_id:uid(5),runtime_execution_id:uid(6),package_id:uid(7),runtime_revision:1,scope_epoch:uid(8),tab_id:1,frame_id:0,document_id:'native-doc-1',document_instance_id:uid(4),url_sha256:'2'.repeat(64),focus_ref:null},operation_id:uid(3),semantic_sha256:'1'.repeat(64)};
 const options={getWorkerInstance:()=> 'TEST_NOT_OPERATING_WORKER',getGeneration:()=>1,
  verifyInput:()=>false,isCurrent:()=>false,verifyRelease:()=>false,verifyCompletion:()=>false,
  reserve:()=>{throw Error('NO_DURABLE_RESERVATION_PROVIDER');}};
 return {win,document,context,input:{context,features:[{feature_id:'IG-04',enabled:true,required:true}]},options};
}
async function prepared(){const f=await fixture(),consume=f.bind(),stored=await f.register();assert.equal(consume(f.trusted,f.attempt,stored),true);return {f,stored,before:await f.rows()};}
test('Core/U4 preparation acceptance grants no receiver APPLY or reservation capability',async()=>{
 const {f,stored,before}=await prepared(),h=receiverFixture(),receiver=new IG04ContentReceiver(h.document);
 const result=await receiver.apply(h.input,stored);
 assert.equal(result.accepted,false);assert.equal(result.reason,'CORE_APIS_REQUIRED');assert.equal(result.local_startup.adapter_start_called,false);
 assert.equal(h.win.listeners.size,0);assert.deepEqual(await f.rows(),before);
});
test('latest receiver requires separate prepareResources even when all seven originally listed seams exist',async()=>{
 const {f,stored,before}=await prepared(),h=receiverFixture(),receiver=new IG04ContentReceiver(h.document,h.options);
 const result=await receiver.apply(h.input,stored);
 assert.equal(result.accepted,false);assert.equal(result.reason,'RESOURCE_PREPARATION_REQUIRED');assert.equal(result.local_startup.adapter_start_called,false);
 assert.equal(h.win.listeners.size,0);assert.deepEqual(await f.rows(),before);
});
test('asynchronous resource response cannot be consumed as synchronous watch readiness; prior Core debts survive',async()=>{
 const {f,stored,before}=await prepared(),h=receiverFixture(),receiver=new IG04ContentReceiver(h.document,{...h.options,prepareResources:()=>Promise.resolve(false)});
 const result=await receiver.apply(h.input,stored);
 assert.equal(result.accepted,false);assert.equal(result.reason,'RESOURCE_LIFETIME_REVALIDATION_REQUIRED');
 assert.equal(result.cleanup_pending,true);assert.equal(result.local_startup.adapter_start_called,false);assert.equal(h.win.listeners.size,0);
 assert.deepEqual(await f.rows(),before);
 const ended=await receiver.release(h.context,stored);assert.equal(ended.accepted,false);assert.deepEqual(await f.rows(),before);
});
