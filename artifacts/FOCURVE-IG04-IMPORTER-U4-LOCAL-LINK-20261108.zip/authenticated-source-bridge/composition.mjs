import {createAuthenticatedSourceTransport} from './transport.mjs';
/** Core owner injects the exact reviewed Adapter and protected suppliers. No Worker/loop startup. */
export function createP1SourceComposition({Adapter,providerStore,capture,isCurrent,attemptRecord,now,readP1PreparationSourceHttp,contractAgreed=false}={}){
 return async function bind(trusted,exactAttempt){
  const snapshot=structuredClone(capture(trusted));
  const readAuthenticatedSource=createAuthenticatedSourceTransport({readP1PreparationSourceHttp,approvedRelativePath:contractAgreed===true?'/amvp/preparation-sources/read':null,isCurrent:()=>isCurrent(trusted,snapshot,exactAttempt)===true});
  const adapter=new Adapter({providerStore,capture,isCurrent,attemptRecord,now,readAuthenticatedSource});
  await adapter.authenticate('read',trusted,exactAttempt);return adapter.forContext(trusted);
 };
}

/** Local no-effect composition. Caller supplies the reviewed Core class and protected providers.
 * Binds the synchronous observation callback to this exact service and captured request lifetime.
 * verifyObservation(stored) is ONE argument; it is not U4's three-argument slot.
 * Core owns the already-reviewed opaque expectation/U4 binding.
 * Does not install U4, listeners, operations or any production authority.
 */
export function createP1PreparationComposition({Preparation,store,client,verifyNative,monotonic,...source}={}){
 const bindSource=createP1SourceComposition(source);
 return async function bindPreparation(trusted,exactAttempt){
  const callbacks=await bindSource(trusted,exactAttempt);
  const preparation=new Preparation({store,client,capture:source.capture,isCurrent:source.isCurrent,
   now:source.now,monotonic,verifyNative,...callbacks});
  const verifyObservation=preparation.createP1ObservationVerifier(trusted,exactAttempt);
  return Object.freeze({preparation,verifyObservation});
 };
}
