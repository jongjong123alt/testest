import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {P1ProtectedOriginalImporter} from './protected-original-importer.mjs';
import {canonical} from '../core-endpoint-040fbbaf/assembled/extension/a1/contract.mjs';
import {createMemberDB} from '../core-endpoint-040fbbaf/assembled/extension/member-a1/db.mjs';
import {A1Store} from '../core-endpoint-040fbbaf/assembled/extension/member-a1/store.mjs';
import {IG04ProviderStore} from '../core-endpoint-040fbbaf/assembled/extension/src/ig04-provider-store.js';
import {p1Utf8Sha256} from '../core-endpoint-040fbbaf/assembled/extension/src/ig04-p1-server-source.js';
const require=createRequire(import.meta.url);
const {IDBFactory}=require(process.env.FOCURVE_FAKE_IDB_PATH??'/workspace/focurve-site-controller-dnr/extension/node_modules/fake-indexeddb');
const uid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const same=(a,b)=>canonical(a)===canonical(b);

// Fixture-only authorization/currentness/native and endpoint input. Real local
// A1Store/provider/Core/composition/importer code; NO operating issuer/network.
async function fixture(){
 const db=createMemberDB(new IDBFactory(),'import-'+crypto.randomUUID()),store=new A1Store(db);
 const binding={owner_key:'MEMBER:1',executor_id:uid(1),binding_id:uid(2),epoch:9};
 const ref={id:uid(3),version:2},original={sourceRef:ref},bytes=canonical(original);
 const expected={requestId:uid(4),sourceRef:ref,sourceVersion:2,original,bytes,digest:await p1Utf8Sha256(bytes)};
 const native={document:'fixture-document',generation:2,attempt:'fixture-native'};
 const creation={reference:ref.id,executor:uid(1),user:'1',requestId:uid(5),requestDigest:await p1Utf8Sha256('creation is NOT read'),
  binding:{bindingId:uid(2),epoch:9},snapshot:{format:'AMVP_P1_SETTINGS_SOURCE_1',bytes:canonical({settings:[]}),settingsVersion:7},
  policyId:'FIXTURE_ONLY',createdAt:'2026-11-06T00:00:00Z',expiresAt:'2026-11-06T00:05:00Z'};
 const raw=canonical(creation),response={sourceRef:ref.id,sourceVersion:2,raw,rawSha256:await p1Utf8Sha256(raw),expiresAt:Date.parse(creation.expiresAt),bindingId:uid(2),ownerEpoch:9,executorId:uid(1)};
 const state={now:Date.parse('2026-11-06T00:01:00Z'),current:true,native:true,denySource:false,requests:0,sourceHook:null};
 const obligations={key:'fixture-existing-obligations',cleanup_pending:true,local:['restore'],terminal:['pending'],outbox:['not-acked']};
 await store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'fence-A',owner_context:'MEMBER:1',transitioning:false});tx.objectStore('metadata').put(obligations);done(null);});
 const provider=new IG04ProviderStore(store,{guard:(action,input,rows)=>{
  const f=rows.find(r=>r.key==='a1:owner-fence');if(f?.owner_context!=='MEMBER:1'||f.epoch!=='fence-A'||f.transitioning)return false;
  if(action==='initialize')return input.id==='authority';
  if(action==='lookup')return input.id==='authority'&&input.localId==='attempt';
  if(action==='register'&&input.id==='authority'){
   if(input.localId==='attempt')return same(input.original,expected);
   if(input.localId==='source')return !state.denySource&&input.original.bytes===raw&&input.original.rawSha256===response.rawSha256
    &&same(input.original.binding,binding)&&same(input.original.sourceRef,ref);
  }return false;
 }});
 const token=await provider.initialize('authority',{scope:native}),trusted=Object.freeze({});
 const context={authorityId:'authority',token,requestLifetime:'request-A',revision:1,sourceLocalId:'source',sourceVersion:1,
  attemptLocalId:'attempt',attemptVersion:1,nativeScope:native,binding,deadline:state.now+120000};
 const capture=t=>t===trusted?structuredClone(context):null;
 const isCurrent=(t,c,a)=>state.current&&t===trusted&&same(c,context)&&same(a,expected);
 const client={credentials:async()=>({owner_key:'MEMBER:1',executor_id:uid(1),access_token:'FIXTURE_ONLY'}),request:async(path,cred,query,_h,options)=>{
  state.requests++;assert.equal(path,'/amvp/preparation-sources/read');assert.deepEqual(options,{expectedStatus:200,expectedContentType:'application/json'});
  assert.equal(JSON.parse(query).readAttempt.original,bytes);if(state.sourceHook)await state.sourceHook();
  if(state.error)throw state.error;return structuredClone(response);
 }};
 const options={providerStore:provider,capture,isCurrent,now:()=>state.now,monotonic:()=>0,client,
  verifyNative:async()=>state.native,contractAgreed:true};
 const importer=new P1ProtectedOriginalImporter(options);
 const rows=()=>db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result);});
 const save=()=>importer.saveReadAttempt(trusted,uid(4),ref);
 const originalRows=()=>rows().then(r=>r.filter(x=>x.key.startsWith('ig04:provider:original:')));
 async function keepObligations(){assert.deepEqual(await store.read(obligations.key),obligations);}
 return {db,store,provider,options,importer,trusted,context,state,response,expected,ref,save,rows,originalRows,keepObligations};
}


export {fixture};
