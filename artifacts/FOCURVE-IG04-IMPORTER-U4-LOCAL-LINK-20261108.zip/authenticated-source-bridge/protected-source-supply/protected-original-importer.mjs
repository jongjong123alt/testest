import {canonical} from '../core-endpoint-040fbbaf/assembled/extension/a1/contract.mjs';
import {IG04ProviderStore} from '../core-endpoint-040fbbaf/assembled/extension/src/ig04-provider-store.js';
import {IG04P1ServerSourceAdapter, p1Utf8Sha256, readP1PreparationSourceHttp} from '../core-endpoint-040fbbaf/assembled/extension/src/ig04-p1-server-source.js';
import {IG04P1Preparation} from '../core-endpoint-040fbbaf/assembled/extension/src/ig04-p1-preparation.js';
import {createP1PreparationComposition} from '../composition.mjs';

const need=(ok,code)=>{if(!ok)throw Error(code);};
const same=(a,b)=>canonical(a)===canonical(b);
const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};
const immutable=x=>freeze(structuredClone(x));
const uuid=x=>typeof x==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(x);
const strict=x=>{if(x&&typeof x.then==='function')Promise.resolve(x).catch(()=>{});return x===true;};

/** Private, inactive original importer, NOT an authority/attempt approval issuer.
 * Existing provider.guard must authenticate EACH register/lookup in its A1 txn.
 * Never initializes/transitions an authority, repairs storage or installs effects.
 * Caller context/reference alone cannot authorize a write. Missing providers deny.
 */
export class P1ProtectedOriginalImporter {
  #provider; #capture; #current; #now; #options; #attempts=new WeakMap(); #denied=new Set();
  constructor({providerStore,capture=()=>null,isCurrent=()=>false,now=Date.now,
    client,verifyNative,monotonic,contractAgreed=false}={}) {
    need(providerStore instanceof IG04ProviderStore,'P1_PROTECTED_STORE_REQUIRED');
    this.#provider=providerStore;this.#capture=capture;this.#current=isCurrent;this.#now=now;
    this.#options={client,verifyNative,monotonic,contractAgreed};
  }
  #key(c){return canonical([c.authorityId,c.token,c.binding,c.requestLifetime]);}
  #check(t,c,a) {
    need(c&&c.binding&&c.token&&c.nativeScope&&typeof c.authorityId==='string'
      &&typeof c.requestLifetime==='string'&&c.attemptLocalId!==c.sourceLocalId
      &&typeof c.attemptLocalId==='string'&&typeof c.sourceLocalId==='string'
      &&c.attemptVersion===1&&c.sourceVersion===1
      &&uuid(c.binding.executor_id)&&uuid(c.binding.binding_id)
      &&typeof c.binding.owner_key==='string'&&c.binding.owner_key.length>0
      &&Number.isSafeInteger(c.binding.epoch)&&c.binding.epoch>=0,'P1_IMPORT_CONTEXT_UNCONFIRMED');
    need(!this.#denied.has(this.#key(c))&&Number.isSafeInteger(c.deadline)
      &&Number.isSafeInteger(this.#now())&&this.#now()<c.deadline
      &&same(this.#capture(t),c)&&strict(this.#current(t,c,a)),'P1_IMPORT_CURRENTNESS_UNCONFIRMED');
  }
  #scoped(t,c,a) {
    // Delegate original authorization unchanged; the extra currentness check runs
    // synchronously INSIDE the same metadata transaction, not just before await.
    return new IG04ProviderStore(this.#provider.store,{guard:(action,input,rows)=>{
      this.#check(t,c,a);
      need(this.#provider.authority(rows,c.authorityId,c.token).owner===c.binding.owner_key,'P1_IMPORT_OWNER_MISMATCH');
      const approved=strict(this.#provider.guard(action,input,rows));
      this.#check(t,c,a);
      need(this.#provider.authority(rows,c.authorityId,c.token).owner===c.binding.owner_key,'P1_IMPORT_OWNER_MISMATCH');
      return approved;
    }});
  }
  #post(t,c,a) {
    try{this.#check(t,c,a);}catch(error){
      this.#denied.add(this.#key(c));
      throw error; // Committed originals/receipts/obligations MUST remain intact.
    }
  }
  #acceptRecord(record,localId,original) {
    need(record.localId===localId&&record.version===1&&record.closedBy===null
      &&same(record.original,original),'P1_IMPORT_PROTECTED_RECORD_MISMATCH');
  }
  async saveReadAttempt(trusted,requestId,sourceRef) {
    need(uuid(requestId)&&sourceRef&&Object.keys(sourceRef).length===2
      &&uuid(sourceRef.id)&&Number.isSafeInteger(sourceRef.version)&&sourceRef.version>0,'P1_IMPORT_ATTEMPT_INVALID');
    const c=immutable(this.#capture(trusted)),ref=immutable(sourceRef),original=immutable({sourceRef:ref});
    const bytes=canonical(original),attempt=immutable({requestId,sourceRef:ref,sourceVersion:ref.version,
      original,bytes,digest:await p1Utf8Sha256(bytes)});
    this.#check(trusted,c,attempt);
    const row=await this.#scoped(trusted,c,attempt).register(c.authorityId,c.token,c.attemptLocalId,attempt);
    this.#post(trusted,c,attempt);this.#acceptRecord(row,c.attemptLocalId,attempt);
    this.#attempts.set(trusted,{context:c,attempt});return attempt;
  }
  async restoreReadAttempt(trusted,exactAttempt) {
    const c=immutable(this.#capture(trusted)),a=immutable(exactAttempt);this.#check(trusted,c,a);
    need(uuid(a.requestId)&&same(a.original,{sourceRef:a.sourceRef})&&a.sourceVersion===a.sourceRef?.version
      &&a.bytes===canonical(a.original)&&a.digest===await p1Utf8Sha256(a.bytes),'P1_IMPORT_ATTEMPT_INVALID');
    const {record}=await this.#scoped(trusted,c,a).lookup(c.authorityId,c.token,c.attemptLocalId);
    this.#post(trusted,c,a);this.#acceptRecord(record,c.attemptLocalId,a);
    this.#attempts.set(trusted,{context:c,attempt:a});return a;
  }
  attemptRecord(trusted) {
    const e=this.#attempts.get(trusted);need(e,'P1_IMPORT_ATTEMPT_UNAVAILABLE');
    this.#check(trusted,e.context,e.attempt);
    return Object.freeze({localId:e.context.attemptLocalId,version:e.context.attemptVersion});
  }
  async importAuthenticatedSource(trusted,exactAttempt) {
    const e=this.#attempts.get(trusted);need(e&&same(e.attempt,exactAttempt),'P1_IMPORT_ATTEMPT_UNAVAILABLE');
    const {context:c,attempt:a}=e;this.#check(trusted,c,a);
    const protectedStore=this.#scoped(trusted,c,a);
    const bind=createP1PreparationComposition({...this.#options,Preparation:IG04P1Preparation,
      Adapter:IG04P1ServerSourceAdapter,store:this.#provider.store,providerStore:protectedStore,
      capture:this.#capture,isCurrent:this.#current,now:this.#now,
      attemptRecord:t=>this.attemptRecord(t),readP1PreparationSourceHttp});
    const {preparation,verifyObservation}=await bind(trusted,a);
    const source=await preparation.readP1Source(trusted,a,c.binding,a.sourceRef);
    // A returned SourceRead alone is not source-registration authority: preserve
    // U2 source/native verification AND the existing transactional write guard.
    const verified=await preparation.verifyP1Preparation(trusted,a,source,c.nativeScope,a);
    this.#check(trusted,c,a);
    const row=await protectedStore.register(c.authorityId,c.token,c.sourceLocalId,source);
    this.#post(trusted,c,a);this.#acceptRecord(row,c.sourceLocalId,source);
    return Object.freeze({preparation,source,verified,verifyObservation});
  }
}
