import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {P1ProtectedOriginalImporter} from './protected-original-importer.mjs';
import {canonical} from '../core-endpoint-040fbbaf/assembled/extension/a1/contract.mjs';
import {createMemberDB} from '../core-endpoint-040fbbaf/assembled/extension/member-a1/db.mjs';
import {A1Store} from '../core-endpoint-040fbbaf/assembled/extension/member-a1/store.mjs';
import {IG04ProviderStore} from '../core-endpoint-040fbbaf/assembled/extension/src/ig04-provider-store.js';
import {p1Utf8Sha256} from '../core-endpoint-040fbbaf/assembled/extension/src/ig04-p1-server-source.js';
const require=createRequire('file:///C:/Users/dahun/Documents/Codex/2026-11-05/p1-local-noeffect-implementation/core/extension/package.json');
const {IDBFactory}=require('fake-indexeddb');
const uid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const same=(a,b)=>canonical(a)===canonical(b);

// Fixture-only authorization/currentness/native and endpoint input. Real local
// A1Store/provider/Core/composition/importer code; NO operating issuer/network.
async function fixture(){
 const db=createMemberDB(new IDBFactory(),'import-'+crypto.randomUUID()),store=new A1Store(db);
 const binding={owner_key:'MEMBER:1',executor_id:uid(1),binding_id:uid(2),epoch:9};
 const ref={id:uid(3),version:2},original={sourceRef:ref},bytes=canonical(original);
 const expected={requestId:uid(4),sourceRef:ref,sourceVersion:2,original,bytes,digest:await p1Utf8Sha256(bytes)};
 const native={document:'fixture-document',generation:2,attempt:'fixture-native'};
 const creation={reference:ref.id,executor:uid(1),user:'1',requestId:uid(5),requestDigest:await p1Utf8Sha256('creation is NOT read'),
  binding:{bindingId:uid(2),epoch:9},snapshot:{format:'AMVP_P1_SETTINGS_SOURCE_1',bytes:canonical({settings:[]}),settingsVersion:7},
  policyId:'FIXTURE_ONLY',createdAt:'2026-11-06T00:00:00Z',expiresAt:'2026-11-06T00:05:00Z'};
 const raw=canonical(creation),response={sourceRef:ref.id,sourceVersion:2,raw,rawSha256:await p1Utf8Sha256(raw),expiresAt:Date.parse(creation.expiresAt),bindingId:uid(2),ownerEpoch:9,executorId:uid(1)};
 const state={now:Date.parse('2026-11-06T00:01:00Z'),current:true,native:true,denySource:false,requests:0,sourceHook:null};
 const obligations={key:'fixture-existing-obligations',cleanup_pending:true,local:['restore'],terminal:['pending'],outbox:['not-acked']};
 await store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'fence-A',owner_context:'MEMBER:1',transitioning:false});tx.objectStore('metadata').put(obligations);done(null);});
 const provider=new IG04ProviderStore(store,{guard:(action,input,rows)=>{
  const f=rows.find(r=>r.key==='a1:owner-fence');if(f?.owner_context!=='MEMBER:1'||f.epoch!=='fence-A'||f.transitioning)return false;
  if(action==='initialize')return input.id==='authority';
  if(action==='lookup')return input.id==='authority'&&input.localId==='attempt';
  if(action==='register'&&input.id==='authority'){
   if(input.localId==='attempt')return same(input.original,expected);
   if(input.localId==='source')return !state.denySource&&input.original.bytes===raw&&input.original.rawSha256===response.rawSha256
    &&same(input.original.binding,binding)&&same(input.original.sourceRef,ref);
  }return false;
 }});
 const token=await provider.initialize('authority',{scope:native}),trusted=Object.freeze({});
 const context={authorityId:'authority',token,requestLifetime:'request-A',revision:1,sourceLocalId:'source',sourceVersion:1,
  attemptLocalId:'attempt',attemptVersion:1,nativeScope:native,binding,deadline:state.now+120000};
 const capture=t=>t===trusted?structuredClone(context):null;
 const isCurrent=(t,c,a)=>state.current&&t===trusted&&same(c,context)&&same(a,expected);
 const client={credentials:async()=>({owner_key:'MEMBER:1',executor_id:uid(1),access_token:'FIXTURE_ONLY'}),request:async(path,cred,query,_h,options)=>{
  state.requests++;assert.equal(path,'/amvp/preparation-sources/read');assert.deepEqual(options,{expectedStatus:200,expectedContentType:'application/json'});
  assert.equal(JSON.parse(query).readAttempt.original,bytes);if(state.sourceHook)await state.sourceHook();
  if(state.error)throw state.error;return structuredClone(response);
 }};
 const options={providerStore:provider,capture,isCurrent,now:()=>state.now,monotonic:()=>0,client,
  verifyNative:async()=>state.native,contractAgreed:true};
 const importer=new P1ProtectedOriginalImporter(options);
 const rows=()=>db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result);});
 const save=()=>importer.saveReadAttempt(trusted,uid(4),ref);
 const originalRows=()=>rows().then(r=>r.filter(x=>x.key.startsWith('ig04:provider:original:')));
 async function keepObligations(){assert.deepEqual(await store.read(obligations.key),obligations);}
 return {db,store,provider,options,importer,trusted,context,state,response,expected,ref,save,rows,originalRows,keepObligations};
}

test('new supply: protected attempt save/restore -> authenticated source import -> existing U3 and fresh requery',async()=>{
 const f=await fixture(),a=await f.save();assert.deepEqual(a,f.expected);
 const restarted=new P1ProtectedOriginalImporter(f.options);await restarted.restoreReadAttempt(f.trusted,a);
 assert.deepEqual(restarted.attemptRecord(f.trusted),{localId:'attempt',version:1});
 const imported=await restarted.importAuthenticatedSource(f.trusted,a);
 const row=await imported.preparation.registerP1Preparation(f.trusted,a,imported.verified,0);
 assert.equal(imported.verifyObservation(row),true);
 const again=await imported.preparation.queryP1Preparation(f.trusted,a);assert.deepEqual(again,row);
 assert.equal((await f.originalRows()).length,2);assert.equal(f.state.requests,2);
 assert.notEqual(JSON.parse(imported.source.bytes).requestDigest,a.digest);assert.equal(imported.source.version,2);
 await f.keepObligations();
});
test('new supply: missing transactional approval denies attempt write without initializing/repairing authority',async()=>{
 const f=await fixture(),before=await f.rows();f.provider.guard=()=>false;
 await assert.rejects(f.save(),/PROVIDER_UNCONFIRMED/);assert.deepEqual(await f.rows(),before);assert.equal(f.state.requests,0);
});
test('new supply: caller-changed request/ref cannot become authenticated original',async()=>{
 const f=await fixture(),before=await f.rows();await assert.rejects(f.importer.saveReadAttempt(f.trusted,uid(9),f.ref),/CURRENTNESS/);
 assert.deepEqual(await f.rows(),before);await f.keepObligations();
});
test('new supply: even a declared current capture cannot cross the stored authority owner',async()=>{
 const f=await fixture(),before=await f.rows();f.context.binding.owner_key='MEMBER:2';
 await assert.rejects(f.save(),{message:'P1_IMPORT_OWNER_MISMATCH'});assert.deepEqual(await f.rows(),before);
});
test('new supply: restore rejects unregistered and modified attempt; no caller digest authentication',async()=>{
 const f=await fixture();await assert.rejects(f.importer.restoreReadAttempt(f.trusted,f.expected),/ORIGINAL_UNAVAILABLE/);
 const a=await f.save(),before=await f.rows();await assert.rejects(f.importer.restoreReadAttempt(f.trusted,{...a,digest:'0'.repeat(64)}),/CURRENTNESS|ATTEMPT_INVALID/);
 assert.deepEqual(await f.rows(),before);
});
test('new supply: changed owner fence rolls back source write and preserves attempt/obligations',async()=>{
 const f=await fixture(),a=await f.save();f.state.sourceHook=()=>f.store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'fence-B',owner_context:'MEMBER:2',transitioning:false});done(null);});
 await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),/PROVIDER_UNCONFIRMED|OWNER_FENCE/);
 assert.equal((await f.originalRows()).length,1);await f.keepObligations();
});
test('new supply: currentness loss during source read rejects late result without source write',async()=>{
 const f=await fixture(),a=await f.save(),before=await f.rows();f.state.sourceHook=()=>{f.state.current=false;};
 await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),{message:'P1_AUTH_CONTEXT_CHANGED'});assert.deepEqual(await f.rows(),before);
});
test('new supply: missing Native verification denies import even after authenticated source read',async()=>{
 const f=await fixture(),a=await f.save(),before=await f.rows();f.state.native=false;
 await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),/NATIVE_UNCONFIRMED/);assert.deepEqual(await f.rows(),before);
});
test('new supply: source write requires independent existing guard approval; read success alone is insufficient',async()=>{
 const f=await fixture(),a=await f.save(),before=await f.rows();f.state.denySource=true;
 await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),/PROVIDER_UNCONFIRMED/);assert.deepEqual(await f.rows(),before);
});
test('new supply: asynchronous approval is not strict true and cannot write an original',async()=>{
 const f=await fixture(),before=await f.rows();f.provider.guard=async()=>true;
 await assert.rejects(f.save(),/PROVIDER_UNCONFIRMED/);assert.deepEqual(await f.rows(),before);
});
test('new supply: currentness changes inside approval callback roll back before the original write',async()=>{
 const f=await fixture(),a=await f.save(),before=await f.rows(),guard=f.provider.guard;
 f.provider.guard=(action,input,rows)=>{const ok=guard(action,input,rows);if(action==='register'&&input.localId==='source')f.state.current=false;return ok;};
 await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),/CURRENT/);assert.deepEqual(await f.rows(),before);
});
test('new supply: current 401 rejects; no retry, source write or existing obligation deletion',async()=>{
 const f=await fixture(),a=await f.save(),before=await f.rows();f.state.error=Object.assign(Error('fixture401'),{status:401});
 await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),e=>e.status===401);assert.equal(f.state.requests,1);assert.deepEqual(await f.rows(),before);
});
test('new supply: commit then currentness loss retains original and denies consumption/restart under that lifetime',async()=>{
 const f=await fixture(),a=await f.save(),atomic=f.store.atomic.bind(f.store);let sourceWritten=false;
 const guard=f.provider.guard;f.provider.guard=(action,input,rows)=>{const ok=guard(action,input,rows);if(action==='register'&&input.localId==='source'&&ok)sourceWritten=true;return ok;};
 f.store.atomic=async(...args)=>{const result=await atomic(...args);if(sourceWritten){sourceWritten=false;f.state.current=false;}return result;};
 await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),/CURRENT/);assert.equal((await f.originalRows()).length,2);
 f.state.current=true;await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),/CURRENT/);await f.keepObligations();
});
test('new supply: default-disabled composition cannot start network, expiry cannot renew originals',async()=>{
 const f=await fixture(),a=await f.save(),before=await f.rows(),disabled=new P1ProtectedOriginalImporter({...f.options,contractAgreed:false});
 await disabled.restoreReadAttempt(f.trusted,a);await assert.rejects(disabled.importAuthenticatedSource(f.trusted,a),/APPROVED_SOURCE_ROUTE/);
 assert.equal(f.state.requests,0);assert.deepEqual(await f.rows(),before);
 f.state.now=f.context.deadline;await assert.rejects(f.importer.importAuthenticatedSource(f.trusted,a),/CURRENT/);assert.deepEqual(await f.rows(),before);
});
