/** Endpoint-only validation; no auth/authority or error-to-null conversion. */
const exact=(v,keys)=>v!==null&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).length===keys.length&&keys.every(k=>Object.hasOwn(v,k));
const uuid=v=>typeof v==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(v);
const positive=v=>Number.isSafeInteger(v)&&v>0;
const hash=v=>typeof v==='string'&&/^[a-f0-9]{64}$/.test(v);
// Same canonical JSON ordering as the existing Core/Server contract; never rehash a projection.
const canonical=v=>JSON.stringify(Array.isArray(v)?v.map(x=>JSON.parse(canonical(x))):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,JSON.parse(canonical(v[k]))])):v);
const instant=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d{1,9})?Z$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(Date.parse(v)).toISOString().slice(0,19)===v.slice(0,19);
const need=v=>{if(!v)throw Error('P1_SOURCE_RESPONSE_INVALID');};
export async function validatePreparationSourceRead(value,query,expectedOwner){
 if(value===null)return null; // Endpoint's confirmed authenticated absence only. U1 must reject it.
 need(exact(value,['sourceRef','sourceVersion','raw','rawSha256','expiresAt','bindingId','ownerEpoch','executorId']));
 need(uuid(value.sourceRef)&&uuid(value.bindingId)&&uuid(value.executorId)&&positive(value.sourceVersion)&&positive(value.ownerEpoch)&&positive(value.expiresAt)
  &&value.sourceRef===query.reference&&value.sourceVersion===query.expectedSourceVersion&&value.executorId===query.executor&&typeof value.raw==='string'&&hash(value.rawSha256));
 const digest=[...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value.raw)))].map(x=>x.toString(16).padStart(2,'0')).join('');
 need(digest===value.rawSha256);
 let original;try{original=JSON.parse(value.raw);}catch{throw Error('P1_SOURCE_RESPONSE_INVALID');}
 need(value.raw===canonical(original)&&exact(original,['reference','executor','user','requestId','requestDigest','binding','snapshot','policyId','createdAt','expiresAt']));
 need(original.reference===value.sourceRef&&original.executor===value.executorId&&typeof original.user==='string'&&/^[1-9][0-9]*$/.test(original.user)
  &&expectedOwner==='MEMBER:'+original.user&&uuid(original.requestId)&&hash(original.requestDigest)&&exact(original.binding,['bindingId','epoch'])&&original.binding.bindingId===value.bindingId&&original.binding.epoch===value.ownerEpoch
  &&exact(original.snapshot,['format','bytes','settingsVersion'])&&['1.1','1.2','AMVP_P1_SETTINGS_SOURCE_1'].includes(original.snapshot.format)
  &&typeof original.snapshot.bytes==='string'&&positive(original.snapshot.settingsVersion)&&typeof original.policyId==='string'&&original.policyId.trim().length>0
  &&instant(original.createdAt)&&instant(original.expiresAt)&&Date.parse(original.createdAt)<Date.parse(original.expiresAt)&&Date.parse(original.expiresAt)===value.expiresAt);
 return value; // Currentness/owner binding/U1 provenance remain Core responsibilities.
}
