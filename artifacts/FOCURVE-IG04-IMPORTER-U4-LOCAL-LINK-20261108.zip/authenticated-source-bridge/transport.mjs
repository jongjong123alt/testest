import {validatePreparationSourceRead} from './source-read-response.mjs';
/** Private composition only: no guessed route or production activation. */
export function createAuthenticatedSourceTransport({approvedRelativePath=null,isCurrent=()=>false,readP1PreparationSourceHttp}={}){
 return async function readAuthenticatedSource(client,credential,query){
  if(typeof approvedRelativePath!=='string'||!/^\/amvp\/[a-z0-9/-]+$/.test(approvedRelativePath))throw Error('P1_APPROVED_SOURCE_ROUTE_REQUIRED');
  if(approvedRelativePath!=='/amvp/preparation-sources/read')throw Error('P1_SOURCE_ROUTE_MISMATCH');
  if(typeof readP1PreparationSourceHttp!=='function')throw Error('P1_STRICT_HTTP_SUPPLIER_REQUIRED');
  const same=(a,b)=>a&&b&&a.executor_id===b.executor_id&&a.owner_key===b.owner_key&&a.access_token===b.access_token;
  const exactQuery=structuredClone(query);
  const before=await client.credentials();
  if(!same(before,credential)||exactQuery.executor!==before.executor_id||isCurrent()!==true)throw Error('P1_AUTH_CONTEXT_CHANGED');
  const result=await readP1PreparationSourceHttp(client,before,exactQuery);
  const validated=await validatePreparationSourceRead(result,exactQuery,before.owner_key);
  const after=await client.credentials();
  if(!same(before,after)||isCurrent()!==true)throw Error('P1_AUTH_CONTEXT_CHANGED');
  return validated; // Only this endpoint200null is preserved; U1 rejects it. No error-to-null.
 };
}
