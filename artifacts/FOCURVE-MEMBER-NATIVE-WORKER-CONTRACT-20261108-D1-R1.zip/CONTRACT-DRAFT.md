# MEMBER-NATIVE-WORKER-IDENTITY-20261108-D1-R1

상태: 공유 Native 명령·응답 **검토 후보**. 방향 동의와 구체 wire 채택을 구분한다. 구현·실행 승인 또는 기존 Native 지원 기능으로 기록하지 않는다.

## 기준과 정확 변경 범위

BASELINE-PINS.json의 16개 원문을 보존했다. historical bcf9cc + 수신 overlay이며 현 설치나 최신 Worker 전체와 같다고 주장하지 않는다.
- NativeLinkHost.cs: 930c75429b62b74f5e3bd564b852be3b11e0f66dc582fb24e1b732aa8ee6acf2.
- R3 helper: ceaa2d2da27a94aa02bca58d8b308b5990bb1e94039ed3bd1a1a11ff7323bd0b.
- 회원 composition binding: 07c381ef915e75e581a3ea7022eeeeb62c2424782033429f1dac37823122deb8.
- 독립 수용된 additive builder: af5517fab19114dec88a8da79f3a7ae428cca36df54ca0e43935e1fbc5a1c9e4.

확인 후 구현할 파일(후보 내부 경로 → 제품 상대 경로):
1. baseline/sources/native/NativeLinkHost.cs → native/NativeLinkHost.cs: 새 읽기 요청 분기 및 설치·현재 launch 검증. 기존 HELLO/서비스 제어 분기 불변.
2. 신규 extension/integration/member-native-observation.mjs: Worker 전용 prepare/read/retire private supplier. 비공개 문맥, 공개 메시지·새 START/END API 없음.
3. baseline/review/composition/member-release-binding.mjs → extension/integration/member-release-binding.mjs: 93e 상수의 신뢰 근거 사용을 제거하고 검증된 private supplier와 R3 결과만 결합. 상수 제거만으로 허용 범위를 넓히지 않는다.
4. baseline/review/composition/vendor/extension/integration/member-release-observation.mjs → extension/integration/member-release-observation.mjs: 선택적 내부 동기 final guard seam. Native 결합 경로는 guard를 필수 주입, strict true 이외 거절. 기존 로컬-only 관측과 Native 검증 주장을 구분.
5. baseline/accepted-additive-builder/build-member-a1.mjs → extension/scripts/build-member-a1.mjs: 새 모듈 입력 추가만. 기본 3출력 불변과 선택적 제4출력 유지.
6. 신규 tests/native-observation-*.test.mjs 및 변경 영향 fixture.

service-worker.js 실제 import/회원 bootstrap/제품 session.js/installer는 이번 Core 구현에서 자동 적용하지 않는다. 이들의 연결 시점은 다훈 확인 범위. Worker 객체를 만들거나 initializeMemberA1/tick을 관측 준비의 편의상 호출하지 않는다.

## 최소 Native wire 제안

기존 HELLO contract는 그대로 유지하고 새 목적을 별도 namespace로 분리한다. 아래 이름/필드는 **이 D1의 제안**이며 채택 전 코드에 넣지 않는다.

요청은 정확 5필드:
- contract: `FOCURVE_MEMBER_OBSERVATION_IDENTITY_1`
- operation: `READ_IDENTITY`
- installationId: Windows 32자리 lowercase hex 설치ID
- extensionId: 기존 Chrome 확장ID
- nonce: Worker가 이 준비 요청에 만든 기존 형식 32자리 lowercase hex

경로·owner·executor·session·만료·launch를 caller가 지정하지 않는다. Native host 이름은 설치가 고정한 설정과 install/extension 조합으로 선택하며 임의 host 주입을 허용하지 않는다. config는 선택/대조 입력이지 Native 검증 성공 근거가 아니다.

성공 응답은 정확 9필드:
- contract: 위 contract
- state: `VERIFIED`
- installationId, extensionId, nonce: 검증한 요청과 동일
- launchId: Native가 현재 설치 원문에서 확인한 32자리 lowercase hex
- grantNotAfterUTC: Native의 hash-pinned binding.json 원래 만료
- launchDeadlineUTC: 검증한 현재 launch 원문의 만료
- authorityGranted: `false`

Worker의 사용 기한은 두 시각의 min. launch가 더 긴 값이어도 grant 기한을 늘리지 않는다. 만료/형식/응답 correlation/알 수 없는 필드/누락은 거절한다. Native가 Core owner/session을 검증했다는 필드는 없다. token·nonce 원문·경로·SID·개인키·DB·credential을 관측 결과로 내보내지 않는다(응답 nonce는 Worker 내부 correlation 용도).

실패는 준비 실패로 reject하고 private Native 원문/예외를 UI·Content에 전달하지 않는다. 공개 오류 enum은 이 후보로 확정하지 않는다. 실패 응답 wire가 필요하다면 그 형식만 별도 확인한다.

## Native 검증 순서와 남은 출처 확인

1. 기존 Main의 compile-pinned binding hash·binding contract·현재 원래 만료·Chrome OS peer/프로필/확장 origin 검사를 그대로 재사용.
2. READ_IDENTITY 요청의 정확 키·purpose·installation/extension·nonce 검사. RuntimeProbe/OPEN_USER_SESSION/서비스·DB·grant 발급 코드로 dispatch하지 않는다.
3. launch의 인증 출처는 아래 R1의 기존 lifecycle 프로세스 내 protected snapshot이다. installation.json/launch-context/ACL은 locator·보조 일치 검사일 뿐 성공 근거가 아니다. 파일이나 marker를 갱신·보수하지 않는다.
4. Native/제품 원문을 읽기 전후 대조하고 원래 만료·OS peer를 응답 직전에 재검사. 바뀐 launch/불명확한 준비·종료 상태/실패·HOLD/중단 상태는 reject.
5. 다훈 측 제안 확인: 준비 호출은 SESSION_READY 이후의 별도 명시 단계로 한정하고, Native가 허용하는 상태는 `PRODUCT_RUNNING_USER_SESSION`만을 초안으로 둔다. 집중 END 후에도 제품 서비스가 계속 RUNNING이면 종료 관측 가능. 설치 STOPPED/HOLD에 예외를 열지 않는다.

**중요:** 기존 install_core.owned_record()는 실행 중 상태를 허용하지 않는다. 이를 완화하거나 무조건 재사용하지 않는다. 또한 `installation.json`의 payload 목록과 그 파일이 서로 일치한다는 사실만으로 독립적인 위변조 방지 근거가 새로 생기지는 않는다. 다훈이 보호 launch의 writer·경로/접근 보호·기존 검증 수명·runtime 생존/상태 근거를 확인해야 한다. 그 근거가 미확정이면 새 read validator는 기본 거절로 남긴다. Native가 현재 파일을 읽었다는 사실을 원격 즉시 철회(C5)나 새 권한으로 표시하지 않는다.

## Worker private supplier

두 문맥을 분리한다.
- 부모: Windows 설치ID/확장/launch/만료/Worker boot/준비 요청 nonce/현재 adapter 객체/제품 제어 document 수명. 비공개 메모리만 사용하고 storage에서 복원하지 않는다.
- 각 조회: 기존 Core executor UUID·owner·session·desired_revision·session_revision·generation·record_version·owner fence. 기존 7scope 유지. Native가 executor/owner/session을 인증했다고 주장하지 않는다.

prepare는 정식 제품 준비의 명시적 호출에서만 Native 연결과 읽기 요청을 수행한다. 기존 adapter가 없으면 초기화하지 않고 거절한다. prepare 시작과 응답 소비 직전에 adapter/Worker/제어 document/요청 수명을 재검사한다. 늦은 응답으로 새 문맥을 덮어쓰지 않는다. 이전 문맥 폐기 후 준비 실패하면 기본 거절로 남긴다. 재시도나 자동 HELLO 없음.

read는 연결·Native 호출·초기화·권한 발급 없이 부모 문맥을 검사하고 R3 조회를 호출한다. 마지막 readonly 판정 안에서 동기 final guard가 같은 private 문맥/adapter/launch·만료를 다시 검사한다. guard 뒤 추가 await 없음. 저장 원문과 미해소 의무는 쓰거나 삭제하지 않는다. 유효 시각은 원래 UTC 기한과 로컬 monotonic 경과로 제한하며 시간 역행으로 연장하지 않는다.

정상 검증 요청은 단발 Native read이다. R1의 성공 프레임 소비→Worker 명시적 disconnect 순서로 단발 완료를 판단한다. EOF만으로 성공이나 Native 프로세스 exit 0을 추정하지 않는다. 기존 서비스 제어 port의 수명과 구분한다.

## 수명·종료 규칙

- 탭 종료/새로고침/문서 교체: Root Chrome 수명 관측으로 부모 문맥 퇴역. 탭 메시지가 인증 성공을 만들 수 없고, 기존 실패 신호는 거절/퇴역 근거로만 소비.
- 기존 서비스 제어 port 실패·STOPPING/FAILED/COMPLETE·만료: 해당 문맥 퇴역. Worker가 이 사건을 관측할 정확 연결 위치는 다훈의 제품 탭 수명 확인과 함께 고정. 보지 못한 원격/OS 전이를 즉시 안다고 주장하지 않는다.
- Worker 재시작: 미준비 거절, 자동 Native 연결/저장값 복원/서비스 재개 없음.
- adapter 교체: 부모 문맥 퇴역. 새 adapter에 문맥 자동 승계 없음.
- 집중 END: 서비스 STOP과 다르다. 유효 부모 문맥 아래 동일 세션의 실제 종료 원장을 새 7scope로 검증할 수 있지만 옛 요청의 generation/record_version은 수정·재사용하지 않는다. 새 session/owner에는 자동 적용하지 않는다.
- 제품 정상 STOP: 문맥을 퇴역하고 저장 원문·cleanup/ACK/outbox 의무는 보존. 재기동은 새 명시적 준비 대상.

## 이번에 확인받을 최소 항목

다훈: READ_IDENTITY 5필드/성공 9필드, SESSION_READY 뒤 명시 준비 시점, 실행 중 보호 launch 검증 출처와 상태 기준, 제어 document/port 실패를 Worker가 제한 신호로 받는 연결.
종민: 기존 Native 검증 재사용·읽기-only 분기, private 문맥/수명, 최종 동기 소비 guard, 정확 후보와 영향시험.
Content 소비 형식은 바꾸지 않는다. 지민의 추가 확인은 Content 입력/복원 의미를 변경할 때만 요청.

이 후보 확인 전 공유 Native 구현·새 wire·설치·권한 발급·END 실행은 하지 않는다.


## R1: 남은 세 항목의 구체 선택안 (D1의 미확정 설명보다 우선)

D1의 5요청/9성공 필드와 SESSION_READY 이후 명시 준비는 다훈 범위에서 수용됐지만, 아래 세부안은 여전히 공동 확인 대상이다. 구현/설치 승인 아님.

### 1. 엄격한 형식·시각·실패

request.schema.DRAFT.json / response.schema.DRAFT.json은 필드 집합·기본 타입을 기계적으로 표현한 제안이다. 스키마 통과만으로 인증하지 않는다.
- 양쪽 모두 JSON plain object. 정확한 required keys, additionalProperties:false. null/array/unknown key/중복 JSON key/타입 강제변환 금지. Native는 새 purpose의 raw JSON에서 중복 키를 잃기 전에 거절해야 한다. 기존 HELLO parser 동작을 임의 변경하지 않는다.
- contract/operation/state는 exact literal. installationId/launchId/nonce는 lowercase `[0-9a-f]{32}`; extensionId는 `[a-p]{32}`. Core executor UUID에는 이 형식을 쓰지 않는다.
- nonce는 명시 prepare의 Worker crypto 난수. 같은 pending 요청에만 소비하고 재시작·다른 문서·다른 adapter·다른 요청의 응답은 거절. 외부 입력이 nonce를 선택하거나 이전 nonce로 자동 재시도하지 않는다.
- authorityGranted는 boolean literal false. 문자열 false/0/null은 거절.
- 두 UTC 시각은 정규형 `YYYY-MM-DDTHH:mm:ss.sssZ`. 실제 달력 유효성·Date roundtrip·유한 정수 epoch를 확인한다. Native는 원본의 UTC offset/소수초를 파싱 후 **내림한 밀리초**로 출력해 원래 기한보다 늦어지지 않게 한다. 초=60, offset 표현, 비정규 표기, 불가능한 날짜는 wire에서 거절.
- Native는 요청 처리 전·보호 snapshot 소비 후·응답 직전에 원래 grant와 launch 기한 모두 `now < expiry` 확인. Worker도 수신 후·최종 소비 직전에 두 기한 모두 엄격히 확인. 효과적 기한은 min이며 임의 여유/연장/동등값 허용 없음. wall clock 역행/monotonic 이상·Worker boot 변경은 문맥 거절/퇴역.
- **실패 wire 선택:** 성공 9필드 이외 오류 JSON을 새로 정의하지 않는다. Native 검증 실패는 stdout 성공 프레임 0개, 제한된 비성공 종료/내부 고정 진단만. Worker는 무응답/단절/timeout/형식 오류를 내부 prepare 실패로 reject한다. private 오류/경로/원문을 전달하지 않고 새 public 오류 enum은 만들지 않는다.
- Native 응답을 기다리는 준비 시간은 기존 native client의 8초 상한과 기존 grant/launch 남은 기한 중 작은 값으로 제한. 만료 원문을 아직 모르는 동안에도 8초를 넘겨 대기하지 않는다. timeout은 준비 요청만 취소/폐기하며 서비스·focus·cleanup을 건드리지 않는다.

### 2. 보호 launch 출처: lifecycle 메모리 + 신규 인증된 읽기 전용 통로

기존 출처는 `UserServiceSession.open_services()`의 `self.r`/`self.end`, `checkpoint('READY_ACKNOWLEDGED')`, `Channel.closed`와 기존 Native parent의 OS 검증이다. 이 값이 존재한다는 사실과 Worker용 공급 통로가 구현돼 있다는 사실은 다르다.

권고하는 한 경로:
1. 기존 lifecycle owner가 실제 준비/READY 검증을 완료한 지점에서 그 프로세스 안에 불변 observation snapshot을 publish한다. Windows설치ID/확장/현재launch/원래 grant기한/launch기한과 lifecycle instance·전진 revision·활성 여부를 포함하되 후자의 internal 값은 9필드 public 응답에 추가하지 않는다. 이 객체는 self.r의 나중 파일 대입이나 임의 JSON로 교체되지 않는다.
2. STOP_REQUESTED/서비스 채널 실패/예외/HOLD/종료 전에 같은 메모리 owner가 snapshot을 retire하고 revision을 전진한다. 파일의 PRODUCT_RUNNING_USER_SESSION 문자열만 보고 활성화하지 않는다. lifecycle owner 재시작은 새 instance이며 파일로 활성 snapshot을 복원하지 않는다.
3. 단발 Native reader는 이 **실제 살아 있는 owner의 snapshot**을 신규 읽기 전용 local IPC로 조회한다. 기존 stdio 서비스 제어 port에 새 명령을 섞거나 OPEN_USER_SESSION을 다시 호출하지 않는다.
4. IPC 권고는 Windows named pipe이지만, ACL은 접근 제한 보조일 뿐이다. 연결된 양 끝의 실제 PID를 OS API로 확인하고 PID 생성시각·SID·실행 이미지/고정 hash·설치경로·Native 부모/자식 관계·원래 Chrome peer/프로필 결속을 검증한다. 파일의 PID/pipe 이름은 locator로만 쓰며 그 값 자체를 인증하지 않는다. 검증 중 peer 교체/PID 재사용/다른 launch/프로세스 소실은 reject한다. 실제 OS peer PID를 얻을 수 없으면 fallback하지 않는다.
5. Native reader의 새 nonce와 owner 내부 lifecycle instance/revision을 read 요청과 응답에 결속한다. owner lock 아래 현재 활성·기한·같은 revision을 확인해 복사하고, Native reader는 응답 전 같은 peer/instance/revision이 유효한지 최종 확인한다. IPC 이름만 맞거나 응답 JSON/ACL만 맞는 경우는 인증 성공이 아니다.
6. Native reader는 검증된 snapshot 값만 9필드로 투영한다. Core executor/owner/session은 이 Native 결과로 만들어 내지 않고 Worker가 별도 인증한다.

**현재 없는 부분:** named pipe/양방향 OS peer 검증/메모리 snapshot publish-retire와 revision 조회 통로는 기존 소스에 없다. 새로 구현·독립 검토·Windows 검증해야 한다. 아직 PASS/보호 출처 완성으로 기록하지 않는다. 이 통로가 없거나 검증자가 빠진 후보는 기본 거절이다. 새 grant·권한·서비스 조작 endpoint를 만들지 않는다.

**추가 소유 조율:** product_user_session.py의 publish/retire 지점과 product_runtime_entry.py의 channel 실패/IPC 연결 hook은 다훈 소유 코드다. 다훈이 hook을 제공하고 종민이 Native reader/peer 검증·Worker consumer를 맡는 안으로 제안한다. 두 사람이 같은 파일을 동시에 수정하지 않는다. 이 소유 확인 없이 Core가 installer 파일을 수정하지 않는다.

이 경로는 Native 읽기 시점의 보호 snapshot을 증명한다. 한 번의 조회로 이후 모든 lifecycle 실패를 즉시 안다고 주장하거나 C5를 해결했다고 선언하지 않는다.

### 3. 단발 완료 / 서비스 port / 문서별 퇴역

단발 준비 상태: UNPREPARED → PREPARING → VERIFIED_REPLY → PREPARED 또는 DENIED/RETIRED.
- Worker가 직접 생성한 준비 채널에서 정확한 성공 프레임을 수신·검증한 때만 VERIFIED_REPLY. 그 뒤 Worker가 요청을 완료 처리하고 해당 단발 채널을 명시적으로 disconnect한다. 이 **자체 완료 뒤 close**만 예상된 단발 종료로 취급한다. Native 프로세스의 정상 exit code를 Chrome EOF로 증명했다는 뜻이 아니다.
- 성공 프레임 이전 unsolicited disconnect/EOF/timeout/중복·잘못된 프레임/기한 초과는 준비 실패. 그 요청을 폐기한 뒤 온 늦은 프레임은 어떤 문맥도 살리지 못한다.
- 기존 제품 탭의 서비스 제어 port는 별도 객체/수명이다. STOPPING/FAILED/COMPLETE/예상 못 한 onDisconnect는 성공한 단발 read의 close와 절대 합치지 않는다.

Worker 문맥 키는 `(Worker boot, adapter 객체 identity, extensionId, tabId, documentId, lifecycle launchId)`이다. 한 문서의 과거 callback이 다른 문서/새 준비를 retire하거나 재활성화하지 않게 준비 instance를 별도로 pin한다.
- prepare 전후 Root Chrome getContexts로 같은 extension TAB document/URL/frame0/nonincognito 확인. 탭에서 보낸 ID는 조회 선택자일 뿐 인증 근거 아님. 관측 호출은 Native 연결·adapter 초기화 없이 이 수명과 로컬 퇴역 상태를 검사한다.
- Root tabs.onRemoved/상위 문서 교체·문맥 소실은 해당 document의 관측 문맥만 퇴역한다. Worker 재시작은 모든 문맥 미준비. adapter 교체는 이전 객체의 문맥만 폐기.
- 제품 탭 session.js에서 현재 port에 묶인 STOPPING/FAILED/COMPLETE/onDisconnect 발생 시 **deny-only 퇴역 신호**를 Worker에 전달하는 최소 hook을 제안한다. exact sender/document/원래 launch·준비 instance를 확인하며, 이 신호로 PREPARED를 만들거나 바꾸거나 권한을 부여할 수 없다. 새 확장 public message 도입 여부·기존 통로 재사용 위치는 다훈 확인 후 고정한다. installer/Content 입력을 임의 trusted로 승격하지 않는다.
- 정상 집중 END는 부모 설치·launch 문맥을 종료하지 않는다. 동일 session의 실제 terminal 7scope를 별도로 검증하며 이전 generation 요청은 거절한다. 제품 STOP/실패/만료는 부모를 퇴역하고 저장 원문·의무는 남긴다.
- 마지막 비동기 Root/identity 조회가 끝난 뒤 R3 readonly transaction의 동기 final guard로 문맥/adapter/7scope/fence/만료를 검사한다. 그 후 추가 await 없음. 이벤트를 아직 전달받지 못한 Native/OS 실패에 대한 즉시 인지를 주장하지 않는다. 그런 지속 현재성까지 요구하면 별도 push/lease 계약이 필요하고 본 단발 성공으로 대체하지 않는다.

### R1 확인 항목과 미실행

1. 형식·시각·성공프레임 전용 실패 방식과 단발 완료 기준.
2. lifecycle 메모리 owner를 출처로 하고 ACL 외 양방향 OS peer 검증이 있는 IPC를 추가하는 방향 및 publish/retire hook 담당.
3. 제품 문서별 deny-only 퇴역 hook의 기존 경로/최소 변경. 이 hook도 공동 채택 전 구현하지 않음.

기존 사례15개와 R1 추가 사례는 모두 NOT_RUN. 원본 코드 변경·실제 IPC/Native/Worker/설치·권한 발급·END·기존 시험 반복은 없음.
