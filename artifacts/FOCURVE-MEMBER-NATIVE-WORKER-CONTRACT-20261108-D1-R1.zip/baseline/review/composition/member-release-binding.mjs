// Member-owned isolated trusted-Worker composition proposal. No message handler,
// initialization, tick/end/flush, browser injection, transport, or deployment.
// Core R2 source is preserved byte-for-byte under vendor; do not overlay its
// whole adapter (which has unrelated schedule-deadline changes) onto smtp-r2.
import {readMemberReleaseObservation} from './vendor/extension/integration/member-release-observation.mjs';
export const NATIVE_INSTALLATION_ID='93e1225f062544e7adf9aebd175844f5';
const scopeKeys=['installation_id','owner_key','session_id','desired_revision','session_revision','generation','record_version'];
const viewKeys=['scope','local_status','release_verification','aggregate_cleanup','binding_cleanup','release_ack_references','owned_dnr_removal','queried_at','stored_ended_at','stored_policy_released_at'];
const exact=(v,keys)=>v&&typeof v==='object'&&!Array.isArray(v)&&Object.keys(v).sort().join('|')===[...keys].sort().join('|');
const uuid=v=>typeof v==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/i.test(v);
const positive=v=>Number.isSafeInteger(v)&&v>0;
const sameScope=(a,b)=>exact(a,scopeKeys)&&scopeKeys.every(k=>a[k]===b[k]);
const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};
const unknown=code=>freeze({status:'UNKNOWN',code,authorityGranted:false,actualAcceptance:'UNCONFIRMED',owned_dnr_removal:'UNKNOWN'});
function expectedValid(expected,context){
 return exact(expected,scopeKeys)&&context?.native_installation_id===NATIVE_INSTALLATION_ID
  // Core installation_id is executor UUID, NOT the Windows installation hex ID.
  &&uuid(context.executor_id)&&expected.installation_id===context.executor_id
  &&typeof context.member_id==='string'&&/^[1-9][0-9]*$/.test(context.member_id)
  &&expected.owner_key==='MEMBER:'+context.member_id&&uuid(expected.session_id)
  &&expected.session_id===context.session_id&&uuid(expected.record_version)
  &&['desired_revision','session_revision','generation'].every(k=>positive(expected[k]));
}
export function mapReleaseObservation(view,expected,context){
 if(!expectedValid(expected,context)||!exact(view,viewKeys)||!sameScope(view.scope,expected))return unknown('OBSERVATION_SCOPE_UNCONFIRMED');
 if(!['ENDED','START_FAILED','INTERRUPTED','ENDING','UNKNOWN','RUNNING','STARTING'].includes(view.local_status)
  ||!['CONFIRMED','UNKNOWN'].includes(view.release_verification)
  ||!['CLEAR','PENDING','UNKNOWN'].includes(view.aggregate_cleanup)||!['CLEAR','PENDING','UNKNOWN'].includes(view.binding_cleanup)
  ||view.owned_dnr_removal!=='UNKNOWN')return unknown('OBSERVATION_SHAPE_UNCONFIRMED');
 if(!Array.isArray(view.release_ack_references)||view.release_ack_references.some(r=>!exact(r,['binding_id','operation_id','request_id'])||!Object.values(r).every(uuid)))return unknown('CONTENT_ACK_REFERENCE_UNCONFIRMED');
 const refs=view.release_ack_references.map(r=>({...r}));
 if(new Set(refs.map(r=>r.binding_id+':'+r.operation_id)).size!==refs.length)return unknown('DUPLICATE_ACK_REFERENCE');
 // Query time is evidence of query time only. Stored end times remain null/old
 // when supplied that way; never manufacture a historical DNR inspection time.
 if(typeof view.queried_at!=='string'||!Number.isFinite(Date.parse(view.queried_at))
  ||['stored_ended_at','stored_policy_released_at'].some(k=>view[k]!==null&&(typeof view[k]!=='string'||!Number.isFinite(Date.parse(view[k])))))return unknown('OBSERVATION_TIME_UNCONFIRMED');
 const local=view.local_status==='ENDED'&&view.release_verification==='CONFIRMED'
  &&view.aggregate_cleanup==='CLEAR'&&view.binding_cleanup==='CLEAR';
 return freeze({status:'LOCAL_RELEASE_MAPPED_DNR_AND_REAL_REENTRY_UNCONFIRMED',scope:{...expected},
  native_installation_id:context.native_installation_id,nativeIdentityVerified:false,
  local_status:view.local_status,local_release_checks_confirmed:local,
  aggregate_cleanup:view.aggregate_cleanup,binding_cleanup:view.binding_cleanup,
  content_release_ack_references:refs,server_report_ack:'NOT_SUPPLIED_BY_CORE_R2',
  owned_dnr_removal:'UNKNOWN',actual_reentry:'NOT_OBSERVED',
  queried_at:view.queried_at,stored_ended_at:view.stored_ended_at,stored_policy_released_at:view.stored_policy_released_at,
  authorityGranted:false,actualAcceptance:'UNCONFIRMED',STARTReady:false});
}
export async function readCurrentMemberRelease(expected,context){
 if(!expectedValid(expected,context))return unknown('EXPECTED_SCOPE_INVALID');
 const current=globalThis.__memberA1;
 if(!current)return unknown('CURRENT_MEMBER_ADAPTER_NOT_INITIALIZED');
 const pinned=structuredClone(expected),ctx=structuredClone(context);
 try{
  // Direct helper composition with the existing adapter; never import/use the
  // newer whole adapter as if it were already installed in93e.
  const view=await readMemberReleaseObservation(current,pinned);
  if(globalThis.__memberA1!==current)return unknown('CURRENT_ADAPTER_CHANGED');
  return mapReleaseObservation(view,pinned,ctx);
 }catch{return unknown('CORE_RELEASE_OBSERVATION_UNCONFIRMED');}
}
