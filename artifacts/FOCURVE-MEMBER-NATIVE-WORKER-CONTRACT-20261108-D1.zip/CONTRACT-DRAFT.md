# MEMBER-NATIVE-WORKER-IDENTITY-20261108-D1

상태: 공유 Native 명령·응답 **검토 후보**. 방향 동의와 구체 wire 채택을 구분한다. 구현·실행 승인 또는 기존 Native 지원 기능으로 기록하지 않는다.

## 기준과 정확 변경 범위

BASELINE-PINS.json의 16개 원문을 보존했다. historical bcf9cc + 수신 overlay이며 현 설치나 최신 Worker 전체와 같다고 주장하지 않는다.
- NativeLinkHost.cs: 930c75429b62b74f5e3bd564b852be3b11e0f66dc582fb24e1b732aa8ee6acf2.
- R3 helper: ceaa2d2da27a94aa02bca58d8b308b5990bb1e94039ed3bd1a1a11ff7323bd0b.
- 회원 composition binding: 07c381ef915e75e581a3ea7022eeeeb62c2424782033429f1dac37823122deb8.
- 독립 수용된 additive builder: af5517fab19114dec88a8da79f3a7ae428cca36df54ca0e43935e1fbc5a1c9e4.

확인 후 구현할 파일(후보 내부 경로 → 제품 상대 경로):
1. baseline/sources/native/NativeLinkHost.cs → native/NativeLinkHost.cs: 새 읽기 요청 분기 및 설치·현재 launch 검증. 기존 HELLO/서비스 제어 분기 불변.
2. 신규 extension/integration/member-native-observation.mjs: Worker 전용 prepare/read/retire private supplier. 비공개 문맥, 공개 메시지·새 START/END API 없음.
3. baseline/review/composition/member-release-binding.mjs → extension/integration/member-release-binding.mjs: 93e 상수의 신뢰 근거 사용을 제거하고 검증된 private supplier와 R3 결과만 결합. 상수 제거만으로 허용 범위를 넓히지 않는다.
4. baseline/review/composition/vendor/extension/integration/member-release-observation.mjs → extension/integration/member-release-observation.mjs: 선택적 내부 동기 final guard seam. Native 결합 경로는 guard를 필수 주입, strict true 이외 거절. 기존 로컬-only 관측과 Native 검증 주장을 구분.
5. baseline/accepted-additive-builder/build-member-a1.mjs → extension/scripts/build-member-a1.mjs: 새 모듈 입력 추가만. 기본 3출력 불변과 선택적 제4출력 유지.
6. 신규 tests/native-observation-*.test.mjs 및 변경 영향 fixture.

service-worker.js 실제 import/회원 bootstrap/제품 session.js/installer는 이번 Core 구현에서 자동 적용하지 않는다. 이들의 연결 시점은 다훈 확인 범위. Worker 객체를 만들거나 initializeMemberA1/tick을 관측 준비의 편의상 호출하지 않는다.

## 최소 Native wire 제안

기존 HELLO contract는 그대로 유지하고 새 목적을 별도 namespace로 분리한다. 아래 이름/필드는 **이 D1의 제안**이며 채택 전 코드에 넣지 않는다.

요청은 정확 5필드:
- contract: `FOCURVE_MEMBER_OBSERVATION_IDENTITY_1`
- operation: `READ_IDENTITY`
- installationId: Windows 32자리 lowercase hex 설치ID
- extensionId: 기존 Chrome 확장ID
- nonce: Worker가 이 준비 요청에 만든 기존 형식 32자리 lowercase hex

경로·owner·executor·session·만료·launch를 caller가 지정하지 않는다. Native host 이름은 설치가 고정한 설정과 install/extension 조합으로 선택하며 임의 host 주입을 허용하지 않는다. config는 선택/대조 입력이지 Native 검증 성공 근거가 아니다.

성공 응답은 정확 9필드:
- contract: 위 contract
- state: `VERIFIED`
- installationId, extensionId, nonce: 검증한 요청과 동일
- launchId: Native가 현재 설치 원문에서 확인한 32자리 lowercase hex
- grantNotAfterUTC: Native의 hash-pinned binding.json 원래 만료
- launchDeadlineUTC: 검증한 현재 launch 원문의 만료
- authorityGranted: `false`

Worker의 사용 기한은 두 시각의 min. launch가 더 긴 값이어도 grant 기한을 늘리지 않는다. 만료/형식/응답 correlation/알 수 없는 필드/누락은 거절한다. Native가 Core owner/session을 검증했다는 필드는 없다. token·nonce 원문·경로·SID·개인키·DB·credential을 관측 결과로 내보내지 않는다(응답 nonce는 Worker 내부 correlation 용도).

실패는 준비 실패로 reject하고 private Native 원문/예외를 UI·Content에 전달하지 않는다. 공개 오류 enum은 이 후보로 확정하지 않는다. 실패 응답 wire가 필요하다면 그 형식만 별도 확인한다.

## Native 검증 순서와 남은 출처 확인

1. 기존 Main의 compile-pinned binding hash·binding contract·현재 원래 만료·Chrome OS peer/프로필/확장 origin 검사를 그대로 재사용.
2. READ_IDENTITY 요청의 정확 키·purpose·installation/extension·nonce 검사. RuntimeProbe/OPEN_USER_SESSION/서비스·DB·grant 발급 코드로 dispatch하지 않는다.
3. 경로는 Native binding의 installationPath에서만 결정. 설치 record.id/extensionId와 binding, 현재 launch record와 launch-context의 launchId/deadline을 대조. 파일 읽기/검증만 수행하고 payload hash/marker/status를 갱신하거나 결손을 보수하지 않는다.
4. Native/제품 원문을 읽기 전후 대조하고 원래 만료·OS peer를 응답 직전에 재검사. 바뀐 launch/불명확한 준비·종료 상태/실패·HOLD/중단 상태는 reject.
5. 다훈 측 제안 확인: 준비 호출은 SESSION_READY 이후의 별도 명시 단계로 한정하고, Native가 허용하는 상태는 `PRODUCT_RUNNING_USER_SESSION`만을 초안으로 둔다. 집중 END 후에도 제품 서비스가 계속 RUNNING이면 종료 관측 가능. 설치 STOPPED/HOLD에 예외를 열지 않는다.

**중요:** 기존 install_core.owned_record()는 실행 중 상태를 허용하지 않는다. 이를 완화하거나 무조건 재사용하지 않는다. 또한 `installation.json`의 payload 목록과 그 파일이 서로 일치한다는 사실만으로 독립적인 위변조 방지 근거가 새로 생기지는 않는다. 다훈이 보호 launch의 writer·경로/접근 보호·기존 검증 수명·runtime 생존/상태 근거를 확인해야 한다. 그 근거가 미확정이면 새 read validator는 기본 거절로 남긴다. Native가 현재 파일을 읽었다는 사실을 원격 즉시 철회(C5)나 새 권한으로 표시하지 않는다.

## Worker private supplier

두 문맥을 분리한다.
- 부모: Windows 설치ID/확장/launch/만료/Worker boot/준비 요청 nonce/현재 adapter 객체/제품 제어 document 수명. 비공개 메모리만 사용하고 storage에서 복원하지 않는다.
- 각 조회: 기존 Core executor UUID·owner·session·desired_revision·session_revision·generation·record_version·owner fence. 기존 7scope 유지. Native가 executor/owner/session을 인증했다고 주장하지 않는다.

prepare는 정식 제품 준비의 명시적 호출에서만 Native 연결과 읽기 요청을 수행한다. 기존 adapter가 없으면 초기화하지 않고 거절한다. prepare 시작과 응답 소비 직전에 adapter/Worker/제어 document/요청 수명을 재검사한다. 늦은 응답으로 새 문맥을 덮어쓰지 않는다. 이전 문맥 폐기 후 준비 실패하면 기본 거절로 남긴다. 재시도나 자동 HELLO 없음.

read는 연결·Native 호출·초기화·권한 발급 없이 부모 문맥을 검사하고 R3 조회를 호출한다. 마지막 readonly 판정 안에서 동기 final guard가 같은 private 문맥/adapter/launch·만료를 다시 검사한다. guard 뒤 추가 await 없음. 저장 원문과 미해소 의무는 쓰거나 삭제하지 않는다. 유효 시각은 원래 UTC 기한과 로컬 monotonic 경과로 제한하며 시간 역행으로 연장하지 않는다.

정상 검증 요청은 단발 Native read이다. 응답 완료 후 **예정된 정상 EOF**는 성공한 read의 프로토콜 종료이며 제품 서비스 port 단절과 구분한다. 응답 전 EOF/timeout/파싱 실패는 prepare 실패다. 제품 탭의 기존 lifecycle port는 계속 유지한다. 이 구분도 이번 shared 계약 확인 대상이다.

## 수명·종료 규칙

- 탭 종료/새로고침/문서 교체: Root Chrome 수명 관측으로 부모 문맥 퇴역. 탭 메시지가 인증 성공을 만들 수 없고, 기존 실패 신호는 거절/퇴역 근거로만 소비.
- 기존 서비스 제어 port 실패·STOPPING/FAILED/COMPLETE·만료: 해당 문맥 퇴역. Worker가 이 사건을 관측할 정확 연결 위치는 다훈의 제품 탭 수명 확인과 함께 고정. 보지 못한 원격/OS 전이를 즉시 안다고 주장하지 않는다.
- Worker 재시작: 미준비 거절, 자동 Native 연결/저장값 복원/서비스 재개 없음.
- adapter 교체: 부모 문맥 퇴역. 새 adapter에 문맥 자동 승계 없음.
- 집중 END: 서비스 STOP과 다르다. 유효 부모 문맥 아래 동일 세션의 실제 종료 원장을 새 7scope로 검증할 수 있지만 옛 요청의 generation/record_version은 수정·재사용하지 않는다. 새 session/owner에는 자동 적용하지 않는다.
- 제품 정상 STOP: 문맥을 퇴역하고 저장 원문·cleanup/ACK/outbox 의무는 보존. 재기동은 새 명시적 준비 대상.

## 이번에 확인받을 최소 항목

다훈: READ_IDENTITY 5필드/성공 9필드, SESSION_READY 뒤 명시 준비 시점, 실행 중 보호 launch 검증 출처와 상태 기준, 제어 document/port 실패를 Worker가 제한 신호로 받는 연결.
종민: 기존 Native 검증 재사용·읽기-only 분기, private 문맥/수명, 최종 동기 소비 guard, 정확 후보와 영향시험.
Content 소비 형식은 바꾸지 않는다. 지민의 추가 확인은 Content 입력/복원 의미를 변경할 때만 요청.

이 후보 확인 전 공유 Native 구현·새 wire·설치·권한 발급·END 실행은 하지 않는다.
