import {readMemberReleaseObservation} from './member-release-observation.mjs';
import {ScheduleDeadline} from '../member-a1/schedule-deadline.mjs';
import {MODE,uuid,validateReport,authorizeCommand,authorizeContinuation,equal} from '../member-a1/protocol.mjs';
import {digest} from '../member-a1/contract.mjs';
const scheduleUtc=v=>typeof v==='string'&&/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(v)&&Number.isFinite(Date.parse(v))&&new Date(Date.parse(v)).toISOString()===v;
// Background trusted caller only. No new Content authority or public START endpoint.
export class MemberA1Adapter {
 constructor({auth,core,db,authority,inspectGuest,fetch=globalThis.fetch.bind(globalThis),now=Date.now,timeoutMs=10000}){Object.assign(this,{auth,core,db,authority,inspectGuest,fetch,now,timeoutMs});this.tail=Promise.resolve();}
 serial(f){const p=this.tail.then(f);this.tail=p.catch(()=>{});return p;}
 async identity(){const s=await this.auth.status();const i={owner_key:'MEMBER:'+s.owner_user_id,executor_id:s.executor_id,authority:s.server_url};if(!s.owner_user_id||!uuid(i.executor_id)||!i.authority)throw Error('MEMBER_AUTH_REQUIRED');if(this.frozen&&!equal(i,this.frozen))throw Error('OWNER_MISMATCH');this.frozen??=i;return i;}
 async request(path,body,headers={},beforeSend=null){if(this.preservedEndScope)throw Error('PRESERVED_END_ONLY');const i=await this.identity(),c=await this.auth.credentials(),again=await this.identity();if(c.owner_key!==i.owner_key||c.executor_id!==i.executor_id||!equal(again,i))throw Error('OWNER_MISMATCH');if(body!==undefined&&/^\/sessions\/[-0-9a-f]{36}\/end$/.test(path)&&!headers['Idempotency-Key']){const key='member:http-intent:'+path+':'+await digest(body);let intent=await this.read(key);if(!intent){intent={id:crypto.randomUUID()};await this.put(key,intent);}headers={...headers,'Idempotency-Key':intent.id};}const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),this.timeoutMs);try{if(beforeSend&&!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');const dispatch=()=>({response:this.fetch(i.authority+path,{method:body===undefined?'GET':'POST',redirect:'error',credentials:'omit',cache:'no-store',signal:controller.signal,headers:{Authorization:'Bearer '+c.access_token,'Content-Type':'application/json',...headers},...(body===undefined?{}:{body:JSON.stringify(body)})})});const sent=beforeSend?await beforeSend(dispatch):dispatch(),res=await sent.response;const result=await res.json();if(!res.ok)throw Error('MEMBER_HTTP_'+res.status+':'+result.error?.code);return result;}finally{clearTimeout(timer);}}
 async read(key){return this.db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').get(key);q.onsuccess=()=>done(q.result??null);});}
 async put(key,value){return this.db.transaction('readwrite',(tx,done)=>{tx.objectStore('metadata').put({key,...structuredClone(value)});done(value);});}
 async authorize(command){const i=await this.identity(),session=await this.request('/sessions/'+command.session_id),issued=await this.request('/executors/'+i.executor_id+'/commands'),original=issued.commands.find(x=>x.command_id===command.command_id);if(!original||await digest(original)!==await digest(command))throw Error('MEMBER_COMMAND_REJECTED');authorizeCommand(command,session,i,this.now());const guest=await this.inspectGuest();if(guest.active||guest.unresolved||guest.cleanup)throw Error('GUEST_OBLIGATION_EXISTS');const claim=await this.authority.claim(i,command.session_id);const admission={authority_epoch:claim.epoch,authority:i.authority,owner_key:i.owner_key,executor_id:i.executor_id,session_id:command.session_id,command_id:command.command_id,server_revision:command.desired_revision,policy_snapshot_id:command.snapshot.policy_snapshot_id,snapshot_sha256:await digest(command.snapshot),command:structuredClone(command)};return {...i,admission};}
 async assertApply(){if(this.preservedEndScope)throw Error('PRESERVED_END_ONLY');const b=await this.core.bundle();if(!b)return;const i=await this.identity(),c=await this.auth.credentials(),s=await this.request('/sessions/'+b.a.session_id);if(c.owner_key!==i.owner_key||s.owner_user_id!==i.owner_key.slice(7)||s.policy_snapshot_id!==b.a.snapshot_ref.policy_snapshot_id||s.time_accounting_mode!==MODE||s.desired_revision!==b.state.session.member_admission.server_revision||!(['STARTING','RUNNING','UNKNOWN'].includes(s.execution_status)||s.execution_status==='NATIVE_VERIFYING'&&b.state.session.member_admission.command.native_transition_contract==='NR01_1'&&!s.first_nr_failure))throw Error('MEMBER_AUTHORITY_INACTIVE');if(b.state.session.started_at)authorizeContinuation(b.state.session.member_admission.command,s,i,b,this.now());else authorizeCommand(b.state.session.member_admission.command,s,i,this.now());}
 async intervals(){return this.db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('intervals').getAll();q.onsuccess=()=>done(q.result);});}
 async nrBound(b,command){return {session_id:b.a.session_id,owner_context:b.a.owner_context,executor_id:b.a.executor_id,command_id:command.command_id,desired_revision:b.a.desired_revision,generation:b.a.generation,fence:b.ownerFenceEpoch,snapshot_ref:b.a.snapshot_ref,r0:await digest(b.a.r0),transition_id:b.a.native_transition?.transition_id??null,effect_transition_id:b.a.effect_transition?.transition_id??null,effect_plan_version:b.a.effect_transition?.grants.map(g=>[g.binding_id,g.plan_version])??null};}
 async nrWitness(b,command){
  if(b?.a.native_transition_contract!=='NR01_1'||command.native_transition_contract!=='NR01_1')return null;
  const snapshot=await this.db.transaction('readonly',(tx,done)=>{const data={};let pending=2;for(const name of ['metadata','intervals']){const q=tx.objectStore(name).getAll();q.onsuccess=()=>{data[name]=q.result;if(!--pending)done(data);};}}),rows=snapshot.metadata,current=rows.find(x=>x.key===b.a.key);if(current?.record_version!==b.a.record_version)throw Error('GENERATION_CHANGED');
  const bindings=rows.filter(x=>x.record_kind==='A1_BINDING'&&x.scope.session_id===b.a.session_id).map(x=>({scope:x.scope,record_version:x.record_version,registration_epoch:x.registration_epoch,authority:x.ordinary_authority,resolution:x.resolution,apply_closed:x.apply_closed,effect:x.current_effect,coverage:x.current_coverage,proof:rows.find(p=>p.key==='a1:p1:NATIVE_BINDING_PROOF:'+x.scope.binding_id)??null,lease:rows.find(p=>p.key==='a1:p1:CLEANUP_LEASE:'+x.scope.binding_id)??null}));
  const bound=await this.nrBound(b,command);
  return {bound,sha256:await digest({bound,transition:b.a.native_transition??null,effect_transition:b.a.effect_transition??null,commit_fence:b.a.commit_fence,bindings}),intervals:snapshot.intervals};
 }
 async report(command,result,{rollbackConfirmed=false,errorCode}={}){const b=await this.core.bundle();if(result==='EFFECT_VERIFYING'&&(b.a.session_status!=='EFFECT_VERIFYING'||!['VERIFYING','READY'].includes(b.a.effect_transition?.phase)))return null;if(result==='REVALIDATING'&&(b.a.session_status!=='NATIVE_VERIFYING'||!b.a.native_transition||['CONFIRMED','FAILED'].includes(b.a.native_transition.phase)))return null;if(result==='APPLIED'&&(b.a.session_status!=='RUNNING'||b.a.native_transition&&b.a.native_transition.phase!=='CONFIRMED'||b.a.effect_transition&&b.a.effect_transition.started_at>=(b.a.native_transition?.started_at??0)&&b.a.effect_transition.phase!=='CONFIRMED'))return null;const witness=await this.nrWitness(b,command),rows=(witness?.intervals??await this.intervals()).filter(i=>i.session_id===command.session_id),intervals=rows.map(({interval_id,kind,start_at,end_at,duration_ms,quality})=>({interval_id,kind,start_at,quality,...(end_at==null?{}:{end_at,duration_ms})}));const observed=result==='APPLIED'?b.a.time.last_trusted_at:result==='EFFECT_VERIFYING'?new Date(b.a.effect_transition.last_seen_at).toISOString():result==='REVALIDATING'?new Date(b.a.native_transition.last_seen_at).toISOString():new Date(this.now()).toISOString();const report={report_id:crypto.randomUUID(),command_id:command.command_id,session_id:command.session_id,executor_id:command.executor_id,desired_revision:command.desired_revision,result,observed_at:observed,intervals,...(result==='RELEASED'||rollbackConfirmed?{rollback_confirmed:true}:{}),...(errorCode?{error_code:errorCode}:{})};const n=b?.a.native_transition;if(n&&command.native_transition_contract==='NR01_1'&&['REVALIDATING','APPLIED','UNCONFIRMED'].includes(result))report.transition_context={version:'NR01_1',transition_id:n.transition_id,root_generation:n.anchor_generation,phase:result==='REVALIDATING'?'VERIFYING':result==='APPLIED'?'CONFIRMED':'FAILED',started_at:new Date(n.started_at).toISOString(),deadline_at:new Date(n.deadline_at).toISOString(),root_evidence_sha256:witness.sha256,...(n.transition_kind?{transition_kind:n.transition_kind,document_transition_contract:'ND01_1'}:{})};const d=b?.a.effect_transition;if(result==='REVALIDATING'&&d?.phase==='CANCELLED'&&command.dom_transition_contract==='DP01_1')report.effect_cancel_ref=d.transition_id;if(d&&command.dom_transition_contract==='DP01_1'&&['EFFECT_VERIFYING','APPLIED','UNCONFIRMED'].includes(result)&&d.started_at>=(n?.started_at??0)){delete report.transition_context;report.effect_transition_context={version:'DP01_1',transition_id:d.transition_id,root_generation:d.anchor_generation,phase:result==='EFFECT_VERIFYING'?'VERIFYING':result==='APPLIED'?'CONFIRMED':'FAILED',started_at:new Date(d.started_at).toISOString(),deadline_at:new Date(d.deadline_at).toISOString(),root_evidence_sha256:witness.sha256};}validateReport(report);const outboxIdentity=await this.identity();if(report.executor_id!==outboxIdentity.executor_id)throw Error('OWNER_MISMATCH');const key='member:last-report:'+command.command_id+':'+result,fp=await digest({...report,report_id:null}),prior=await this.read(key);if(prior?.fp===fp)return prior.report;await this.db.transaction('readwrite',(tx,done)=>{const md=tx.objectStore('metadata');md.put({key:'member:outbox:'+report.report_id,kind:'REPORT',body:report,acked:false,...outboxIdentity,...(witness?{nr01:true,root_binding:witness.bound,root_evidence_sha256:witness.sha256}:{})});md.put({key,fp,report});done(null);});return report;}
 flush(){const work=(this.flushTail??Promise.resolve()).then(()=>this.flushBody());this.flushTail=work.catch(()=>{});return work;}
 async pendingOutbox(i){return this.db.transaction('readonly',(tx,done)=>{let metadata,sessions;const finish=()=>{if(!metadata||!sessions)return;done(metadata.filter(row=>{if(!row.key?.startsWith('member:outbox:')||row.acked)return false;const body=row.body,reports=row.kind==='REPORT'?[body]:row.kind==='LOCAL_END'&&Array.isArray(body?.local_actions)?body.local_actions.map(a=>a.report):[];const sid=row.kind==='REPORT'?body?.session_id:body?.journal_summary?.session_id;if(!sid||!reports.length||reports.some(r=>!r||r.executor_id!==i.executor_id||r.session_id!==sid))return false;if(row.kind==='LOCAL_END'&&body.local_actions.some(a=>a.session_id!==sid))return false;const scoped=['owner_key','executor_id','authority'].some(k=>row[k]!==undefined);if(scoped)return row.owner_key===i.owner_key&&row.executor_id===i.executor_id&&row.authority===i.authority;return sessions.some(s=>s.session_id===sid&&s.owner_key===i.owner_key&&s.executor_id===i.executor_id&&s.member_admission?.authority===i.authority); }));};const md=tx.objectStore('metadata').getAll(),ss=tx.objectStore('sessions').getAll();md.onsuccess=()=>{metadata=md.result;finish();};ss.onsuccess=()=>{sessions=ss.result;finish();};});}
 async flushBody(){const i=await this.identity(),rows=await this.pendingOutbox(i);rows.sort((a,b)=>(Date.parse(a.body.observed_at??a.body.local_actions?.[0]?.report?.observed_at)||0)-(Date.parse(b.body.observed_at??b.body.local_actions?.[0]?.report?.observed_at)||0));for(const row of rows){const ack=await this.request('/executors/'+i.executor_id+(row.kind==='LOCAL_END'?'/reconcile':'/reports'),row.body);if(!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');let serverAck=null;if(row.nr01){if(!['ACCEPTED','DUPLICATE'].includes(ack.result)||!Number.isSafeInteger(ack.desired_revision)||ack.desired_revision<row.body.desired_revision)throw Error('REPORT_ACK_UNCONFIRMED');serverAck={...ack,running_confirmed:false};if(row.body.result==='APPLIED'){const confirmation=ack.execution_confirmation;if(confirmation!==undefined&&(confirmation?.contract!=='NR01_REPORT_CONFIRMATION_1'||confirmation.report_id!==row.body.report_id||confirmation.command_id!==row.body.command_id||!confirmation.state||typeof confirmation.state!=='object'||Array.isArray(confirmation.state)))throw Error('REPORT_ACK_UNCONFIRMED');const state=confirmation===undefined?await this.request('/sessions/'+row.body.session_id):confirmation.state,r=row.root_binding,n=row.body.transition_context,d=row.body.effect_transition_context;if(!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');if(state.session_id!==row.body.session_id||state.native_transition_contract!=='NR01_1'||state.time_accounting_mode!==MODE||state.owner_user_id!==i.owner_key.slice(7)||state.executor_id!==i.executor_id||state.policy_snapshot_id!==r.snapshot_ref.policy_snapshot_id){await this.put(row.key,{...row,acked:true,server_ack:serverAck});await this.core.markUnknown('OWNER_MISMATCH');throw Error('SERVER_SCOPE_MISMATCH');}serverAck.running_confirmed=state.execution_status==='RUNNING'&&state.native_transition_contract==='NR01_1'&&!state.first_nr_failure&&state.owner_user_id===i.owner_key.slice(7)&&state.executor_id===i.executor_id&&state.desired_revision===r.desired_revision&&state.policy_snapshot_id===r.snapshot_ref.policy_snapshot_id&&(!n||state.native_transition?.transition_id===n.transition_id&&state.native_transition?.phase==='CONFIRMED'&&state.native_transition?.root_generation===n.root_generation)&&(!d||state.dom_transition_contract==='DP01_1'&&!state.first_dp_failure&&state.effect_transition?.transition_id===d.transition_id&&state.effect_transition?.phase==='CONFIRMED'&&state.effect_transition?.root_generation===d.root_generation);if(state.execution_status==='UNKNOWN'&&state.desired_revision===r.desired_revision){await this.put(row.key,{...row,acked:true,server_ack:serverAck});await this.core.markUnknown('REVALIDATION_REQUIRED');throw Error('SERVER_EXECUTION_UNCONFIRMED');}}}
if(!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');
if(row.kind==='LOCAL_END'&&!ack.acknowledged_actions?.includes(row.body.local_actions[0].action_id))throw Error('RECONCILE_UNCONFIRMED');if(row.kind==='LOCAL_END'||row.body.result==='RELEASED')await this.authority.released(i,row.kind==='LOCAL_END'?row.body.local_actions[0].session_id:row.body.session_id);await this.put(row.key,{...row,acked:true,...(serverAck?{server_ack:serverAck}:{})});}return rows.length;}
 // Read-only local admission snapshot. Unknown state/debt is not an idle grant.
 async scheduleClaimLocal(i){
  await this.core.ready;
  const b=await this.core.bundle(),rows=await this.core.registry.rows(),root=await this.authority.current(),intent=await this.read('member:start-intent');
  if(!Array.isArray(rows))throw Error('MEMBER_LOCAL_STATE_UNCONFIRMED');
  if(intent&&intent.completed!==true)throw Error('START_INTENT_CONFLICT');
  const sessions=new Set();let foreign=false;
  const debt=(sid,context)=>{if(!uuid(sid)||typeof context!=='string')throw Error('MEMBER_LOCAL_STATE_UNCONFIRMED');sessions.add(sid);if(context!==i.owner_key)foreign=true;};
  if(b){
   if(b.a.owner_context!==i.owner_key||b.a.executor_id!==i.executor_id)throw Error('OWNER_MISMATCH');
   if(!['ENDED','START_FAILED','INTERRUPTED'].includes(b.a.session_status)||b.a.cleanup_pending||b.state?.journal?.desired!=='RELEASED'||b.state?.journal?.observed!=='RELEASED')debt(b.a.session_id,i.owner_key);
   for(const binding of b.bindings??[])if(binding.resolution==='NONE'||binding.cleanup_pending)debt(binding.scope?.session_id,binding.scope?.owner_context);
  }
  for(const row of rows){
   if(row.record_kind==='A1_BINDING'&&(row.resolution==='NONE'||row.cleanup_pending))debt(row.scope?.session_id,row.scope?.owner_context);
   if(row.record_kind==='A1_OPERATION'&&['ISSUED','IN_FLIGHT','IN_DOUBT'].includes(row.phase))debt(row.command?.payload?.scope?.session_id,row.command?.owner_context);
  }
  if(root){
   if(!['ACTIVE','RELEASED'].includes(root.phase))throw Error('MEMBER_LOCAL_STATE_UNCONFIRMED');
   if(root.phase==='ACTIVE'){
    if(root.owner_key!==i.owner_key||root.executor_id!==i.executor_id||root.authority!==i.authority)throw Error('ROOT_OBLIGATION_EXISTS');
    debt(root.session_id,i.owner_key);
   }
  }
  return {bundle:b,sessions:[...sessions],foreign};
 }
 async guardScheduleClaim(i){
  if(!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');
  const guest=await this.inspectGuest();if(guest.active||guest.unresolved||guest.cleanup)throw Error('GUEST_OBLIGATION_EXISTS');
  const local=await this.scheduleClaimLocal(i);if(local.foreign||local.sessions.length)throw Error('CLEANUP_REQUIRED');
  await this.authority.idle();
  const again=await this.scheduleClaimLocal(i);if(again.foreign||again.sessions.length)throw Error('CLEANUP_REQUIRED');
 }
 async dispatchScheduleClaim(i,send){
  // Linearize the last read and synchronous fetch initiation with Core transitions.
  // send() boxes its response Promise: release Core.serial before awaiting the network.
  if(typeof this.core.serial!=='function')throw Error('SCHEDULE_ADMISSION_UNSUPPORTED');
  return this.core.serial(async()=>{await this.guardScheduleClaim(i);return send();});
 }
 async recoverScheduleClaim(body,i,local){
  // A matching busy occurrence is recovery by GET only, never a new mutation or APPLY replay.
  if(local.foreign||local.sessions.length!==1)throw Error('CLEANUP_REQUIRED');
  const page=await this.request('/schedules/'+body.schedule_id+'/occurrences');
  if(!Array.isArray(page?.items)||page.has_more!==false||page.next_cursor!==null)throw Error('SCHEDULE_OCCURRENCE_UNCONFIRMED');
  const matches=page.items.filter(r=>r.schedule_id===body.schedule_id&&r.scheduled_start_at===body.scheduled_start_at&&r.schedule_version===body.version);
  if(matches.length!==1||!uuid(matches[0].occurrence_id)||matches[0].session_id!==local.sessions[0]||!scheduleUtc(matches[0].scheduled_end_at)||Date.parse(matches[0].scheduled_end_at)<=Date.parse(body.scheduled_start_at))throw Error('CLEANUP_REQUIRED');
  const row=matches[0],saved=await this.request('/sessions/'+row.session_id);
  if(!equal(await this.identity(),i)||saved?.session_id!==row.session_id||saved.executor_id!==i.executor_id||'MEMBER:'+saved.owner_user_id!==i.owner_key||saved.source!=='SCHEDULE'||saved.origin!=='MEMBER'||saved.planned_end_at!==row.scheduled_end_at)throw Error('SCHEDULE_SESSION_UNCONFIRMED');
  const fresh=await this.scheduleClaimLocal(i);if(fresh.foreign||fresh.sessions.some(s=>s!==row.session_id))throw Error('CLEANUP_REQUIRED');
  const execution=await this.status();if(!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');
  return {occurrence_session_id:row.session_id,execution:execution?.session_id===row.session_id?execution:null,read_only:true,recovery_required:true};
 }
 // Trusted background caller only; same Server occurrence is the sole writer.
 claimSchedule(input){const body=structuredClone(input);return this.serial(async()=>{
  const utc=scheduleUtc;
  if(!body||Object.keys(body).sort().join(',')!=='schedule_id,scheduled_start_at,version'||!uuid(body.schedule_id)||!Number.isSafeInteger(body.version)||body.version<1||!utc(body.scheduled_start_at))throw Error('INVALID_SCHEDULE_CLAIM');
  if(this.preservedEndScope)throw Error('PRESERVED_END_ONLY');
  const i=await this.identity(),guest=await this.inspectGuest();
  if(guest.active||guest.unresolved||guest.cleanup)throw Error('GUEST_OBLIGATION_EXISTS');
  const local=await this.scheduleClaimLocal(i);
  if(local.sessions.length||local.foreign)return this.recoverScheduleClaim(body,i,local);
  await this.guardScheduleClaim(i);
  const list=await this.request('/schedules?executor_id='+encodeURIComponent(i.executor_id));
  if(!Array.isArray(list?.items)||list.has_more!==false||list.next_cursor!==null)throw Error('SCHEDULE_LIST_UNCONFIRMED');
  const matches=list.items.filter(r=>r.schedule_id===body.schedule_id);
  if(matches.length!==1)throw Error('SCHEDULE_NOT_FOUND');
  const schedule=matches[0];
  if(schedule.executor_id!==i.executor_id||schedule.version!==body.version||schedule.enabled!==true||schedule.deleted_at!==null||!Number.isInteger(schedule.duration_minutes)||schedule.duration_minutes<1||schedule.duration_minutes>180)throw Error('SCHEDULE_VERSION_UNCONFIRMED');
  const end=new Date(Date.parse(body.scheduled_start_at)+schedule.duration_minutes*60000).toISOString();
  if(!utc(end))throw Error('INVALID_SCHEDULE_CLAIM');
  // Default closed: current confirmed-run Core cannot enforce a scheduled fixed end.
  // Only a trusted Core deadline implementation may authorize this admission.
  if(typeof this.core.verifyScheduledDeadline!=='function'||await this.core.verifyScheduledDeadline({owner:structuredClone(i),claim:structuredClone(body),fixedEndAt:end})!==true)throw Error('SCHEDULE_FIXED_END_UNSUPPORTED');
  if(!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');
  await this.guardScheduleClaim(i);
  const result=await this.request('/schedule-occurrences/claim',body,{},send=>this.dispatchScheduleClaim(i,send));
  if(!equal(await this.identity(),i))throw Error('OWNER_MISMATCH');
  if(result?.execution_status!==undefined){
   if(!uuid(result.session_id)||result.executor_id!==i.executor_id||'MEMBER:'+result.owner_user_id!==i.owner_key||result.source!=='SCHEDULE'||result.origin!=='MEMBER'||result.planned_end_at!==end||!['STARTING','RUNNING','EFFECT_VERIFYING','NATIVE_VERIFYING','UNKNOWN','ENDING','ENDED','START_FAILED','INTERRUPTED'].includes(result.execution_status))throw Error('SCHEDULE_SESSION_UNCONFIRMED');
   // Bind the returned session to the exact durable Server occurrence.
   const occurrences=await this.request('/schedules/'+body.schedule_id+'/occurrences');
   if(!Array.isArray(occurrences?.items)||occurrences.has_more!==false||occurrences.next_cursor!==null)throw Error('SCHEDULE_OCCURRENCE_UNCONFIRMED');
   const links=occurrences.items.filter(r=>r.schedule_id===body.schedule_id&&r.scheduled_start_at===body.scheduled_start_at);
   if(links.length!==1||!uuid(links[0].occurrence_id)||links[0].schedule_version!==body.version||links[0].scheduled_end_at!==end||links[0].session_id!==result.session_id)throw Error('SCHEDULE_SESSION_UNCONFIRMED');
   // Re-read the existing Server session before the normal command authorization path.
   const saved=await this.request('/sessions/'+result.session_id);
   if(!equal(await this.identity(),i)||saved.session_id!==result.session_id||saved.executor_id!==i.executor_id||'MEMBER:'+saved.owner_user_id!==i.owner_key||saved.source!=='SCHEDULE'||saved.origin!=='MEMBER'||saved.planned_end_at!==end)throw Error('SCHEDULE_SESSION_UNCONFIRMED');
   // HTTP success is not RUNNING. tickInner re-fetches and authorizes actual commands.
   const execution=await this.tickInner();
   if(execution?.session_id!==result.session_id)throw Error('SCHEDULE_EXECUTION_UNCONFIRMED');
   return {occurrence_session_id:result.session_id,execution};
  }
  if(!uuid(result?.occurrence_id)||result.schedule_id!==body.schedule_id||result.schedule_version!==body.version||result.scheduled_start_at!==body.scheduled_start_at||result.scheduled_end_at!==end||!['PENDING','WAITING_CONFLICT','SKIPPED'].includes(result.status)||result.session_id!==null)throw Error('SCHEDULE_OCCURRENCE_UNCONFIRMED');
  return {occurrence_id:result.occurrence_id,status:result.status,reason:result.reason??null,scheduled_end_at:end};
 });}
 start(minutes,uiRequestId){return this.serial(async()=>{if(this.preservedEndScope)throw Error('PRESERVED_END_ONLY');if(!Number.isInteger(minutes)||minutes<1||minutes>180)throw Error('INVALID_DURATION');if(uiRequestId!==undefined&&!uuid(uiRequestId))throw Error('INVALID_UI_REQUEST_ID');const i=await this.identity(),guest=await this.inspectGuest();if(guest.active||guest.unresolved||guest.cleanup)throw Error('GUEST_OBLIGATION_EXISTS');await this.authority.idle();const existing=await this.core.bundle();if(existing&&(!['ENDED','START_FAILED','INTERRUPTED'].includes(existing.a.session_status)||existing.bindings.some(x=>x.resolution==='NONE')))throw Error('CLEANUP_REQUIRED');let intent=await this.read('member:start-intent');if(uiRequestId!==undefined&&intent?.ui_request_id===uiRequestId&&intent.completed)throw Error('START_REQUEST_ALREADY_RECORDED');if(uiRequestId!==undefined&&intent&&!intent.completed){if(!intent.ui_request_id)throw Error('START_REQUEST_CORRELATION_UNCONFIRMED');if(intent.ui_request_id!==uiRequestId)throw Error('START_INTENT_CONFLICT');throw Error('START_REQUEST_OUTCOME_UNCONFIRMED');}if(!intent||intent.completed)intent={id:uiRequestId??crypto.randomUUID(),minutes,completed:false,...(uiRequestId===undefined?{}:{ui_request_id:uiRequestId})};if(intent.minutes!==minutes)throw Error('START_INTENT_CONFLICT');await this.put('member:start-intent',intent);const s=await this.request('/sessions',{executor_id:i.executor_id,duration_minutes:minutes,...(this.core.nd01?{document_transition_contract:'ND01_1'}:{}),...(this.core.nr01?{native_transition_contract:'NR01_1'}:{}),...(this.core.dp01?{dom_transition_contract:'DP01_1'}:{})},{'Idempotency-Key':intent.id});await this.put('member:start-intent',{...intent,completed:true,session_id:s.session_id});if(s.execution_status!=='STARTING')throw Error('FALSE_RUNNING');await this.tickInner();return this.status();});}
 // Consume an already protected fixed-end obligation; never arm or grant a
 // new schedule. Missing/corrupt scope or new-boot anchor rejects before APPLY.
 async enforceStoredScheduleDeadline(){
  const b=await this.core.bundle();if(!b)return null;
  const service=new ScheduleDeadline(this.core),row=await service.read(b.a.session_id);if(!row)return null;
  const result=await service.check(b.a.session_id);
  if(result.state!=='RELEASED')return null;
  await this.offlineEndInner(b.a.session_id);return b.a.session_id;
 }
 async tickInnerBody(){if(this.preservedEndScope)throw Error('PRESERVED_END_ONLY');await this.core.ready;await this.identity();await this.flush();await this.enforceStoredScheduleDeadline();const i=await this.identity(),response=await this.request('/executors/'+i.executor_id+'/commands');for(const command of response.commands){if(command.type==='APPLY_POLICY'&&await this.enforceStoredScheduleDeadline()===command.session_id)continue;const session=await this.request('/sessions/'+command.session_id);try{authorizeCommand(command,session,i,this.now());}catch(error){if(command.type!=='APPLY_POLICY'||error.cause?.stage!=='COMMAND_EXPIRY')throw error;await this.request('/sessions/'+command.session_id+'/end',{reason:'APPLY_EXPIRED'});return this.status();}await this.put('member:active-command',{command});if(command.type==='APPLY_POLICY'){await this.core.startCommand(command);const b=await this.core.bundle();if(b.a.session_status!=='RUNNING')throw Error('LOCAL_APPLY_UNCONFIRMED');await this.report(command,'APPLIED');}else{const b=await this.core.bundle();if(b&&b.a.session_id===command.session_id){if(session.policy_snapshot_id!==b.a.snapshot_ref.policy_snapshot_id)throw Error('SNAPSHOT_MISMATCH');if(b.a.session_status==='START_FAILED'){await this.verifyRelease();}else if(!b.state.session.started_at&&!session.started_at){await this.core.endIntent(command.session_id,'SYSTEM_START_FAILURE');await this.core.serial(()=>this.core.finish());}else await this.core.end(command.session_id);await this.verifyRelease();await this.report(command,'RELEASED');}else {await this.authority.claim(i,command.session_id);const report={report_id:crypto.randomUUID(),command_id:command.command_id,session_id:command.session_id,executor_id:i.executor_id,desired_revision:command.desired_revision,result:'RELEASED',observed_at:new Date(this.now()).toISOString(),intervals:[],rollback_confirmed:true};if((await this.core.chrome.declarativeNetRequest.getSessionRules()).length||(await this.core.registry.rows()).some(r=>r.record_kind==='A1_BINDING'&&r.resolution==='NONE'))throw Error('CLEANUP_REQUIRED');await this.put('member:outbox:'+report.report_id,{kind:'REPORT',body:report,acked:false,...i});}}}await this.flush();const b=await this.core.bundle();if(b&&!['ENDED','START_FAILED','INTERRUPTED'].includes(b.a.session_status)){await this.core.tick();const fresh=await this.core.bundle();if(fresh.a.session_status==='RUNNING'){await this.report(fresh.state.session.member_admission.command,'APPLIED');await this.flush();}else if(fresh.a.session_status==='EFFECT_VERIFYING'){await this.report(fresh.state.session.member_admission.command,'EFFECT_VERIFYING');await this.flush();}else if(fresh.a.session_status==='NATIVE_VERIFYING'){await this.report(fresh.state.session.member_admission.command,'REVALIDATING');await this.flush();}else if(['ENDED','INTERRUPTED'].includes(fresh.a.session_status)){await this.offlineEndInner();await this.flush();}else throw Error('LOCAL_EXECUTION_UNCONFIRMED');}return this.status();}
 async tickInner(){try{return await this.tickInnerBody();}catch(e){const b=await this.core.bundle(),active=await this.read('member:active-command');if(b?.a.session_status==='START_FAILED'&&active?.command?.type==='APPLY_POLICY'){await this.verifyRelease();await this.report(active.command,'FAILED',{rollbackConfirmed:true,errorCode:e.message});await this.flush();}if(b?.a.session_status==='UNKNOWN'&&active?.command){try{const code=b.state?.session?.last_error_code??this.core.firstFailureDiagnostic?.code;const safeCode=['REVALIDATION_REQUIRED','STORE_UNCONFIRMED','OWNER_MISMATCH','GENERATION_CHANGED','INVALID_CURRENT_RESPONSE','RUNNING_GATE_DENIED','INVALID_EFFECT_EVIDENCE','CLEANUP_REQUIRED','INVALID_TRANSITION_STATE','UNAUTHORIZED_SENDER','MEMBER_AUTH_REQUIRED','INVALID_SNAPSHOT','SCOPE_MISMATCH'].includes(code)?code:null;await this.report(active.command,'UNCONFIRMED',safeCode?{errorCode:safeCode}:{});await this.flush();}catch{}}throw e;}}
 tick(){return this.serial(()=>this.tickInner());}
 readReleaseObservation(expected){return readMemberReleaseObservation(this,expected);}
 async verifyRelease(){const b=await this.core.bundle();if(!b||!['ENDED','START_FAILED','INTERRUPTED'].includes(b.a.session_status)||b.state.journal.desired!=='RELEASED'||b.state.journal.observed!=='RELEASED'||b.bindings.some(x=>x.resolution==='NONE'||x.cleanup_pending))throw Error('RELEASE_UNCONFIRMED');return b;}
 end(){return this.serial(async()=>{const b=await this.core.bundle();if(!b)throw Error('SESSION_NOT_FOUND');await this.request('/sessions/'+b.a.session_id+'/end',{});return this.tickInner();});}
 disconnect(){return this.serial(async()=>{
  const identity=await this.identity(),bundle=await this.core.bundle();
  if(bundle){await this.verifyRelease();const server=await this.request('/sessions/'+bundle.a.session_id);if(!['ENDED','START_FAILED'].includes(server.execution_status))throw Error('SERVER_RELEASE_UNCONFIRMED');}
  const registry=await this.core.registry.rows();if(registry.some(r=>r.record_kind==='A1_BINDING'&&(r.resolution==='NONE'||r.cleanup_pending))||(await this.core.chrome.declarativeNetRequest.getSessionRules()).length)throw Error('CLEANUP_REQUIRED');
  await this.flush();await this.authority.idle();
  const pending=await this.db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result.some(r=>r.key.startsWith('member:outbox:')&&!r.acked));});if(pending)throw Error('SERVER_RELEASE_UNCONFIRMED');
  // Serialize revocation with token refresh/link. Only authentication secrets are retired.
  await this.auth.credentials();return this.auth.serial(async()=>{
   const r=await this.auth.load();if(r.phase!=='LINKED'||'MEMBER:'+r.owner_user_id!==identity.owner_key||r.executor_id!==identity.executor_id||r.server_url!==identity.authority)throw Error('OWNER_MISMATCH');
   const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),this.timeoutMs);
   try{const res=await this.fetch(r.server_url+'/extension-installations/'+r.executor_id+'/connection',{method:'DELETE',redirect:'error',credentials:'omit',cache:'no-store',signal:controller.signal,headers:{Authorization:'Bearer '+r.access_token}});if(res.status!==204)throw Error('DISCONNECT_UNCONFIRMED');
    const saved=await this.auth.store.put(this.auth.registered(r));return this.auth.publicState(saved);
   }finally{clearTimeout(timer);}
  });
 });}
 async reconcilePreservedEnd(scope,send){return this.serial(async()=>{
  const i=await this.identity(),b=await this.verifyRelease();
  if(typeof send!=='function'||scope.session_id!==b.a.session_id||scope.executor_id!==i.executor_id||scope.owner_user_id!==i.owner_key.slice(7)||scope.origin+'/api/v1'!==i.authority||scope.policy_snapshot_id!==b.a.snapshot_ref.policy_snapshot_id)throw Error('OWNER_MISMATCH');
  if((await this.core.chrome.declarativeNetRequest.getSessionRules()).length||(await this.core.chrome.declarativeNetRequest.getDynamicRules()).length)throw Error('RELEASE_UNCONFIRMED');
  const local=await this.read('member:local-end:'+scope.session_id),rows=await this.db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result.filter(r=>r.key?.startsWith('member:outbox:')&&!r.acked));});
  if(!local?.confirmed)throw Error('RELEASE_UNCONFIRMED');
  for(const row of rows){
   const sid=row.kind==='LOCAL_END'?row.body?.journal_summary?.session_id:row.body?.session_id;
   if(sid!==scope.session_id||row.executor_id!==i.executor_id||row.owner_key!==i.owner_key||row.authority!==i.authority)throw Error('OUTBOX_SCOPE_UNCONFIRMED');
   if(row.kind==='REPORT'){
    if(row.body.desired_revision!==scope.base_revision||!Number.isFinite(Date.parse(row.body.observed_at))||Date.parse(row.body.observed_at)>Date.parse(scope.not_before))throw Error('OUTBOX_SCOPE_UNCONFIRMED');
    validateReport(row.body);
   }else if(row.kind!=='LOCAL_END'||row.body.local_actions?.length!==1||row.body.local_actions[0].action_id!==local.action_id)throw Error('OUTBOX_SCOPE_UNCONFIRMED');
  }
  const ending=rows.filter(r=>r.kind==='LOCAL_END');
  if(ending.length>1)throw Error('RECONCILE_UNCONFIRMED');
  // Existing immutable local END is sent first. Historical APPLIED/UNCONFIRMED
  // reports cannot be delivered until Server has confirmed terminal release.
  for(const row of ending){
   const ack=await send('/executors/'+i.executor_id+'/reconcile',row.body);
   if(!equal(await this.identity(),i)||ack.desired_state!=='RELEASED'||!ack.acknowledged_actions?.includes(local.action_id))throw Error('RECONCILE_UNCONFIRMED');
   await this.put(row.key,{...row,acked:true});
  }
  const terminal=async()=>{const s=await send('/sessions/'+scope.session_id);if(s.session_id!==scope.session_id||s.owner_user_id!==scope.owner_user_id||s.executor_id!==scope.executor_id||s.policy_snapshot_id!==scope.policy_snapshot_id||s.desired_revision!==scope.base_revision+1||s.execution_status!=='ENDED'||!s.policy_released_at)throw Error('SERVER_RELEASE_UNCONFIRMED');};
  await terminal();
  for(const row of rows.filter(r=>r.kind!=='LOCAL_END')){
   if(row.kind!=='REPORT'||row.body.desired_revision!==scope.base_revision||!Number.isFinite(Date.parse(row.body.observed_at))||Date.parse(row.body.observed_at)>Date.parse(scope.not_before))throw Error('OUTBOX_SCOPE_UNCONFIRMED');
   validateReport(row.body);const ack=await send('/executors/'+i.executor_id+'/reports',row.body);
   if(!equal(await this.identity(),i)||!['ACCEPTED','DUPLICATE'].includes(ack.result)||!Number.isSafeInteger(ack.desired_revision)||ack.desired_revision!==scope.base_revision+1)throw Error('REPORT_ACK_UNCONFIRMED');
   await this.put(row.key,{...row,acked:true,...(row.nr01?{server_ack:{...ack,running_confirmed:false}}:{})});
  }
  await terminal();await this.verifyRelease();
  if((await this.pendingOutbox(i)).length)throw Error('RECONCILE_UNCONFIRMED');
  const done=await send('/install/preserved-end');
  if(done.session_id!==scope.session_id||done.owner_user_id!==scope.owner_user_id||done.executor_id!==scope.executor_id||done.server_ended!==true||done.lock_released!==true||done.focus_allowed!==false)throw Error('SERVER_RELEASE_UNCONFIRMED');
  await this.authority.released(i,scope.session_id);
  return {local_release_confirmed:true,server_ended_confirmed:true,server_lock_released:true,pending_member_reports:0,focus_allowed:false,hold_preserved:true};
 });}
 async offlineEnd(){
  // Local restoration already has Core END priority. Persist that intent
  // before waiting behind Server I/O; this grants no new APPLY authority.
  const i=await this.identity(),b=await this.core.bundle();if(!b)throw Error('SESSION_NOT_FOUND');
  const admission=b.state.session.member_admission;
  if(b.a.owner_context!==i.owner_key||b.a.executor_id!==i.executor_id||b.state.session.owner_key!==i.owner_key||b.state.session.executor_id!==i.executor_id||admission?.authority!==i.authority||admission?.session_id!==b.a.session_id)throw Error('OWNER_MISMATCH');
  const again=await this.identity();if(!equal(i,again))throw Error('OWNER_MISMATCH');
  await this.core.endIntent(b.a.session_id);
  return this.serial(()=>this.offlineEndInner(b.a.session_id));
 }
 async offlineEndInner(expectedSessionId=null){const i=await this.identity(),b=await this.core.bundle();if(!b)throw Error('SESSION_NOT_FOUND');if(expectedSessionId!==null&&b.a.session_id!==expectedSessionId)throw Error('SCOPE_MISMATCH');const prior=await this.read('member:local-end:'+b.a.session_id);if(prior)return {local_release_confirmed:prior.confirmed,server_ended_confirmed:false};await this.core.end(b.a.session_id);const finished=await this.verifyRelease(),rows=(await this.intervals()).filter(x=>x.session_id===b.a.session_id),at=new Date(this.now()).toISOString();const report={report_id:crypto.randomUUID(),command_id:null,session_id:b.a.session_id,executor_id:i.executor_id,desired_revision:b.state.session.member_admission.server_revision,result:'RELEASED',observed_at:at,intervals:rows.map(({interval_id,kind,start_at,end_at,duration_ms,quality})=>({interval_id,kind,start_at,end_at,duration_ms,quality})),rollback_confirmed:true};validateReport(report,{local:true});const action={action_id:crypto.randomUUID(),local_action_seq:1,type:'END',session_id:b.a.session_id,base_revision:report.desired_revision,original_command_id:b.state.session.member_admission.command_id,policy_snapshot_id:b.a.snapshot_ref.policy_snapshot_id,restoration_digest:await digest(finished.bindings.map(x=>({scope:x.scope,resolution:x.resolution,release_evidence:x.release_evidence}))),report};const body={journal_summary:{session_id:b.a.session_id,known_revision:report.desired_revision,observed_state:'RELEASED'},local_actions:[action]};await this.db.transaction('readwrite',(tx,done)=>{const md=tx.objectStore('metadata');md.put({key:'member:outbox:'+action.action_id,kind:'LOCAL_END',body,acked:false,...i});md.put({key:'member:local-end:'+b.a.session_id,confirmed:true,action_id:action.action_id});done(null);});return {local_release_confirmed:true,server_ended_confirmed:false};}
 async status(){const b=await this.core.bundle();let projection={};if(b?.a.native_transition_contract==='NR01_1'){const command=b.state.session.member_admission.command,bound=await this.nrBound(b,command),last=await this.read('member:last-report:'+command.command_id+':APPLIED'),ack=last?.report?await this.read('member:outbox:'+last.report.report_id):null,confirmed=b.a.session_status==='RUNNING'&&!b.a.nr_first_failure&&ack?.nr01&&ack.acked&&ack.server_ack?.running_confirmed===true&&equal(ack.root_binding,bound);projection={server_confirmed_running:!!confirmed,display_status:b.a.session_status==='RUNNING'&&!confirmed?'NATIVE_VERIFYING':b.a.session_status};}return {...projection,mode:MODE,local_status:b?.a.session_status??'IDLE',session_id:b?.a.session_id??null,feature_event_collection:'NOT_COLLECTED',pause_resume:'UNSUPPORTED'};}
 pause(){throw Error('FEATURE_NOT_IMPLEMENTED');}resume(){throw Error('FEATURE_NOT_IMPLEMENTED');}
}
