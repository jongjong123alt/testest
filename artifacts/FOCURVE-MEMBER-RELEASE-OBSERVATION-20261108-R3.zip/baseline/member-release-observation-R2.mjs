import {same,valid,releaseConfirmed,digest} from '../member-a1/contract.mjs';
const need=(v)=>{if(!v)throw Error('RELEASE_OBSERVATION_UNCONFIRMED');};
const bound=b=>({installation_id:b.a.executor_id,owner_key:b.a.owner_context,
 session_id:b.a.session_id,desired_revision:b.a.desired_revision,
 session_revision:b.a.session_revision,generation:b.a.generation,record_version:b.a.record_version});
const utc=v=>typeof v==='string'&&Number.isFinite(Date.parse(v))?v:null;
const freeze=v=>{if(v&&typeof v==='object'){Object.values(v).forEach(freeze);Object.freeze(v);}return v;};
// Trusted Worker caller only. No runtime message handler, network, DNR mutation,
// lifecycle dispatch, storage write or new authority. Return is evidence, not a grant.
export async function readMemberReleaseObservation(adapter,expected){
 expected=structuredClone(expected);
 need(expected&&Object.keys(expected).length===7&&typeof expected.installation_id==='string'
  &&typeof expected.owner_key==='string'&&typeof expected.session_id==='string'
  &&Number.isSafeInteger(expected.desired_revision)&&Number.isSafeInteger(expected.session_revision)
  &&Number.isSafeInteger(expected.generation)&&typeof expected.record_version==='string');
 const first=await adapter.core.bundle();need(first&&same(bound(first),expected));
 let release='UNKNOWN';
 try{const checked=await adapter.verifyRelease();need(same(checked,first));release='CONFIRMED';}
 catch(e){if(e.message!=='RELEASE_UNCONFIRMED')throw e;}
 const rows=()=>adapter.db.transaction('readonly',(tx,done)=>{
  const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result);
 });
 const before=await rows();
 need(before.some(r=>r.key===first.a.key&&same(r,first.a)));
 need(same(before.filter(r=>r.record_kind==='A1_BINDING'&&r.scope?.session_id===expected.session_id),first.bindings));
 const bindingIds=new Set(first.bindings.map(b=>b.scope.binding_id));
 const relevant=all=>all.filter(r=>r.key===first.a.key||r.key==='current'||r.key==='a1:owner-fence'
  ||r.record_kind==='A1_BINDING'&&r.scope?.session_id===expected.session_id
  ||r.record_kind==='A1_OPERATION'&&bindingIds.has(r.binding_id));
 const pointer=before.find(r=>r.key==='current'),fence=before.find(r=>r.key==='a1:owner-fence');
 need(pointer?.owner_key===expected.owner_key&&pointer.session_id===expected.session_id
  &&fence?.owner_context===expected.owner_key&&fence.epoch===first.ownerFenceEpoch&&!fence.transitioning);
 const acks=[];
 for(const b of first.bindings){
  need(b.scope.owner_context===expected.owner_key&&b.scope.session_id===expected.session_id);
  need(before.some(r=>r.key===b.key&&same(r,b)));
  for(const op of before.filter(r=>r.record_kind==='A1_OPERATION'&&r.binding_id===b.scope.binding_id)){
   const r=op.first_response,c=op.command;
   if(!valid(op,'operation')||op.key!=='a1:operation:'+b.scope.binding_id+':'+op.operation_id
    ||c?.owner_context!==expected.owner_key||c?.payload?.command_revision!==op.command_revision
    ||op.phase!=='COMPLETED'||!op.cleanup_slot||!c||c.payload?.operation!=='RELEASE'
    ||c.payload.operation_id!==op.operation_id||op.scope_epoch!==b.scope.scope_epoch
    ||!same(c.payload.scope,b.scope))continue;
   if(!valid(r,'control_ok')||r.request_id!==c.request_id||r.data.operation!=='RELEASE'
    ||r.data.operation_id!==op.operation_id||r.data.result_state!=='RELEASED'
    ||!same(r.data.scope,b.scope)||!releaseConfirmed(r.data.release_evidence))continue;
   const original=structuredClone(c);delete original.request_id;
   if(await digest(original)!==op.fingerprint)continue;
   // Never project channel credentials, command payload, raw ACK or release evidence.
   acks.push({binding_id:b.scope.binding_id,operation_id:op.operation_id,request_id:r.request_id});
  }
 }
 const last=await adapter.core.bundle(),after=await rows();
 need(last&&same(first,last)&&same(bound(last),expected)&&same(relevant(before),relevant(after)));
 // Last identity validation is read-only. env.owner is the existing trusted
 // installation/owner supplier used by MemberCore.bundle; do not accept caller identity.
 const owner=await adapter.core.env.owner();
 need(owner.owner_key===expected.owner_key&&owner.installation_id===expected.installation_id);
 return freeze({scope:expected,local_status:first.a.session_status,release_verification:release,
  aggregate_cleanup:typeof first.a.cleanup_pending==='boolean'?(first.a.cleanup_pending?'PENDING':'CLEAR'):'UNKNOWN',
  binding_cleanup:first.bindings.some(b=>b.cleanup_pending===true||b.resolution==='NONE')?'PENDING':
   first.bindings.every(b=>b.cleanup_pending===false&&['RELEASE_VERIFIED','GONE_NATIVE'].includes(b.resolution))?'CLEAR':'UNKNOWN',
  release_ack_references:acks,owned_dnr_removal:'UNKNOWN',
  queried_at:new Date(adapter.now()).toISOString(),stored_ended_at:utc(first.state.session.ended_at),
  stored_policy_released_at:utc(first.state.session.policy_released_at)});
}
