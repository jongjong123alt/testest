import test from 'node:test';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createMemberDB} from '../member-a1/db.mjs';
import {A1Store} from '../member-a1/store.mjs';
import {A1Core} from '../member-a1/core.mjs';
import {aggregate,binding,control} from '../member-a1/domain.mjs';
import {ref,VERSION,valid} from '../member-a1/contract.mjs';
import {MemberA1Adapter} from '../integration/member-a1-adapter.mjs';
const require=createRequire(import.meta.url);
const {IDBFactory}=require(process.env.FOCURVE_FAKE_IDB_PATH??'/workspace/focurve-site-controller-dnr/extension/node_modules/fake-indexeddb');
const id=()=>crypto.randomUUID(),at='2026-11-08T00:00:00.000Z';
async function setup({pending=false,withBinding=true}={}){
 const db=createMemberDB(new IDBFactory(),'release-test-'+id());
 const owner={owner_key:'MEMBER:1',installation_id:id()};
 const snapshot={policy_snapshot_id:id(),format_version:'1.1',source_version:1};
 const snapshotRef=await ref(snapshot);
 const s={owner_key:owner.owner_key,session_id:id(),executor_id:owner.installation_id,duration_minutes:25,execution_contract:VERSION,status:'ENDED',snapshot,ended_at:at,policy_released_at:at};
 const a=aggregate(s,snapshotRef,{boot:id(),profile:id()});Object.assign(a,{intent:'END',phase:'ENDED',session_status:'ENDED',end_origin:'USER_END',cleanup_pending:pending});
 const j={owner_key:s.owner_key,session_id:s.session_id,revision:1,action_seq:1,desired:'RELEASED',observed:'RELEASED',rules:[]};
 const b=binding(a,{tabId:1,documentId:'doc',url:'https://www.youtube.com/shorts/test'},{canonical_host:'youtube.com',site_id:'1',version:1,access_policy:'ALLOW'});
 Object.assign(b,{readiness:'READY',ordinary_authority:'REVOKED',apply_closed:true,resolution:pending?'NONE':'RELEASE_VERIFIED',cleanup_pending:pending});
 const evidence={observer_stopped:true,timers_cleared:true,listeners_removed:true,notice_removed:true,owned_changes_restored:true,remaining_owned_changes:0,error_count:0};
 b.release_evidence=evidence;
 const c=control(b,a,'RELEASE',true),op={key:'a1:operation:'+b.scope.binding_id+':'+c.payload.operation_id,record_kind:'A1_OPERATION',schema_version:VERSION,operation_id:c.payload.operation_id,binding_id:b.scope.binding_id,scope_epoch:b.scope.scope_epoch,command_revision:1,command:c,fingerprint:'f'.repeat(64),phase:'COMPLETED',cleanup_slot:true,first_response:{request_id:c.request_id,status:'OK',error:null,data:{protocol_version:VERSION,family:'CONTROL',operation_id:c.payload.operation_id,operation:'RELEASE',scope:b.scope,result_state:'RELEASED',effect_evidence:null,coverage_evidence:null,release_evidence:evidence,observed_at:at}}};
 assert(valid(a,'aggregate'));assert(valid(b,'binding'));assert(valid(op.first_response,'control_ok'));
 const fence={key:'a1:owner-fence',epoch:id(),owner_context:s.owner_key,transitioning:false};
 await db.transaction('readwrite',(tx,done)=>{for(const r of [{key:'current',owner_key:s.owner_key,session_id:s.session_id,execution_contract:VERSION},a,fence,...(withBinding?[b,op]:[])])tx.objectStore('metadata').put(r);tx.objectStore('sessions').put(s);tx.objectStore('journal').put(j);done(null);});
 const store=new A1Store(db),core=Object.create(A1Core.prototype);Object.assign(core,{store,env:{owner:async()=>structuredClone(owner)}});
 const adapter=new MemberA1Adapter({db,core,now:()=>Date.parse(at)+1000});
 for(const name of ['tick','end','finish','flush','request','put']){adapter[name]=()=>assert.fail(name);core[name]=()=>assert.fail(name);}
 const expected={installation_id:owner.installation_id,owner_key:s.owner_key,session_id:s.session_id,desired_revision:a.desired_revision,session_revision:a.session_revision,generation:a.generation,record_version:a.record_version};
 const dump=()=>db.transaction('readonly',(tx,done)=>{const out={};let pending=6;for(const name of ['metadata','sessions','journal','events','intervals','outbox']){const q=tx.objectStore(name).getAll();q.onsuccess=()=>{out[name]=q.result;if(!--pending)done(out);};}});
 return {db,adapter,core,expected,a,b,dump};
}
test('real A1Core.bundle + A1Store + member DB: ACK projection leaves all six stores byte-equivalent',async()=>{const x=await setup(),before=await x.dump();const transaction=x.db.transaction;let reads=0;const observed={transaction(mode,fn){assert.equal(mode,'readonly');reads++;return transaction(mode,fn);}};x.adapter.db=observed;x.core.store.db=observed;const out=await x.adapter.readReleaseObservation(x.expected);assert.equal(out.release_verification,'CONFIRMED');assert.equal(out.release_ack_references.length,1);assert.equal(out.owned_dnr_removal,'UNKNOWN');assert.deepEqual(await x.dump(),before);assert(reads>0);});
test('real stored unresolved binding and aggregate obligations preserved',async()=>{const x=await setup({pending:true}),before=await x.dump(),out=await x.adapter.readReleaseObservation(x.expected);assert.equal(out.release_verification,'UNKNOWN');assert.equal(out.binding_cleanup,'PENDING');assert.equal(out.aggregate_cleanup,'PENDING');assert.deepEqual(await x.dump(),before);});
test('plan/binding zero does not invent ACK or DNR proof',async()=>{const x=await setup({withBinding:false}),out=await x.adapter.readReleaseObservation(x.expected);assert.deepEqual(out.release_ack_references,[]);assert.equal(out.owned_dnr_removal,'UNKNOWN');});
test('real transaction commit changing generation during read rejects without repair',async()=>{const x=await setup(),original=x.core.bundle.bind(x.core);let n=0;x.core.bundle=async()=>{if(++n===3)await x.db.transaction('readwrite',(tx,done)=>{tx.objectStore('metadata').put({...x.a,generation:x.a.generation+1});done(null);});return original();};await assert.rejects(x.adapter.readReleaseObservation(x.expected));const after=await x.dump();assert.equal(after.metadata.find(r=>r.key===x.a.key).generation,x.a.generation+1);});
