Core endpoint strict status local handoff — 2026-11-06
Baseline commit: ed8755a597973922d02bd675e80b00c410dfdaf4 + uncommitted supplier ZIP in inputs (SHA d5b70426b2ad72ff907ee1981cac820744c76d1f4e8d9c1fed946c009c8b37b4).
Apply source/test delta to the existing supplier, not directly to baseline alone. before/ stores exact pre-change files. after/ docs are cumulative working records, not clean baseline replacements.
Owner: Core Jongmin; no Server/Content file edits. No commit/push/PR.
Signature: client.request(path,credential,body,headers={}, {expectedStatus,expectedContentType}={}). Existing four-argument callers unchanged.
Inject readP1PreparationSourceHttp as readAuthenticatedSource only in authorized private composition. Helper is not installed in a Worker or startup. Query and SourceRead remain unchanged. It sets expectedStatus=200 and expectedContentType=application/json. Existing source adapter validates fields/types/hash/owner/lifetime; null rejects U1.
Server responsibility: strict request parsing, authenticated foreign/missing reference privacy, authenticated owner/journal/current checks, route and response implementation. These are not supplied by this Core helper. Wire shape alone is not authenticated provenance.
Commands (cwd extension; Node v24.19.0):
node --test tests/ig04-p1-endpoint-status.test.mjs => 15 PASS
node --test --test-name-pattern='actual Core adapter maps|authenticated source absence|additional wire key|missing authenticated supplier|401|request lifetime|withdrawal' tests/ig04-p1-server-source.test.mjs => 5 PASS
node --test --test-name-pattern='endpoint composition:' tests/ig04-p1-server-source.test.mjs => 3 PASS
23 non-overlapping selected tests PASS, FAIL=0, SKIP=0. Synthetic fetch/credentials/Native; real Core/client/adapter local code and fake-indexeddb 6.2.5. No actual HTTP/DB/server process. Runtime dependencies from existing local extension installation; package lock supplied in prior ZIP. Historical execution-time dependency identity remains unverified.
Existing Core-U4 8+2 evidence reused, not rerun. U4 input/three args/sync boolean unchanged.
201/202/204 reject before JSON parsing; 401 status retained; other endpoints default successful statuses unchanged. JSON content type, exact 8 keys/null validated. Currentness failures still use existing Core handling and preserve committed records.
C2/C5, actual DB/HTTP execution, Worker bridge, operating authority/effects HOLD; MVP_FINAL_COMPLETE=false.
