import {canonical} from '../a1/contract.mjs';
import {IG04ProviderStore} from './ig04-provider-store.js';

const need = (v, m) => { if (!v) throw Error(m); };
const uuid = v => typeof v === 'string' && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(v);
const positive = v => Number.isSafeInteger(v) && v > 0;
const hash = v => typeof v === 'string' && /^[a-f0-9]{64}$/.test(v);
const same = (a,b) => canonical(a) === canonical(b);
const copy = v => { const r=structuredClone(v); const freeze=x=>{if(x&&typeof x==='object'){Object.values(x).forEach(freeze);Object.freeze(x);}return x;};return freeze(r); };
const exact = (v,keys) => v && typeof v === 'object' && !Array.isArray(v)
  && Object.keys(v).length === keys.length && keys.every(k=>Object.hasOwn(v,k));
const ref = v => exact(v,['id','version']) && uuid(v.id) && positive(v.version);
const sourceReadKeys = ['sourceRef','sourceVersion','raw','rawSha256','expiresAt','bindingId','ownerEpoch','executorId'];
// Explicitly injected, inactive-by-default transport seam. It authenticates no
// caller by itself; the existing adapter still verifies protected read context.
export async function readP1PreparationSourceHttp(client, credential, query) {
  const raw = await client.request('/amvp/preparation-sources/read', credential,
    canonical(query), {}, { expectedStatus: 200, expectedContentType: 'application/json' });
  need(raw === null || exact(raw, sourceReadKeys), 'P1_SERVER_SOURCE_SHAPE');
  return raw;
}

export async function p1Utf8Sha256(bytes) {
  need(typeof bytes==='string','P1_SOURCE_BYTES_REQUIRED');
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(bytes)))].map(v=>v.toString(16).padStart(2,'0')).join('');
}
const strict = value => {if(value&&typeof value.then==='function')Promise.resolve(value).catch(()=>{});return value===true;};

/** Private mapping of AmvpP1ServerConnection.SourceRead at Server commit
 * 66c28ebd21086d31c657e979ee74f8bdd5308666. No route, credentials provider,
 * registry approval or execution authority is installed. readAuthenticatedSource
 * must be supplied by the approved authenticated transport; absent => reject.
 * The Server readAttemptSource path resolves ByReference's CREATION digest from
 * its own protected journal. The Core read-attempt digest is NOT that digest.
 */
export class IG04P1ServerSourceAdapter {
  #store; #capture; #current; #record; #read; #now; #attempts=new WeakMap(); #denied=new Set();
  constructor({providerStore,capture,isCurrent,attemptRecord,readAuthenticatedSource,now=Date.now}={}) {
    need(providerStore instanceof IG04ProviderStore,'P1_PROTECTED_STORE_REQUIRED');
    this.#store=providerStore;this.#capture=capture??(()=>null);this.#current=isCurrent??(()=>false);
    this.#record=attemptRecord??(()=>null);this.#read=readAuthenticatedSource;this.#now=now;
  }
  #key(context){return canonical([context.authorityId,context.token,context.binding]);}
  #check(trusted,context,attempt){
    need(context&&!this.#denied.has(this.#key(context))&&this.#now()<context.deadline
      &&same(this.#capture(trusted),context)&&strict(this.#current(trusted,context,attempt)), 'P1_SOURCE_CONTEXT_UNCONFIRMED');
  }
  // Read authentication is a guarded original lookup, not checkedExact() or
  // possession of a caller digest. Success installs a private lifetime binding;
  // it grants no creation history, execution rights or persistent permission.
  async authenticate(action,trusted,exactAttempt) {
    need(action==='read','P1_AUTHENTICATION_ACTION_UNSUPPORTED');
    const context=copy(this.#capture(trusted)),location=copy(this.#record(trusted)),attempt=copy(exactAttempt);
    this.#check(trusted,context,attempt);
    need(location&&typeof location.localId==='string'&&positive(location.version),'P1_PROTECTED_ATTEMPT_REQUIRED');
    try {
    const {record}=await this.#store.lookup(context.authorityId,context.token,location.localId);
    this.#check(trusted,context,attempt);
    need(record.version===location.version&&record.closedBy===null&&same(record.original,attempt),'P1_PROTECTED_ATTEMPT_MISMATCH');
    need(uuid(attempt.requestId)&&ref(attempt.sourceRef)&&same(attempt.original?.sourceRef,attempt.sourceRef)
      &&exact(attempt.original,['sourceRef'])&&attempt.sourceVersion===attempt.sourceRef.version
      &&attempt.bytes===canonical(attempt.original)&&hash(attempt.digest),'P1_ATTEMPT_SOURCE_MISMATCH');
    need(await p1Utf8Sha256(attempt.bytes)===attempt.digest,'P1_ATTEMPT_DIGEST_MISMATCH');
    this.#check(trusted,context,attempt);
    let entries=this.#attempts.get(trusted);if(!entries){entries=new Map();this.#attempts.set(trusted,entries);}
    const prior=entries.get(attempt.requestId);
    if(prior&&same(prior.context,context))need(same(prior.attempt,attempt),'P1_PROTECTED_ATTEMPT_CONFLICT');
    entries.set(attempt.requestId,{attempt,context,location,original:record.original,lastRead:null});
    } catch(error) {
      // A known failure of the protected authentication boundary cannot leave
      // a previous observation under that captured lifetime consumable.
      this.#denied.add(this.#key(context));
      throw error;
    }
  }
  async openAttempt(trusted,exactAttempt) {
    await this.authenticate('read',trusted,exactAttempt);
  }
  #entry(trusted,attempt){
    const entry=this.#attempts.get(trusted)?.get(attempt?.requestId);
    need(entry&&same(entry.attempt,attempt),'P1_PROTECTED_ATTEMPT_REQUIRED');
    this.#check(trusted,entry.context,entry.attempt);return entry;
  }
  async #map(raw,entry,binding){
    const sourceRef=entry.attempt.sourceRef;
    need(exact(raw,sourceReadKeys)&&raw.sourceRef===sourceRef.id&&raw.sourceVersion===sourceRef.version
      &&typeof raw.raw==='string'&&hash(raw.rawSha256)&&raw.bindingId===binding.binding_id
      &&raw.ownerEpoch===binding.epoch&&raw.executorId===binding.executor_id
      &&Number.isSafeInteger(raw.expiresAt)&&this.#now()<raw.expiresAt,'P1_SERVER_SOURCE_MISMATCH');
    need(await p1Utf8Sha256(raw.raw)===raw.rawSha256,'P1_PREPARATION_HASH_MISMATCH');
    const original=JSON.parse(raw.raw);
    need(raw.raw===canonical(original)&&exact(original,['reference','executor','user','requestId','requestDigest','binding','snapshot','policyId','createdAt','expiresAt'])
      &&original.reference===sourceRef.id&&original.executor===binding.executor_id
      &&typeof original.user==='string'&&/^\d+$/.test(original.user)&&binding.owner_key==='MEMBER:'+original.user
      &&uuid(original.requestId)&&hash(original.requestDigest)
      &&exact(original.binding,['bindingId','epoch'])&&original.binding.bindingId===binding.binding_id&&original.binding.epoch===binding.epoch
      &&exact(original.snapshot,['format','bytes','settingsVersion'])&&typeof original.snapshot.format==='string'
      &&typeof original.snapshot.bytes==='string'&&positive(original.snapshot.settingsVersion)
      &&typeof original.policyId==='string'&&original.policyId.length>0
      &&Date.parse(original.expiresAt)===raw.expiresAt&&Number.isFinite(Date.parse(original.createdAt))
      &&Date.parse(original.createdAt)<raw.expiresAt,'P1_PREPARATION_ORIGINAL_MISMATCH');
    // Hash is over the ENTIRE canonical PreparationOriginal. settingsVersion is
    // preserved only inside bytes; neither source version nor Core CAS version.
    return copy({sourceRef,version:sourceRef.version,bytes:raw.raw,rawSha256:raw.rawSha256,
      expiresAt:raw.expiresAt,binding});
  }
  forContext(trusted){
    return Object.freeze({
      authenticate:(action,t,attempt)=>{
        need(t===trusted,'P1_SOURCE_CONTEXT_UNCONFIRMED');
        return this.authenticate(action,t,attempt);
      },
      verifyAttempt:(t,attempt)=>{try{return t===trusted&&!!this.#entry(t,attempt);}catch{return false;}},
      sourceReader:async(client,credential,sourceRef,attempt,binding)=>{
        const entry=this.#entry(trusted,attempt);const expected=copy(binding),reference=copy(sourceRef);
        need(ref(reference)&&same(reference,entry.attempt.sourceRef)&&same(expected,entry.context.binding)
          &&credential.owner_key===expected.owner_key&&credential.executor_id===expected.executor_id,'P1_SOURCE_SCOPE_MISMATCH');
        need(typeof this.#read==='function','P1_AUTHENTICATED_SERVER_SOURCE_UNAVAILABLE');
        try{
          // Recheck protected attempt/version before the authenticated query.
          const {record}=await this.#store.lookup(entry.context.authorityId,entry.context.token,entry.location.localId);
          this.#check(trusted,entry.context,entry.attempt);
          need(record.version===entry.location.version&&record.closedBy===null&&same(record.original,entry.original),'P1_PROTECTED_ATTEMPT_MISMATCH');
          const query=copy({executor:expected.executor_id,readAttempt:{requestId:entry.attempt.requestId,original:entry.attempt.bytes},
            reference:reference.id,expectedSourceVersion:reference.version});
          const raw=await this.#read(client,credential,query);
          this.#check(trusted,entry.context,entry.attempt);
          need(raw!==null&&raw!==undefined,'P1_SERVER_SOURCE_ABSENT');
          const normalized=await this.#map(copy(raw),entry,expected);this.#check(trusted,entry.context,entry.attempt);
          entry.lastRead=normalized;return normalized;
        }catch(error){
          entry.lastRead=null;
          // Known rejection/UNKNOWN cannot leave old consumption evidence live.
          // Bind to the captured lifetime, never retire a replacement owner.
          if(error?.status!==401)this.#denied.add(this.#key(entry.context));
          throw error;
        }
      },
      verifySource:async(t,source,attempt)=>{
        try{
          if(t!==trusted)return false;
          const entry=this.#entry(t,attempt);
          // Provenance is the private result of the authenticated supplier, not
          // a fourth/fifth caller assertion. It includes creation requestId/digest
          // only as recovered by the Server's protected creation-journal lookup.
          if(!entry.lastRead||!same(source,entry.lastRead)
            ||!same(source.binding,entry.context.binding))return false;
          if(await p1Utf8Sha256(source.bytes)!==source.rawSha256)return false;
          this.#check(t,entry.context,entry.attempt);return true;
        }catch{return false;}
      }
    });
  }
}
