import test from 'node:test';
import assert from 'node:assert/strict';
import {MemberExecutionClient} from '../src/member-execution-client.js';
import {readP1PreparationSourceHttp} from '../src/ig04-p1-server-source.js';
const uuid='00000000-0000-4000-8000-000000000001';
const credential={owner_key:'MEMBER:1',executor_id:uuid,access_token:'synthetic-test-token'};
const query={executor:uuid,readAttempt:{requestId:uuid,original:'{"sourceRef":{"id":"'+uuid+'","version":1}}'},reference:uuid,expectedSourceVersion:1};
// Wire-only synthetic fetch. No real HTTP, credentials provider or Native.
const raw={sourceRef:uuid,sourceVersion:1,raw:'synthetic',rawSha256:'0'.repeat(64),expiresAt:1,bindingId:uuid,ownerEpoch:1,executorId:uuid};
function fixture(status,body=raw,type='application/json'){
 const state={parsed:0,calls:[]};
 const client=new MemberExecutionClient({baseUrl:'https://example.test/api/v1',store:{},getCredentials:async()=>credential,
  fetch:async(url,init)=>{state.calls.push({url,init});return {status,ok:status>=200&&status<300,headers:new Headers({'Content-Type':type}),json:async()=>{state.parsed++;return body;}};}});
 return {state,client,read:()=>readP1PreparationSourceHttp(client,credential,query)};
}
test('endpoint accepts exact 200 JSON object and preserves authenticated request controls',async()=>{
 const f=fixture(200);assert.deepEqual(await f.read(),raw);
 const {url,init}=f.state.calls[0];assert.equal(url,'https://example.test/api/v1/amvp/preparation-sources/read');
 assert.equal(init.method,'POST');assert.deepEqual(JSON.parse(init.body),query);
 assert.equal(init.headers.Authorization,'Bearer '+credential.access_token);
 assert.equal(init.credentials,'omit');assert.equal(init.redirect,'error');assert.equal(init.cache,'no-store');assert.ok(init.signal instanceof AbortSignal);
});
test('endpoint permits only exact 200 JSON null as wire absence',async()=>{
 const f=fixture(200,null,'application/json; charset=UTF-8');assert.equal(await f.read(),null);
});
for(const status of [201,202,204])test('endpoint rejects '+status+' before parsing even a valid SourceRead body',async()=>{
 const f=fixture(status);await assert.rejects(f.read(),e=>e.status===status&&/UNEXPECTED_STATUS/.test(e.message));assert.equal(f.state.parsed,0);
});
for(const status of [401,403,404,409,503])test('endpoint preserves HTTP '+status+' rejection, never converts to null',async()=>{
 const f=fixture(status,null);await assert.rejects(f.read(),e=>e.status===status&&e.message==='EXECUTION_HTTP_'+status);assert.equal(f.state.parsed,0);
});
test('endpoint rejects incorrect content type before parsing',async()=>{
 const f=fixture(200,raw,'text/html');await assert.rejects(f.read(),/UNEXPECTED_CONTENT_TYPE/);assert.equal(f.state.parsed,0);
});
test('endpoint rejects extra and missing fields, arrays and undefined',async()=>{
 const missing={...raw};delete missing.rawSha256;
 for(const value of [{...raw,access_token:'forbidden'},missing,[],undefined]){
  const f=fixture(200);f.client.fetch=async()=>({status:200,ok:true,headers:new Headers({'Content-Type':'application/json'}),json:async()=>value});
  await assert.rejects(f.read(),/SERVER_SOURCE_SHAPE/);
 }
});
test('other endpoints retain default successful-status handling',async()=>{
 const f=fixture(201,{created:true},'text/plain');assert.deepEqual(await f.client.request('/other',credential,'{}'),{created:true});
});
test('network errors and malformed JSON are propagated, never null',async()=>{
 const f=fixture(200),failure=new Error('synthetic-network');f.client.fetch=async()=>{throw failure;};await assert.rejects(f.read(),e=>e===failure);
 f.client.fetch=async()=>({status:200,ok:true,headers:new Headers({'Content-Type':'application/json'}),json:async()=>{throw new SyntaxError('synthetic-json');}});
 await assert.rejects(f.read(),SyntaxError);
});
test('endpoint retains existing timeout abort path',async()=>{
 const f=fixture(200);f.client.timeoutMs=5;
 f.client.fetch=async(_url,{signal})=>new Promise((_resolve,reject)=>signal.addEventListener('abort',()=>reject(signal.reason),{once:true}));
 await assert.rejects(f.read(),e=>e.name==='AbortError');
});
