import assert from 'node:assert/strict';
import test from 'node:test';
import { runInNewContext } from 'node:vm';
import { createP1ConsumptionGuard } from '../content/ig04-p1-consumption-guard.mjs';

const registration = Object.freeze({ version: 4 });
const expectation = Object.freeze({ revision: 2 });
const trusted = Object.freeze({});

test('denies rejected Promises synchronously without an unhandled rejection', async () => {
  const rejected = [
    Promise.reject(new Error('verifier rejected')),
    runInNewContext("Promise.reject(new Error('foreign verifier rejected'))"),
  ];
  for (const verdict of rejected) {
    assert.equal(createP1ConsumptionGuard(() => verdict)(trusted, expectation, registration), false);
  }
  let thenRead = false;
  const thenable = { get then() { thenRead = true; } };
  assert.equal(createP1ConsumptionGuard(() => thenable)(trusted, expectation, registration), false);
  assert.equal(thenRead, false);
  await new Promise(resolve => setImmediate(resolve));
});

test('accepts only a strict synchronous verifier result for the original three arguments', () => {
  const consume = createP1ConsumptionGuard((...args) => {
    assert.equal(args.length, 3);
    assert.equal(args[0], trusted);
    assert.equal(args[1], expectation);
    assert.equal(args[2], registration);
    return true;
  });
  assert.equal(consume(trusted, expectation, registration), true);
  for (const verdict of [false, 1, { current: true }, Promise.resolve(true)]) {
    assert.equal(createP1ConsumptionGuard(() => verdict)(trusted, expectation, registration), false);
  }
});

test('checks the current request at consumption after an asynchronous result', async () => {
  let currentExpectation = expectation;
  const consume = createP1ConsumptionGuard((context, expected, stored) =>
    context === trusted && expected === currentExpectation && stored === registration);
  const pending = Promise.resolve(registration);
  currentExpectation = Object.freeze({ revision: 3 });
  const stored = await pending;
  assert.equal(consume(trusted, expectation, stored), false);
  assert.equal(consume({ current: true }, currentExpectation, stored), false);
  assert.equal(consume(trusted, currentExpectation, { ...stored }), false);
  assert.equal(consume(trusted, currentExpectation, stored), true);
});

test('denies missing evidence, verifier failure and reentrant receipt', () => {
  assert.equal(createP1ConsumptionGuard()(trusted, expectation, registration), false);
  let calls = 0;
  const consume = createP1ConsumptionGuard(() => {
    calls++;
    assert.equal(consume(trusted, expectation, registration), false);
    if (calls === 1) throw new Error('observation unavailable');
    return true;
  });
  assert.equal(consume(trusted, expectation, null), false);
  assert.equal(calls, 0);
  assert.equal(consume(trusted, expectation, registration), false);
  assert.equal(consume(trusted, expectation, registration), true);
});
