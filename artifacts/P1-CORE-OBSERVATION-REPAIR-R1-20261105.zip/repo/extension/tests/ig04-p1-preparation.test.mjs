import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory} from 'fake-indexeddb';
import {createMemberDB} from '../member-a1/db.mjs';
import {A1Store} from '../member-a1/store.mjs';
import {digest, canonical} from '../a1/contract.mjs';
import {IG04ProviderStore} from '../src/ig04-provider-store.js';
import {MemberExecutionClient} from '../src/member-execution-client.js';
import {IG04P1Preparation} from '../src/ig04-p1-preparation.js';
const clone = structuredClone;
const defer = () => { let resolve, reject; const promise = new Promise((a,b) => {resolve=a;reject=b;});return {promise,resolve,reject}; };
async function fixture() {
  const db=createMemberDB(new IDBFactory(),'p1-'+crypto.randomUUID()),store=new A1Store(db);
  await store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'uuid-fence',owner_context:'MEMBER:1',transitioning:false});done(null);});
  const provider=new IG04ProviderStore(store,{guard:()=>true});
  const token=await provider.initialize('authority',{document:'native-doc'});
  const trusted=Object.freeze({}),state={now:100,mono:0,active:true,reads:0,expires:0};
  const binding={owner_key:'MEMBER:1',executor_id:'00000000-0000-4000-8000-000000000001',binding_id:'00000000-0000-4000-8000-000000000002',epoch:5};
  const attempt={requestId:'original-request',sourceRef:'prepared-source',sourceVersion:2,bytes:'original-request-bytes',digest:'existing-request-digest'};
  const a1={operation:'A1 original command'},rc2={feature:'IG-04',semantic:'different original'};
  const source={sourceRef:attempt.sourceRef,version:2,bytes:'authenticated prepared bytes',binding,expiresAt:900,
    hashes:{a1:{original:a1,fingerprint:await digest(a1)},rc2:{original:rc2,semantic_sha256:await digest(rc2)}}};
  const local=await provider.register('authority',token,'source-local',source);
  const context={authorityId:'authority',token,requestLifetime:'request-life',revision:1,sourceVersion:local.version,
    sourceLocalId:'source-local',nativeScope:{document:'native-doc',generation:3,attempt:'attempt-1',channel:'worker-channel'},binding,deadline:800};
  const credential={owner_key:binding.owner_key,executor_id:binding.executor_id,access_token:'NEVER_PERSIST_TOKEN'};
  const options={store,client:{credentials:async()=>clone(credential),request:async()=>{throw Error('UNEXPECTED_HTTP');}},
    capture:t=>t===trusted?clone(context):null,
    isCurrent:(t,c)=>t===trusted&&state.active&&canonical(c)===canonical(context),
    verifyAttempt:(_t,a)=>a.bytes===attempt.bytes&&a.digest===attempt.digest,
    sourceReader:async()=>{state.reads++;return clone(source);},
    verifySource:(_t,s)=>canonical(s)===canonical(source),
    verifyNative:(_t,n)=>canonical(n)===canonical(context.nativeScope),now:()=>state.now,monotonic:()=>state.mono};
  const api=new IG04P1Preparation(options);
  const read=()=>api.readP1Source(trusted,attempt,binding,attempt.sourceRef);
  const verify=async()=>api.verifyP1Preparation(trusted,attempt,await read(),context.nativeScope,attempt);
  const register=async()=>api.registerP1Preparation(trusted,attempt,await verify(),0);
  const rows=()=>store.db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result);});
  return {db,store,provider,token,trusted,state,binding,attempt,source,context,credential,options,api,read,verify,register,rows};
}
test('U1 uses the real existing auth client without starting loop, GET-only and token-private',async()=>{
  const f=await fixture(),calls=[];
  const client=new MemberExecutionClient({baseUrl:'https://example.test/api/v1',getCredentials:async()=>f.credential,
    fetch:async(url,options)=>{calls.push({url,options});return {ok:true,json:async()=>clone(f.source)};}});
  // Injected synthetic route belongs to this test, not a production API contract.
  const api=new IG04P1Preparation({...f.options,client,sourceReader:(c,credential)=>c.request('/test-only-source',credential)});
  const value=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  assert.equal(calls.length,1);assert.equal(calls[0].options.method,'GET');assert.equal(calls[0].options.redirect,'error');
  assert.equal(calls[0].options.headers.Authorization,'Bearer '+f.credential.access_token);
  assert.equal(JSON.stringify(value).includes(f.credential.access_token),false);
});
test('normal verify/register/requery/replay is immutable, non-executable and separate from obligations',async()=>{
  const f=await fixture(),before=await f.rows(),h=await f.verify();
  const stored=await f.api.registerP1Preparation(f.trusted,f.attempt,h,0);
  assert.equal(stored.kind,'P1_NON_EXECUTABLE_PREPARATION');assert.equal(stored.version,1);
  assert.equal(f.api.hasCurrentP1Observation(f.trusted,f.attempt,stored),true);
  assert.equal(f.api.hasCurrentP1Observation(f.trusted,f.attempt,clone(stored)),false);
  assert.deepEqual(await f.api.registerP1Preparation(f.trusted,f.attempt,h,0),stored);
  assert.deepEqual(await f.api.queryP1Preparation(f.trusted,f.attempt),stored);
  const after=await f.rows();assert.equal(after.length,before.length+1);
  for(const row of before)assert.deepEqual(after.find(x=>x.key===row.key),row);
  assert.equal(JSON.stringify(after).includes(f.credential.access_token),false);
  assert.equal(after.some(r=>/closure|reservation|receipt|A1_OPERATION/.test(r.key)),false);
});
test('only authenticated registration absence is null; unavailable remote source rejects',async()=>{
  const f=await fixture();assert.equal(await f.api.queryP1Preparation(f.trusted,f.attempt),null);
  const bad=new IG04P1Preparation({...f.options,sourceReader:async()=>null});
  await assert.rejects(bad.queryP1Preparation(f.trusted,f.attempt),/SOURCE_MISMATCH/);
});
test('default/async current/attempt guards and unavailable source/native providers deny',async()=>{
  const f=await fixture();
  for(const override of [{capture:undefined},{isCurrent:async()=>true},{verifyAttempt:async()=>true},{sourceReader:undefined},{verifySource:undefined}]){
    const api=new IG04P1Preparation({...f.options,...override});
    await assert.rejects(api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef));
  }
  const api=new IG04P1Preparation({...f.options,verifyNative:undefined});
  const read=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  await assert.rejects(api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt),/NATIVE_UNCONFIRMED/);
});
test('read and verified handles cannot be cloned or fabricated or used across service instances',async()=>{
  const f=await fixture(),read=await f.read(),h=await f.verify();
  for(const candidate of [clone(read),{}])await assert.rejects(f.api.verifyP1Preparation(f.trusted,f.attempt,candidate,f.context.nativeScope,f.attempt),/HANDLE_REQUIRED/);
  for(const candidate of [clone(h),{},h]){
    const api=candidate===h?new IG04P1Preparation(f.options):f.api;
    await assert.rejects(api.registerP1Preparation(f.trusted,f.attempt,candidate,0),/HANDLE_REQUIRED/);
  }
});
test('binding absence, wrong owner/epoch/source version and native scope are rejected',async()=>{
  const f=await fixture();
  for(const binding of [null,{...f.binding,epoch:6},{...f.binding,owner_key:'MEMBER:2'}])await assert.rejects(f.api.readP1Source(f.trusted,f.attempt,binding,f.attempt.sourceRef));
  f.context.binding.binding_id=null;await assert.rejects(f.read(),/BINDING_REQUIRED/);
});
for(const field of ['document','generation','attempt','channel'])test('native '+field+' substitution rejects',async()=>{
  const f=await fixture(),read=await f.read();
  await assert.rejects(f.api.verifyP1Preparation(f.trusted,f.attempt,read,{...f.context.nativeScope,[field]:'wrong'},f.attempt),/NATIVE_SCOPE/);
});
for(const kind of ['a1','rc2'])test(kind+' existing hash is checked against its own original',async()=>{
  const f=await fixture();
  const key=kind==='a1'?'fingerprint':'semantic_sha256';f.source.hashes[kind][key]='0'.repeat(64);
  const read=await f.read();await assert.rejects(f.api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt),/HASH_MISMATCH/);
});
test('source without command/hash does not fabricate either',async()=>{
  const f=await fixture();delete f.source.hashes;
  const api=new IG04P1Preparation(f.options),r=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  assert.equal(Object.hasOwn(r,'hashes'),false);
  await api.verifyP1Preparation(f.trusted,f.attempt,r,f.context.nativeScope,f.attempt);
});
test('post-await native revocation and expiry reject without returning a handle',async()=>{
  for(const retire of [f=>{f.state.active=false;},f=>{f.state.now=901;},f=>{f.context.revision++;}]){
    const f=await fixture(),wait=defer(),api=new IG04P1Preparation({...f.options,verifyNative:()=>wait.promise});
    const read=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
    const pending=api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt);
    await new Promise(r=>setImmediate(r));retire(f);wait.resolve(true);await assert.rejects(pending,/CURRENTNESS/);
  }
});
test('absolute lifetime also expires on monotonic time when wall clock rolls back',async()=>{
  const f=await fixture(),h=await f.verify();f.state.now=0;f.state.mono=701;
  await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,0),/CURRENTNESS/);
});
for(const status of [401,503])test('current HTTP '+status+' preserves exact rejection cause and does not retry',async()=>{
  const f=await fixture(),error=Object.assign(Error('original'),{status}),calls=[];
  const api=new IG04P1Preparation({...f.options,sourceReader:async()=>{calls.push(1);throw error;}});
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),e=>e===error);assert.equal(calls.length,1);
});
test('retired late 401 stays on old promise; new owner context receives no event or reissue',async()=>{
  const f=await fixture(),wait=defer(),error=Object.assign(Error('old401'),{status:401});let calls=0;
  const api=new IG04P1Preparation({...f.options,sourceReader:()=>{calls++;return wait.promise;}});
  const pending=api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);await new Promise(r=>setImmediate(r));
  f.context.requestLifetime='new-request';f.context.revision++;wait.reject(error);
  await assert.rejects(pending,e=>e===error);assert.equal(calls,1);assert.equal(f.state.active,true);
});
test('owner/token change during source query rejects instead of reissuing',async()=>{
  const f=await fixture(),api=new IG04P1Preparation({...f.options,sourceReader:async()=>{f.credential.access_token='NEW';return f.source;}});
  await assert.rejects(api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef),/CREDENTIAL_SCOPE_CHANGED/);
});
test('source extras do not cross SourceRead boundary',async()=>{
  const f=await fixture(),api=new IG04P1Preparation({...f.options,sourceReader:async()=>({...f.source,access_token:f.credential.access_token})});
  const r=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);assert.equal('access_token' in r,false);
});
test('changed protected source version between verify and transaction rejects',async()=>{
  const f=await fixture(),h=await f.verify();
  await f.store.atomic((tx,done)=>{const md=tx.objectStore('metadata'),q=md.getAll();q.onsuccess=()=>{const row=q.result.find(r=>r.localId==='source-local');row.version++;md.put(row);done(null);};});
  await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,0),/PROTECTED_SOURCE_CHANGED/);
});
test('authority revision or owner fence changes before CAS reject without writing registration',async()=>{
  for(const ownerFence of [false,true]){
    const f=await fixture(),h=await f.verify();
    if(ownerFence)await f.store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'different',owner_context:'MEMBER:1'});done(null);});
    else await f.provider.transition('authority',f.token,{document:'new'});
    await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,0));
    assert.equal((await f.rows()).some(r=>r.key.startsWith('ig04:p1-preparation:')),false);
  }
});
test('same ID changed original conflicts; different ID cannot overwrite original registration',async()=>{
  const f=await fixture(),first=await f.register();f.attempt.bytes='changed';
  const h=await f.verify();await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,0),/REQUEST_CONFLICT/);
  assert.deepEqual((await f.rows()).find(r=>r.key===first.key),first);
});
test('register version conflict and duplicate concurrent requests do not create multiple rows',async()=>{
  const f=await fixture(),h=await f.verify();
  await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,1),/VERSION_CONFLICT/);
  const [a,b]=await Promise.all([0,0].map(v=>f.api.registerP1Preparation(f.trusted,f.attempt,h,v)));assert.deepEqual(a,b);
});
test('transaction abort is not success; protected source and obligations survive',async()=>{
  const f=await fixture(),h=await f.verify(),before=await f.rows();
  f.store.beforeCommit=()=>{throw Error('disk rollback');};await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,0),/disk rollback/);delete f.store.beforeCommit;
  assert.deepEqual(await f.rows(),before);assert.equal(await f.api.queryP1Preparation(f.trusted,f.attempt),null);
});
test('commit followed by failed current check preserves stored record, denies consumption and recovers on authenticated query',async()=>{
  const f=await fixture(),h=await f.verify();f.store.beforeCommit=()=>{f.state.active=false;};
  await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,0),/CURRENTNESS/);delete f.store.beforeCommit;
  const row=(await f.rows()).find(r=>r.key.startsWith('ig04:p1-preparation:'));assert.ok(row);
  assert.equal(f.api.hasCurrentP1Observation(f.trusted,f.attempt,row),false);
  f.state.active=true;f.context.requestLifetime='recovery';f.context.revision++;
  const restarted=new IG04P1Preparation(f.options),recovered=await restarted.queryP1Preparation(f.trusted,f.attempt);
  assert.deepEqual(recovered,row);assert.equal(restarted.hasCurrentP1Observation(f.trusted,f.attempt,recovered),true);
  f.context.revision++;assert.equal(restarted.hasCurrentP1Observation(f.trusted,f.attempt,recovered),false);
});
test('caller mutation during pending read cannot retarget frozen request/source expectation',async()=>{
  const f=await fixture(),wait=defer(),api=new IG04P1Preparation({...f.options,sourceReader:()=>wait.promise});
  const a=clone(f.attempt),binding=clone(f.binding),pending=api.readP1Source(f.trusted,a,binding,a.sourceRef);
  await new Promise(r=>setImmediate(r));a.sourceRef='other';binding.epoch=999;wait.resolve(f.source);
  const read=await pending;assert.equal(read.sourceRef,'prepared-source');assert.equal(read.binding.epoch,5);
});
test('current 401 retires the exact request lifetime and blocks an older verified handle/observation',async()=>{
  const f=await fixture(),h=await f.verify(),stored=await f.api.registerP1Preparation(f.trusted,f.attempt,h,0);
  f.options.sourceReader=async()=>{throw Object.assign(Error('401'),{status:401});};
  // Same service is used for the entire producer/consumer request lifetime.
  let rejectNow=false;
  const api=new IG04P1Preparation({...f.options,sourceReader:async()=>{if(rejectNow)throw Object.assign(Error('401'),{status:401});return clone(f.source);}});
  const read=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  const verified=await api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt);
  const result=await api.registerP1Preparation(f.trusted,f.attempt,verified,0);rejectNow=true;
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),e=>e.status===401);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,result),false);
  await assert.rejects(api.registerP1Preparation(f.trusted,f.attempt,verified,0),/CURRENTNESS/);
  assert.deepEqual((await f.rows()).find(r=>r.key===stored.key),stored);
});
test('source expiry uses the original observation monotonic deadline across later stages',async()=>{
  const f=await fixture();f.source.expiresAt=200;
  const read=await f.read();f.state.now=0;f.state.mono=101;
  await assert.rejects(f.api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt),/CURRENTNESS/);
});
test('new authenticated request lifetime can query a prior commit but old observations stay retired',async()=>{
  const f=await fixture();let fail=false;
  const api=new IG04P1Preparation({...f.options,sourceReader:async()=>{if(fail)throw Object.assign(Error('401'),{status:401});return clone(f.source);}});
  const r=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  const h=await api.verifyP1Preparation(f.trusted,f.attempt,r,f.context.nativeScope,f.attempt);
  const stored=await api.registerP1Preparation(f.trusted,f.attempt,h,0);fail=true;
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt));
  f.context.requestLifetime='new-auth-life';f.context.revision++;fail=false;
  const recovered=await api.queryP1Preparation(f.trusted,f.attempt);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,stored),false);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,recovered),true);assert.deepEqual(recovered,stored);
});
test('authentication failure in an async verifier also retires the current local request',async()=>{
  const f=await fixture();let reject=false;const error=Object.assign(Error('verifier401'),{status:401});
  const api=new IG04P1Preparation({...f.options,verifySource:async()=>{if(reject)throw error;return true;}});
  const r=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);reject=true;
  await assert.rejects(api.verifyP1Preparation(f.trusted,f.attempt,r,f.context.nativeScope,f.attempt),e=>e===error);
  reject=false;await assert.rejects(api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef),/CURRENTNESS/);
});
test('protected source absence or an existing closure never becomes a registration result',async()=>{
  for(const closed of [false,true]){
    const f=await fixture(),h=await f.verify();
    await f.store.atomic((tx,done)=>{const md=tx.objectStore('metadata'),q=md.getAll();q.onsuccess=()=>{const row=q.result.find(r=>r.localId==='source-local');if(closed){row.closedBy='existing-obligation';md.put(row);}else md.delete(row.key);done(null);};});
    await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,0),/PROTECTED_SOURCE_CHANGED/);
  }
});
test('generation retirement while an authenticated source response is pending denies late success',async()=>{
  const f=await fixture(),wait=defer();let calls=0;
  const api=new IG04P1Preparation({...f.options,sourceReader:()=>{calls++;return wait.promise;}});
  const pending=api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);await new Promise(r=>setImmediate(r));
  f.context.nativeScope.generation++;f.context.revision++;wait.resolve(f.source);
  await assert.rejects(pending,/CURRENTNESS/);assert.equal(calls,1);
});
test('existing auth client abort/network cause is preserved without fallback success',async()=>{
  const f=await fixture(),error=new DOMException('cancelled','AbortError');
  const client=new MemberExecutionClient({baseUrl:'https://example.test/api/v1',getCredentials:async()=>f.credential,fetch:async()=>{throw error;}});
  const api=new IG04P1Preparation({...f.options,client,sourceReader:(c,credential)=>c.request('/test-only-source',credential)});
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),e=>e===error);
});
test('authenticated revocation observation reaches the verifier privately and is not stored as source',async()=>{
  const f=await fixture();let revoked=false,seen;
  const api=new IG04P1Preparation({...f.options,sourceReader:async()=>({...f.source,current:{revoked},transport_token:'PRIVATE_ONLY'}),
    verifySource:(_trusted,source,_attempt,_binding,authenticatedRead)=>{seen=authenticatedRead;return authenticatedRead.current.revoked===false&&canonical(source)===canonical(f.source);}});
  const source=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  assert.equal(seen.transport_token,'PRIVATE_ONLY');assert.equal('current' in source,false);assert.equal('transport_token' in source,false);
  const h=await api.verifyP1Preparation(f.trusted,f.attempt,source,f.context.nativeScope,f.attempt);
  const stored=await api.registerP1Preparation(f.trusted,f.attempt,h,0);
  assert.equal(JSON.stringify(stored).includes('PRIVATE_ONLY'),false);
  revoked=true;await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),/SOURCE_UNCONFIRMED/);
});
test('R1 required: requery without current native verification cannot mint a consumable observation',async()=>{
  const f=await fixture(),stored=await f.register(),before=await f.rows();
  const restarted=new IG04P1Preparation({...f.options,verifyNative:undefined});
  await assert.rejects(restarted.queryP1Preparation(f.trusted,f.attempt),/NATIVE_UNCONFIRMED/);
  assert.equal(restarted.hasCurrentP1Observation(f.trusted,f.attempt,stored),false);
  assert.deepEqual(await f.rows(),before);
});
test('R1 required: already observed authenticated revocation invalidates previous consumption evidence',async()=>{
  const f=await fixture();let revoked=false;
  const api=new IG04P1Preparation({...f.options,sourceReader:async()=>({...f.source,current:{revoked}}),
    verifySource:(_t,_s,_a,_b,observation)=>observation.current.revoked===false});
  const read=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  const h=await api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt);
  const stored=await api.registerP1Preparation(f.trusted,f.attempt,h,0),before=await f.rows();
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,stored),true);
  revoked=true;await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),/SOURCE_UNCONFIRMED/);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,stored),false);
  await assert.rejects(api.registerP1Preparation(f.trusted,f.attempt,h,0),/CURRENTNESS/);
  assert.deepEqual(await f.rows(),before);
});
test('R1 impact: authenticated native-positive requery mints only a fresh service-owned observation',async()=>{
  const f=await fixture(),first=await f.register();let nativeChecks=0;
  const api=new IG04P1Preparation({...f.options,verifyNative:async()=>{nativeChecks++;return true;}});
  const result=await api.queryP1Preparation(f.trusted,f.attempt);
  assert.equal(nativeChecks,1);assert.deepEqual(result,first);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,result),true);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,first),false);
});
test('R1 impact: false native observation blocks old result consumption and keeps historical storage',async()=>{
  const f=await fixture();let native=true;
  const api=new IG04P1Preparation({...f.options,verifyNative:async()=>native});
  const read=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  const h=await api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt);
  const first=await api.registerP1Preparation(f.trusted,f.attempt,h,0),before=await f.rows();native=false;
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),/NATIVE_UNCONFIRMED/);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,first),false);
  assert.deepEqual(await f.rows(),before);
});
test('R1 impact: pending requery native verification cannot publish after local retirement',async()=>{
  const f=await fixture(),first=await f.register(),wait=defer();let entered=false;
  const api=new IG04P1Preparation({...f.options,verifyNative:()=>{entered=true;return wait.promise;}});
  const pending=api.queryP1Preparation(f.trusted,f.attempt);
  while(!entered)await new Promise(r=>setImmediate(r));
  f.context.revision++;wait.resolve(true);await assert.rejects(pending,/CURRENTNESS/);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,first),false);
  assert.deepEqual((await f.rows()).find(r=>r.key===first.key),first);
});
test('R1 impact: a denied authority cannot revive by positive retry or new request lifetime',async()=>{
  const f=await fixture();let valid=true;
  const api=new IG04P1Preparation({...f.options,verifySource:async()=>valid});
  const read=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  const h=await api.verifyP1Preparation(f.trusted,f.attempt,read,f.context.nativeScope,f.attempt);
  const first=await api.registerP1Preparation(f.trusted,f.attempt,h,0);valid=false;
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),/SOURCE_UNCONFIRMED/);
  valid=true;f.context.requestLifetime='new-request-same-authority';f.context.revision++;
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),/CURRENTNESS/);
  assert.deepEqual((await f.rows()).find(r=>r.key===first.key),first);
  // Only a real protected local authority transition can establish a new life.
  f.context.token=await f.provider.transition('authority',f.token,{document:'native-doc'});
  const recovered=await api.queryP1Preparation(f.trusted,f.attempt);
  assert.deepEqual(recovered,first);assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,recovered),true);
});
test('R1 impact: late negative source verification retires captured old authority, not another active lifetime',async()=>{
  const f=await fixture(),otherTrusted=Object.freeze({}),otherToken=await f.provider.initialize('other-authority',{document:'other-doc'});
  await f.provider.register('other-authority',otherToken,'other-source-local',f.source);
  const otherContext={...clone(f.context),authorityId:'other-authority',token:otherToken,sourceLocalId:'other-source-local',requestLifetime:'other-life'};
  const contexts=new Map([[f.trusted,f.context],[otherTrusted,otherContext]]),wait=defer();let delayed=false,entered=false;
  const api=new IG04P1Preparation({...f.options,capture:t=>clone(contexts.get(t)),
    isCurrent:(t,c)=>canonical(contexts.get(t))===canonical(c),
    verifySource:async t=>{if(t===f.trusted&&delayed){entered=true;return wait.promise;}return true;}});
  async function register(t,context){const r=await api.readP1Source(t,f.attempt,f.binding,f.attempt.sourceRef);const h=await api.verifyP1Preparation(t,f.attempt,r,context.nativeScope,f.attempt);return api.registerP1Preparation(t,f.attempt,h,0);}
  const old=await register(f.trusted,f.context),other=await register(otherTrusted,otherContext),before=await f.rows();
  delayed=true;const pending=api.queryP1Preparation(f.trusted,f.attempt);
  while(!entered)await new Promise(r=>setImmediate(r));
  wait.resolve(false);await assert.rejects(pending,/SOURCE_UNCONFIRMED/);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,old),false);
  assert.equal(api.hasCurrentP1Observation(otherTrusted,f.attempt,other),true);
  assert.deepEqual(await f.rows(),before);
});
test('R1 impact: trusted source rejection preserves original error and invalidates old observation',async()=>{
  const f=await fixture();let failure=null;
  const api=new IG04P1Preparation({...f.options,verifySource:async()=>{if(failure)throw failure;return true;}});
  const r=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
  const h=await api.verifyP1Preparation(f.trusted,f.attempt,r,f.context.nativeScope,f.attempt);
  const stored=await api.registerP1Preparation(f.trusted,f.attempt,h,0);failure=Error('trusted source denied');
  await assert.rejects(api.queryP1Preparation(f.trusted,f.attempt),e=>e===failure);
  assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,stored),false);
});
test('R1 impact: same SessionDB services share known authority rejection without changing stored records',async()=>{
  const f=await fixture(),stored=await f.register(),before=await f.rows();
  const another=new IG04P1Preparation({...f.options,store:new A1Store(f.db),verifySource:async()=>false});
  await assert.rejects(another.queryP1Preparation(f.trusted,f.attempt),/SOURCE_UNCONFIRMED/);
  assert.equal(f.api.hasCurrentP1Observation(f.trusted,f.attempt,stored),false);
  const recreated=new IG04P1Preparation(f.options);
  await assert.rejects(recreated.queryP1Preparation(f.trusted,f.attempt),/CURRENTNESS/);
  assert.deepEqual(await f.rows(),before);
});
