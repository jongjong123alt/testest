import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory} from 'fake-indexeddb';
import {createMemberDB} from '../member-a1/db.mjs';
import {A1Store} from '../member-a1/store.mjs';
import {canonical} from '../a1/contract.mjs';
import {IG04ProviderStore} from '../src/ig04-provider-store.js';
import {IG04P1Preparation} from '../src/ig04-p1-preparation.js';
import {IG04P1ServerSourceAdapter,p1Utf8Sha256} from '../src/ig04-p1-server-source.js';
const uid=n=>'00000000-0000-4000-8000-'+String(n).padStart(12,'0');
const clone=structuredClone;
const deferred=()=>{let resolve;const promise=new Promise(r=>{resolve=r;});return {promise,resolve};};
// Synthetic authenticated boundary, using the exact pinned Java SourceRead /
// full PreparationOriginal mapping. This is not an executed Java/HTTP fixture.
async function setup({missingReader=false}={}){
 const db=createMemberDB(new IDBFactory(),'server-source-'+crypto.randomUUID()),store=new A1Store(db);
 await store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'native-fence',owner_context:'MEMBER:1',transitioning:false});done(null);});
 const provider=new IG04ProviderStore(store,{guard:()=>true}),token=await provider.initialize('authority',{document:'doc'});
 const binding={owner_key:'MEMBER:1',executor_id:uid(1),binding_id:uid(2),epoch:7};
 const sourceRef={id:uid(3),version:1},original={sourceRef};
 const attempt={requestId:uid(4),sourceRef,sourceVersion:1,original,bytes:canonical(original),digest:await p1Utf8Sha256(canonical(original))};
 await provider.register('authority',token,'read-attempt',attempt);
 const creationDigest=await p1Utf8Sha256('protected Server creation request');
 const preparation={reference:sourceRef.id,executor:binding.executor_id,user:'1',requestId:uid(5),requestDigest:creationDigest,
  binding:{bindingId:binding.binding_id,epoch:7},snapshot:{format:'AMVP_P1_SETTINGS_SOURCE_1',bytes:canonical({settings:[{name:'한글·설정',version:8}]}),settingsVersion:8},
  policyId:'fixture-policy',createdAt:'2026-11-06T00:00:00Z',expiresAt:'2026-11-06T00:05:00Z'};
 const raw=canonical(preparation),response={sourceRef:sourceRef.id,sourceVersion:1,raw,rawSha256:await p1Utf8Sha256(raw),expiresAt:Date.parse(preparation.expiresAt),bindingId:binding.binding_id,ownerEpoch:7,executorId:binding.executor_id};
 const trusted=Object.freeze({}),state={now:Date.parse('2026-11-06T00:01:00Z'),response,queries:[],error:null};
 const context={authorityId:'authority',token,requestLifetime:'read-life',revision:1,sourceLocalId:'prepared-original',sourceVersion:1,
  attemptLocalId:'read-attempt',attemptVersion:1,nativeScope:{document:'doc',generation:1,attempt:'local-attempt'},binding,deadline:state.now+120000};
 const capture=t=>t===trusted?clone(context):null,isCurrent=(t,c)=>t===trusted&&canonical(c)===canonical(context);
 const client={credentials:async()=>({owner_key:'MEMBER:1',executor_id:uid(1),access_token:'fixture-only'}),request:async()=>{throw Error('no-public-route');}};
 const readAuthenticatedSource=missingReader?undefined:async(c,credentials,query)=>{
  assert.equal(c,client);assert.equal(credentials.access_token,'fixture-only');state.queries.push(query);
  if(state.error)throw state.error;return clone(state.response);
 };
 const adapter=new IG04P1ServerSourceAdapter({providerStore:provider,capture,isCurrent,attemptRecord:()=>({localId:'read-attempt',version:1}),readAuthenticatedSource,now:()=>state.now});
 await adapter.openAttempt(trusted,attempt);
 const options={store,client,capture,isCurrent,...adapter.forContext(trusted),verifyNative:async()=>true,now:()=>state.now};
 const api=new IG04P1Preparation(options);
 const read=()=>api.readP1Source(trusted,attempt,binding,attempt.sourceRef);
 async function register(){const source=await read();await provider.register('authority',token,'prepared-original',source);const h=await api.verifyP1Preparation(trusted,attempt,source,context.nativeScope,attempt);return api.registerP1Preparation(trusted,attempt,h,0);}
 const rows=()=>db.transaction('readonly',(tx,done)=>{const q=tx.objectStore('metadata').getAll();q.onsuccess=()=>done(q.result);});
 return {db,store,provider,token,binding,sourceRef,attempt,preparation,trusted,state,context,client,adapter,api,read,register,rows,capture,isCurrent,options};
}
test('actual Core adapter maps full Server-original shape, separates all versions and queries without caller creation digest',async()=>{
 const f=await setup(),stored=await f.register();
 assert.deepEqual(stored.source.sourceRef,{id:uid(3),version:1});assert.equal(stored.source.version,1);assert.equal(stored.version,1);
 const original=JSON.parse(stored.source.bytes);assert.equal(original.snapshot.settingsVersion,8);assert.equal(original.binding.epoch,7);
 assert.equal(stored.source.rawSha256,await p1Utf8Sha256(canonical(f.preparation)));
 assert.notEqual(stored.source.rawSha256,await p1Utf8Sha256(original.snapshot.bytes));
 assert.notEqual(f.attempt.digest,original.requestDigest);
 assert.deepEqual(f.state.queries[0],{executor:uid(1),readAttempt:{requestId:uid(4),original:f.attempt.bytes},reference:uid(3),expectedSourceVersion:1});
 assert.equal('expectedDigest' in f.state.queries[0],false);
 assert.equal(f.api.hasCurrentP1Observation(f.trusted,f.attempt,stored),true);
 assert.deepEqual(await f.api.queryP1Preparation(f.trusted,f.attempt),stored);
 assert.equal(stored.kind,'P1_NON_EXECUTABLE_PREPARATION');
});
test('missing authenticated supplier denies without guessing an HTTP route',async()=>{
 const f=await setup({missingReader:true});await assert.rejects(f.read(),/AUTHENTICATED_SERVER_SOURCE_UNAVAILABLE/);assert.equal(f.state.queries.length,0);
});
test('U1 authenticated source absence rejects; U3 authenticated registration absence alone is null',async()=>{
 const f=await setup(),source=await f.read();await f.provider.register('authority',f.token,'prepared-original',source);
 assert.equal(await f.api.queryP1Preparation(f.trusted,f.attempt),null);
 f.state.response=null;await assert.rejects(f.read(),/SERVER_SOURCE_ABSENT/);
});
test('caller cannot override protected attempt digest or original sourceRef',async()=>{
 for(const mutate of [a=>{a.digest='0'.repeat(64);},a=>{a.original.sourceRef={id:uid(99),version:1};},a=>{a.sourceRef.version=8;a.sourceVersion=8;}]){
  const f=await setup(),altered=clone(f.attempt);mutate(altered);
  await assert.rejects(f.adapter.openAttempt(f.trusted,altered),/PROTECTED_ATTEMPT_MISMATCH/);
 }
});
test('even a registered attempt must hash canonical original UTF-8 and match sourceRef',async()=>{
 const f=await setup(),bad={...f.attempt,digest:'0'.repeat(64)};
 await f.provider.register('authority',f.token,'bad-attempt',bad);
 const adapter=new IG04P1ServerSourceAdapter({providerStore:f.provider,capture:f.capture,isCurrent:f.isCurrent,attemptRecord:()=>({localId:'bad-attempt',version:1}),now:()=>f.state.now});
 await assert.rejects(adapter.openAttempt(f.trusted,bad),/DIGEST_MISMATCH/);
});
for(const [name,mutate] of [
 ['nested-only hash',async r=>{r.rawSha256=await p1Utf8Sha256(JSON.parse(r.raw).snapshot.bytes);}],
 ['settings version used as creation version',async r=>{r.sourceVersion=8;}],
 ['wrong preparation',async r=>{r.sourceRef=uid(90);}],
 ['wrong owner epoch',async r=>{r.ownerEpoch=8;}],
 ['wrong installation',async r=>{r.executorId=uid(90);}],
 ['expired source',async(r,f)=>{r.expiresAt=f.state.now;}],
 ['hash-correct partial original',async r=>{r.raw=canonical(JSON.parse(r.raw).snapshot);r.rawSha256=await p1Utf8Sha256(r.raw);}],
 ['noncanonical duplicate property',async r=>{r.raw=r.raw.replace('{','{"reference":"duplicate",');r.rawSha256=await p1Utf8Sha256(r.raw);}]
])test('Server source rejects '+name,async()=>{
 const f=await setup();await mutate(f.state.response,f);await assert.rejects(f.read());
});
test('direct callback input cannot manufacture authenticated source provenance',async()=>{
 const f=await setup(),callbacks=f.adapter.forContext(f.trusted);
 const fake={sourceRef:f.sourceRef,version:1,bytes:f.state.response.raw,rawSha256:f.state.response.rawSha256,binding:f.binding,expiresAt:f.state.response.expiresAt};
 assert.equal(await callbacks.verifySource(f.trusted,fake,f.attempt,f.binding,fake),false);
});
test('protected attempt change during native await rejects final CAS without consuming obligations',async()=>{
 const f=await setup(),source=await f.read();await f.provider.register('authority',f.token,'prepared-original',source);
 const wait=deferred();let entered=false;const api=new IG04P1Preparation({...f.options,verifyNative:()=>{entered=true;return wait.promise;}});
 const r=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
 const pending=api.verifyP1Preparation(f.trusted,f.attempt,r,f.context.nativeScope,f.attempt);
 while(!entered)await new Promise(r=>setImmediate(r));
 await f.store.atomic((tx,done)=>{const md=tx.objectStore('metadata'),q=md.getAll();q.onsuccess=()=>{const record=q.result.find(x=>x.localId==='read-attempt');record.version++;md.put(record);done(null);};});
 wait.resolve(true);const h=await pending;
 await assert.rejects(api.registerP1Preparation(f.trusted,f.attempt,h,0),/PROTECTED_ATTEMPT_CHANGED/);
 assert.equal((await f.rows()).some(r=>r.kind==='P1_NON_EXECUTABLE_PREPARATION'),false);
});
test('observed authenticated Server rejection invalidates previous evidence, preserves committed original',async()=>{
 const f=await setup(),stored=await f.register(),before=await f.rows();f.state.error=Error('SOURCE_UNCONFIRMED');
 await assert.rejects(f.api.queryP1Preparation(f.trusted,f.attempt),e=>e===f.state.error);
 assert.equal(f.api.hasCurrentP1Observation(f.trusted,f.attempt,stored),false);assert.deepEqual(await f.rows(),before);
});
test('401 rejects without replay or converting to absence',async()=>{
 const f=await setup();f.state.error=Object.assign(Error('UNAUTHENTICATED'),{status:401});
 await assert.rejects(f.read(),e=>e===f.state.error);assert.equal(f.state.queries.length,1);
});
test('registration expectedVersion is neither saved source revision nor settings version',async()=>{
 const f=await setup(),source=await f.read();await f.provider.register('authority',f.token,'prepared-original',source);
 const h=await f.api.verifyP1Preparation(f.trusted,f.attempt,source,f.context.nativeScope,f.attempt);
 for(const wrong of [source.sourceRef.version,JSON.parse(source.bytes).snapshot.settingsVersion])
  await assert.rejects(f.api.registerP1Preparation(f.trusted,f.attempt,h,wrong),/REGISTRATION_VERSION_CONFLICT/);
 const stored=await f.api.registerP1Preparation(f.trusted,f.attempt,h,0);assert.equal(stored.version,1);
});
test('adapter and Core currentness provider receive the same protected attempt as third argument',async()=>{
 const f=await setup();let checks=0;
 const current=(t,c,a)=>{checks++;return f.isCurrent(t,c)&&canonical(a)===canonical(f.attempt);};
 const adapter=new IG04P1ServerSourceAdapter({providerStore:f.provider,capture:f.capture,isCurrent:current,
  attemptRecord:()=>({localId:'read-attempt',version:1}),readAuthenticatedSource:async()=>clone(f.state.response),now:()=>f.state.now});
 await adapter.openAttempt(f.trusted,f.attempt);
 const api=new IG04P1Preparation({...f.options,isCurrent:current,...adapter.forContext(f.trusted)});
 const source=await api.readP1Source(f.trusted,f.attempt,f.binding,f.attempt.sourceRef);
 await f.provider.register('authority',f.token,'prepared-original',source);
 const h=await api.verifyP1Preparation(f.trusted,f.attempt,source,f.context.nativeScope,f.attempt);
 const stored=await api.registerP1Preparation(f.trusted,f.attempt,h,0);
 assert.equal(api.hasCurrentP1Observation(f.trusted,f.attempt,stored),true);assert.ok(checks>0);
});
