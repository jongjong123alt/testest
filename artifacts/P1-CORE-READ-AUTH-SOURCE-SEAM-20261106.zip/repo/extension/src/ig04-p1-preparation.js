import {canonical, digest as rc2Digest} from '../a1/contract.mjs';
import {digest as a1Digest} from '../member-a1/contract.mjs';
import {IG04ProviderStore} from './ig04-provider-store.js';

const clone = structuredClone;
const same = (a, b) => canonical(a) === canonical(b);
const need = (ok, message) => { if (!ok) throw Error(message); };
const label = v => typeof v === 'string' && v.length > 0 && v.length <= 512;
const version = v => Number.isSafeInteger(v) && v >= 1;
const freeze = v => { if (v && typeof v === 'object') { Object.values(v).forEach(freeze); Object.freeze(v); } return v; };
const immutable = v => freeze(clone(v));
const uuid = v => typeof v === 'string' && /^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(v);
const reference = v => v && Object.keys(v).length === 2 && uuid(v.id) && version(v.version);
const deny = () => false;
// Service recreation in this Worker must not discard known rejections of the
// same shared SessionDB authority. Not an OS/Worker-restart revocation provider.
const rejectedByDatabase = new WeakMap();
// Strict synchronous providers cannot accidentally authorize with a Promise.
function strict(v) { if (v && typeof v.then === 'function') Promise.resolve(v).catch(() => {}); return v === true; }

/** Private, non-executable preparation only. No startup import, loop, listener,
 * endpoint, capability issuer, operation issuer, reservation or closure write.
 * sourceReader uses the existing client.credentials/request through a trusted
 * source adapter; no prepared HTTP route is invented here. All policy/provider
 * defaults deny. verifySource also receives the authenticated read (fifth
 * provider argument) for current/revocation observations; it is kept private,
 * never flattened into the immutable stored source or returned registration.
 * Provider functions belong to the trusted Worker composition,
 * never a message body's callbacks or booleans.
 */
export class IG04P1Preparation {
  #store; #client; #p; #reads = new WeakMap(); #verified = new WeakMap(); #observations = new WeakMap();
  #authority; #retired = new WeakMap(); #rejectedAuthorities;
  constructor({store, client, sourceReader, verifySource = deny, verifyNative = deny,
    verifyAttempt = deny, capture = () => null, isCurrent = deny,
    now = Date.now, monotonic = () => performance.now()} = {}) {
    need(store && typeof store.atomic === 'function', 'P1_STORE_REQUIRED');
    need(client && typeof client.credentials === 'function' && typeof client.request === 'function', 'P1_CLIENT_REQUIRED');
    this.#store = store; this.#client = client; this.#authority = new IG04ProviderStore(store);
    const database = store.db ?? store;
    if (!rejectedByDatabase.has(database)) rejectedByDatabase.set(database, new Set());
    this.#rejectedAuthorities = rejectedByDatabase.get(database);
    this.#p = {sourceReader, verifySource, verifyNative, verifyAttempt, capture, isCurrent, now, monotonic};
  }
  #context(trusted, attempt) {
    const snapshot = immutable(this.#p.capture(trusted));
    need(snapshot && label(snapshot.authorityId) && label(snapshot.requestLifetime)
      && version(snapshot.revision) && version(snapshot.sourceVersion) && label(snapshot.sourceLocalId)
      && label(snapshot.attemptLocalId) && version(snapshot.attemptVersion)
      && snapshot.nativeScope && snapshot.token && snapshot.binding
      && Number.isSafeInteger(snapshot.deadline), 'P1_CONTEXT_UNCONFIRMED');
    need(attempt && label(attempt.requestId) && reference(attempt.sourceRef) && attempt.sourceVersion === attempt.sourceRef.version
      && same(attempt.original?.sourceRef, attempt.sourceRef)
      && typeof attempt.bytes === 'string' && label(attempt.digest), 'P1_ATTEMPT_INVALID');
    const binding = snapshot.binding;
    need(uuid(binding.binding_id) && uuid(binding.executor_id) && label(binding.owner_key)
      && Number.isSafeInteger(binding.epoch) && binding.epoch >= 0, 'P1_BINDING_REQUIRED');
    const state = {snapshot, attempt: immutable(attempt), trusted,
      end: this.#p.monotonic() + Math.max(0, snapshot.deadline - this.#p.now())};
    this.#check(state);
    need(strict(this.#p.verifyAttempt(trusted, state.attempt)), 'P1_ATTEMPT_UNCONFIRMED');
    return state;
  }
  #authorityKey(s) {
    return canonical([s.snapshot.authorityId, s.snapshot.token, s.snapshot.binding]);
  }
  #check(s, source = null) {
    const now = this.#p.now(), mono = this.#p.monotonic();
    need(!this.#rejectedAuthorities.has(this.#authorityKey(s))
      && !this.#retired.get(s.trusted)?.has(s.snapshot.requestLifetime)
      && Number.isSafeInteger(now) && now < s.snapshot.deadline && mono < s.end
      && (s.sourceEnd === undefined || mono < s.sourceEnd)
      && (!source || now < source.expiresAt)
      && strict(this.#p.isCurrent(s.trusted, s.snapshot, s.attempt)), 'P1_CURRENTNESS_UNCONFIRMED');
  }
  #sameContext(a, b) { need(a.trusted === b.trusted && same(a.snapshot, b.snapshot)
    && same(a.attempt, b.attempt), 'P1_CONTEXT_MISMATCH'); }
  #authenticationFailure(s, error) {
    let current = false;
    try { current = strict(this.#p.isCurrent(s.trusted, s.snapshot, s.attempt)); } catch {}
    if (error?.status === 401 && current) {
      let retired = this.#retired.get(s.trusted);
      if (!retired) { retired = new Set(); this.#retired.set(s.trusted, retired); }
      retired.add(s.snapshot.requestLifetime);
    }
    return error;
  }
  async #verify(provider, s, ...args) {
    try { return await provider(s.trusted, ...args); }
    catch (error) { throw this.#authenticationFailure(s, error); }
  }
  async #sourceVerified(s, source, authenticatedRead) {
    // A trusted verifier's negative/failed observation must retire existing
    // consumption evidence, not merely reject this new call. Bind the latch to
    // the captured authority token/binding, never the currently active caller.
    // Keep storage/obligations intact; a new request ID cannot revive this life.
    let result;
    try { result = await this.#verify(this.#p.verifySource, s, source, s.attempt,
      s.snapshot.binding, authenticatedRead); }
    catch (error) {
      // 401 already retires the captured request lifetime, not every new auth
      // request under the same authority. Other verifier failures fail closed.
      if (error?.status !== 401) this.#rejectedAuthorities.add(this.#authorityKey(s));
      throw error;
    }
    if (result !== true) {
      this.#rejectedAuthorities.add(this.#authorityKey(s));
      throw Error('P1_SOURCE_UNCONFIRMED');
    }
  }
  async #credential(s) {
    let credential;
    try { credential = clone(await this.#client.credentials()); }
    catch (error) { throw this.#authenticationFailure(s, error); }
    this.#check(s);
    need(credential.owner_key === s.snapshot.binding.owner_key
      && credential.executor_id === s.snapshot.binding.executor_id, 'P1_CREDENTIAL_SCOPE_CHANGED');
    return credential;
  }
  async readP1Source(trusted, exactAttempt, expectedBinding, sourceRef) {
    const s = this.#context(trusted, exactAttempt), expected = immutable(expectedBinding), ref = immutable(sourceRef);
    need(same(expected, s.snapshot.binding) && same(ref, s.attempt.sourceRef), 'P1_SOURCE_SCOPE_MISMATCH');
    const credential = await this.#credential(s);
    need(typeof this.#p.sourceReader === 'function', 'P1_SOURCE_UNAVAILABLE');
    // Existing HTTP/abort/network errors propagate unchanged. No refresh/reissue.
    let raw;
    try { raw = await this.#p.sourceReader(this.#client, credential, ref, s.attempt, expected); }
    catch (error) {
      if (error?.status !== 401) this.#rejectedAuthorities.add(this.#authorityKey(s));
      throw this.#authenticationFailure(s, error);
    }
    this.#check(s);
    s.authenticatedRead = immutable(raw);
    // Only source originals cross this boundary; credentials/transport extras do not.
    const source = raw == null ? null : immutable({sourceRef: raw.sourceRef, version: raw.version,
      bytes: raw.bytes, binding: raw.binding, expiresAt: raw.expiresAt,
      ...(raw.rawSha256 === undefined ? {} : {rawSha256: raw.rawSha256}),
      ...(raw.hashes === undefined ? {} : {hashes: raw.hashes})});
    need(source && same(source.sourceRef, ref) && source.version === ref.version
      && typeof source.bytes === 'string' && Number.isSafeInteger(source.expiresAt)
      && same(source.binding, expected), 'P1_SOURCE_MISMATCH');
    s.sourceEnd = this.#p.monotonic() + Math.max(0, source.expiresAt - this.#p.now());
    await this.#sourceVerified(s, source, s.authenticatedRead);
    this.#check(s, source);
    // Re-read credential scope; do not leak any token in SourceRead or storage.
    const after = await this.#credential(s);
    need(after.owner_key === credential.owner_key && after.executor_id === credential.executor_id
      && after.access_token === credential.access_token, 'P1_CREDENTIAL_SCOPE_CHANGED');
    this.#check(s, source);
    this.#reads.set(source, s); return source;
  }
  async verifyP1Preparation(trusted, exactAttempt, sourceRead, nativeScopeOriginal, expectedAttempt) {
    const s = this.#context(trusted, exactAttempt), prior = this.#reads.get(sourceRead);
    need(prior, 'P1_SOURCE_HANDLE_REQUIRED'); this.#sameContext(s, prior); this.#check(prior, sourceRead);
    const native = immutable(nativeScopeOriginal), expected = immutable(expectedAttempt);
    need(same(expected, s.attempt) && same(native, s.snapshot.nativeScope), 'P1_NATIVE_SCOPE_MISMATCH');
    await this.#sourceVerified(s, sourceRead, prior.authenticatedRead);
    this.#check(s, sourceRead);
    if (await this.#verify(this.#p.verifyNative, s, native, s.snapshot, s.attempt) !== true) {
      this.#rejectedAuthorities.add(this.#authorityKey(s));
      throw Error('P1_NATIVE_UNCONFIRMED');
    }
    this.#check(s, sourceRead);
    // The mappings are optional existing originals, not a new operation/proof.
    // A1 hashes its command original; RC2 hashes its semantic original separately.
    if (sourceRead.hashes?.a1) {
      const x = sourceRead.hashes.a1;
      need(await a1Digest(x.original) === x.fingerprint, 'P1_A1_HASH_MISMATCH'); this.#check(s, sourceRead);
    }
    if (sourceRead.hashes?.rc2) {
      const x = sourceRead.hashes.rc2;
      need(await rc2Digest(x.original) === x.semantic_sha256, 'P1_RC2_HASH_MISMATCH'); this.#check(s, sourceRead);
    }
    const handle = Object.freeze(Object.create(null));
    this.#verified.set(handle, {state: prior, source: sourceRead}); return handle;
  }
  #local(rows, s, source) {
    this.#check(s, source);
    const a = s.snapshot;
    this.#authority.authority(rows, a.authorityId, a.token);
    const attemptKey = 'ig04:provider:original:' + canonical([a.authorityId, a.attemptLocalId]);
    const protectedAttempt = rows.find(r => r.key === attemptKey);
    need(protectedAttempt && protectedAttempt.version === a.attemptVersion && protectedAttempt.closedBy === null
      && same(protectedAttempt.original, s.attempt), 'P1_PROTECTED_ATTEMPT_CHANGED');
    const key = 'ig04:provider:original:' + canonical([a.authorityId, a.sourceLocalId]);
    const row = rows.find(r => r.key === key);
    need(row && row.authorityId === a.authorityId && row.version === a.sourceVersion
      && row.closedBy === null && same(row.original, source), 'P1_PROTECTED_SOURCE_CHANGED');
    // Protected source registration/lifecycle uses existing provider-store. This
    // module cannot create/repair its authority, fence or source by declaration.
  }
  #atomic(s, source, work) {
    return this.#store.atomic((tx, done, reject) => {
      const md = tx.objectStore('metadata'), request = md.getAll();
      request.onsuccess = () => { try { this.#local(request.result, s, source); done(clone(work(md, request.result))); }
        catch (error) { reject(error); } };
    });
  }
  #key(s) { return 'ig04:p1-preparation:registration:' + canonical([s.snapshot.authorityId, s.attempt.requestId]); }
  #post(s, source, result) {
    this.#check(s, source); // Commit already happened. Failure NEVER deletes it.
    if (result !== null) {
      result = immutable(result);
      this.#observations.set(result, {state: s, source});
    }
    return result;
  }
  async registerP1Preparation(trusted, exactAttempt, verifiedPreparation, expectedVersion) {
    const s = this.#context(trusted, exactAttempt), verified = this.#verified.get(verifiedPreparation);
    need(verified, 'P1_VERIFIED_HANDLE_REQUIRED'); this.#sameContext(s, verified.state);
    this.#check(verified.state, verified.source);
    s.end = Math.min(s.end, verified.state.end); s.sourceEnd = verified.state.sourceEnd;
    need(Number.isSafeInteger(expectedVersion) && expectedVersion >= 0, 'P1_VERSION_INVALID');
    const {source} = verified, result = await this.#atomic(s, source, (md, rows) => {
      const key = this.#key(s), previous = rows.find(r => r.key === key);
      if (previous) {
        need(same(previous.attempt, s.attempt) && same(previous.source, source)
          && same(previous.local, s.snapshot), 'P1_REQUEST_CONFLICT');
        return previous; // Replay does not mutate/advance the immutable receipt.
      }
      need(expectedVersion === 0, 'P1_REGISTRATION_VERSION_CONFLICT');
      const row = {key, kind: 'P1_NON_EXECUTABLE_PREPARATION', registrationRef: crypto.randomUUID(),
        version: 1, attempt: s.attempt, source, local: s.snapshot};
      md.add(row); return row;
    });
    return this.#post(s, source, result);
  }
  async queryP1Preparation(trusted, exactAttempt) {
    const s = this.#context(trusted, exactAttempt);
    // A cached row alone is insufficient. Auth/network errors reject, not null.
    const source = await this.readP1Source(trusted, s.attempt, s.snapshot.binding, s.attempt.sourceRef);
    // Requery is another consumption-evidence producer, not a storage-only
    // shortcut. Reuse U2 including fresh native validation and final guards.
    await this.verifyP1Preparation(trusted, s.attempt, source, s.snapshot.nativeScope, s.attempt);
    const readState = this.#reads.get(source); this.#sameContext(s, readState);
    s.end = Math.min(s.end, readState.end); s.sourceEnd = readState.sourceEnd;
    const result = await this.#atomic(s, source, (_md, rows) => {
      const row = rows.find(r => r.key === this.#key(s));
      if (!row) return null;
      need(same(row.attempt, s.attempt) && same(row.source, source), 'P1_REQUEST_CONFLICT');
      return row;
    });
    return this.#post(s, source, result);
  }
  // Trusted U4 composition may call this synchronously through its own opaque
  // context. No fourth U4 parameter, permission wrapper or serialized proof.
  hasCurrentP1Observation(trusted, exactAttempt, stored) {
    try {
      const observation = this.#observations.get(stored); if (!observation) return false;
      const s = this.#context(trusted, exactAttempt);
      this.#sameContext(s, observation.state); this.#check(observation.state, observation.source);
      return same(stored.attempt, s.attempt) && same(stored.source, observation.source);
    } catch { return false; }
  }
}
