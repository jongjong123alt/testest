import {canonical} from '../a1/contract.mjs';

const copy = structuredClone;
const equal = (a,b) => canonical(a) === canonical(b);
const need = (ok,code) => { if (!ok) throw Error(code); };
const prefix = 'ig04:provider:';
const key = (kind,id) => prefix + kind + ':' + id;
const label = x => typeof x === 'string' && x.length > 0 && x.length <= 512;

/** Private persistence seam. Not an issuer, Wire endpoint or authenticated provider.
 * Caller must supply a synchronous trusted guard over this transaction's rows.
 * No default allow; no external await inside the transaction. All authority
 * transitions and this store's writes must share the same A1Store/database.
 */
export class IG04ProviderStore {
  constructor(store,{guard}={}) {
    need(store && typeof store.atomic === 'function','IG04_STORE_REQUIRED');
    this.store=store; this.guard=guard ?? (()=>false);
  }
  async atomic(action,input,work) {
    // Freeze caller arguments before the first await/IDB callback.
    const args=copy(input);
    return this.store.atomic((tx,done,reject)=>{
      const md=tx.objectStore('metadata'),q=md.getAll();
      q.onsuccess=()=>{try{
        const rows=q.result;
        // A Promise is never treated as successful authentication.
        const verified=this.guard(action,copy(args),copy(rows));
        if(verified && typeof verified.then==='function')Promise.resolve(verified).catch(()=>{});
        need(verified===true,'IG04_PROVIDER_UNCONFIRMED');
        done(copy(work(rows,md,args)));
      }catch(e){reject(e);}};
    });
  }
  authority(rows,id,expected) {
    const a=rows.find(r=>r.key===key('authority',id));
    need(a && a.active,'IG04_AUTHORITY_CLOSED');
    const f=rows.find(r=>r.key==='a1:owner-fence');
    need(f && !f.transitioning && f.epoch===a.ownerFence && f.owner_context===a.owner,'IG04_OWNER_FENCE_CHANGED');
    need(equal(a.token,expected),'IG04_REVISION_CHANGED');
    return a;
  }
  // Local initialization only after trusted guard checks the current source.
  // Never use this to silently repair missing/corrupt storage after recovery.
  initialize(id,binding) {
    return this.atomic('initialize',{id,binding},(rows,md,{id,binding})=>{
      need(label(id),'IG04_INVALID_KEY');
      need(!rows.some(r=>r.key===key('authority',id)),'IG04_ALREADY_INITIALIZED');
      const f=rows.find(r=>r.key==='a1:owner-fence');
      need(f && !f.transitioning && label(f.epoch) && label(f.owner_context),'IG04_OWNER_FENCE_CHANGED');
      const a={key:key('authority',id),binding,owner:f.owner_context,ownerFence:f.epoch,
        token:{lifetime_ref:crypto.randomUUID(),revision:1},active:true};
      md.add(a);return a.token;
    });
  }
  // Revocation is permanent for this authority id. New authority uses a new id.
  // A->B->A binding transitions always advance revision; old tokens stay stale.
  transition(id,expected,binding,{revoke=false}={}) {
    return this.atomic('transition',{id,expected,binding,revoke},(rows,md,a)=>{
      // Allow retiring a row whose A1 fence has already changed. No effect rights.
      const row=rows.find(r=>r.key===key('authority',a.id));
      need(row && row.active && equal(row.token,a.expected),'IG04_REVISION_CHANGED');
      need(Number.isSafeInteger(row.token.revision+1),'IG04_REVISION_EXHAUSTED');
      const f=rows.find(r=>r.key==='a1:owner-fence');
      if(!a.revoke)need(f && !f.transitioning && f.epoch===row.ownerFence && f.owner_context===row.owner,'IG04_OWNER_FENCE_CHANGED');
      row.token.revision++; row.binding=a.binding; row.active=!a.revoke;md.put(row);return row.token;
    });
  }
  register(id,expected,localId,original) {
    return this.atomic('register',{id,expected,localId,original},(rows,md,a)=>{
      this.authority(rows,a.id,a.expected);need(label(a.localId),'IG04_INVALID_KEY');
      const k=key('original',canonical([a.id,a.localId])),prior=rows.find(r=>r.key===k);
      if(prior){need(equal(prior.original,a.original),'IG04_ORIGINAL_CONFLICT');return prior;}
      const r={key:k,authorityId:a.id,localId:a.localId,version:1,original:a.original,closedBy:null};md.add(r);return r;
    });
  }
  // Only supported mutation: verified hash/identity creation before dispatch.
  // Scope/provenance validation remains a trusted guard responsibility.
  finalizeIdentity(id,expected,localId,previousVersion,identity) {
    return this.atomic('finalizeIdentity',{id,expected,localId,previousVersion,identity},(rows,md,a)=>{
      this.authority(rows,a.id,a.expected);
      const r=rows.find(r=>r.key===key('original',canonical([a.id,a.localId])));
      need(r && !r.closedBy && r.version===a.previousVersion && r.original.identity===null && a.identity!==null,'IG04_ORIGINAL_CONFLICT');
      need(Number.isSafeInteger(r.version+1),'IG04_REVISION_EXHAUSTED');
      r.original.identity=a.identity;r.version++;md.put(r);return r;
    });
  }
  lookup(id,expected,localId) {
    return this.atomic('lookup',{id,expected,localId},(rows,_md,a)=>{
      this.authority(rows,a.id,a.expected);
      const r=rows.find(r=>r.key===key('original',canonical([a.id,a.localId])));
      need(r,'IG04_ORIGINAL_UNAVAILABLE');return {record:r,closure_fence:a.expected};
    });
  }
  // Returns committed INTERNAL result, not a public ACK/proof. Final native
  // postcheck and Content consumption checks remain integration requirements.
  close(id,expected,requestId,request,originalVersions) {
    return this.atomic('close',{id,expected,requestId,request,originalVersions},(rows,md,a)=>{
      this.authority(rows,a.id,a.expected);need(label(a.requestId),'IG04_INVALID_KEY');
      const k=key('closure',canonical([a.id,a.requestId])),prior=rows.find(r=>r.key===k);
      const input={request:a.request,originalVersions:a.originalVersions};
      if(prior){need(equal(prior.input,input),'IG04_REQUEST_CONFLICT');return prior;}
      need(Array.isArray(a.originalVersions) && a.originalVersions.length > 0 && new Set(a.originalVersions.map(x=>x.localId)).size===a.originalVersions.length,'IG04_ORIGINAL_CONFLICT');
      for(const v of a.originalVersions){
        const r=rows.find(r=>r.key===key('original',canonical([a.id,v.localId])));
        need(r && r.version===v.version && !r.closedBy,'IG04_ORIGINAL_CONFLICT');
        r.closedBy=k;md.put(r);
      }
      const result={key:k,input,closureRef:crypto.randomUUID(),authorityId:a.id,token:a.expected};md.add(result);return result;
    });
  }
  queryClosure(id,expected,requestId,request,originalVersions) {
    return this.atomic('queryClosure',{id,expected,requestId,request,originalVersions},(rows,_md,a)=>{
      this.authority(rows,a.id,a.expected);
      const r=rows.find(r=>r.key===key('closure',canonical([a.id,a.requestId])));
      need(r,'IG04_CLOSURE_UNCONFIRMED');
      need(equal(r.input,{request:a.request,originalVersions:a.originalVersions}),'IG04_REQUEST_CONFLICT');return r;
    });
  }
}
