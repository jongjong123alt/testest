// The composition root supplies the synchronous verifier of the private Core
// observation. It must bind the exact registration and expectation to the
// current request and reject missing, expired, revoked or unknown evidence.
export function createP1ConsumptionGuard(verifyCurrentPreparation) {
  let checking = false;

  return function consumeP1Preparation(trusted, consumeExpectation, storedPreparationRegistration) {
    if (checking || typeof verifyCurrentPreparation !== 'function'
      || trusted == null || consumeExpectation == null || storedPreparationRegistration == null) {
      return false;
    }

    checking = true;
    try {
      // This strict result is the local receipt. No asynchronous work or
      // receiver/cleanup operation runs between verification and receipt.
      const verdict = verifyCurrentPreparation(trusted, consumeExpectation, storedPreparationRegistration);
      if (verdict === true) return true;
      if (verdict !== null && typeof verdict === 'object') {
        // Observe native Promise rejection without assimilating arbitrary thenables.
        Promise.prototype.then.call(verdict, undefined, () => {});
      }
      return false;
    } catch {
      return false;
    } finally {
      checking = false;
    }
  };
}
