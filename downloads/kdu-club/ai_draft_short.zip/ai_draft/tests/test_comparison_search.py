import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_workflow import WorkflowTests

class SearchCoverageTests(WorkflowTests):
    def test_description_and_campus_search(self):
        self.execute('UPDATE clubs SET description=? WHERE id=1', ('검색검증고유설명',))
        for keyword in ('검색검증고유설명', '글로벌캠퍼스'):
            response = self.student.get('/', query_string={'keyword': keyword})
            self.assertEqual(response.status_code, 200)
            self.assertIn('KDU 코딩클럽', response.text)

# 기존 테스트를 중복 집계하지 않고 추가된 검색 검사만 수집합니다.
def load_tests(loader, tests, pattern):
    import unittest
    return unittest.TestSuite([SearchCoverageTests('test_description_and_campus_search')])
