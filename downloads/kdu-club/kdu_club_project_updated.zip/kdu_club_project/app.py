import os
import uuid
import secrets
import hmac
from flask import Flask, render_template, request, redirect, url_for, session, g, abort
import sqlite3
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = os.environ.get('KDU_SECRET_KEY') or secrets.token_hex(32)
app.config.update(MAX_CONTENT_LENGTH=5 * 1024 * 1024, SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.environ.get('KDU_DATABASE', os.path.join(BASE_DIR, 'database.db'))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'static', 'uploads')
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'pdf'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        db.executescript('''
            DROP TABLE IF EXISTS notifications;
            DROP TABLE IF EXISTS club_qna;
            DROP TABLE IF EXISTS club_schedules;
            DROP TABLE IF EXISTS club_favorites;
            DROP TABLE IF EXISTS club_posts;
            DROP TABLE IF EXISTS club_members;
            DROP TABLE IF EXISTS clubs;
            DROP TABLE IF EXISTS users;

            CREATE TABLE users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                name TEXT NOT NULL,
                role TEXT NOT NULL 
            );

            CREATE TABLE clubs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT NOT NULL,
                image_path TEXT,
                room_location TEXT,
                open_chat_link TEXT,
                status TEXT DEFAULT 'pending',
                applicant_id INTEGER,
                FOREIGN KEY (applicant_id) REFERENCES users (id)
            );

            CREATE TABLE club_members (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                club_id INTEGER,
                user_id INTEGER,
                reason TEXT,
                availability TEXT,
                goal TEXT,
                personality TEXT,
                status TEXT DEFAULT 'pending',
                FOREIGN KEY (club_id) REFERENCES clubs (id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            CREATE TABLE club_favorites (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                club_id INTEGER,
                FOREIGN KEY (user_id) REFERENCES users (id),
                FOREIGN KEY (club_id) REFERENCES clubs (id)
            );

            CREATE TABLE club_posts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                club_id INTEGER,
                user_id INTEGER,
                title TEXT NOT NULL,
                content TEXT NOT NULL,
                file_path TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (club_id) REFERENCES clubs (id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            CREATE TABLE club_schedules (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                club_id INTEGER,
                title TEXT NOT NULL,
                event_date TEXT NOT NULL,
                description TEXT,
                FOREIGN KEY (club_id) REFERENCES clubs (id)
            );

            CREATE TABLE club_qna (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                club_id INTEGER,
                user_id INTEGER,
                question TEXT NOT NULL,
                answer TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (club_id) REFERENCES clubs (id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            CREATE TABLE notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                message TEXT NOT NULL,
                is_read INTEGER NOT NULL DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            );

            INSERT INTO users (username, password, name, role) VALUES ('20211234', '1234', '윤종민', 'student');
            INSERT INTO users (username, password, name, role) VALUES ('prof1', '1234', '김교수', 'professor');

            INSERT INTO clubs (name, category, description, room_location, open_chat_link, status, applicant_id) 
            VALUES ('KDU 코딩클럽', '학술', '알고리즘 및 웹 프로그래밍을 함께 공부하는 동아리입니다. 초보자 환영!', '학생회관 301호', 'https://open.kakao.com/o/sample1', 'approved', 1);

            INSERT INTO clubs (name, category, description, room_location, open_chat_link, status, applicant_id) 
            VALUES ('사운드웨이브', '공연', '통기타와 밴드 합주를 통해 캠퍼스의 로망을 즐기는 밴드 동아리입니다.', '동아리관 지하 102호', 'https://open.kakao.com/o/sample2', 'approved', 1);

            INSERT INTO clubs (name, category, description, room_location, open_chat_link, status, applicant_id) 
            VALUES ('피닉스 FC', '체육', '매주 주말 함께 모여 축구를 즐기는 축구 동아리입니다. 실력 무관!', '대운동장', 'https://open.kakao.com/o/sample3', 'approved', 1);

            INSERT INTO club_schedules (club_id, title, event_date, description) VALUES (1, '2026 1학기 정기 스터디 오리엔테이션', '2026-03-10', '신입 부원 대상 파이썬 기초 세션 진행');
            INSERT INTO club_schedules (club_id, title, event_date, description) VALUES (2, '교내 버스킹 공연', '2026-05-20', '학생식당 앞 광장 정오 공연');
        ''')
        db.commit()

if not os.path.exists(DATABASE):
    init_db()

# 기존 DB를 삭제하지 않고 새 필드와 비밀번호 저장 방식을 적용합니다.
with app.app_context():
    db = get_db()
    columns = {row['name'] for row in db.execute('PRAGMA table_info(club_members)')}
    for column in ('availability', 'goal', 'personality'):
        if column not in columns:
            db.execute(f'ALTER TABLE club_members ADD COLUMN {column} TEXT')
    columns = {row['name'] for row in db.execute('PRAGMA table_info(notifications)')}
    if 'is_read' not in columns:
        db.execute('ALTER TABLE notifications ADD COLUMN is_read INTEGER NOT NULL DEFAULT 0')
    for user in db.execute('SELECT id, password FROM users').fetchall():
        if not user['password'].startswith(('scrypt:', 'pbkdf2:')):
            db.execute('UPDATE users SET password = ? WHERE id = ?',
                       (generate_password_hash(user['password']), user['id']))
    db.commit()

@app.context_processor
def csrf_context():
    if 'csrf_token' not in session:
        session['csrf_token'] = secrets.token_hex(32)
    return {'csrf_token': session['csrf_token']}

@app.before_request
def protect_forms():
    if request.method == 'POST':
        expected = session.get('csrf_token', '')
        supplied = request.form.get('csrf_token', '')
        if not expected or not hmac.compare_digest(expected, supplied):
            abort(400, description='요청이 만료되었습니다. 페이지를 새로고침하고 다시 시도하세요.')

@app.errorhandler(413)
def upload_too_large(error):
    return '파일을 포함한 요청 크기는 5MB 이하여야 합니다.', 413

def save_upload(file, images_only=False):
    if not file or not file.filename:
        return None
    allowed = {'png', 'jpg', 'jpeg'} if images_only else ALLOWED_EXTENSIONS
    ext = file.filename.rsplit('.', 1)[-1].lower()
    if '.' not in file.filename or ext not in allowed:
        abort(400, description='허용되지 않은 파일 형식입니다.')
    header = file.stream.read(16)
    file.stream.seek(0)
    valid = ((ext == 'png' and header.startswith(b'\x89PNG\r\n\x1a\n')) or
             (ext in {'jpg', 'jpeg'} and header.startswith(b'\xff\xd8\xff')) or
             (ext == 'pdf' and header.startswith(b'%PDF-')))
    if not valid:
        abort(400, description='파일 내용과 확장자가 일치하지 않습니다.')
    filename = f'{uuid.uuid4().hex}.{ext}'
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
    return f'uploads/{filename}'

def visible_club(club_id):
    club = get_db().execute('SELECT * FROM clubs WHERE id = ?', (club_id,)).fetchone()
    if not club:
        abort(404)
    if club['status'] != 'approved' and session.get('role') != 'professor' and club['applicant_id'] != session.get('user_id'):
        abort(403)
    return club

@app.route('/notifications/<int:notification_id>/read', methods=['POST'])
def read_notification(notification_id):
    if 'user_id' not in session:
        return redirect(url_for('login'))
    db = get_db()
    db.execute('UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?',
               (notification_id, session['user_id']))
    db.commit()
    return redirect(url_for('index'))


@app.route('/')
def index():
    keyword = request.args.get('keyword', '')
    category = request.args.get('category', 'all')
    
    db = get_db()
    query = "SELECT * FROM clubs WHERE status = 'approved'"
    params = []
    
    if keyword:
        query += " AND (name LIKE ? OR description LIKE ?)"
        params.extend([f"%{keyword}%", f"%{keyword}%"])
        
    if category != 'all':
        query += " AND category = ?"
        params.append(category)
        
    clubs = db.execute(query, params).fetchall()
    
    favorite_club_ids = []
    notifications = []
    if 'user_id' in session:
        user_id = session['user_id']
        notifications = db.execute('SELECT * FROM notifications WHERE user_id = ? AND is_read = 0 ORDER BY id DESC', (user_id,)).fetchall()
        favs = db.execute('SELECT club_id FROM club_favorites WHERE user_id = ?', (user_id,)).fetchall()
        favorite_club_ids = [f['club_id'] for f in favs]
        
    return render_template('index.html', clubs=clubs, notifications=notifications, keyword=keyword, category=category, favorite_club_ids=favorite_club_ids)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        db = get_db()
        user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        if user and check_password_hash(user['password'], password):
            session.clear()
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['name'] = user['name']
            session['role'] = user['role']
            if user['role'] == 'professor':
                return redirect(url_for('professor_dashboard'))
            else:
                return redirect(url_for('index'))
        return render_template('login.html', error='학번(교번) 또는 비밀번호가 잘못되었습니다.')
    return render_template('login.html')

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        name = request.form['name']
        if not username.strip() or not name.strip() or len(password) < 8:
            return render_template('signup.html', error='학번과 이름을 입력하고 비밀번호를 8자 이상 설정하세요.'), 400
        role = 'student'
        
        db = get_db()
        existing_user = db.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
        if existing_user:
            return render_template('signup.html', error='이미 존재하는 학번입니다.')
            
        db.execute('INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)', (username, generate_password_hash(password), name, role))
        db.commit()
        return redirect(url_for('login'))
        
    return render_template('signup.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/clubs/register', methods=['GET', 'POST'])
def register_club():
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
        
    if request.method == 'POST':
        name = request.form['name']
        category = request.form['category']
        description = request.form['description']
        room_location = request.form['room_location']
        open_chat_link = request.form['open_chat_link']
        if not name.strip() or not description.strip() or category not in {'학술', '공연', '체육', '봉사', '취미', '기타'}:
            abort(400, description='동아리 이름, 소개, 올바른 분류를 입력하세요.')
        file = request.files.get('file')
        
        file_path = save_upload(file, images_only=True)
        
        db = get_db()
        db.execute(
            'INSERT INTO clubs (name, category, description, room_location, open_chat_link, image_path, applicant_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
            (name, category, description, room_location, open_chat_link, file_path, session['user_id'], 'pending')
        )
        db.commit()
        return redirect(url_for('index'))
        
    return render_template('register_club.html')

# 가입 신청서 작성 및 제출 라우트
@app.route('/clubs/apply/<int:club_id>', methods=['GET', 'POST'])
def apply_club(club_id):
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
        
    user_id = session['user_id']
    db = get_db()
    club = visible_club(club_id)
    
    if club['status'] != 'approved':
        abort(403)
    if request.method == 'POST':
        reason = request.form.get('reason', '')
        availability = request.form.get('availability', '')
        goal = request.form.get('goal', '')
        personality = request.form.get('personality', '')
        
        existing = db.execute('SELECT * FROM club_members WHERE club_id = ? AND user_id = ?', (club_id, user_id)).fetchone()
        if not existing:
            db.execute(
                'INSERT INTO club_members (club_id, user_id, reason, availability, goal, personality, status) VALUES (?, ?, ?, ?, ?, ?, ?)',
                (club_id, user_id, reason, availability, goal, personality, 'pending')
            )
            db.commit()
        return redirect(url_for('club_detail', club_id=club_id))
        
    return render_template('club_apply.html', club=club)

# [신규] 가입 신청 취소 라우트
@app.route('/clubs/cancel_apply/<int:club_id>', methods=['POST'])
def cancel_apply(club_id):
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
        
    user_id = session['user_id']
    db = get_db()
    db.execute('DELETE FROM club_members WHERE club_id = ? AND user_id = ? AND status != "approved"', (club_id, user_id))
    db.commit()
    return redirect(request.referrer or url_for('index'))

@app.route('/clubs/favorite/<int:club_id>', methods=['POST'])
def toggle_favorite(club_id):
    if 'user_id' not in session or session['role'] != 'student':
        return redirect(url_for('login'))
        
    visible_club(club_id)
    user_id = session['user_id']
    db = get_db()
    existing = db.execute('SELECT * FROM club_favorites WHERE user_id = ? AND club_id = ?', (user_id, club_id)).fetchone()
    if existing:
        db.execute('DELETE FROM club_favorites WHERE user_id = ? AND club_id = ?', (user_id, club_id))
    else:
        db.execute('INSERT INTO club_favorites (user_id, club_id) VALUES (?, ?)', (user_id, club_id))
    db.commit()
    return redirect(request.referrer or url_for('index'))

@app.route('/clubs/<int:club_id>')
def club_detail(club_id):
    db = get_db()
    club = visible_club(club_id)

    posts = db.execute('SELECT club_posts.*, users.name as author_name FROM club_posts JOIN users ON club_posts.user_id = users.id WHERE club_posts.club_id = ? ORDER BY club_posts.id DESC', (club_id,)).fetchall()
    schedules = db.execute('SELECT * FROM club_schedules WHERE club_id = ? ORDER BY event_date ASC', (club_id,)).fetchall()
    qnas = db.execute('SELECT club_qna.*, users.name as author_name FROM club_qna JOIN users ON club_qna.user_id = users.id WHERE club_qna.club_id = ? ORDER BY club_qna.id DESC', (club_id,)).fetchall()
    
    membership = None
    is_favorite = False
    if 'user_id' in session and session['role'] == 'student':
        user_id = session['user_id']
        membership = db.execute('SELECT * FROM club_members WHERE club_id = ? AND user_id = ?', (club_id, user_id)).fetchone()
        fav = db.execute('SELECT * FROM club_favorites WHERE user_id = ? AND club_id = ?', (user_id, club_id)).fetchone()
        if fav: is_favorite = True
            
    return render_template('club_detail.html', club=club, posts=posts, schedules=schedules, qnas=qnas, membership=membership, is_favorite=is_favorite)

@app.route('/clubs/<int:club_id>/post', methods=['POST'])
def create_club_post(club_id):
    if 'user_id' not in session or session['role'] != 'student': 
        return redirect(url_for('login'))
    
    user_id = session['user_id']
    db = get_db()
    
    # [보안 검증] 오직 해당 동아리의 개설자(회장)만 공지 등록 가능
    club = db.execute('SELECT * FROM clubs WHERE id = ? AND applicant_id = ?', (club_id, user_id)).fetchone()
    if not club or club['status'] != 'approved':
        return "권한이 없습니다.", 403

    title = request.form['title']
    content = request.form['content']
    file = request.files.get('file')
    
    file_path = save_upload(file)

    db.execute('INSERT INTO club_posts (club_id, user_id, title, content, file_path) VALUES (?, ?, ?, ?, ?)', (club_id, user_id, title, content, file_path))
    db.commit()
    return redirect(url_for('club_detail', club_id=club_id))

@app.route('/clubs/<int:club_id>/qna', methods=['POST'])
def add_qna(club_id):
    if 'user_id' not in session or session['role'] != 'student': return redirect(url_for('login'))
    visible_club(club_id)
    question = request.form['question']
    db = get_db()
    db.execute('INSERT INTO club_qna (club_id, user_id, question) VALUES (?, ?, ?)', (club_id, session['user_id'], question))
    db.commit()
    return redirect(url_for('club_detail', club_id=club_id))

@app.route('/clubs/qna/answer/<int:qna_id>', methods=['POST'])
def answer_qna(qna_id):
    if 'user_id' not in session or session['role'] != 'student': return redirect(url_for('login'))
    answer = request.form['answer']
    db = get_db()
    qna = db.execute('SELECT * FROM club_qna WHERE id = ?', (qna_id,)).fetchone()
    if not qna:
        abort(404)
    club = db.execute('SELECT * FROM clubs WHERE id = ? AND applicant_id = ?', (qna['club_id'], session['user_id'])).fetchone()
    if not club:
        abort(403)
    if club:
        db.execute('UPDATE club_qna SET answer = ? WHERE id = ?', (answer, qna_id))
        db.commit()
    return redirect(url_for('club_detail', club_id=qna['club_id']))

@app.route('/student/mypage')
def student_mypage():
    if 'user_id' not in session or session['role'] != 'student': return redirect(url_for('login'))
    user_id = session['user_id']
    db = get_db()
    my_applications = db.execute('SELECT clubs.id as club_id, clubs.name, clubs.category, club_members.status, club_members.reason, club_members.availability, club_members.goal, club_members.personality FROM club_members JOIN clubs ON club_members.club_id = clubs.id WHERE club_members.user_id = ?', (user_id,)).fetchall()
    my_clubs = db.execute('SELECT * FROM clubs WHERE applicant_id = ?', (user_id,)).fetchall()
    my_favorites = db.execute('SELECT clubs.id as club_id, clubs.name, clubs.category, clubs.description, clubs.image_path FROM club_favorites JOIN clubs ON club_favorites.club_id = clubs.id WHERE club_favorites.user_id = ?', (user_id,)).fetchall()
    
    applicants = []
    if any(c['status'] == 'approved' for c in my_clubs):
        club_ids = [c['id'] for c in my_clubs if c['status'] == 'approved']
        placeholders = ','.join(['?'] * len(club_ids))
        applicants = db.execute(f'SELECT club_members.id as member_id, clubs.name as club_name, users.name as student_name, users.username as student_no, club_members.status, club_members.reason, club_members.availability, club_members.goal, club_members.personality FROM club_members JOIN clubs ON club_members.club_id = clubs.id JOIN users ON club_members.user_id = users.id WHERE club_members.club_id IN ({placeholders})', club_ids).fetchall()
        
    return render_template('student_mypage.html', my_applications=my_applications, my_clubs=my_clubs, my_favorites=my_favorites, applicants=applicants)

@app.route('/student/manage_member', methods=['POST'])
def manage_member():
    if 'user_id' not in session or session['role'] != 'student': return redirect(url_for('login'))
    member_id, action = request.form['member_id'], request.form['action']
    if action not in {'approve', 'reject'}:
        abort(400)
    new_status = 'approved' if action == 'approve' else 'rejected'
    db = get_db()
    mem = db.execute('SELECT club_members.*, clubs.name as club_name, club_members.user_id FROM club_members JOIN clubs ON club_members.club_id = clubs.id WHERE club_members.id = ?', (member_id,)).fetchone()
    if not mem:
        abort(404)
    club = db.execute('SELECT * FROM clubs WHERE id = ?', (mem['club_id'],)).fetchone()
    if not club or club['applicant_id'] != session['user_id'] or club['status'] != 'approved':
        abort(403)
    updated = db.execute("UPDATE club_members SET status = ? WHERE id = ? AND status = 'pending'", (new_status, member_id))
    if updated.rowcount:
        msg = f"'{mem['club_name']}' 동아리 가입 신청이 {'승인' if new_status == 'approved' else '거절'}되었습니다."
        db.execute('INSERT INTO notifications (user_id, message) VALUES (?, ?)', (mem['user_id'], msg))
    db.commit()
    return redirect(url_for('student_mypage'))

@app.route('/professor/dashboard', methods=['GET', 'POST'])
def professor_dashboard():
    if 'user_id' not in session or session['role'] != 'professor': return redirect(url_for('login'))
    db = get_db()
    if request.method == 'POST':
        club_id, action = request.form['club_id'], request.form['action']
        if action not in {'approve', 'reject'}:
            abort(400)
        club = db.execute('SELECT * FROM clubs WHERE id = ?', (club_id,)).fetchone()
        if not club:
            abort(404)
        if club['status'] != 'pending':
            return redirect(url_for('professor_dashboard'))
        new_status = 'approved' if action == 'approve' else 'rejected'
        updated = db.execute("UPDATE clubs SET status = ? WHERE id = ? AND status = 'pending'", (new_status, club_id))
        if not updated.rowcount:
            db.commit()
            return redirect(url_for('professor_dashboard'))
        club = db.execute('SELECT * FROM clubs WHERE id = ?', (club_id,)).fetchone()
        msg = f"'{club['name']}' 동아리 개설 신청이 {'승인' if new_status == 'approved' else '반려'}되었습니다."
        db.execute('INSERT INTO notifications (user_id, message) VALUES (?, ?)', (club['applicant_id'], msg))
        db.commit()
        return redirect(url_for('professor_dashboard'))
    pending_clubs = db.execute("SELECT * FROM clubs WHERE status = 'pending'").fetchall()
    all_clubs = db.execute("SELECT * FROM clubs").fetchall()
    return render_template('professor_dashboard.html', pending_clubs=pending_clubs, all_clubs=all_clubs)

if __name__ == '__main__':
    app.run(debug=os.environ.get('KDU_DEBUG') == '1')