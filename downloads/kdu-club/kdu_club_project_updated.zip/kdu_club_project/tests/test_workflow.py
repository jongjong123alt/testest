"""원본 DB와 업로드 파일을 건드리지 않는 회귀 검증."""
import os
import sys
import tempfile
import unittest
from io import BytesIO
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
_sandbox = tempfile.TemporaryDirectory()
os.environ['KDU_DATABASE'] = str(Path(_sandbox.name) / 'initial.db')
import app as module
from werkzeug.security import generate_password_hash, check_password_hash

class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        module.DATABASE = str(Path(self.temp.name) / 'test.db')
        module.app.config.update(TESTING=True, UPLOAD_FOLDER=str(Path(self.temp.name) / 'uploads'))
        module.init_db()
        with module.app.app_context():
            db = module.get_db()
            for row in db.execute('SELECT id,password FROM users').fetchall():
                db.execute('UPDATE users SET password=? WHERE id=?', (generate_password_hash(row['password']),row['id']))
            db.execute('INSERT INTO users(username,password,name,role) VALUES(?,?,?,?)', ('other',generate_password_hash('password123'),'다른학생','student'))
            db.execute('INSERT INTO users(username,password,name,role) VALUES(?,?,?,?)', ('outsider',generate_password_hash('password123'),'무관한학생','student'))
            db.commit()
        self.owner = self.client(1)
        self.prof = self.client(2, 'professor')
        self.student = self.client(3)
        self.outsider = self.client(4)

    def tearDown(self):
        self.temp.cleanup()

    def client(self, uid, role='student'):
        c = module.app.test_client()
        with c.session_transaction() as session:
            session.update(user_id=uid, role=role, name='테스트', csrf_token='token')
        return c

    def post(self,c,path,data=None):
        return c.post(path, data={'csrf_token':'token', **(data or {})})

    def rows(self,sql,params=()):
        with module.app.app_context():
            return [dict(r) for r in module.get_db().execute(sql,params)]

    def register(self, **extra):
        return self.post(self.owner,'/clubs/register',dict(name='새동아리',category='학술',description='설명',room_location='301',open_chat_link='',**extra))

    def test_creation_requires_professor_and_notifies_once(self):
        self.assertEqual(self.register().status_code,302)
        cid=self.rows('SELECT id FROM clubs WHERE name=?',('새동아리',))[0]['id']
        self.assertEqual(self.rows('SELECT status FROM clubs WHERE id=?',(cid,))[0]['status'],'pending')
        self.assertNotIn('새동아리',self.student.get('/').text)
        self.assertEqual(self.student.get(f'/clubs/{cid}').status_code,403)
        self.assertEqual(self.owner.get(f'/clubs/{cid}').status_code,200)
        self.assertIn('승인 대기',self.owner.get('/student/mypage').text)
        for _ in range(2): self.assertEqual(self.post(self.prof,'/professor/dashboard',dict(club_id=cid,action='approve')).status_code,302)
        notices=self.rows('SELECT * FROM notifications')
        self.assertEqual(len(notices),1); self.assertEqual(notices[0]['user_id'],1)
        self.assertIn('새동아리',self.student.get('/').text)

    def test_membership_authorization_and_notification_recipient(self):
        self.post(self.student,'/clubs/apply/1',dict(reason='공부'))
        mid=self.rows('SELECT id FROM club_members')[0]['id']
        data=dict(member_id=mid,action='approve')
        self.assertEqual(self.post(self.outsider,'/student/manage_member',data).status_code,403)
        for _ in range(2): self.assertEqual(self.post(self.owner,'/student/manage_member',data).status_code,302)
        self.assertEqual(self.rows('SELECT user_id FROM notifications'),[{'user_id':3}])
        self.assertEqual(self.rows('SELECT status FROM club_members')[0]['status'],'approved')

    def test_notification_read_is_scoped_to_owner(self):
        self.post(self.student,'/clubs/apply/1')
        mid=self.rows('SELECT id FROM club_members')[0]['id']
        self.post(self.owner,'/student/manage_member',dict(member_id=mid,action='reject'))
        nid=self.rows('SELECT id FROM notifications')[0]['id']
        self.post(self.outsider,f'/notifications/{nid}/read')
        self.assertEqual(self.rows('SELECT is_read FROM notifications')[0]['is_read'],0)
        self.post(self.student,f'/notifications/{nid}/read')
        self.assertEqual(self.rows('SELECT is_read FROM notifications')[0]['is_read'],1)

    def test_search_filter_and_injection(self):
        c=module.app.test_client()
        r=c.get('/',query_string={'keyword':'코딩','category':'학술'})
        self.assertEqual(r.status_code,200)
        self.assertIn('KDU 코딩클럽',r.text); self.assertNotIn('사운드웨이브',r.text)
        r=c.get('/',query_string={'keyword':"' OR 1=1 --",'category':"'"})
        self.assertEqual(r.status_code,200)
        self.assertNotIn('KDU 코딩클럽',r.text)
        self.assertEqual(len(self.rows('SELECT * FROM clubs')),3)

    def test_upload_rejects_extension_content_and_size(self):
        for name, body, status in [('bad.exe',b'MZ',400),('bad.png',b'not an image',400),('huge.png',b'\x89PNG\r\n\x1a\n'+b'x'*(5*1024*1024),413)]:
            with self.subTest(name=name):
                self.assertEqual(self.register(file=(BytesIO(body),name)).status_code,status)
        self.assertEqual(len(self.rows('SELECT * FROM clubs')),3)

    def test_valid_upload_and_pdf_post(self):
        image=next((Path(module.BASE_DIR)/'static/uploads').glob('*.png')).read_bytes()
        self.assertEqual(self.register(file=(BytesIO(image),'poster.png')).status_code,302)
        self.assertEqual(self.post(self.owner,'/clubs/1/post',dict(title='안내',content='내용',file=(BytesIO(b'%PDF-1.4\n'),'notice.pdf'))).status_code,302)
        self.assertIn('PDF 첨부파일 보기',self.owner.get('/clubs/1').text)

    def test_csrf_rejected(self):
        self.assertEqual(self.owner.post('/clubs/register',data={}).status_code,400)

    def test_password_hash_and_login(self):
        c=module.app.test_client(); c.get('/signup')
        with c.session_transaction() as session: token=session['csrf_token']
        self.assertEqual(c.post('/signup',data=dict(csrf_token=token,username='new',password='secure123',name='신규')).status_code,302)
        password=self.rows('SELECT password FROM users WHERE username=?',('new',))[0]['password']
        self.assertNotEqual(password,'secure123'); self.assertTrue(check_password_hash(password,'secure123'))
        self.assertEqual(c.post('/login',data=dict(csrf_token=token,username='new',password='wrong')).status_code,200)
        with c.session_transaction() as session: self.assertNotIn('user_id',session)
        self.assertEqual(c.post('/login',data=dict(csrf_token=token,username='new',password='secure123')).status_code,302)
        with c.session_transaction() as session: self.assertEqual(session['role'],'student')

    def test_unknown_ids_and_invalid_actions(self):
        self.assertEqual(self.student.get('/clubs/999').status_code,404)
        self.assertEqual(self.student.get('/clubs/apply/999').status_code,404)
        self.assertEqual(self.post(self.owner,'/clubs/qna/answer/999',dict(answer='답변')).status_code,404)
        self.assertEqual(self.post(self.prof,'/professor/dashboard',dict(club_id=1,action='bad')).status_code,400)
        self.assertEqual(self.post(self.prof,'/professor/dashboard',dict(club_id=999,action='approve')).status_code,404)

    def test_screens_render(self):
        for path in ('/','/clubs/1','/clubs/apply/1','/student/mypage','/clubs/register'):
            self.assertEqual(self.owner.get(path).status_code,200,path)
        self.assertEqual(self.prof.get('/professor/dashboard').status_code,200)

if __name__=='__main__': unittest.main()
