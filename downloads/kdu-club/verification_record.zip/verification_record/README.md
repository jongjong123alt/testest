# 검증 기록 제출 자료

현재 코드(Git 7e45c93)를 바탕으로 재구성한 비교용 초안이며, 코드 구성·수정 및 테스트는 AI가 수행했습니다. 본인 직접 수행 여부는 확인 필요입니다.

- ai_revision_verification.docx / pdf: 검증 기록 문서
- ai_draft.zip: 비교용 초안 전체 실행 코드
- final_code.zip: 최종 전체 실행 코드
- code_comparison.md: 수정 위치·전후 코드·이유
- code_changes.diff: app.py의 정확한 변경점
- evidence/: 실행 로그·변경 내역·종료 코드

압축 해제 후 각 코드 폴더에서 python app.py를 실행하세요. Python 3.10 이상(3.12 권장)이 필요하고 최초 라이브러리 설치에는 인터넷 연결이 필요합니다. 초안은 비교 학습용이며 실제 사용할 실행본은 final_code입니다.
