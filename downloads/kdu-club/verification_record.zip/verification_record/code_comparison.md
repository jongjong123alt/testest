# AI 초안 수정 및 검증 기록

현재 코드(Git 7e45c93)를 바탕으로 재구성한 비교용 초안이며, 코드 구성·수정 및 테스트는 AI가 수행했습니다. 본인 직접 수행 여부는 확인 필요입니다.

작성일: 2026-10-19 | 언어: Python | Flask·SQLite | 검증 환경: Linux Python 3.12

## 1. 비교 대상과 실행 방법
ai_draft/는 이름 검색·PDF 첨부·개별 알림 읽음을 중심으로 범위를 축소한 코드입니다. final_code/는 현재 실행 코드 사본입니다. 계정 권한, SQL 매개변수 바인딩, 파일 용량 제한, 알림 중복·수신자 검사는 초안에도 유지했습니다.

각 폴더에서 `python app.py`로 실행합니다. Python 3.10 이상(3.12 권장)과 최초 의존성 설치 시 인터넷 연결이 필요합니다. 학생: kdu_student / sample1234, 교수: kdu_professor / sample1234.

## 2. 수정 위치·코드·이유

### 1. 검색 범위 확대
app.py / index(): 초안 312행, 최종 312행
이름만 검색하는 범위를 소개와 캠퍼스까지 확대했습니다. 입력값은 계속 ? 매개변수로 전달하여 따옴표를 SQL 문법으로 처리하지 않습니다.

수정 전:
```python
def index():
    keyword = request.args.get('keyword', '').strip()
    category = request.args.get('category', 'all')
    query = "SELECT * FROM clubs WHERE status='approved'"
    params = []
    if keyword:
        query += ' AND name LIKE ?'
        params.append(f'%{keyword}%')
    if category != 'all':
        aliases={'예술':['예술','공연'],'사회·봉사':['사회·봉사','봉사']}
        selected=aliases.get(category,[category])
        query += ' AND category IN ('+','.join('?' for _ in selected)+')'
        params.extend(selected)
    clubs = [club_view(c) for c in rows(query + ' ORDER BY id', params)]
    recruiting_only = request.args.get('recruiting') == '1'
    if recruiting_only:
        clubs = [c for c in clubs if c['recruitment']['open']]
    favorites = {r['club_id'] for r in rows('SELECT club_id FROM club_favorites WHERE user_id=?', (session.get('user_id', 0),))}
    return render_template('index.html', clubs=clubs, keyword=keyword, category=category,
                           recruiting_only=recruiting_only, favorite_club_ids=favorites)
```

수정 후:
```python
def index():
    keyword = request.args.get('keyword', '').strip()
    category = request.args.get('category', 'all')
    query = "SELECT * FROM clubs WHERE status='approved'"
    params = []
    if keyword:
        query += ' AND (name LIKE ? OR description LIKE ? OR campus LIKE ?)'
        params.extend([f'%{keyword}%'] * 3)
    if category != 'all':
        aliases={'예술':['예술','공연'],'사회·봉사':['사회·봉사','봉사']}
        selected=aliases.get(category,[category])
        query += ' AND category IN ('+','.join('?' for _ in selected)+')'
        params.extend(selected)
    clubs = [club_view(c) for c in rows(query + ' ORDER BY id', params)]
    recruiting_only = request.args.get('recruiting') == '1'
    if recruiting_only:
        clubs = [c for c in clubs if c['recruitment']['open']]
    favorites = {r['club_id'] for r in rows('SELECT club_id FROM club_favorites WHERE user_id=?', (session.get('user_id', 0),))}
    return render_template('index.html', clubs=clubs, keyword=keyword, category=category,
                           recruiting_only=recruiting_only, favorite_club_ids=favorites)
```

### 2. 첨부 형식 확대
app.py / validated_upload(): 초안 748행, 최종 749행
PDF만 받는 범위를 PDF/HWP/DOCX/JPG/PNG로 확대하고 이미지·문서 형식 검사를 추가했습니다. 10MiB 용량 제한과 금지 확장자 거부는 두 버전 모두 유지합니다.

수정 전:
```python
def validated_upload(file):
    """PDF 첨부의 용량과 헤더를 확인합니다."""
    data = file.read(10 * 1024 * 1024 + 1)
    if len(data) > 10 * 1024 * 1024:
        raise ValueError('파일은 각각 10MB 이하여야 합니다.')
    ext = Path(file.filename or '').suffix.lower()
    if ext != '.pdf' or not data.startswith(b'%PDF-'):
        raise ValueError('PDF 파일만 첨부할 수 있습니다.')
    return data, ext
```

수정 후:
```python
def validated_upload(file):
    """용량·실제 형식을 검사합니다. 파일 이름은 표시용으로만 사용합니다."""
    data=file.read(10*1024*1024+1)
    if len(data)>10*1024*1024:
        raise ValueError('파일은 각각 10MB 이하여야 합니다. 작성 내용은 유지됩니다.')
    if not data:
        raise ValueError('빈 파일은 첨부할 수 없습니다.')
    ext=Path(file.filename or '').suffix.lower()
    if ext in {'.jpg','.jpeg','.png'}:
        try:
            with Image.open(io.BytesIO(data)) as image:
                if image.format not in ({'PNG'} if ext=='.png' else {'JPEG'}):
                    raise ValueError()
                image.verify()
        except (UnidentifiedImageError,OSError,ValueError,Image.DecompressionBombError):
            raise ValueError('이미지 내용과 확장자가 일치하지 않거나 이미지가 손상되었습니다.')
    elif ext=='.pdf':
        if not data.startswith(b'%PDF-'):
            raise ValueError('PDF 형식을 확인해주세요.')
    elif ext=='.hwp':
        if not data.startswith(b'\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1'):
            raise ValueError('HWP 형식을 확인해주세요.')
    elif ext=='.docx':
        try:
            with zipfile.ZipFile(io.BytesIO(data)) as archive:
                if 'word/document.xml' not in archive.namelist() or sum(f.file_size for f in archive.infolist())>100*1024*1024:
                    raise ValueError()
        except (zipfile.BadZipFile,ValueError):
            raise ValueError('DOCX 형식을 확인해주세요.')
    else:
        raise ValueError('PDF, HWP, DOCX, JPG, PNG 파일만 첨부할 수 있습니다.')
    return data,ext
```

### 3. 알림 일괄 읽음 처리
app.py / read_all_notifications(): 초안 569행, 최종 569행
개별 읽음만 안내하던 처리를 현재 로그인한 사용자의 알림만 일괄 갱신하도록 바꿨습니다. 중복 알림 방지 및 수신자 제한은 기존 기능이며 별도로 검증합니다.

수정 전:
```python
def read_all_notifications():
    student_required()
    flash('알림을 하나씩 선택하여 읽음 처리해주세요.', 'info')
    return redirect(url_for('notifications'))
```

수정 후:
```python
def read_all_notifications():
    student_required()
    get_db().execute('UPDATE notifications SET is_read=1 WHERE user_id=?', (session['user_id'],))
    get_db().commit()
    return redirect(url_for('notifications'))
```

## 3. 7장 체크리스트 점검

### 외부 API 연동
API 요청 실패 처리와 API 키 노출 여부
외부 API 기능을 선택하지 않아 해당 없음. 학교 SSO·외부 메시지 발송을 구현하지 않았습니다.

### 파일 업로드
금지 확장자 또는 지나치게 큰 파일 거부
두 버전 모두 해당 테스트 통과. bad.exe, 손상된 이미지/PDF/DOCX, 10MiB 초과 파일을 거부하고 첨부 DB에 저장하지 않는지 검사합니다. 최종본은 정상 PNG/PDF/HWP/DOCX 허용 테스트도 통과했습니다.

### 검색·필터
특수문자·따옴표 입력 시 오류 없이 동작하고 SQL 인젝션 방지
두 버전 모두 해당 테스트 통과. 따옴표 및 SQL 형태 문자열을 입력하여 HTTP 200, 불필요한 결과 없음, 동아리 데이터 유지 여부를 검사합니다. 소개·캠퍼스 검색은 추가 기능 검사로 초안 실패, 최종 통과입니다.

### 알림
동일 이벤트 중복 방지 및 잘못된 수신자 방지
두 버전 모두 중복 심사·수신자 검사 통과. 개설/가입 승인 반복 시 알림 중복 여부와 수신자 ID를 확인합니다. 다른 사용자의 알림 접근을 차단하는지도 검사합니다. 일괄 읽음 범위 검사는 초안 실패, 최종 통과입니다.

## 4. 실제 테스트 결과
실행 명령: `python -m unittest discover -s tests -v`
초안: 50개 실행 / 45개 통과 / 실패 3개 / 오류 2개
최종: 50개 실행 / 50개 통과 / 실패 0개 / 오류 0개

- test_description_and_campus_search: 소개·캠퍼스 검색 결과가 없음. index()의 LIKE 검색 범위를 확대.
- test_valid_file_formats: 정상 PNG 업로드가 400으로 거부됨. validated_upload()의 허용 형식과 실제 내용 검사 확대.
- test_read_all_scoped: 본인 알림이 읽음으로 바뀌지 않음. read_all_notifications()에서 user_id 조건으로 UPDATE.
- test_post_attachment_limit_and_cross_club / test_post_validation_preserves_fields: PNG 업로드가 거부되어 응답에 id가 없고 테스트에서 KeyError 발생. 첨부 형식 확대로 정상 PNG 업로드 응답에 id 제공.

## 5. 검증 한계
Linux Python 3.12에서 테스트 코드를 실행했습니다. Windows·브라우저 수동 조작은 미실행입니다. 학생 본인의 직접 수정 및 직접 실행 여부는 확인 필요입니다.

상세 로그: evidence/ai_draft_tests.log, evidence/final_code_tests.log
