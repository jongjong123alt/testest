# IG04 Core 공유 형식 후보 P1-R1

- ID: `IG04-CORE-SHARED-FORMATS-20261102-P1-R1` / 2026-11-02 KST / 작성 윤종민.
- 상태: **Core 제안·UNAPPROVED / M1 BLOCKED / 실제 연결 착수 안 함**.
- 범위: 기존에 수락한 J1~J5의 공유 자료와 결과 표현 구체화. 새 기능 추가·복원 원칙 재검토·Server/Content 업무 재배정 없음.
- 이 폴더는 저장소 밖 검토 자료다. 아래 이름·필드·상태 값은 **후보 DTO/fixture**이며 기존 #87 API, 승인된 Wire enum/Schema/endpoint 또는 구현된 provider가 아니다. 공동 확인 전 제품에서 소비/활성화하지 않는다.

기존 RC2의 BindingScope/CleanupGrant/Control, #88 admission, #87 context/plan/transport·gate·Ledger 복원/완료 규칙을 재사용한다. 계약 파일이나 제품 코드를 수정하지 않았다. M2/M4 private key·원장·CAS·writer/cutoff 구현은 Core 소유로 남긴다.

## 검토할 파일

| 파일 | 용도 |
|---|---|
| `SPEC.md` | 공유 형식5개, 필드 타입·상태·실패 의미·callback 대응·결정 요청 |
| `fixtures.json` | 회원 focus **합성** context, 같은 claim의 P1/P2·다른 계획/최종 목표, 실제 RC2 형상의 Grant/RELEASE, 공유 근거/조회/인수 후보 예시 |
| `build-fixtures.mjs` | 기존 Core canonical/digest로 fixture를 재생성. 제품 IO 없음 |
| `seed-footprint.json` | 앞서 작성한 미승인 합성 profile 예시를 재사용한 seed. 실제 runtime-only 발급 근거가 아님 |
| `check-fixtures.mjs` | 기존 Core/Content canonical 교차 대조와 후보 관계·변조/실패 예시 검사. 완전한 production parser/인증 validator가 아님 |
| `validation-results.json` | **후보 fixture 정합성 37/37**, 제품 시험 수가 아님 |
| `rc2-compatibility.json` | 합성 scope1/Grant2/RELEASE2의 기존 RC2 정의 구조 검증 **5/5** |
| `source-and-files.json` | 고정 source pin·blob 및 자료 SHA-256 식별 |
| `review-request.md` | 다훈·지민에게 전달할 검토 요청 |

현재 `context/plan/reservation_identity/transport`, reserve의 exact plan_id 및 verifyCompletion strict true는 유지한다. 새 근거·local 미호출 종료·cleanup-only 인수의 producer/consumer seam은 아직 구현되지 않았다. true/accepted·본문 hash/opaque ID만으로 native 권한·영속 commit·복원 성공을 인정하지 않는다.

## 실행과 검증 한계

Node24에서 기존 고정 소스 checkout을 지정한다. fixture 경로 외에는 쓰지 않고 브라우저·서비스·실제 세션·DB를 열지 않는다.

```bash
# source pins: Core ed8755a5… / Content 2704148b…
IG04_CORE_ROOT=/path/to/core IG04_CONTENT_ROOT=/path/to/content node build-fixtures.mjs
IG04_CORE_ROOT=/path/to/core IG04_CONTENT_ROOT=/path/to/content node check-fixtures.mjs
# 기존 계약의 Python jsonschema 의존성이 설치된 경우:
IG04_CORE_ROOT=/path/to/core python3 check-rc2.py
```

소스가 같아야 기존 helpers의 같은 bytes/digest 근거를 재사용할 수 있다. fixture는 실제 발급된 operation·native truth·동작 권한이 아니다. 미래 timestamp나 임의 known UUID가 유효한 lease를 만들지 않는다.

기존 RC2 구조 검사에서 처음에는 선택한 하위 정의와 함께 root message oneOf를 남긴 검증 도구 설정 오류가 있었다. 하위 정의 참조용 envelope만 바로잡아5/5 확인했고, 원본 Schema/fixture의 제약을 완화하지 않았다. 대규모 제품/기존 전체 시험은 이번 범위에서 재실행하지 않았다.

## 종료·다음 행동

Core 후보 명세/fixture/정합성 검사와 인계 자료 작성 완료. **이 새 공유 형식 제안은 담당 검토 필요**하다. 지민이는 실제 #87에서 추가할 수 있는 근거/종료/인수 seam과 DTO 호환을, 다훈은 기존 RC2·발급/복원·권한/보존 의미 충돌 여부만 확인한다. 내부 Core 저장 구현 재승인을 요청하지 않는다.

같은 후보 ID·자료 hash로 수정 의견/선택을 합쳐 공유 형식을 확정한다. **다섯 형식 합의 후에도 M1 BLOCKED는 해제되지 않으며 실제 연결 착수는 별도 결정**이다. 제품 저장소의 새 PR·Commit/Push/Merge·제품 코드/Schema/DB·다른 worktree/index 변경 및 실제 START/END는 수행하지 않았다.

## P1 독립 검토 보완

`REPAIR.md`의 변경 규칙이 아래 원문 설명보다 우선한다. 원래 cleanup property 완전성과 resource/claim·property 중복 거절을 보완했다. 원래 24건 + 새 거절 12건 + terminal 없는 부분 진행 1건 = **37/37**이다. `repair-fixtures.json`, `repair-results.json`, `before-results.json`, `after-results.json`에서 변경 예시와 전후 결과를 확인할 수 있다.

`scan_scheduled=true` + fenced callback 허용은 기존 P1 후보 규칙을 그대로 둔 것이며 합의 완료가 아니다. 지민과 예약 scan 0 필수안의 선택이 남아 있다. M1은 계속 BLOCKED다.
