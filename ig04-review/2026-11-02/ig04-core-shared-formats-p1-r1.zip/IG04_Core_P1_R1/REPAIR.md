# P1-R1 수정 범위

후보: IG04-CORE-SHARED-FORMATS-20261102-P1-R1
상태: 변경분 검토 대기 / M1 BLOCKED / 제품 코드 변경 없음

기존 P1 검사기가 원래 cleanup property 완전성과 중복 결과를 검사하지 않아 잘못된 RESTORED terminal을 허용했다. inert 누락, display 상충 중복, resource/claim 행 상충 중복의 세 형태를 기존 P1에서 재현했다. evidence hash를 다시 계산한 같은 반례를 R1에서는 모두 거절한다.

원래 plan에서 얻은 필수 property 전체를 RESTORED_LOCAL에서 요구하며, resource/claim 행과 각 property를 유일하게 제한한다. 동일 값 중복도 거절한다. PARTIAL_LOCAL은 terminal로 승격되지 않으며 미해결 의무를 유지한다. 상세 규칙은 SPEC.md의 마지막 절에 있다.

검증: 후보 관계 검사 37/37 (기존 24 + 거절 반례 12 + 부분 진행 1), 기존 RC2 하위 정의 구조 5/5. before-results.json·after-results.json은 같은 원본 P1 fixture의 동일 반례 전후 결과다. repair-fixtures.json의 mutation은 check-fixtures.mjs가 실제 적용·재해시해 검사한다.

기준 fixture의 proposal_id 외 모든 값 및 canonical/footprint/hash 구조 동일, 기존 P1 자료 원본 보존. scan_scheduled 허용 여부는 지민과 공동 결정 대기이며 이번 검사 통과는 그 선택의 승인이 아니다. 실제 Chrome·권한 provider·영속 저장·제품 통합은 검증하지 않았다.
