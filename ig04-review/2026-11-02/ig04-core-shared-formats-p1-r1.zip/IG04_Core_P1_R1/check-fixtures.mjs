// Candidate document/fixture checks only. No real provider, ledger, storage,
// reservation, channel authentication, authority or cleanup proof verification.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const core=process.env.IG04_CORE_ROOT||'/workspace/focurve-ig04-verification-lifetime';
const content=process.env.IG04_CONTENT_ROOT||'/workspace/review-ig04-receiver';
const {canonical,digest}=await import(pathToFileURL(core+'/extension/a1/contract.mjs'));
const {canonical:contentCanonical,localDigest}=await import(pathToFileURL(content+'/extension/content/local-evidence.mjs'));
const f=JSON.parse(await readFile(new URL('fixtures.json',import.meta.url)));
const same=(a,b)=>canonical(a)===canonical(b),uuid=x=>typeof x==='string'&&/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/.test(x);
const identityKey=x=>canonical(x);
const unique=(a,message)=>assert.equal(new Set(a).size,a.length,message);
const exact=(o,keys)=>assert.deepEqual(Object.keys(o).sort(),keys.sort());
async function check(d){
 assert.equal(d.status,'UNAPPROVED');assert.equal(d.synthetic,true);assert.equal(d.m1,'BLOCKED');
 const ctx=await digest(d.context);assert.equal(await localDigest(d.context),ctx);
 unique(d.plans.map(p=>p.plan_id));unique(d.grants.map(g=>g.grant_id));
 for(let i=0;i<d.plans.length;i++){
  const p=d.plans[i],{reservation_identity:r,...base}=p;
  // The original admitted IG04 plan, not the submitted cleanup result, owns
  // the property scope. This is the unchanged #88 display/inert plan shape.
  assert.deepEqual(p.properties.map(p=>p.property),['display','inert'],'INVALID_ORIGINAL_PLAN_PROPERTIES');
  assert.equal(r.context_sha256,ctx);assert.equal(r.plan_sha256,await digest({...base,context_sha256:ctx}));
  assert.equal(r.operation_id,d.context.operation_id);assert.equal(r.generation,d.context.scope.generation);assert.equal(r.plan_id,p.plan_id);
  const input=['FOCURVE_IG04_PLAN_FOOTPRINT_1',d.context,p,d.transport],vector=d.footprints[i],grant=d.grants[i];
  assert.equal(canonical(input),contentCanonical(input));assert.equal(vector.canonical_utf8,canonical(input));
  assert.equal(vector.sha256,await digest(input));assert.equal(vector.sha256,await localDigest(input));
  assert.notEqual(vector.sha256,r.plan_sha256);assert.equal(grant.footprint_sha256,vector.sha256);
  assert(same(grant.scope,d.context.scope));assert.equal(grant.operation_slots,1);assert.equal(grant.receipt_slots,1);
  const c=d.cleanup_controls[i].payload,{semantic_sha256,channel_credential,...semantic}=c;
  assert.equal(semantic_sha256,await digest(semantic));assert.equal(c.operation_id,grant.reserved_operation_id);assert.equal(c.cleanup_grant_id,grant.grant_id);
 }
 const evidence=d.claim_cleanup,watch=d.watch_cleanup;
 for(const e of [evidence,watch]){const {evidence_sha256,...raw}=e;assert.equal(evidence_sha256,await digest(raw));assert.equal(e.context_sha256,ctx);assert(same(e.transport,d.transport));}
 assert.equal(evidence.cutoff_ref,watch.cutoff_ref);unique(evidence.members.map(m=>identityKey(m.identity)));
 const expectedResources=new Map();
 for(const m of evidence.members){
  const p=d.plans.find(p=>same(p.reservation_identity,m.identity));assert(p);assert.equal(p.claim,m.claim);
  const key=canonical([m.resource_ref,m.claim]);
  if(!expectedResources.has(key))expectedResources.set(key,new Set());
  for(const property of p.properties)expectedResources.get(key).add(property.property);
 }
 unique(evidence.resources.map(r=>canonical([r.resource_ref,r.claim])),'DUPLICATE_CLEANUP_RESOURCE');
 const actualResources=new Set();
 for(const r of evidence.resources){
  const key=canonical([r.resource_ref,r.claim]),expected=expectedResources.get(key);
  assert(expected,'UNEXPECTED_CLEANUP_RESOURCE');
  assert(!actualResources.has(key),'DUPLICATE_CLEANUP_RESOURCE');actualResources.add(key);
  const properties=new Set();
  for(const property of r.properties){
   assert(expected.has(property.property),'UNEXPECTED_CLEANUP_PROPERTY');
   assert(!properties.has(property.property),'DUPLICATE_CLEANUP_PROPERTY');properties.add(property.property);
  }
  if(evidence.result==='RESTORED_LOCAL')assert.deepEqual([...properties].sort(),[...expected].sort(),'INCOMPLETE_CLEANUP_PROPERTIES');
 }
 // Retain P1's required member/resource relation for every result. A PARTIAL
 // observation may omit unconfirmed properties, never certify their cleanup.
 assert.equal(actualResources.size,expectedResources.size,'INCOMPLETE_CLEANUP_RESOURCES');
 if(evidence.result==='RESTORED_LOCAL'){
  assert.equal(evidence.error_count,0);
  for(const r of evidence.resources)for(const p of r.properties){assert.equal(p.own_claim_remaining,false);assert.equal(p.pending_restore,false);assert.equal(p.other_claims_preserved,true);assert(same(p.goal,p.observed));}
 }
 if(watch.result==='CLOSED_LOCAL'){
  assert.equal(watch.observer_stopped,true);assert.equal(watch.listeners_detached,true);assert.equal(watch.scan_in_progress,false);
  assert.equal(watch.future_effects_closed,true);if(watch.scan_scheduled)assert.equal(watch.scheduled_callbacks_fenced,true);
 }
 const recon=d.dispatch_reconciliation;assert.equal(recon.context_sha256,ctx);assert.equal(recon.cutoff_ref,watch.cutoff_ref);assert.equal(recon.watch_ref,watch.watch_ref);
 unique(recon.entries.map(e=>e.local_plan_id));
 for(const r of recon.entries){
  if(r.identity){assert.equal(r.identity.plan_id,r.local_plan_id);assert.equal(r.identity.context_sha256,ctx);assert(d.plans.some(p=>same(p.reservation_identity,r.identity)));}
  if(r.call_state==='CALLED'){assert(r.identity);assert(uuid(r.dispatch_ref));assert(watch.accounted_dispatches.some(i=>same(i,r.identity)));}
  if(r.resolution==='RESERVATION_CONFIRMED'){assert(r.identity);assert.equal(r.lookup,'FOUND');assert(uuid(r.result_ref));}
  if(r.resolution==='LOCAL_UNCALLED_CLOSED'){assert.equal(r.call_state,'NOT_CALLED');assert.equal(r.dispatch_ref,null);assert.equal(r.lookup,'NOT_FOUND');assert(uuid(r.closure_ref));assert(uuid(r.result_ref));}
 }
 for(const q of d.completion_queries){
  assert.equal(q.context_sha256,ctx);const i=d.plans.findIndex(p=>same(p.reservation_identity,q.identity));assert(i>=0);const grant=d.grants[i];
  assert.equal(q.cleanup_operation_id,grant.reserved_operation_id);assert.equal(q.cleanup_semantic_sha256,d.cleanup_controls[i].payload.semantic_sha256);assert.equal(q.reserved_receipt_id,grant.reserved_receipt_id);
  if(q.state==='TERMINAL'){
   assert.equal(q.retry_hint,'QUERY_ONLY');assert.equal(q.terminal_receipt_id,grant.reserved_receipt_id);assert.equal(q.proof,grant.reserved_receipt_id);assert(uuid(q.terminal_basis_ref));
   if(q.terminal_kind==='RESTORED'){
    assert.equal(q.claim_evidence_ref,evidence.evidence_id);assert.equal(q.watch_evidence_ref,watch.evidence_id);assert.equal(evidence.result,'RESTORED_LOCAL');assert.equal(watch.result,'CLOSED_LOCAL');
    assert(evidence.members.some(m=>same(m.identity,q.identity)&&m.application==='APPLIED'));
   }else{assert.equal(q.terminal_kind,'DOCUMENT_GONE');assert.equal(q.claim_evidence_ref,null);}
  }else{assert.equal(q.terminal_receipt_id,null);assert.equal(q.proof,null);assert.equal(q.terminal_kind,null);}
 }
 const a=d.takeover_request,b=d.takeover_reply;
 assert.equal(b.request_id,a.request_id);assert.equal(b.context_sha256,await digest(a.context));
 assert.equal(b.original_receiver_instance_id,a.original_transport.receiver_instance_id);
 for(const k of ['new_worker_instance_id','channel_ref','challenge_id'])assert.equal(b[k],a[k]);
 unique(a.identities.map(identityKey));const partition=[...b.accepted_identities,...b.pending_identities];unique(partition.map(identityKey));assert.deepEqual(partition.map(identityKey).sort(),a.identities.map(identityKey).sort());
 assert(b.allowed_operations.every(op=>['QUERY_OLD_SCOPE','RELEASE_OLD_SCOPE','COMPLETE_OLD_RESERVATION'].includes(op)));
 if(b.state==='ACCEPTED'){assert.equal(b.pending_identities.length,0);assert(uuid(b.takeover_ref));}
 if(b.state==='PARTIAL'){assert(b.pending_identities.length);assert(!b.allowed_operations.includes('RELEASE_OLD_SCOPE'));}
 if(['DENIED','REVALIDATION_REQUIRED'].includes(b.state)){assert.equal(b.accepted_identities.length,0);assert.equal(b.allowed_operations.length,0);assert.equal(b.takeover_ref,null);}
 // These are closed candidate packages, NOT production Wire validators.
 exact(d.transport,['receiver_instance_id','worker_instance_id']);
}
await check(f);const checks=[{name:'baseline candidate consistency/Core-Content bytes',passed:true}];
const cases=[
 ['mutated immutable plan restore',d=>{d.plans[0].properties[0].restore.value='block';}],
 ['wrong original transport hash',d=>{d.transport.worker_instance_id='other';}],
 ['claim member from another context',d=>{d.claim_cleanup.members[0].identity.context_sha256='f'.repeat(64);}],
 ['resource reference missing',d=>{d.claim_cleanup.members[0].resource_ref='missing';}],
 ['duplicate plan member',d=>{d.claim_cleanup.members.push(d.claim_cleanup.members[0]);}],
 ['terminal for other reserved receipt',d=>{d.completion_queries[0].terminal_receipt_id=d.grants[1].reserved_receipt_id;}],
 ['proof for other plan',d=>{d.completion_queries[0].proof=d.grants[1].reserved_receipt_id;}],
 ['terminal from pending restore',d=>{d.claim_cleanup.resources[0].properties[0].pending_restore=true;}],
 ['watch callbacks not fenced',d=>{d.watch_cleanup.scheduled_callbacks_fenced=false;}],
 ['uncalled closure missing authoritative basis',d=>{d.dispatch_reconciliation.entries[2].closure_ref=null;}],
 ['called request relabelled uncalled',d=>{d.dispatch_reconciliation.entries[0].resolution='LOCAL_UNCALLED_CLOSED';}],
 ['NOT_FOUND is not a confirmed reservation',d=>{d.dispatch_reconciliation.entries[0].lookup='NOT_FOUND';}],
 ['takeover response correlation changed',d=>{d.takeover_reply.challenge_id='foreign';}],
 ['takeover response worker changed',d=>{d.takeover_reply.new_worker_instance_id='foreign';}],
 ['new APPLY operation smuggled into cleanup',d=>{d.takeover_reply.allowed_operations.push('APPLY');}],
 ['takeover identity duplicated in pending',d=>{d.takeover_reply.pending_identities.push(d.takeover_reply.accepted_identities[0]);}],
 ['partial takeover claims session RELEASE',d=>{d.takeover_reply.state='PARTIAL';d.takeover_reply.pending_identities.push(d.takeover_reply.accepted_identities.pop());}],
];
for(const [name,mutate] of cases){const d=structuredClone(f);mutate(d);await assert.rejects(check(d));checks.push({name,passed:true});}
// Re-seal evidence so the branch checks, rather than a stale digest alone, fail.
for(const [name,change] of [
 ['rehashed pending restore cannot be terminal',d=>{d.claim_cleanup.resources[0].properties[0].pending_restore=true;}],
 ['rehashed unapplied plan cannot get normal restored terminal',d=>{d.claim_cleanup.members[1].application='NOT_APPLIED';}],
 ['rehashed watch still open cannot close',d=>{d.watch_cleanup.future_effects_closed=false;}],
]){const d=structuredClone(f);change(d);for(const k of ['claim_cleanup','watch_cleanup']){const {evidence_sha256,...raw}=d[k];d[k].evidence_sha256=await digest(raw);}await assert.rejects(check(d));checks.push({name,passed:true});}
for(const [name,change] of [
 ['other owner can stay protected after own claim cleanup',d=>{for(const p of d.claim_cleanup.resources[0].properties){p.goal=p.property==='display'?{value:'none',priority:'important'}:{value:true};p.observed=structuredClone(p.goal);p.goal_basis='OTHER_CLAIM';}}],
 ['latest valid page edit need not equal any old plan restore',d=>{const p=d.claim_cleanup.resources[0].properties[0];p.goal={value:'block',priority:''};p.observed=structuredClone(p.goal);p.goal_basis='PAGE_EDIT';}],
 ['stale takeover rejection has no cleanup authority',d=>{const b=d.takeover_reply;b.state='DENIED';b.reason='STALE_TAKEOVER';b.pending_identities=[...b.accepted_identities];b.accepted_identities=[];b.allowed_operations=[];b.takeover_ref=null;}],
]){const d=structuredClone(f);change(d);for(const k of ['claim_cleanup','watch_cleanup']){const {evidence_sha256,...raw}=d[k];d[k].evidence_sha256=await digest(raw);}await check(d);checks.push({name,passed:true});}
const repairCases=[
 ['missing original inert property',d=>{d.claim_cleanup.resources[0].properties=d.claim_cleanup.resources[0].properties.filter(p=>p.property!=='inert');},'INCOMPLETE_CLEANUP_PROPERTIES'],
 ['missing original display property',d=>{d.claim_cleanup.resources[0].properties=d.claim_cleanup.resources[0].properties.filter(p=>p.property!=='display');},'INCOMPLETE_CLEANUP_PROPERTIES'],
 ['empty final property results',d=>{d.claim_cleanup.resources[0].properties=[];},'INCOMPLETE_CLEANUP_PROPERTIES'],
 ['missing entire original resource',d=>{d.claim_cleanup.resources=[];},'INCOMPLETE_CLEANUP_RESOURCES'],
 ['conflicting duplicate display property',d=>{const p=structuredClone(d.claim_cleanup.resources[0].properties[0]);p.goal.value='block';p.observed.value='block';d.claim_cleanup.resources[0].properties.push(p);},'DUPLICATE_CLEANUP_PROPERTY'],
 ['identical duplicate display property',d=>{d.claim_cleanup.resources[0].properties.push(structuredClone(d.claim_cleanup.resources[0].properties[0]));},'DUPLICATE_CLEANUP_PROPERTY'],
 ['identical duplicate inert property',d=>{d.claim_cleanup.resources[0].properties.push(structuredClone(d.claim_cleanup.resources[0].properties[1]));},'DUPLICATE_CLEANUP_PROPERTY'],
 ['conflicting duplicate resource/claim row',d=>{const r=structuredClone(d.claim_cleanup.resources[0]);r.properties[0].goal.value='block';r.properties[0].observed.value='block';d.claim_cleanup.resources.push(r);},'DUPLICATE_CLEANUP_RESOURCE'],
 ['identical duplicate resource/claim row',d=>{d.claim_cleanup.resources.push(structuredClone(d.claim_cleanup.resources[0]));},'DUPLICATE_CLEANUP_RESOURCE'],
 ['split duplicate resource rows are not implicitly merged',d=>{const r=structuredClone(d.claim_cleanup.resources[0]);r.properties=[r.properties[1]];d.claim_cleanup.resources[0].properties=[d.claim_cleanup.resources[0].properties[0]];d.claim_cleanup.resources.push(r);},'DUPLICATE_CLEANUP_RESOURCE'],
 ['extra property cannot widen original cleanup scope',d=>{const r=d.claim_cleanup.resources[0];r.properties.push({...structuredClone(r.properties[0]),property:'opacity'});},'UNEXPECTED_CLEANUP_PROPERTY'],
 ['extra resource cannot widen original cleanup scope',d=>{const r=structuredClone(d.claim_cleanup.resources[0]);r.resource_ref='00000000-0000-4000-8000-000000000999';d.claim_cleanup.resources.push(r);},'UNEXPECTED_CLEANUP_RESOURCE'],
];
const repairResults=[];
for(const [name,mutate,code] of repairCases){const d=structuredClone(f);mutate(d);const {evidence_sha256,...raw}=d.claim_cleanup;d.claim_cleanup.evidence_sha256=await digest(raw);
 await assert.rejects(check(d),e=>e.message.includes(code));checks.push({name,passed:true});repairResults.push({name,rejected_with:code,passed:true});}
const partial=structuredClone(f);partial.claim_cleanup.result='PARTIAL_LOCAL';partial.claim_cleanup.error_count=1;partial.claim_cleanup.resources[0].properties=partial.claim_cleanup.resources[0].properties.filter(p=>p.property==='display');
for(const q of partial.completion_queries){q.state='IN_PROGRESS';q.reason='PROPERTY_UNCONFIRMED';q.retry_hint='SAME_OPERATION_AFTER_FRESH_CHECK';q.terminal_receipt_id=q.proof=q.terminal_kind=q.terminal_basis_ref=null;}
const {evidence_sha256:partialHash,...partialBody}=partial.claim_cleanup;partial.claim_cleanup.evidence_sha256=await digest(partialBody);await check(partial);
checks.push({name:'incomplete properties may remain explicitly partial without terminal proof',passed:true});
await writeFile(new URL('repair-fixtures.json',import.meta.url),JSON.stringify({proposal_id:'IG04-CORE-SHARED-FORMATS-20261102-P1-R1',status:'UNAPPROVED',mutations:repairCases.map(([name,,code])=>({name,expected_rejection:code})),partial_example:partial.claim_cleanup,partial_queries:partial.completion_queries},null,2)+'\n');
await writeFile(new URL('repair-results.json',import.meta.url),JSON.stringify({cases:repairResults,explicit_partial_accepted_without_terminal:true,scan_policy:'PENDING_CONTENT_DECISION_CURRENT_P1_RULE_UNCHANGED'},null,2)+'\n');
const results={kind:'UNAPPROVED_CANDIDATE_FIXTURE_CHECKS_NOT_PRODUCT_TESTS',proposal_id:'IG04-CORE-SHARED-FORMATS-20261102-P1-R1',passed:checks.length,total:checks.length,checks,m1:'BLOCKED',product_calls:0,scan_policy:'PENDING_CONTENT_DECISION_CURRENT_P1_RULE_UNCHANGED'};
await writeFile(new URL('validation-results.json',import.meta.url),JSON.stringify(results,null,2)+'\n');console.log(JSON.stringify({kind:results.kind,passed:results.passed,total:results.total}));
