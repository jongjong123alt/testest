다훈아, 지민아. P1 독립 검토에서 나온 두 관계 검사 누락을 보완했어.

수정 후보: **IG04-CORE-SHARED-FORMATS-20261102-P1-R1**

- 원래 plan의 cleanup property 전체를 RESTORED_LOCAL 필수 범위로 확인해. inert 등 하나라도 빠지면 RESTORED terminal을 거절해.
- 같은 resource/claim의 행 중복과 property 중복을 거절해. flex/block 상충뿐 아니라 동일 값 중복이나 분할 행도 암묵 병합하지 않아.
- 부분 확인은 PARTIAL_LOCAL·진행 중으로 남기고 terminal proof와 cleanup 의무 종료를 허용하지 않아.

기존 P1이 허용하던 inert 누락·display 상충 중복·resource/claim 행 상충 중복 세 반례를 재현했고, 같은 원본 fixture에서 hash를 다시 계산한 뒤에도 R1은 전부 거절했어.

**후보 관계 검사 37/37**(기존 24 + 새 거절 12 + 부분 진행 1), **기존 RC2 구조 검사 5/5** 통과했어. 제품 검증 수치는 아니야. 원래 plan·footprint·Grant·RELEASE·evidence hash 및 canonical 구조, ClaimLedger의 유효 복원 목표 원칙은 유지했어.

첨부의 REPAIR.md·SPEC.md 변경 절, repair-fixtures.json·repair-results.json과 before/after-results.json 기준으로 이번 수정분만 재확인 부탁해.

**scan_scheduled=true + fenced callback으로 CLOSED_LOCAL을 허용할지, 예약 scan 0을 필수로 할지는 지민과 공동 결정으로 남겨뒀어.** 기존 P1 후보 동작을 보존했으며 확정한 건 아니야. 이 항목 선택 의견도 같이 부탁해.

M1은 계속 BLOCKED고 실제 연결·Chrome START·제품 코드 변경·병합은 하지 않았어.
