다훈아, 지민아. 남은 공유 형식5개에 대해 Core 입출력 후보를 실제 필드·예시로 정리했어.

후보 ID: **IG04-CORE-SHARED-FORMATS-20261102-P1**
상태: **미승인 Core 제안 / M1 BLOCKED 유지 / 실제 연결 미착수**.

기존 원칙 문서 재검토 요청은 아니고, 첨부 후보 SPEC.md와 fixtures.json의 필드·상태·관계 중 수락 가능한 부분과 정확히 수정할 부분만 확인 부탁해.

1. **plan·claim 최종 근거:** 원래 context/instance·Element의 안전한 resource 참조·claim·포함 plan 목록·Ledger의 유효 goal/관측/basis를 결속했어. P1 원문이 grid여도 P2/페이지의 유효 목표 flex로 정리한 근거를 공유할 수 있고, terminal은 예약별로 검증해. 과거 restore 재생이나 claim 문자열만으로 전체 완료는 허용하지 않아.
2. **footprint:** 기존 context·완전 plan·원래 transport를 별도 domain의 canonical 배열로 hash하는 기존 제안을 유지했어. Core/Content bytes·digest를 대조할 정확한 예시를 넣었어.
3. **감시·plan0·dispatch/cutoff:** 별도 watch 종료 근거와 호출/조회 결과를 구분했어. hash 전 identity=null인 미호출 record도 별도 분류하고, NOT_FOUND나 취소 상태만으로 의무를 끝내지 않아.
4. **부분 진행·terminal/proof:** 원래 RELEASE operation/hash·reserved receipt 결속과 진행/재검증/조회 미확인/terminal/충돌 결과를 나눴어. proof 참조 자체는 권한이 아니고 실제 Core 원문 검증이 필요해. 문서 소멸 결과로 Content restored나 완료 hook을 위조하지 않아. Grant 만료는 합의된 재검증 전까지 대기이며 임의 갱신하지 않아.
5. **cleanup-only 인수:** 요청 correlation·현재 Worker/live channel·old context/예약과 기존 provenance를 결속했어. 대상별 수락/잔여를 나누고, partial 인수를 전체 세션 RELEASE 권한으로 쓰지 않아. stale 인수는 기존 기대 참조와 Core CAS로 거절하며 일반 APPLY 권한을 주지 않아.

지민이는 위 자료를 실제 #87의 기존 callback/완료 hook과 새 최소 근거·미호출 종료·cleanup-only seam에 연결할 수 있는지 확인해 줘. 특히 어떤 provenance/goal basis/자원 종료 자료를 원래 instance에서 제공할 수 있는지 알려주면 돼.

다훈이는 기존 RC2·old-scope 권한·원문 보존/조회 의미와 충돌하는 부분만 확인 부탁해. M2/M4 내부 원장·private key·CAS·writer/cutoff 구현은 내가 맡아. 이 후보를 새 Server endpoint나 기존 Wire 필드로 확정한 것은 아니야.

검증은 **후보 fixture 정합성24/24**, 기존 RC2 scope/Grant/RELEASE **구조 검사5/5**야. 모두 합성 자료이고 제품 시험·실제 권한/영속 commit/채널 검증 PASS는 아니야.

제품 코드·공용 Schema·DB·PR·GitHub 승인·병합은 변경하지 않았어. **5개 형식에 합의하더라도 M1 BLOCKED는 자동 해제되지 않고, 실제 연결 착수는 별도 결정**으로 유지하자. 기존 복원/안전 원칙은 그대로 재사용하면 돼!
