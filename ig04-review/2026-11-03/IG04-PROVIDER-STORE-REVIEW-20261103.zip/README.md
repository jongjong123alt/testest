# IG04 provider-store 로컬 독립 검토 자료

기준 소스: ed8755a597973922d02bd675e80b00c410dfdaf4 (#88).
신규 미커밋 파일: extension/src/ig04-provider-store.js 및 extension/tests/ig04-provider-store.test.mjs.
source-manifest.json은 각 소스의 SHA-256과 출처를 제공한다. 직접/전이 상대 import 의존성을 포함했다. 의존 소스는 고정 Git 원본과 byte 동일성을 확인했다. node_modules는 포함하지 않는다.

## 재현

Node 24 환경에서 extension 디렉터리로 이동하고 npm ci --ignore-scripts 로 잠금 파일의 의존성을 준비한다. fake-indexeddb 6.2.5를 사용한다.
ZIP 루트에서:

```sh
node --test extension/tests/ig04-provider-store.test.mjs extension/tests/additional-ig04-admission.test.mjs extension/tests/additional-ig04-lifetime.test.mjs
```

기존 실제 실행 로그: test-results-56.log. 56 PASS, FAIL/SKIP 0 (신규9+기존47). 이번 포장 작업에서 시험을 반복하지 않았다. 신규 반례만 추가할 경우 원본과 다른 경로에 보존한다.

## 검토 경계

다훈 담당: A1Store transaction/CAS 및 원본 null→identity·의무 소비 호환성.
guard는 기본 거절이며 시험 true guard는 합성 대역이다. 운영 인증, 원본 provenance, 전체 권한 전이 hook, 실제 Worker/Content ACK, plan0/watch 공통 종료 및 cleanup-only 재인수는 미연결/HOLD.
객체 재생성 재조회 시험은 실제 OS Worker 재시작 시험이 아니다. 56 PASS를 운영 provider ABA 안전성이나 제품 연결 완료로 확대하지 않는다.
이번 소스는 내부 local record 저장 단위다. M1 BLOCKED. Git Commit/Push/PR/병합 없음.

manifest.json의 SHA-256으로 모든 포함 파일을 확인할 수 있다. manifest 자체 해시는 ZIP 옆 sha256 파일에 기록한다.
