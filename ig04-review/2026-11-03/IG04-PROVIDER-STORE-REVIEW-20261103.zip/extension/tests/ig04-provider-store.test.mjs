import test from 'node:test';
import assert from 'node:assert/strict';
import {IDBFactory} from 'fake-indexeddb';
import {createMemberDB} from '../member-a1/db.mjs';
import {A1Store} from '../member-a1/store.mjs';
import {IG04ProviderStore} from '../src/ig04-provider-store.js';
async function fixture(){
 const db=createMemberDB(new IDBFactory(),'provider-test'),store=new A1Store(db);
 await store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'a1-fence',owner_context:'owner',transitioning:false});done(null);});
 const p=new IG04ProviderStore(store,{guard:()=>true}),token=await p.initialize('watch',{document:'doc'});
 return {db,store,p,token};
}
test('default and async guards deny even with valid storage',async()=>{
 const f=await fixture();
 for(const guard of [undefined,async()=>true])await assert.rejects(new IG04ProviderStore(f.store,{guard}).lookup('watch',f.token,'x'),/PROVIDER_UNCONFIRMED/);
});
test('A->B->A never restores prior token; revoke cannot reopen',async()=>{
 const {p,token}=await fixture();const b=await p.transition('watch',token,{document:'B'}),a=await p.transition('watch',b,{document:'doc'});
 assert.equal(a.revision,3);assert.equal(a.lifetime_ref,token.lifetime_ref);
 await assert.rejects(p.lookup('watch',token,'x'),/REVISION_CHANGED/);
 const retired=await p.transition('watch',a,{}, {revoke:true});
 await assert.rejects(p.transition('watch',retired,{}),/REVISION_CHANGED/);
 await assert.rejects(p.initialize('watch',{}),/ALREADY_INITIALIZED/);
});
test('persist original, null->identity version CAS, preserve input copy',async()=>{
 const {p,token}=await fixture();const original={identity:null,watch:'original-watch'};
 const pending=p.register('watch',token,'local',original);original.watch='forged';await pending;
 let lookup=await p.lookup('watch',token,'local');assert.equal(lookup.record.original.watch,'original-watch');
 await p.finalizeIdentity('watch',token,'local',1,{plan_id:'local'});
 await assert.rejects(p.close('watch',token,'request',{},[{localId:'local',version:1}]),/ORIGINAL_CONFLICT/);
 lookup=await p.lookup('watch',token,'local');assert.equal(lookup.record.version,2);
 await assert.rejects(p.register('watch',token,'local',original),/ORIGINAL_CONFLICT/);
});
test('authority change between lookup and final write denies consumption',async()=>{
 const {p,token}=await fixture();await p.register('watch',token,'local',{identity:null});
 await p.lookup('watch',token,'local');await p.transition('watch',token,{document:'new'});
 await assert.rejects(p.close('watch',token,'req',{},[{localId:'local',version:1}]),/REVISION_CHANGED/);
});
test('A1 fence changed invalidates IG04 reads and writes',async()=>{
 const {p,store,token}=await fixture();await store.atomic((tx,done)=>{tx.objectStore('metadata').put({key:'a1:owner-fence',epoch:'other',owner_context:'owner'});done(null);});
 await assert.rejects(p.register('watch',token,'local',{}),/OWNER_FENCE_CHANGED/);
});
test('lost reply/recreated provider recovers same closure, same request conflicts',async()=>{
 const {p,store,token}=await fixture();await p.register('watch',token,'local',{identity:null});const versions=[{localId:'local',version:1}];
 const first=await p.close('watch',token,'req',{cutoff:'cutoff'},versions);
 const restarted=new IG04ProviderStore(store,{guard:()=>true});
 assert.deepEqual(await restarted.queryClosure('watch',token,'req',{cutoff:'cutoff'},versions),first);
 assert.deepEqual(await restarted.close('watch',token,'req',{cutoff:'cutoff'},versions),first);
 await assert.rejects(restarted.close('watch',token,'req',{cutoff:'different'},versions),/REQUEST_CONFLICT/);
 await assert.rejects(restarted.close('watch',token,'other',{},versions),/ORIGINAL_CONFLICT/);
});
test('abort after writes rolls back both closure and consumed obligations',async()=>{
 const {p,store,token}=await fixture();await p.register('watch',token,'local',{identity:null});
 store.beforeCommit=()=>{throw Error('disk');};
 await assert.rejects(p.close('watch',token,'req',{},[{localId:'local',version:1}]),/disk/);delete store.beforeCommit;
 assert.equal((await p.lookup('watch',token,'local')).record.closedBy,null);
 await assert.rejects(p.queryClosure('watch',token,'req',{},[]),/CLOSURE_UNCONFIRMED/);
});
test('simultaneous consumers cannot consume same record twice',async()=>{
 const {p,token}=await fixture();await p.register('watch',token,'local',{});
 const outcomes=await Promise.allSettled(['r1','r2'].map(id=>p.close('watch',token,id,{},[{localId:'local',version:1}])));
 assert.equal(outcomes.filter(x=>x.status==='fulfilled').length,1);
});
test('guard failure preserves obligations; empty plan scope still requires guard',async()=>{
 const {store,token}=await fixture();const p=new IG04ProviderStore(store,{guard:action=>action!=='close'});
 await assert.rejects(p.close('watch',token,'req',{},[]),/PROVIDER_UNCONFIRMED/);
});
