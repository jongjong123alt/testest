IG04 P3 누적 후보. Node24/Python3+기존 jsonschema 필요. 실행: python3 run-checks.py. 설치/네트워크/제품실행 없음.
SPEC.txt와 FIELD-TYPES.txt는 현재 후보 기준. baseline-preserved와 upstream은 과거 원문. legacy build-*는 실행하지 않는다.
RESULT.txt에서 이번 실행을 확인. 실제 provider/Worker/DB/Chrome 미연결, M1 BLOCKED/HOLD 유지. 후보 검사기 변경 및 회귀만 구현했고 제품 provider-store 미커밋 작업은 별도 보존했다.
