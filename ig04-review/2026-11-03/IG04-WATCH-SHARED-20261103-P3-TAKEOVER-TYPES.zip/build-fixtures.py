"""Candidate JSON/vector generation only; no product, provider, DB or browser IO."""
from pathlib import Path
import json, hashlib, copy

ROOT=Path(__file__).resolve().parent
UP=ROOT/'upstream/IG04_Core_P1_R2_SCAN0'
def clone(v): return copy.deepcopy(v)
def uid(n): return f'00000000-0000-4000-8000-{n:012d}'
def canonical(v): return json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
def digest(v): return hashlib.sha256(canonical(v).encode('utf-8')).hexdigest()
def write(path,v): path.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')

old=json.loads((UP/'fixtures.json').read_text(encoding='utf-8'))
base=clone(old);base['proposal_id']='IG04-WATCH-SHARED-20261102-W2'
base['watch_cleanup']['evidence_id']=uid(181)
base['watch_cleanup']['scan_scheduled']=False
raw={k:v for k,v in base['watch_cleanup'].items() if k!='evidence_sha256'}
base['watch_cleanup']['evidence_sha256']=digest(raw)
for q in base['completion_queries']:q['watch_evidence_ref']=uid(181)
write(ROOT/'fixtures/plan-baseline.json',base)
write(ROOT/'fixtures/baseline-change.json',{
 'proposal_id':base['proposal_id'],'old_watch_evidence_id':old['watch_cleanup']['evidence_id'],
 'new_watch_evidence_id':uid(181),'old_scan_scheduled':True,'new_scan_scheduled':False,
 'old_watch_hash':old['watch_cleanup']['evidence_sha256'],'new_watch_hash':base['watch_cleanup']['evidence_sha256'],
 'unchanged_keys':[k for k in old if old[k]==base[k]],
 'changed_keys':[k for k in old if old[k]!=base[k]],'historical_evidence_rewritten':False})

BIND={'context':base['context'],'context_sha256':digest(base['context']),
      'original_transport':base['transport'],'watch_ref':uid(72)}
IDS=[p['reservation_identity'] for p in base['plans']]
LOCAL=uid(290)
def oracle(zero=False):
 return {'fixture_only':True,'binding':clone(BIND),'cutoff_ref':uid(70),'watch_prepared':True,
  'preparation_ref':uid(201),'closure_ref':uid(202),'takeover_ref':uid(203),
  'authenticated_current_caller':True,'native_document_verified':True,'native_status':'ACTIVE',
  'current_worker':BIND['original_transport']['worker_instance_id'],'current_channel_ref':uid(204),
  'apply_current':True,'old_cleanup_authorized':True,'watch_cleanup_authorized':True,
  'session_release_authorized':True,'scope_complete':True,'current_takeover_ref':None,
  'start_never_called':True,'start_attempts_fenced':True,'writers_fenced':True,'no_late_commit':True,
  'context_identities':[] if zero else clone(IDS),'authorized_identities':[] if zero else clone(IDS),
  'context_local_plan_ids':[LOCAL],'uncalled_local_ids':[LOCAL],'authorized_local_plan_ids':[LOCAL],
  'cleanup_authorization_ref':uid(205),'validated_challenge':uid(206)}
def remaining(o,watch=True,local_ids=None):
 return {'watch':watch,'local_plan_ids':clone(o['context_local_plan_ids'] if local_ids is None else local_ids),
         'reservation_identities':clone(o['context_identities'])}
def ref_case(mode='PREPARE'):
 o=oracle();b=clone(BIND)
 if mode=='PREPARE':b['watch_ref']=None
 req={'format_version':'IG04_WATCH_REFERENCE_REQUEST_CANDIDATE_1','request_id':uid(210),
      'mode':mode,'binding':b,'channel_ref':o['current_channel_ref']}
 rep={'format_version':'IG04_WATCH_REFERENCE_REPLY_CANDIDATE_1','request_id':req['request_id'],
      'request_sha256':digest(req),'binding':clone(BIND),'status':'READY',
      'preparation_ref':o['preparation_ref'],'reason':None}
 return {'kind':'reference','oracle':o,'request':req,'reply':rep}
def closure_case(kind='NOT_STARTED',status='CLOSED',close_watch=True):
 o=oracle(True)
 records=[{'local_plan_id':LOCAL,'identity':None,'call_state':'NOT_CALLED'}]
 req={'format_version':'IG04_WATCH_CLOSURE_REQUEST_CANDIDATE_1','request_id':uid(220),
  'binding':clone(BIND),'cutoff_ref':o['cutoff_ref'],'kind':kind,'close_watch':close_watch,
  'local_records':clone(records),'evidence_ref':uid(221)}
 start='NOT_CALLED' if kind=='NOT_STARTED' else 'STARTED'
 e={'format_version':'IG04_WATCH_LIFECYCLE_EVIDENCE_CANDIDATE_1','evidence_id':uid(221),
  'binding':clone(BIND),'cutoff_ref':o['cutoff_ref'],'adapter_start_state':start,
  'start_attempts_closed':True,'observer_stopped':True,'listeners_detached':True,
  'scan_in_progress':False,'scan_scheduled':False,'scheduled_callbacks_fenced':True,
  'future_effects_closed':True,'own_claim_count':0,'local_records':clone(records),
  'result':'CLOSED_LOCAL'}
 if status=='PARTIAL':
  e['adapter_start_state']='PARTIAL';e['observer_stopped']=False;e['own_claim_count']=1
  e['result']='PARTIAL_LOCAL';o['start_never_called']=False
 e['evidence_sha256']=digest(e)
 success=status=='CLOSED'
 rep={'format_version':'IG04_WATCH_CLOSURE_REPLY_CANDIDATE_1','request_id':req['request_id'],
  'request_sha256':digest(req),'binding':clone(BIND),'cutoff_ref':o['cutoff_ref'],'status':status,
  'closure_ref':o['closure_ref'] if success else None,'closed_local_plan_ids':[LOCAL] if success else [],
  'watch_closed':success and close_watch,
  'remaining':remaining(o,watch=not(success and close_watch),local_ids=[] if success else None),
  'reason':None if success else 'PARTIAL_START_CLEANUP_PENDING'}
 return {'kind':'closure','oracle':o,'request':req,'reply':rep,'evidence':e}
def takeover_case(zero=False,partial=False,session=False):
 o=oracle(zero);o['current_worker']='fixture-worker-2'
 req={'format_version':'IG04_WATCH_TAKEOVER_REQUEST_CANDIDATE_1','request_id':uid(230),
  'binding':clone(BIND),'cutoff_ref':o['cutoff_ref'],'new_worker_instance_id':o['current_worker'],
  'channel_ref':o['current_channel_ref'],'challenge_id':o['validated_challenge'],
  'expected_takeover_ref':None,'cleanup_authorization_ref':o['cleanup_authorization_ref'],
  'identities':clone(o['context_identities']),'local_plan_ids':[LOCAL],
  'request_watch_cleanup':True,'request_session_release':session}
 accepted=clone(req['identities']);pending=[]
 if partial:
  pending=[accepted.pop()];o['authorized_identities']=clone(accepted)
  o['watch_cleanup_authorized']=False;o['session_release_authorized']=False
 watch=not partial;full=session and not partial
 ops=['QUERY_OLD_SCOPE']
 if accepted:ops.append('COMPLETE_OLD_RESERVATION')
 if full:ops.append('RELEASE_OLD_SCOPE')
 rep={'format_version':'IG04_WATCH_TAKEOVER_REPLY_CANDIDATE_1','request_id':req['request_id'],
  'request_sha256':digest(req),'binding':clone(BIND),'cutoff_ref':o['cutoff_ref'],
  'new_worker_instance_id':o['current_worker'],'channel_ref':o['current_channel_ref'],
  'challenge_id':o['validated_challenge'],'takeover_ref':o['takeover_ref'],
  'state':'PARTIAL' if partial else 'ACCEPTED','accepted_identities':accepted,'pending_identities':pending,
  'accepted_local_plan_ids':[LOCAL],'pending_local_plan_ids':[],
  'watch_cleanup_accepted':watch,'session_release_accepted':full,'allowed_operations':ops,
  'remaining':remaining(o),'expires_at':'2026-11-02T12:00:00.000Z',
  'reason':'PARTIAL_SCOPE' if partial else None}
 return {'kind':'takeover','oracle':o,'request':req,'reply':rep}

cases=[]
def add(name,c,valid=True,code=None):
 c=clone(c);c['name']=name;c['expected']={'valid':valid,'code':code};cases.append(c)
def altered(name,source,fn,code):
 c=clone(source);fn(c);add(name,c,False,code)
def reseal(c):
 if 'evidence' in c:
  e=c['evidence'];e['evidence_sha256']=digest({k:v for k,v in e.items() if k!='evidence_sha256'})
 if c.get('reply') is not None:c['reply']['request_sha256']=digest(c['request'])

p=ref_case();add('watch prepare and separately bound delivery',p)
add('watch lookup reuses the same durable obligation',ref_case('LOOKUP'))
add('identical prepare retry reuses original response and watch',p)
c=ref_case('LOOKUP');c['request']['request_id']=uid(211);c['reply']['request_id']=uid(211);reseal(c);add('new query correlation same obligation',c)
altered('foreign watch reference rejected',p,lambda c:c['reply']['binding'].__setitem__('watch_ref',uid(999)),'WATCH_BINDING')
c=ref_case('LOOKUP');c['request']['binding']['context']['scope']['document_id']='other-document';c['request']['binding']['context_sha256']=digest(c['request']['binding']['context']);c['reply']['binding']=clone(c['request']['binding']);reseal(c);add('rehash foreign native scope rejected',c,False,'WATCH_BINDING')
altered('foreign original receiver rejected',p,lambda c:c['reply']['binding']['original_transport'].__setitem__('receiver_instance_id',uid(999)),'WATCH_BINDING')
altered('foreign original Worker rejected',p,lambda c:c['reply']['binding']['original_transport'].__setitem__('worker_instance_id','foreign'),'WATCH_BINDING')
altered('ready response after APPLY authority changed rejected',p,lambda c:c['oracle'].__setitem__('apply_current',False),'APPLY_NOT_CURRENT')
c=ref_case();c['reply']['status']='UNCONFIRMED';c['reply']['preparation_ref']=None;c['reply']['reason']='AUTHORITY_CHANGED_AFTER_PREPARE';c['oracle']['apply_current']=False;add('prepared obligation survives authority change',c)
c=ref_case();c['reply']=None;c['caller_outcome']='TIMEOUT';add('prepare response lost keeps committed watch',c)

n=closure_case();add('verified adapter never-started closure',n)
add('null identity closes only local record not whole watch',closure_case(close_watch=False))
c=closure_case('STARTED_CLEANUP');c['oracle']['start_never_called']=False;add('plan0 started watch cleanup',c)
c=closure_case('STARTED_CLEANUP','PARTIAL');add('partial start retains original obligations',c)
c=closure_case('STARTED_CLEANUP');c['oracle']['start_never_called']=False;c['oracle']['apply_current']=False;add('old cleanup allowed after APPLY authority disappears',c)
altered('already-started cannot use never-started closure',n,lambda c:c['oracle'].__setitem__('start_never_called',False),'START_WAS_CALLED')
c=clone(n);c['evidence']['adapter_start_state']='UNCONFIRMED';reseal(c);add('uncertain start cannot be closed as never-started',c,False,'START_STATE')
c=clone(n);c['evidence']['scan_in_progress']=True;reseal(c);add('running scan cannot produce CLOSED_LOCAL',c,False,'SCAN_NOT_DRAINED')
c=clone(n);c['evidence']['scan_scheduled']=True;c['evidence']['scheduled_callbacks_fenced']=True;reseal(c);add('scheduled fenced callback still cannot close',c,False,'SCAN_NOT_DRAINED')
c=closure_case('STARTED_CLEANUP');c['oracle']['start_never_called']=False
previous=clone(c['evidence']);previous['evidence_id']=uid(222);previous['scan_scheduled']=True;previous['result']='PARTIAL_LOCAL';previous['evidence_sha256']=digest({k:v for k,v in previous.items() if k!='evidence_sha256'})
c['prior_evidence']=previous;c['drain_observation']={'fixture_only':True,'source_ref':uid(223),'previous_evidence_id':uid(222),'next_evidence_id':c['evidence']['evidence_id'],'callbacks_drained':True};add('new evidence after independently observed drain accepts scan0',c)
c=clone(n);c['evidence']['cutoff_ref']=uid(999);reseal(c);add('local null record bound to wrong cutoff rejected',c,False,'CUTOFF_BINDING')
c=clone(n);c['request']['local_records'][0]['local_plan_id']=uid(998);c['evidence']['local_records']=clone(c['request']['local_records']);c['reply']['closed_local_plan_ids']=[uid(998)];reseal(c);add('foreign local obligation cannot be closed',c,False,'UNKNOWN_LOCAL')
c=clone(n);c['request']['local_records'][0]['call_state']='CALLED';c['evidence']['local_records']=clone(c['request']['local_records']);reseal(c);add('called reserve cannot use uncalled local closure',c,False,'LOCAL_NOT_UNCALLED')
c=clone(n);c['oracle']['no_late_commit']=False;add('late commit possibility preserves null local obligation',c,False,'UNCALLED_NOT_PROVEN')
c=clone(n);c['reply']['proof']=uid(50);add('fake reservation proof forbidden in watch closure',c,False,'CLOSURE_REPLY_FIELDS')
c=clone(n);c['reply']=None;c['caller_outcome']='TIMEOUT';add('closure response loss is not rollback or local completion',c)

t=takeover_case(zero=True);add('empty identities watch-only takeover',t)
add('same takeover request replay has same bound outcome',t)
add('partial plans do not acquire common watch or session release',takeover_case(partial=True,session=True))
add('full separately authorized context can acquire session release',takeover_case(session=True))
altered('watch-only takeover cannot omit watch ref',t,lambda c:c['request']['binding'].__setitem__('watch_ref',None),'WATCH_BINDING')
c=clone(t);c['reply']['cutoff_ref']=uid(999);add('watch-only takeover wrong cutoff rejected',c,False,'CUTOFF_BINDING')
c=takeover_case(partial=True,session=True);c['reply']['session_release_accepted']=True;c['reply']['allowed_operations'].append('RELEASE_OLD_SCOPE');add('partial takeover cannot smuggle full session release',c,False,'SESSION_SCOPE_INCOMPLETE')
c=takeover_case(session=True);c['request']['identities']=[c['request']['identities'][0]];c['reply']['accepted_identities']=clone(c['request']['identities']);c['oracle']['scope_complete']=False;reseal(c);add('hidden remaining reservation prevents full release',c,False,'SESSION_SCOPE_INCOMPLETE')
c=clone(t);c['oracle']['current_worker']='fixture-worker-3';add('late old Worker success cannot replace latest takeover',c,False,'STALE_WORKER')
c=clone(t);c['oracle']['current_takeover_ref']=uid(999);add('old expected takeover cannot become current authority',c,False,'STALE_TAKEOVER')
c=clone(t);c['oracle']['current_takeover_ref']=uid(999);c['reply']['state']='STALE';c['reply']['takeover_ref']=None;c['reply']['watch_cleanup_accepted']=False;c['reply']['session_release_accepted']=False;c['reply']['accepted_local_plan_ids']=[];c['reply']['pending_local_plan_ids']=[LOCAL];c['reply']['allowed_operations']=[];c['reply']['reason']='STALE_TAKEOVER';add('explicit stale reply preserves all duties without rights',c)
c=clone(t);c['reply']['request_id']=uid(999);add('late response correlation rejected',c,False,'REPLY_CORRELATION')
c=clone(t);c['reply']['allowed_operations'].append('APPLY');add('cleanup takeover never returns APPLY authority',c,False,'APPLY_FORBIDDEN')
c=clone(t);c['reply']['remaining']['local_plan_ids']=[];add('accepted takeover cannot hide unresolved null record',c,False,'REMAINING_MISMATCH')
c=clone(t);c['oracle']['lease_valid']=False;c['reply']['state']='UNCONFIRMED';c['reply']['takeover_ref']=None;c['reply']['watch_cleanup_accepted']=False;c['reply']['accepted_local_plan_ids']=[];c['reply']['pending_local_plan_ids']=[LOCAL];c['reply']['allowed_operations']=[];c['reply']['reason']='AUTHORITY_EXPIRED';add('expiry keeps old duties and grants no fresh rights',c)
c=clone(t);c['oracle']['prior_request_sha256']=digest(c['request']);c['request']['request_session_release']=True;reseal(c);add('same takeover request ID different meaning rejected',c,False,'REQUEST_ID_CONFLICT')
for c in cases:
 c['oracle'].setdefault('lease_valid',True)
 c['oracle'].setdefault('prior_request_sha256',None)
 if 'retry reuses' in c['name'] or 'same takeover request replay' in c['name']:
  c['oracle']['prior_request_sha256']=digest(c['request'])
write(ROOT/'fixtures/watch-cases.json',{'proposal_id':base['proposal_id'],'status':'UNAPPROVED','fixture_only':True,'cases':cases})
print(f'Generated plan scan0 baseline and {len(cases)} new watch-only candidate cases; no product IO')
