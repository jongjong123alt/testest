from pathlib import Path
import json,copy,hashlib
p=Path(__file__).resolve().parent;cp=copy.deepcopy
can=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
digest=lambda x:hashlib.sha256(can(x).encode()).hexdigest()
f=json.loads((p/'upstream/TYPE-R1/watch-cases.json').read_text(encoding='utf-8'));f['proposal_id']='IG04-WATCH-SHARED-20261103-LOCAL-ORIGIN-P1'
sources={}
def original(c):
 return [{'binding':cp(c['request']['binding']),'cutoff_ref':c['request']['cutoff_ref'],'local_plan_id':r['local_plan_id'],'identity':cp(r['identity'])} for r in c['request'].get('local_records',[])]
for c in f['cases']:sources[c['name']]=original(c) if c['kind']=='closure' else []
base=cp(next(c for c in f['cases'] if c['name']=='TYPE-R1 nonnull identity after hash but before reserve call is legal'))
null=cp(next(c for c in f['cases'] if c['name']=='verified adapter never-started closure'))
new=[]
def add(name,c,expected=None,source=None):
 c['name']='ORIGIN '+name;c['expected']={'valid':expected is None}
 if expected:c['expected']['code']=expected
 if c.get('evidence'):c['evidence']['evidence_sha256']=digest({k:v for k,v in c['evidence'].items() if k!='evidence_sha256'})
 if c.get('reply'):c['reply']['request_sha256']=digest(c['request'])
 sources[c['name']]=cp(original(base) if source is None else source);new.append(c)
add('original nonnull exact six fields accepted',cp(base))
for field,value in [('plan_sha256','f'*64),('gate_id','00000000-0000-4000-8000-000000001998'),('plan_id','00000000-0000-4000-8000-000000001997'),('context_sha256','a'*64),('operation_id','00000000-0000-4000-8000-000000001996'),('generation',2)]:
 c=cp(base)
 for r in [c['request']['local_records'][0],c['evidence']['local_records'][0]]:r['identity'][field]=value
 if field=='plan_id':
  for r in [c['request']['local_records'][0],c['evidence']['local_records'][0]]:r['local_plan_id']=value
  for k in ['context_local_plan_ids','uncalled_local_ids','authorized_local_plan_ids']:c['oracle'][k]=[value]
  c['reply']['closed_local_plan_ids']=[value]
 add('rehashed input '+field+' changed',c,'LOCAL_ORIGINAL_IDENTITY_MISMATCH' if field in ['plan_sha256','gate_id'] else 'LOCAL_ORIGIN_UNAVAILABLE' if field=='plan_id' else 'LOCAL_IDENTITY')
# All six comparisons also exercised at the protected-source boundary; syntactically valid client identity stays unchanged.
for field,value in [('plan_sha256','e'*64),('gate_id','00000000-0000-4000-8000-000000001995'),('plan_id','00000000-0000-4000-8000-000000001994'),('context_sha256','b'*64),('operation_id','00000000-0000-4000-8000-000000001993'),('generation',2)]:
 source=original(base);source[0]['identity'][field]=value
 add('source original differs in '+field,cp(base),'LOCAL_ORIGINAL_IDENTITY_MISMATCH',source)
add('missing trusted source is blocked',cp(base),'LOCAL_ORIGIN_UNAVAILABLE',[])
c=cp(base);add('no injected provider is blocked',c,'LOCAL_ORIGIN_UNAVAILABLE')
c=cp(base);add('provider exception is blocked',c,'LOCAL_ORIGIN_UNAVAILABLE')
source=original(base);source[0]['cutoff_ref']='00000000-0000-4000-8000-000000001992';add('wrong original cutoff binding',cp(base),'LOCAL_ORIGIN_BINDING',source)
c=cp(base)
for r in [c['request']['local_records'][0],c['evidence']['local_records'][0]]:r['identity']=None
add('downgrade original nonnull to null denied',c,'LOCAL_ORIGINAL_IDENTITY_MISMATCH')
add('original null accepted without invented identity',cp(null),source=original(null))
c=cp(null);add('null without original provenance is blocked',c,'LOCAL_ORIGIN_UNAVAILABLE',original(null))
for name in ['W3 valid takeover then new Worker closure (original transport preserved)','partial plans do not acquire common watch or session release','null identity closes only local record not whole watch']:
 c=cp(next(c for c in f['cases'] if c['name']==name));add('preserve '+name,c,source=original(c) if c['kind']=='closure' else [])
f['cases']+=new
(p/'fixtures/watch-cases.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(p/'fixtures/protected-originals.synthetic.json').write_text(json.dumps({'synthetic_only':True,'not_wire_or_authority':True,'snapshots':sources},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(p/'fixtures/origin-delta.json').write_text(json.dumps({'existing_cases':81,'new_cases':len(new),'names':[c['name'] for c in new]},indent=2)+'\n')
print('new',len(new),'total',len(f['cases']))
