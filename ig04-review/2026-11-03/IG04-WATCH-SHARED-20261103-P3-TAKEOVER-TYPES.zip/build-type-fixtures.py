from pathlib import Path
import json,copy,hashlib
p=Path(__file__).resolve().parent;cp=copy.deepcopy
read=lambda f:json.loads((p/f).read_text(encoding='utf-8'))
can=lambda v:json.dumps(v,ensure_ascii=False,sort_keys=True,separators=(',',':'))
digest=lambda v:hashlib.sha256(can(v).encode()).hexdigest()
f=read('upstream/W3/watch-cases.json');f['proposal_id']='IG04-WATCH-SHARED-20261102-W3-TYPE-R1';new=[]
def seal(c):
 if c.get('evidence'):c['evidence']['evidence_sha256']=digest({k:v for k,v in c['evidence'].items() if k!='evidence_sha256'})
 if c.get('reply'):c['reply']['request_sha256']=digest(c['request'])
def add(name,c,error=None):
 c['name']='TYPE-R1 '+name;c['expected']={'valid':error is None}
 if error:c['expected']['code']=error
 new.append(c)
b=cp(next(c for c in f['cases'] if c['kind']=='closure' and c['expected']['valid'] and c.get('reply') and c['reply']['status']=='CLOSED' and c['request']['executor']['takeover_ref'] is None))
t=cp(next(c for c in f['cases'] if c['kind']=='takeover' and c['expected']['valid'] and c['reply']['state']=='ACCEPTED'))
add('normal closure reply contains no proof key',cp(b))
c=cp(b);c['reply']['proof']='forbidden';add('forbidden proof cannot become required normal field',c,'CLOSURE_REPLY_FIELDS')
c=cp(t);c['oracle']['current_takeover_ref']='00000000-0000-4000-8000-000000000990';c['request']['expected_takeover_ref']=c['oracle']['current_takeover_ref'];seal(c);add('nonnull expected takeover matches active record',c)
c=cp(t);add('null expected takeover valid only when no active record',c)
c=cp(t);c['oracle']['current_takeover_ref']='00000000-0000-4000-8000-000000000990';add('null expectation cannot overwrite active takeover',c,'STALE_TAKEOVER')
c=cp(t);c['request']['expected_takeover_ref']='00000000-0000-4000-8000-000000000990';seal(c);add('nonnull expectation cannot match absent record',c,'STALE_TAKEOVER')
c=cp(t);c['request']['expected_takeover_ref']=123;seal(c);add('expected takeover ref numeric type denied',c,'EXPECTED_TAKEOVER_REF_TYPE')
add('null identity before plan hashing may close formally uncalled record',cp(b))
identity=cp(next(c for c in f['cases'] if c['kind']=='takeover' and c['request']['identities'])['request']['identities'][0])
c=cp(b);old=c['request']['local_records'][0]['local_plan_id'];pid=identity['plan_id']
for rec in [c['request']['local_records'][0],c['evidence']['local_records'][0]]:rec['identity']=cp(identity);rec['local_plan_id']=pid
for k in ['context_local_plan_ids','uncalled_local_ids','authorized_local_plan_ids']:c['oracle'][k]=[pid]
c['reply']['closed_local_plan_ids']=[pid];seal(c);add('nonnull identity after hash but before reserve call is legal',c)
d=cp(c)
for rec in [d['request']['local_records'][0],d['evidence']['local_records'][0]]:del rec['identity']['plan_sha256']
seal(d);add('nonnull identity must carry all six original fields',d,'LOCAL_IDENTITY_FIELDS')
d=cp(c)
for rec in [d['request']['local_records'][0],d['evidence']['local_records'][0]]:rec['identity']['operation_id']='00000000-0000-4000-8000-000000000999'
seal(d);add('nonnull identity wrong operation denied',d,'LOCAL_IDENTITY')
d=cp(c)
for rec in [d['request']['local_records'][0],d['evidence']['local_records'][0]]:rec['call_state']='CALLED'
seal(d);add('nonnull identity does not prove reserve uncalled',d,'LOCAL_NOT_UNCALLED')
f['cases']+=new
(p/'fixtures/watch-cases.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(p/'fixtures/type-delta.json').write_text(json.dumps({'candidate':f['proposal_id'],'prior_W3':69,'new_type_cases':len(new),'cases':[c['name'] for c in new]},indent=2)+'\n')
# Candidate type dictionary: derive keys from success/non-error examples ONLY, never forbidden negative keys.
def ty(v):return 'null' if v is None else 'boolean' if isinstance(v,bool) else 'integer' if isinstance(v,int) else 'string' if isinstance(v,str) else 'array' if isinstance(v,list) else 'object'
schemas={}
def observe(n,v):
 n.setdefault('types',[])
 if ty(v) not in n['types']:n['types'].append(ty(v))
 if isinstance(v,dict):
  fs=n.setdefault('fields',{})
  for k,x in v.items():observe(fs.setdefault(k,{}),x)
  n['required']=sorted(fs);n['additional_keys']=False
 elif isinstance(v,list):
  for x in v:observe(n.setdefault('items',{}),x)
for c in f['cases']:
 if not c['expected']['valid']:continue
 for part in ['request','reply','evidence']:
  if c.get(part):observe(schemas.setdefault(c[part]['format_version'],{}),c[part])
# Preserve identity shape even for arrays that happen to have no members in positives.
idnode={};observe(idnode,identity)
def fix(n,key=''):
 if key=='identity' and 'null' in n.get('types',[]):
  n['types']=['null','object'];n.update({k:cp(v) for k,v in idnode.items() if k!='types'})
 if key=='expected_takeover_ref':n['types']=['null','string']
 if n.get('types')==['array'] and 'items' not in n:n['items']=cp(idnode) if 'identit' in key else {'types':['string']}
 for k,v in n.get('fields',{}).items():fix(v,k)
 if 'items' in n:fix(n['items'],key+'[]')
for n in schemas.values():fix(n)
(p/'field-contract.json').write_text(json.dumps({'candidate':f['proposal_id'],'kind':'candidate type dictionary, not public Schema','messages':schemas},indent=2)+'\n')
print('cases',len(f['cases']),'new',len(new),'message formats',len(schemas))
