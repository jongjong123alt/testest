from pathlib import Path
import json,copy,hashlib
p=Path(__file__).resolve().parent
cp=copy.deepcopy
can=lambda x:json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))
digest=lambda x:hashlib.sha256(can(x).encode()).hexdigest()
f=json.loads((p/'upstream/W2/watch-cases.json').read_text(encoding='utf-8'))
f['proposal_id']='IG04-WATCH-SHARED-20261102-W3'
def seal(c):
 if c.get('reply'):c['reply']['request_sha256']=digest(c['request'])
for c in f['cases']:
 c['oracle']['old_watch_query_authorized']=True
 c['oracle']['active_takeover']=None
 if c['kind']=='closure':
  ex={'worker_instance_id':c['request']['binding']['original_transport']['worker_instance_id'],'channel_ref':c['oracle']['current_channel_ref'],'takeover_ref':None}
  c['request']['executor']=cp(ex)
  if c.get('reply'):c['reply']['executor']=cp(ex)
  seal(c)
  if c['oracle']['prior_request_sha256'] is not None:c['oracle']['prior_request_sha256']=digest(c['request'])
oldcount=len(f['cases']);new=[]
def add(name,c,error=None):
 c['name']='W3 '+name;c['expected']={'valid':error is None}
 if error:c['expected']['code']=error
 new.append(c)
r=cp(next(c for c in f['cases'] if c['kind']=='reference' and c['request']['mode']=='LOOKUP' and c['expected']['valid'] and c.get('reply') and c['reply']['status']=='READY'))
c=cp(r);c['oracle']['apply_current']=False;add('LOOKUP after APPLY revoked with exact old authority',c)
c=cp(r);c['oracle']['apply_current']=False;c['request']['mode']='PREPARE';seal(c);add('new PREPARE denied after APPLY revoked',c,'APPLY_NOT_CURRENT')
c=cp(r);c['oracle']['apply_current']=False;c['consumer_start_attempt']=True;add('LOOKUP cannot authorize start',c,'LOOKUP_NOT_START_AUTHORIZATION')
c=cp(r);c['oracle']['old_watch_query_authorized']=False;add('LOOKUP needs exact old watch query permission',c,'OLD_WATCH_QUERY_UNAUTHORIZED')
c=cp(r);c['oracle']['old_cleanup_authorized']=False;add('LOOKUP needs old cleanup permission',c,'OLD_WATCH_QUERY_UNAUTHORIZED')
c=cp(r);c['oracle']['apply_current']=False;add('lost PREPARE response same watch recovery after APPLY revoked',c)
c=cp(r);c['oracle']['lease_valid']=False;add('expired LOOKUP',c,'AUTHORITY_EXPIRED')
c=cp(r);c['oracle']['current_worker']='stale-worker';add('stale LOOKUP',c,'STALE_WORKER')
b=cp(next(c for c in f['cases'] if c['kind']=='closure' and c['expected']['valid'] and c.get('reply') and c['reply']['status']=='CLOSED' and c['request']['close_watch']))
t=cp(next(c for c in f['cases'] if c['kind']=='takeover' and c['expected']['valid'] and c['reply']['state']=='ACCEPTED' and c['reply']['watch_cleanup_accepted'] and not c['request']['identities']))
def after():
 c=cp(b);o=c['oracle'];tr=t['reply'];o['current_worker']=tr['new_worker_instance_id'];o['current_channel_ref']=tr['channel_ref'];o['current_takeover_ref']=tr['takeover_ref'];o['apply_current']=False
 o['active_takeover']={'takeover_ref':tr['takeover_ref'],'worker_instance_id':tr['new_worker_instance_id'],'channel_ref':tr['channel_ref'],'binding':cp(tr['binding']),'cutoff_ref':tr['cutoff_ref'],'watch_cleanup_accepted':True,'full_watch_scope':True,'valid':True,'accepted_local_plan_ids':cp(tr['accepted_local_plan_ids'])}
 c['request']['executor']={'worker_instance_id':o['current_worker'],'channel_ref':o['current_channel_ref'],'takeover_ref':tr['takeover_ref']};c['reply']['executor']=cp(c['request']['executor']);c['takeover_chain']=cp(t);seal(c);return c
c=after();add('valid takeover then new Worker closure (original transport preserved)',c)
c=cp(b);c['oracle']['watch_cleanup_authorized']=False;add('same Worker without watch authority denied',c,'WATCH_CLEANUP_UNAUTHORIZED')
c=after();c['oracle']['watch_cleanup_authorized']=False;add('takeover without current watch authority denied',c,'WATCH_CLEANUP_UNAUTHORIZED')
c=after();c['oracle']['current_takeover_ref']='00000000-0000-4000-8000-000000000999';add('stale takeover closure',c,'STALE_TAKEOVER')
c=after();c['oracle']['active_takeover']['valid']=False;add('expired takeover closure',c,'TAKEOVER_EXPIRED')
c=after();c['oracle']['active_takeover']['watch_cleanup_accepted']=False;add('partial plans without accepted watch cannot close watch',c,'WATCH_TAKEOVER_NOT_ACCEPTED')
c=after();c['oracle']['active_takeover']['full_watch_scope']=False;add('partial watch resource scope cannot close full watch',c,'WATCH_TAKEOVER_NOT_ACCEPTED')
c=after();c['oracle']['active_takeover']['accepted_local_plan_ids']=[];add('unaccepted local record closure denied',c,'LOCAL_TAKEOVER_SCOPE')
c=after();c['oracle']['active_takeover']['cutoff_ref']='00000000-0000-4000-8000-000000000999';add('takeover cutoff binding mismatch',c,'TAKEOVER_BINDING')
for key in ['watch','cutoff','owner']:
 c=after()
 if key=='watch':c['request']['binding']['watch_ref']='00000000-0000-4000-8000-000000000999'
 if key=='cutoff':c['request']['cutoff_ref']='00000000-0000-4000-8000-000000000999'
 if key=='owner':
  c['request']['binding']['context']['scope']['owner_binding_id']='00000000-0000-4000-8000-000000000999';c['request']['binding']['context_sha256']=digest(c['request']['binding']['context'])
 seal(c);add('foreign '+key+' closure denied',c,'CUTOFF_BINDING' if key=='cutoff' else 'WATCH_BINDING')
c=after();c['reply']=None;c['caller_outcome']='TIMEOUT';add('closure reply lost preserves obligations',c)
c=after();c['oracle']['prior_request_sha256']=digest(c['request']);add('same closure exact retry verifies same persistent closure result',c)
c=after();c['oracle']['prior_request_sha256']=digest(c['request']);c['request']['close_watch']=False;seal(c);add('closure request ID different original rejected',c,'REQUEST_ID_CONFLICT')
c=after();c['oracle']['old_cleanup_authorized']=False;add('old cleanup authority revoked',c,'OLD_CLEANUP_UNAUTHORIZED')
f['cases']+=new
serialized=json.dumps(f,ensure_ascii=False)
for t in ['REFERENCE_REQUEST','REFERENCE_REPLY','CLOSURE_REQUEST','CLOSURE_REPLY']:serialized=serialized.replace('IG04_WATCH_'+t+'_CANDIDATE_1','IG04_WATCH_'+t+'_CANDIDATE_3')
f=json.loads(serialized)
for c in f['cases']:
 old_prior=c['oracle']['prior_request_sha256']
 if c['name']!='late response with wrong request correlation rejected':seal(c)
 if old_prior is not None and c['name']!='W3 closure request ID different original rejected' and c['name']!='same takeover request ID different meaning rejected':c['oracle']['prior_request_sha256']=digest(c['request'])
(p/'fixtures/watch-cases.json').write_text(json.dumps(f,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(p/'fixtures/w3-delta.json').write_text(json.dumps({'base_W2_cases':oldcount,'new_cases':len(new),'cases':[c['name'] for c in new]},indent=2)+'\n')
print(oldcount,len(new))
