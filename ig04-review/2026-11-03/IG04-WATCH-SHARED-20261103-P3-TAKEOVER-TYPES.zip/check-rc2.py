"""Synthetic fixture structure only; no providers, network or DB access."""
import json
import os
from pathlib import Path
import jsonschema

here = Path(__file__).resolve().parent
root = Path(os.environ.get('IG04_CORE_ROOT', '/workspace/focurve-ig04-verification-lifetime'))
fixture = json.loads((here / 'fixtures/plan-baseline.json').read_text(encoding='utf-8'))
schema = json.loads((root / 'contracts/additional-mvp/rc1/schema.json').read_text(encoding='utf-8'))
checked = []
for name, values in [('BindingScope', [fixture['context']['scope']]),
                     ('CleanupGrant', fixture['grants']), ('Control', fixture['cleanup_controls'])]:
    # Select only the definition, not the root's separate message oneOf.
    definition = {'$schema': schema['$schema'], '$defs': schema['$defs'], '$ref': '#/$defs/' + name}
    validator = jsonschema.Draft202012Validator(definition, format_checker=jsonschema.FormatChecker())
    for index, value in enumerate(values):
        errors = list(validator.iter_errors(value))
        if errors:
            raise SystemExit(f'{name}[{index}]: {errors[0].message[:180]}')
        checked.append({'definition': name, 'fixture': index})
result = {'scope': 'unchanged RC2 definitions; synthetic fixture structure only',
          'checks': checked, 'pass': len(checked), 'product_authority': False,
          'setup_correction': 'Initial harness kept root message oneOf while selecting a subdefinition; corrected resolver envelope only. No contract or fixture relaxation.'}
(here / 'results/rc2-compatibility.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print(f'Existing RC2 synthetic fixture structure: {len(checked)}/{len(checked)} PASS')
