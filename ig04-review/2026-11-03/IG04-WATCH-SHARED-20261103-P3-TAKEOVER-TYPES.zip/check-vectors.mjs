import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {canonical,digest} from './pinned-core/extension/a1/contract.mjs';
import {canonical as cc,localDigest} from './pinned-content/extension/content/local-evidence.mjs';
const f=JSON.parse(await readFile(new URL('fixtures/watch-cases.json',import.meta.url)));const v=[];
for(const c of f.cases)for(const field of ['request','reply','evidence']){if(!c[field])continue;const raw=structuredClone(c[field]);if(field==='evidence')delete raw.evidence_sha256;const bytes=canonical(raw);assert.equal(bytes,cc(raw));const hash=await digest(raw);assert.equal(hash,await localDigest(raw));v.push({case:c.name,field,hash_scope:field==='evidence'?'body excluding evidence_sha256':'complete message; vector hash only',canonical_utf8:bytes,utf8_hex:Buffer.from(bytes).toString('hex'),byte_length:Buffer.byteLength(bytes),sha256:hash});}
await writeFile(new URL('fixtures/canonical-vectors.json',import.meta.url),JSON.stringify({candidate:'IG04-WATCH-SHARED-20261103-P3-TAKEOVER-TYPES',vectors:v},null,2));await writeFile(new URL('results/vector-results.json',import.meta.url),JSON.stringify({passed:v.length,total:v.length,core_content_bytes_digest_equal:true,synthetic:true},null,2));console.log(JSON.stringify({canonical_vectors:v.length,passed:true}));
