import {readFile,writeFile} from 'node:fs/promises';import assert from 'node:assert/strict';import {validate,digest} from './independent-export.mjs';import {validate as p1} from './p1-checker-export.mjs';
const f=JSON.parse(await readFile(new URL('fixtures/watch-cases.json',import.meta.url)));const cp=structuredClone;const good=()=>cp(f.cases.find(c=>c.name==='ORIGIN original nonnull exact six fields accepted'));const take=()=>cp(f.cases.find(c=>c.name==='ORIGIN preserve W3 valid takeover then new Worker closure (original transport preserved)'));const nul=()=>cp(f.cases.find(c=>c.name==='ORIGIN original null accepted without invented identity'));
const rows=[];
async function trial(name,make,change,expected,oldCompare=false,options={}){
 const c=make();const original={binding:cp(c.request.binding),cutoff_ref:c.request.cutoff_ref,local_plan_id:c.request.local_records[0].local_plan_id,identity:cp(c.request.local_records[0].identity),closure_fence:{lifetime_ref:'test-original-lifetime',revision:'r1'}};
 let state={lifetime_ref:'test-original-lifetime',revision:'r1'},entered,release;const entry=new Promise(r=>entered=r),hold=new Promise(r=>release=r);let readCount=0;
 const reader=()=>{readCount++;if(options.finalUnknown&&readCount>1)return null;return cp(state);};
 const lookup=async()=>{entered();await hold;if(options.lost)throw Error('SOURCE_RESPONSE_LOST');return cp(original);};
 const job=validate(c,lookup,reader).then(()=>null,e=>e.message);await entry;change(c,state,original);release();const actual=await job;
 let before=null;
 if(oldCompare){const d=make();const o={binding:cp(d.request.binding),cutoff_ref:d.request.cutoff_ref,local_plan_id:d.request.local_records[0].local_plan_id,identity:cp(d.request.local_records[0].identity)};let en,go;const ready=new Promise(r=>en=r),wait=new Promise(r=>go=r);const oldjob=p1(d,async()=>{en();await wait;return cp(o);}).then(()=>null,e=>e.message);await ready;change(d,{lifetime_ref:'test-original-lifetime',revision:'r1'},o);go();before=await oldjob;assert.equal(before,null);}
 const pass=actual===expected;rows.push({name,expected,actual,pass,p1:oldCompare?{accepted:before===null}:null,barrier:'provider entered before mutation',input:c,source_original:original,current_fence:state});
}
await trial('watch cleanup revoked during lookup',good,c=>c.oracle.watch_cleanup_authorized=false,'WATCH_CLEANUP_UNAUTHORIZED',true);
await trial('Worker changed during lookup',good,c=>c.oracle.current_worker='replacement-worker','STALE_WORKER',true);
await trial('takeover expired during lookup',take,c=>c.oracle.active_takeover.valid=false,'TAKEOVER_EXPIRED',true);
await trial('live channel changed',good,c=>c.oracle.current_channel_ref='replacement-channel','STALE_CHANNEL');
await trial('old cleanup permission revoked',good,c=>c.oracle.old_cleanup_authorized=false,'OLD_CLEANUP_UNAUTHORIZED');
await trial('Content instance changed',good,c=>c.oracle.binding.original_transport.receiver_instance_id='00000000-0000-4000-8000-000000009999','WATCH_BINDING');
await trial('native generation changed',good,c=>c.oracle.binding.context.scope.generation+=1,'WATCH_BINDING');
await trial('takeover superseded',take,c=>c.oracle.current_takeover_ref='00000000-0000-4000-8000-000000009999','STALE_TAKEOVER');
await trial('takeover watch scope withdrawn',take,c=>c.oracle.active_takeover.watch_cleanup_accepted=false,'WATCH_TAKEOVER_NOT_ACCEPTED');
await trial('late commit possibility reopens',good,c=>c.oracle.no_late_commit=false,'UNCALLED_NOT_PROVEN');
await trial('same visible authority but revision changed',good,(c,s)=>s.revision='r2','CLOSURE_FENCE_CHANGED');
await trial('ABA authority restored with new revision',good,(c,s)=>{c.oracle.watch_cleanup_authorized=false;s.revision='r2';c.oracle.watch_cleanup_authorized=true;},'CLOSURE_FENCE_CHANGED');
await trial('lifetime replaced',good,(c,s)=>s.lifetime_ref='different-lifetime','CLOSURE_FENCE_CHANGED');
await trial('original lookup uses foreign fence',good,(c,s,o)=>o.closure_fence.revision='stale-source','LOCAL_ORIGIN_FENCE_MISMATCH');
await trial('currentness UNKNOWN after lookup',good,()=>{},'CLOSURE_FENCE_UNAVAILABLE',false,{finalUnknown:true});
await trial('lookup response lost',good,()=>{},'LOCAL_ORIGIN_UNAVAILABLE',false,{lost:true});
await trial('unchanged normal nonnull closure',good,()=>{},null);
await trial('unchanged null plan0 closure',nul,()=>{},null);
await trial('unchanged valid takeover closure',take,()=>{},null);
await trial('original plan hash altered',good,(c,s,o)=>o.identity.plan_sha256='f'.repeat(64),'LOCAL_ORIGINAL_IDENTITY_MISMATCH');
await trial('client local identity mutated during lookup',good,c=>{c.request.local_records[0].identity.plan_sha256='e'.repeat(64);c.evidence.local_records[0].identity.plan_sha256='e'.repeat(64);},'LOCAL_ORIGINAL_IDENTITY_MISMATCH');
await trial('client closure target changed while pending',good,c=>c.request.close_watch=false,'CLOSURE_INPUT_CHANGED');
// A later consumption must verify again, rather than reusing a prior resolved Promise as authority.
const c=good();const saved={binding:cp(c.request.binding),cutoff_ref:c.request.cutoff_ref,local_plan_id:c.request.local_records[0].local_plan_id,identity:cp(c.request.local_records[0].identity),closure_fence:{lifetime_ref:'late-test',revision:'r1'}};let fence={lifetime_ref:'late-test',revision:'r1'};await validate(c,async()=>cp(saved),()=>cp(fence));fence.revision='r2';c.oracle.current_worker='new-worker';let err=null;try{await validate(c,async()=>cp(saved),()=>cp(fence));}catch(e){err=e.message;}rows.push({name:'late resolved closure re-consumed after new state',expected:'STALE_WORKER',actual:err,pass:err==='STALE_WORKER',note:'Fixture revalidation only; actual Content consumer still unimplemented; no state write performed'});
const result={candidate:'IG04-WATCH-SHARED-20261103-LOCAL-ORIGIN-P2-CURRENTNESS',total:rows.length,passed:rows.filter(x=>x.pass).length,failed:rows.filter(x=>!x.pass).length,kind:'SYNTHETIC_DEFERRED_SOURCE_TESTS_NOT_PROVIDER_ACCEPTANCE',rows};await writeFile(new URL('results/currentness-results.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify({passed:result.passed,total:result.total,failures:rows.filter(x=>!x.pass)}));if(result.failed)process.exitCode=1;
