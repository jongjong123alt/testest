from pathlib import Path
import json,copy,hashlib
p=Path(__file__).resolve().parent
f=p/'fixtures/watch-cases.json';d=json.loads(f.read_text(encoding='utf-8'))
base=next(c for c in d['cases'] if c['kind']=='closure' and c['expected']['valid'] and c['request']['kind']=='NOT_STARTED' and c['reply'] and c['reply']['status']=='CLOSED')
for name,field,value,code in [('adapter never called but receiver pagehide listener remains','listeners_detached',False,'WATCH_RESOURCES_REMAIN'),('numeric zero is not boolean scan0','scan_scheduled',0,'EVIDENCE_BOOLEAN_TYPE')]:
 c=copy.deepcopy(base);c['name']=name;c['evidence'][field]=value;body={k:v for k,v in c['evidence'].items() if k!='evidence_sha256'};c['evidence']['evidence_sha256']=hashlib.sha256(json.dumps(body,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();c['expected']={'valid':False,'code':code};d['cases'].append(c)
f.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
