import {fixtureClosureFence,fixtureOriginLookup} from './fixture-origin-harness.mjs';
import {validateMessage} from './type-check.mjs';
// Candidate relation checks over synthetic source observations, not production authority code.
import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {digest,canonical} from './pinned-core/extension/a1/contract.mjs';
import {localDigest,canonical as contentCanonical} from './pinned-content/extension/content/local-evidence.mjs';
const load=async p=>JSON.parse(await readFile(new URL(p,import.meta.url),'utf8'));
const same=(a,b)=>canonical(a)===canonical(b);
const fail=(condition,code)=>{if(!condition)throw Error(code);};
const uuid=x=>typeof x==='string'&&/^[a-f0-9]{8}(?:-[a-f0-9]{4}){3}-[a-f0-9]{12}$/.test(x);
const exact=(o,keys,code)=>fail(o&&same(Object.keys(o).sort(),keys.slice().sort()),code);
const key=canonical;
const seteq=(a,b)=>a.length===b.length&&same(a.map(key).sort(),b.map(key).sort());
const unique=(a,code)=>fail(new Set(a.map(key)).size===a.length,code);
const REPLY_STATES=['UNCONFIRMED','STALE','REJECTED'];
function binding(b,o,{prepare=false}={}){
 exact(b,['context','context_sha256','original_transport','watch_ref'],'WATCH_BINDING');
 fail(same(b.context,o.binding.context)&&b.context_sha256===o.binding.context_sha256
  &&same(b.original_transport,o.binding.original_transport),'WATCH_BINDING');
 fail((prepare&&b.watch_ref===null)||b.watch_ref===o.binding.watch_ref,'WATCH_BINDING');
}
async function correlation(req,rep,o){
 fail(rep.request_id===req.request_id&&rep.request_sha256===await digest(req),'REPLY_CORRELATION');
 if(o.prior_request_sha256!==null)fail(o.prior_request_sha256===await digest(req),'REQUEST_ID_CONFLICT');
}
function current(o,worker,channel){
 fail(o.authenticated_current_caller,'CALLER_UNCONFIRMED');
 fail(o.native_document_verified&&o.native_status==='ACTIVE','NATIVE_UNCONFIRMED');
 fail(worker===o.current_worker,'STALE_WORKER');
 fail(channel===o.current_channel_ref,'STALE_CHANNEL');
 fail(o.lease_valid,'AUTHORITY_EXPIRED');
}
function sourceRemaining(o,{watch=true,locals=o.context_local_plan_ids}={}){
 return {watch,local_plan_ids:locals,reservation_identities:o.context_identities};
}
function matchRemaining(rep,expected){fail(same(rep.remaining,expected),'REMAINING_MISMATCH');}
function failure(rep,state){
 fail(REPLY_STATES.includes(state)||state==='PARTIAL','RESULT_STATE');
 fail(typeof rep.reason==='string'&&rep.reason.length>0,'FAILURE_REASON');
}
async function reference(c){
 const {request:a,reply:b,oracle:o}=c;
 exact(a,['format_version','request_id','mode','binding','channel_ref'],'REFERENCE_REQUEST_FIELDS');
 fail(a.format_version==='IG04_WATCH_REFERENCE_REQUEST_CANDIDATE_3','FORMAT_VERSION');
 fail(['PREPARE','LOOKUP'].includes(a.mode),'REFERENCE_MODE');
 binding(a.binding,o,{prepare:a.mode==='PREPARE'});
 if(a.mode==='LOOKUP')fail(uuid(a.binding.watch_ref),'WATCH_BINDING');
 if(b===null){fail(c.caller_outcome==='TIMEOUT'&&o.watch_prepared,'TIMEOUT_PRESERVATION');return;}
 exact(b,['format_version','request_id','request_sha256','binding','status','preparation_ref','reason'],'REFERENCE_REPLY_FIELDS');
 binding(b.binding,o);await correlation(a,b,o);
 fail(b.format_version==='IG04_WATCH_REFERENCE_REPLY_CANDIDATE_3','FORMAT_VERSION');
 if(b.status==='READY'){
  current(o,a.binding.original_transport.worker_instance_id,a.channel_ref);
  if(a.mode==='PREPARE')fail(o.apply_current,'APPLY_NOT_CURRENT');
  else{fail(o.old_cleanup_authorized&&o.old_watch_query_authorized,'OLD_WATCH_QUERY_UNAUTHORIZED');fail(!c.consumer_start_attempt,'LOOKUP_NOT_START_AUTHORIZATION');}
  fail(o.watch_prepared,'WATCH_NOT_PREPARED');
  fail(b.preparation_ref===o.preparation_ref&&uuid(b.preparation_ref),'PREPARATION_BINDING');
  fail(b.reason===null,'SUCCESS_REASON');
 }else{failure(b,b.status);fail(b.preparation_ref===null,'UNCONFIRMED_NO_START');}
}
async function lifecycle(e,o){
 exact(e,['format_version','evidence_id','binding','cutoff_ref','adapter_start_state','start_attempts_closed',
  'observer_stopped','listeners_detached','scan_in_progress','scan_scheduled','scheduled_callbacks_fenced',
  'future_effects_closed','own_claim_count','local_records','result','evidence_sha256'],'EVIDENCE_FIELDS');
 fail(e.format_version==='IG04_WATCH_LIFECYCLE_EVIDENCE_CANDIDATE_1','FORMAT_VERSION');
 binding(e.binding,o);fail(e.cutoff_ref===o.cutoff_ref,'CUTOFF_BINDING');
 const {evidence_sha256,...body}=e;fail(evidence_sha256===await digest(body),'EVIDENCE_HASH');
 fail(evidence_sha256===await localDigest(body)&&canonical(body)===contentCanonical(body),'CORE_CONTENT_BYTES');
 fail(['NOT_CALLED','STARTED','PARTIAL','UNCONFIRMED'].includes(e.adapter_start_state),'START_STATE');
 fail(['CLOSED_LOCAL','PARTIAL_LOCAL','UNCONFIRMED'].includes(e.result),'LOCAL_RESULT');
 for(const k of ['start_attempts_closed','observer_stopped','listeners_detached','scan_in_progress','scan_scheduled','scheduled_callbacks_fenced','future_effects_closed'])fail(typeof e[k]==='boolean','EVIDENCE_BOOLEAN_TYPE');
 if(e.result==='CLOSED_LOCAL'){
  fail(!e.scan_in_progress&&!e.scan_scheduled,'SCAN_NOT_DRAINED');
  fail(e.observer_stopped&&e.listeners_detached&&e.scheduled_callbacks_fenced
   &&e.future_effects_closed&&e.start_attempts_closed,'WATCH_RESOURCES_REMAIN');
  fail(e.own_claim_count===0,'OWN_CLAIMS_REMAIN');
 }
}
function closureFence(readClosureFence){
 fail(typeof readClosureFence==='function','CLOSURE_FENCE_UNAVAILABLE');
 let f;try{f=readClosureFence();}catch{throw Error('CLOSURE_FENCE_UNAVAILABLE');}
 fail(f&&typeof f.then!=='function'&&typeof f.lifetime_ref==='string'&&f.lifetime_ref.length>0&&typeof f.revision==='string'&&f.revision.length>0,'CLOSURE_FENCE_UNAVAILABLE');
 return {lifetime_ref:f.lifetime_ref,revision:f.revision};
}
function finalClosureAuthority(a,o){
 binding(a.binding,o);fail(a.cutoff_ref===o.cutoff_ref,'CUTOFF_BINDING');
 current(o,a.executor.worker_instance_id,a.executor.channel_ref);
 fail(o.old_cleanup_authorized,'OLD_CLEANUP_UNAUTHORIZED');fail(o.watch_cleanup_authorized,'WATCH_CLEANUP_UNAUTHORIZED');
 if(a.executor.takeover_ref===null){fail(a.executor.worker_instance_id===a.binding.original_transport.worker_instance_id&&o.current_takeover_ref===null,'TAKEOVER_REQUIRED');}
 else{const t=o.active_takeover;
  fail(t&&a.executor.takeover_ref===o.current_takeover_ref&&t.takeover_ref===a.executor.takeover_ref,'STALE_TAKEOVER');
  fail(t.valid,'TAKEOVER_EXPIRED');
  fail(t.worker_instance_id===a.executor.worker_instance_id&&t.channel_ref===a.executor.channel_ref,'TAKEOVER_EXECUTOR');
  fail(same(t.binding,a.binding)&&t.cutoff_ref===a.cutoff_ref,'TAKEOVER_BINDING');
  fail(t.watch_cleanup_accepted&&t.full_watch_scope,'WATCH_TAKEOVER_NOT_ACCEPTED');
  fail(a.local_records.every(r=>t.accepted_local_plan_ids.includes(r.local_plan_id)),'LOCAL_TAKEOVER_SCOPE');
 }
 for(const r of a.local_records){fail(o.context_local_plan_ids.includes(r.local_plan_id),'UNKNOWN_LOCAL');fail(r.call_state==='NOT_CALLED'&&o.uncalled_local_ids.includes(r.local_plan_id)&&o.writers_fenced&&o.no_late_commit,'UNCALLED_NOT_PROVEN');}
}

async function closure(c,lookupOriginalLocalRecord,readClosureFence){
 const {request:a,reply:b,oracle:o,evidence:e}=c;
 exact(a,['format_version','request_id','binding','cutoff_ref','kind','close_watch','local_records','evidence_ref','executor'],'CLOSURE_REQUEST_FIELDS');
 fail(a.format_version==='IG04_WATCH_CLOSURE_REQUEST_CANDIDATE_3','FORMAT_VERSION');
 binding(a.binding,o);fail(a.cutoff_ref===o.cutoff_ref,'CUTOFF_BINDING');
 fail(['NOT_STARTED','STARTED_CLEANUP'].includes(a.kind),'CLOSURE_KIND');
 await lifecycle(e,o);fail(e.evidence_id===a.evidence_ref,'EVIDENCE_REF');
 fail(same(e.local_records,a.local_records),'LOCAL_RECORD_BINDING');unique(a.local_records.map(x=>x.local_plan_id),'DUPLICATE_LOCAL');
 for(const r of a.local_records){
  exact(r,['local_plan_id','identity','call_state'],'LOCAL_RECORD_FIELDS');
  fail(o.context_local_plan_ids.includes(r.local_plan_id),'UNKNOWN_LOCAL');
  if(r.identity!==null){
   exact(r.identity,['gate_id','plan_id','context_sha256','plan_sha256','operation_id','generation'],'LOCAL_IDENTITY_FIELDS');
   fail(uuid(r.identity.gate_id)&&uuid(r.identity.plan_id)&&uuid(r.identity.operation_id)&&Number.isInteger(r.identity.generation)&&r.identity.generation>=0&&/^[a-f0-9]{64}$/.test(r.identity.context_sha256)&&/^[a-f0-9]{64}$/.test(r.identity.plan_sha256),'LOCAL_IDENTITY_TYPE');
   fail(r.identity.plan_id===r.local_plan_id&&r.identity.context_sha256===a.binding.context_sha256&&r.identity.operation_id===a.binding.context.operation_id&&r.identity.generation===a.binding.context.scope.generation,'LOCAL_IDENTITY');
  }
 }
 if(b===null){fail(c.caller_outcome==='TIMEOUT'&&o.watch_prepared,'TIMEOUT_PRESERVATION');return;}
 exact(b,['format_version','request_id','request_sha256','binding','cutoff_ref','status','closure_ref',
  'closed_local_plan_ids','watch_closed','remaining','reason','executor'],'CLOSURE_REPLY_FIELDS');
 fail(b.format_version==='IG04_WATCH_CLOSURE_REPLY_CANDIDATE_3','FORMAT_VERSION');
 binding(b.binding,o);fail(b.cutoff_ref===o.cutoff_ref,'CUTOFF_BINDING');await correlation(a,b,o);
 fail(same(a.executor,b.executor),'EXECUTOR_CORRELATION');
 if(b.status==='CLOSED'){
  exact(a.executor,['worker_instance_id','channel_ref','takeover_ref'],'EXECUTOR_FIELDS');
  current(o,a.executor.worker_instance_id,a.executor.channel_ref);
  fail(o.old_cleanup_authorized,'OLD_CLEANUP_UNAUTHORIZED');
  fail(o.watch_cleanup_authorized,'WATCH_CLEANUP_UNAUTHORIZED');
  if(a.executor.takeover_ref===null){
   fail(a.executor.worker_instance_id===a.binding.original_transport.worker_instance_id&&o.current_takeover_ref===null,'TAKEOVER_REQUIRED');
  }else{
   const t=o.active_takeover;
   fail(t&&a.executor.takeover_ref===o.current_takeover_ref&&t.takeover_ref===a.executor.takeover_ref,'STALE_TAKEOVER');
   fail(t.valid,'TAKEOVER_EXPIRED');
   fail(t.worker_instance_id===a.executor.worker_instance_id&&t.channel_ref===a.executor.channel_ref,'TAKEOVER_EXECUTOR');
   fail(same(t.binding,a.binding)&&t.cutoff_ref===a.cutoff_ref,'TAKEOVER_BINDING');
   fail(t.watch_cleanup_accepted&&t.full_watch_scope,'WATCH_TAKEOVER_NOT_ACCEPTED');
   fail(a.local_records.every(r=>t.accepted_local_plan_ids.includes(r.local_plan_id)),'LOCAL_TAKEOVER_SCOPE');
   if(c.takeover_chain){await takeover(c.takeover_chain);const r=c.takeover_chain.reply;
    fail(r.takeover_ref===t.takeover_ref&&r.watch_cleanup_accepted&&same(r.binding,t.binding)&&r.cutoff_ref===t.cutoff_ref,'TAKEOVER_CHAIN');}
  }
  fail(e.result==='CLOSED_LOCAL','LOCAL_CLEANUP_UNCONFIRMED');
  if(a.kind==='NOT_STARTED'){
   fail(o.start_never_called,'START_WAS_CALLED');fail(e.adapter_start_state==='NOT_CALLED','START_STATE');
   fail(o.start_attempts_fenced&&e.start_attempts_closed,'START_NOT_FENCED');
  }
  for(const r of a.local_records){
   fail(r.call_state==='NOT_CALLED','LOCAL_NOT_UNCALLED');
   fail(o.uncalled_local_ids.includes(r.local_plan_id)&&o.writers_fenced&&o.no_late_commit,'UNCALLED_NOT_PROVEN');
  }
  const beforeFence=closureFence(readClosureFence);
  const beforeBytes=canonical([a,b,e]);
  for(const r of a.local_records){
   fail(typeof lookupOriginalLocalRecord==='function','LOCAL_ORIGIN_UNAVAILABLE');
   let original;try{original=await lookupOriginalLocalRecord({binding:structuredClone(a.binding),cutoff_ref:a.cutoff_ref,local_plan_id:r.local_plan_id,closure_fence:structuredClone(beforeFence)});}catch{throw Error('LOCAL_ORIGIN_UNAVAILABLE');}
   fail(original!==null&&original!==undefined,'LOCAL_ORIGIN_UNAVAILABLE');
   fail(same(original.closure_fence,beforeFence),'LOCAL_ORIGIN_FENCE_MISMATCH');
   fail(same(original.binding,a.binding)&&original.cutoff_ref===a.cutoff_ref&&original.local_plan_id===r.local_plan_id,'LOCAL_ORIGIN_BINDING');
   fail(same(original.identity,r.identity),'LOCAL_ORIGINAL_IDENTITY_MISMATCH');
  }
  fail(canonical([a,b,e])===beforeBytes,'CLOSURE_INPUT_CHANGED');
  const afterFence=closureFence(readClosureFence);
  finalClosureAuthority(a,o);
  fail(same(beforeFence,afterFence),'CLOSURE_FENCE_CHANGED');
  fail(b.closure_ref===o.closure_ref&&uuid(b.closure_ref),'CLOSURE_SOURCE');
  fail(seteq(b.closed_local_plan_ids,a.local_records.map(r=>r.local_plan_id)),'CLOSED_LOCAL_SCOPE');
  fail(b.watch_closed===a.close_watch,'WATCH_CLOSURE_SCOPE');
  matchRemaining(b,sourceRemaining(o,{watch:!b.watch_closed,locals:o.context_local_plan_ids.filter(id=>!b.closed_local_plan_ids.includes(id))}));
  fail(b.reason===null,'SUCCESS_REASON');
 }else{
  failure(b,b.status);fail(b.closure_ref===null&&!b.watch_closed&&b.closed_local_plan_ids.length===0,'NONTERMINAL_CLOSURE');
  matchRemaining(b,sourceRemaining(o));
 }
 if(c.prior_evidence){
  const p=c.prior_evidence;fail(p.evidence_id!==e.evidence_id&&p.scan_scheduled&&p.result==='PARTIAL_LOCAL','DRAIN_PREVIOUS');
  fail(c.drain_observation.fixture_only&&c.drain_observation.callbacks_drained
   &&c.drain_observation.previous_evidence_id===p.evidence_id&&c.drain_observation.next_evidence_id===e.evidence_id,'DRAIN_OBSERVATION');
  fail(!e.scan_in_progress&&!e.scan_scheduled,'SCAN_NOT_DRAINED');
 }
}
async function takeover(c){
 const {request:a,reply:b,oracle:o}=c;
 exact(a,['format_version','request_id','binding','cutoff_ref','new_worker_instance_id','channel_ref',
  'challenge_id','expected_takeover_ref','cleanup_authorization_ref','identities','local_plan_ids',
  'request_watch_cleanup','request_session_release'],'TAKEOVER_REQUEST_FIELDS');
 fail(a.format_version==='IG04_WATCH_TAKEOVER_REQUEST_CANDIDATE_1','FORMAT_VERSION');
 binding(a.binding,o);fail(a.cutoff_ref===o.cutoff_ref,'CUTOFF_BINDING');
 exact(b,['format_version','request_id','request_sha256','binding','cutoff_ref','new_worker_instance_id','channel_ref',
  'challenge_id','takeover_ref','state','accepted_identities','pending_identities','accepted_local_plan_ids',
  'pending_local_plan_ids','watch_cleanup_accepted','session_release_accepted','allowed_operations','remaining',
  'expires_at','reason'],'TAKEOVER_REPLY_FIELDS');
 fail(b.format_version==='IG04_WATCH_TAKEOVER_REPLY_CANDIDATE_1','FORMAT_VERSION');
 binding(b.binding,o);fail(b.cutoff_ref===o.cutoff_ref,'CUTOFF_BINDING');await correlation(a,b,o);
 for(const k of ['new_worker_instance_id','channel_ref','challenge_id'])fail(a[k]===b[k],'REPLY_CORRELATION');
 unique(a.identities,'DUPLICATE_IDENTITY');unique(a.local_plan_ids,'DUPLICATE_LOCAL');
 const partition=[...b.accepted_identities,...b.pending_identities],locals=[...b.accepted_local_plan_ids,...b.pending_local_plan_ids];
 unique(partition,'DUPLICATE_IDENTITY');unique(locals,'DUPLICATE_LOCAL');
 fail(seteq(partition,a.identities)&&seteq(locals,a.local_plan_ids),'TAKEOVER_PARTITION');
 fail(b.allowed_operations.every(x=>['QUERY_OLD_SCOPE','RELEASE_OLD_SCOPE','COMPLETE_OLD_RESERVATION'].includes(x)),'APPLY_FORBIDDEN');
 unique(b.allowed_operations,'DUPLICATE_OPERATION');matchRemaining(b,sourceRemaining(o));
 fail(a.expected_takeover_ref===null||uuid(a.expected_takeover_ref),'EXPECTED_TAKEOVER_REF_TYPE');
 if(['ACCEPTED','PARTIAL'].includes(b.state)){
  current(o,a.new_worker_instance_id,a.channel_ref);
  fail(o.old_cleanup_authorized&&a.cleanup_authorization_ref===o.cleanup_authorization_ref,'OLD_CLEANUP_UNAUTHORIZED');
  fail(a.challenge_id===o.validated_challenge,'CHALLENGE_UNCONFIRMED');
  fail(a.expected_takeover_ref===o.current_takeover_ref,'STALE_TAKEOVER');
  if(a.expected_takeover_ref!==null){
   const prior=o.expected_takeover_source;
   fail(prior&&prior.takeover_ref===a.expected_takeover_ref,'EXPECTED_TAKEOVER_SOURCE');
   fail(prior.valid===true,'EXPECTED_TAKEOVER_EXPIRED');
   fail(same(prior.binding,a.binding)&&prior.cutoff_ref===a.cutoff_ref,'EXPECTED_TAKEOVER_SCOPE');
  }

  fail(b.takeover_ref===o.takeover_ref&&uuid(b.takeover_ref),'TAKEOVER_SOURCE');
  for(const id of b.accepted_identities)fail(o.authorized_identities.some(x=>same(x,id)),'IDENTITY_SCOPE');
  for(const id of b.accepted_local_plan_ids)fail(o.authorized_local_plan_ids.includes(id),'LOCAL_SCOPE');
  if(b.session_release_accepted){
   fail(a.request_session_release&&o.session_release_authorized&&o.scope_complete&&b.watch_cleanup_accepted
    &&b.pending_identities.length===0&&b.pending_local_plan_ids.length===0
    &&seteq(a.identities,o.context_identities)&&seteq(a.local_plan_ids,o.context_local_plan_ids),'SESSION_SCOPE_INCOMPLETE');
  }
  if(b.watch_cleanup_accepted)fail(a.request_watch_cleanup&&o.watch_cleanup_authorized,'WATCH_CLEANUP_UNAUTHORIZED');
  if(b.allowed_operations.includes('RELEASE_OLD_SCOPE'))fail(b.session_release_accepted,'SESSION_SCOPE_INCOMPLETE');
  if(b.allowed_operations.includes('COMPLETE_OLD_RESERVATION'))fail(b.accepted_identities.length>0,'IDENTITY_SCOPE');
  const all=b.pending_identities.length===0&&b.pending_local_plan_ids.length===0
   &&(!a.request_watch_cleanup||b.watch_cleanup_accepted)&&(!a.request_session_release||b.session_release_accepted);
  if(b.state==='ACCEPTED'){fail(all,'ACCEPTED_SCOPE');fail(b.reason===null,'SUCCESS_REASON');}
  else{fail(!all&&(b.accepted_identities.length+b.accepted_local_plan_ids.length>0||b.watch_cleanup_accepted),'PARTIAL_SCOPE');failure(b,b.state);}
  fail(typeof b.expires_at==='string'&&Number.isFinite(Date.parse(b.expires_at)),'EXPIRY_FORMAT');
 }else{
  failure(b,b.state);fail(b.takeover_ref===null&&b.accepted_identities.length===0&&b.accepted_local_plan_ids.length===0
   &&!b.watch_cleanup_accepted&&!b.session_release_accepted&&b.allowed_operations.length===0,'FAILED_TAKEOVER_NO_RIGHTS');
 }
}
export async function validate(c,lookupOriginalLocalRecord,readClosureFence){
 fail(c.oracle.fixture_only,'FIXTURE_ONLY');
 fail(c.request.binding.context_sha256===await digest(c.request.binding.context),'CONTEXT_HASH');
 if(c.kind==='reference')await reference(c);
 else if(c.kind==='closure')await closure(c,lookupOriginalLocalRecord,readClosureFence);
 else if(c.kind==='takeover')await takeover(c);
 else throw Error('CASE_KIND');
 for(const part of ['request','reply','evidence'])if(c[part])validateMessage(c[part]);
}

export {digest};
