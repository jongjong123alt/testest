import assert from 'node:assert/strict';
import {readFile,writeFile} from 'node:fs/promises';
import {validate,digest} from './independent-export.mjs';
const f=JSON.parse(await readFile(new URL('fixtures/watch-cases.json',import.meta.url)));
const get=n=>structuredClone(f.cases.find(c=>c.name===n));
const base=get('ORIGIN preserve W3 valid takeover then new Worker closure (original transport preserved)');
// Preserve old binding/transport, remove plans from both sides of the chain.
const p0=structuredClone(base);
for(const c of [p0,p0.takeover_chain]){
 for(const k of ['context_local_plan_ids','uncalled_local_ids','authorized_local_plan_ids'])c.oracle[k]=[];
 c.reply.remaining.local_plan_ids=[];
}
p0.request.local_records=[];p0.evidence.local_records=[];p0.reply.closed_local_plan_ids=[];
p0.oracle.active_takeover.accepted_local_plan_ids=[];
p0.takeover_chain.request.local_plan_ids=[];
p0.takeover_chain.reply.accepted_local_plan_ids=[];p0.takeover_chain.reply.pending_local_plan_ids=[];
const rows=[],inputs=[];
async function seal(c){
 if(c.takeover_chain)await seal(c.takeover_chain);
 if(c.reply)c.reply.request_sha256=await digest(c.request);
 if(c.evidence){const {evidence_sha256,...body}=c.evidence;c.evidence.evidence_sha256=await digest(body);}
}
async function run(name,source,mutate=()=>{},code=null,changeFence=false){
 const c=structuredClone(source);
 const originals=(source.request.local_records??[]).map(r=>({binding:structuredClone(source.request.binding),cutoff_ref:source.request.cutoff_ref,...structuredClone(r)}));
 mutate(c);await seal(c);let reads=0;
 const fence=()=>({lifetime_ref:'protected-test-lifetime',revision:changeFence&&++reads>1?'r2':'r1'});
 const lookup=async({local_plan_id})=>{const r=originals.find(x=>x.local_plan_id===local_plan_id);return r?{...r,closure_fence:{lifetime_ref:'protected-test-lifetime',revision:'r1'}}:null;};
 let error=null;try{await validate(c,lookup,fence);}catch(e){error=e.message;}
 assert.equal(error,code,name);rows.push({name,positive:code===null,pass:true,error});inputs.push({name,input:c,expected:code});
}
await run('01 valid takeover -> plan0 closure',p0);
assert.deepEqual(p0.request.binding.original_transport,base.request.binding.original_transport);
assert(!p0.takeover_chain.reply.allowed_operations.includes('RELEASE_OLD_SCOPE'));
await run('02 old actor cannot consume accepted takeover',p0,c=>{c.request.executor.worker_instance_id=c.request.binding.original_transport.worker_instance_id;c.reply.executor.worker_instance_id=c.request.executor.worker_instance_id;},'STALE_WORKER');
await run('03 expired takeover',p0,c=>c.oracle.active_takeover.valid=false,'TAKEOVER_EXPIRED');
await run('04 different cutoff in authorization',p0,c=>c.oracle.active_takeover.cutoff_ref='foreign','TAKEOVER_BINDING');
await run('05 foreign watch in authorization',p0,c=>c.oracle.active_takeover.binding.watch_ref='foreign','TAKEOVER_BINDING');
const take=get('empty identities watch-only takeover');
await run('06 cleanup cannot grant session release',take,c=>{c.reply.allowed_operations.push('RELEASE_OLD_SCOPE');},'SESSION_SCOPE_INCOMPLETE');
await run('07 null original identity',get('ORIGIN original null accepted without invented identity'));
await run('08 complete original identity',get('ORIGIN original nonnull exact six fields accepted'));
await run('09 incomplete identity',get('ORIGIN original nonnull exact six fields accepted'),c=>{for(const r of [c.request.local_records[0],c.evidence.local_records[0]])delete r.identity.plan_sha256;},'LOCAL_IDENTITY_FIELDS');
await run('10 null expected takeover',take);
const retake=get('TYPE-R1 nonnull expected takeover matches active record');
await run('11 existing ref re-takeover',retake);
await run('12 existing ref foreign owner',retake,c=>c.oracle.expected_takeover_source.binding.context.scope.owner_binding_id='foreign','EXPECTED_TAKEOVER_SCOPE');
await run('13 existing ref foreign cutoff',retake,c=>c.oracle.expected_takeover_source.cutoff_ref='foreign','EXPECTED_TAKEOVER_SCOPE');
await run('14 existing ref foreign watch',retake,c=>c.oracle.expected_takeover_source.binding.watch_ref='foreign','EXPECTED_TAKEOVER_SCOPE');
await run('15 normal closure_ref without reservation proof',p0);
await run('16 negative fixture proof forbidden',p0,c=>c.reply.proof='synthetic-proof','CLOSURE_REPLY_FIELDS');
await run('17 timeout cannot clear obligations',p0,c=>{c.reply=null;c.caller_outcome='TIMEOUT';});
await run('18 pending restore blocks closed success',p0,c=>c.evidence.result='PARTIAL_LOCAL','LOCAL_CLEANUP_UNCONFIRMED');
await run('19 changed revision before final consumption',p0,()=>{},'CLOSURE_FENCE_CHANGED',true);
await run('20 revoked watch permission',p0,c=>c.oracle.watch_cleanup_authorized=false,'WATCH_CLEANUP_UNAUTHORIZED');
await run('21 missing previous reference source',retake,c=>delete c.oracle.expected_takeover_source,'EXPECTED_TAKEOVER_SOURCE');
await run('22 expired previous reference source',retake,c=>c.oracle.expected_takeover_source.valid=false,'EXPECTED_TAKEOVER_EXPIRED');
await writeFile(new URL('fixtures/p3-regression.json',import.meta.url),JSON.stringify({candidate:'IG04-WATCH-SHARED-20261103-P3-TAKEOVER-TYPES',cases:inputs},null,2));
const result={passed:rows.length,failed:0,skipped:0,total:rows.length,positive:rows.filter(x=>x.positive).length,negative:rows.filter(x=>!x.positive).length,kind:'candidate implementation tests; synthetic authority, not product provider',rows};
await writeFile(new URL('results/p3-regression.json',import.meta.url),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
