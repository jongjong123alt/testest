from pathlib import Path
import subprocess,os,sys
p=Path(__file__).resolve().parent
e=os.environ.copy();e['IG04_CORE_ROOT']=str(p/'pinned-core');e['IG04_CONTENT_ROOT']=str(p/'pinned-content')
for n in ['check-candidate.mjs','currentness-cases.mjs','independent-origin-check.mjs','check-type-consistency.mjs','independent-sequence.mjs','p3-regression.mjs','check-r2-regression.mjs','check-vectors.mjs']:
 subprocess.run(['node',n],cwd=p,env=e,check=True)
subprocess.run([sys.executable,'check-rc2.py'],cwd=p,env=e,check=True)
