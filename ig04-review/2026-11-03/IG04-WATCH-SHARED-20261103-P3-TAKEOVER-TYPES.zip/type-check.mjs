import {readFile} from 'node:fs/promises';
const dictionary=JSON.parse(await readFile(new URL('field-contract.json',import.meta.url)));
const type=v=>v===null?'null':Array.isArray(v)?'array':typeof v==='number'&&Number.isInteger(v)?'integer':typeof v;
export function checkNode(n,v,path='$'){
 if(!n.types.includes(type(v)))throw Error('TYPE_DICTIONARY:'+path);
 if(type(v)==='object'){
  for(const k of n.required)if(!Object.hasOwn(v,k))throw Error('TYPE_REQUIRED:'+path+'.'+k);
  for(const k of Object.keys(v)){if(!Object.hasOwn(n.fields,k))throw Error('TYPE_FORBIDDEN:'+path+'.'+k);checkNode(n.fields[k],v[k],path+'.'+k);}
 }
 if(Array.isArray(v))for(const x of v)checkNode(n.items,x,path+'[]');
}
export function validateMessage(v){const n=dictionary.messages[v.format_version];if(!n)throw Error('TYPE_FORMAT');checkNode(n,v);}
export {dictionary};
