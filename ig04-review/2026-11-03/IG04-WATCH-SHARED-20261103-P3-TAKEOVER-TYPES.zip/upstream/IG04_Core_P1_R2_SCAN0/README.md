# IG04 Core P1-R2-SCAN0 검토 자료

후보 ID: `IG04-CORE-SHARED-FORMATS-20261102-P1-R2-SCAN0`
상태: 합의된 scan0 조건 반영 / 전체 공유 형식 미확정 / M1 BLOCKED

이번 변경은 P1-R1의 watch 종료 조건과 합성 fixture·검사에 한정한다. 첫 CLOSED_LOCAL은 scan_in_progress=false 및 scan_scheduled=false를 모두 요구한다. scan_scheduled=true이면 fenced callback이어도 거절하며, UNCONFIRMED·IN_PROGRESS와 빈 terminal proof로 의무를 보존한 예시를 제공한다.

- SPEC.md: §3 및 마지막 보완 절의 scan0 조건
- fixtures.json: 정상 종료에서 두 scan=false인 기준 예시
- scan0-fixtures.json: 기준 fixture에 watch_cleanup/completion_queries를 대입하는 추가 6개 예시
- scan0-results.json: 새 scan 관계 검사6/6
- validation-results.json: 기존 R1 37건 + scan0 6건 = 43/43
- repair-fixtures.json·repair-results.json: 기존 property 완전성·중복 검사 유지
- rc2-compatibility.json: 기존 RC2 하위 정의 구조5/5
- preservation-proof.json·source-and-files.json: 원본·hash 보존과 파일 해시
- before-results.json·after-results.json: 이전 P1 property 결함의 역사적 전후 결과이며 scan0 실행 결과가 아님

```bash
IG04_CORE_ROOT=/path/to/core node build-fixtures.mjs
IG04_CORE_ROOT=/path/to/core IG04_CONTENT_ROOT=/path/to/content node check-fixtures.mjs
IG04_CORE_ROOT=/path/to/core python3 check-rc2.py
```

고정 source는 기존 Core ed8755a597973922d02bd675e80b00c410dfdaf4 / Content 2704148b9d6036a16d1ba2083ffe43ae14580744다. Python 구조 검사는 jsonschema가 필요하다. 후보 자료 관계 검사이며 실제 scheduler·Core 영속 권한·MV3·Server 제품 검증이 아니다. 기존 #87이 새 종료 조건을 이미 구현했다고 주장하지 않는다.

원래 P1/P1-R1 자료는 수정하지 않고 별도 후보로 보존했다. property coverage·중복·Ledger 유효 복원 목표·reserve exact plan_id·strict true·canonical/footprint 구조는 유지한다. watch 본문 값이 바뀌므로 watch evidence hash는 새로 계산한다.

watch_ref 전달·미시작 closure·부분 takeover의 정확한 입출력은 별도 공동 확정 대기다. M2/M4 저장 구현·제품 코드·공용 Schema·PR·병합·Chrome START는 변경하지 않았다.
