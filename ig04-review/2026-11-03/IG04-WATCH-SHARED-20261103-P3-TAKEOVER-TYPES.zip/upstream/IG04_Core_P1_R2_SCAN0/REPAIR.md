# 이번 최소 변경

P1-R1 property 보완은 그대로 유지한다. 이번에는 합의된 scan0 조건만 변경했다.

- 정상 watch: scan_in_progress=false, scan_scheduled=false, CLOSED_LOCAL.
- 예약 scan=true: fenced여도 CLOSED_LOCAL 거절. UNCONFIRMED watch와 IN_PROGRESS·null terminal proof 예시는 허용해 의무를 보존한다.
- 진행 scan=true도 동일하게 종료 보류. 실제 새 관측으로 두 값이 false가 된 근거를 다시 검증한다.
- watch evidence_sha256를 기존 canonical digest로 재계산했다. 기준 context/plan/footprint/Grant/RELEASE/claim_cleanup 원문과 hash는 불변이다.

기존 R1 검사37건 유지 + scan 관계6건 = 후보43/43, RC2 구조5/5. 제품 시험이 아니다. watch_ref/미시작 closure/부분 takeover 형식과 M1 BLOCKED는 그대로다.
