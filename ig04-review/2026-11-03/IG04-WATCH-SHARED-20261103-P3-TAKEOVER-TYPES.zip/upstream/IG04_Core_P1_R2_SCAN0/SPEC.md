# Core 공유 형식5개 — P1-R2-SCAN0 후보

이 문서는 `IG04-CORE-SHARED-FORMATS-20261102-P1-R2-SCAN0`의 미승인 후보다. 기존 공용 Wire/Schema를 변경하거나 실제 provider를 제공하지 않는다. 아래 새 필드/상태는 리뷰할 DTO 예시이며 모두 source 검증 전에는 untrusted data다. `fixtures.json`이 정확한 합성 예시이며 여기서 보이지 않는 내부 Core 원장 형식은 공동 계약 대상으로 추가하지 않는다.

## 공통 타입과 신뢰 경계

| 타입/필드 | 뜻 |
|---|---|
| UUID / Hash | 기존 소문자 UUID / 64hex SHA-256 profile 재사용 |
| `context` | 기존 `{scope:BindingScope,operation_id,semantic_sha256}` 전체. 여기의 op/hash는 원래 APPLY다 |
| `transport` | 원래 `{receiver_instance_id,worker_instance_id}`. Worker 인수 후에도 원본을 바꾸지 않음 |
| `identity` | 기존 reservation_identity 6필드 전체. plan_id/claim 하나로 대체하지 않음 |
| `*_ref` | 고정 소유 범위의 검증 원문을 찾는 opaque 참조. 자체 capability/성공 증명 아님 |
| `request_id` | 조회/handshake 요청 correlation. 재시도에 transport ID를 바꿔도 원래 identity/op/hash는 보존 |
| `format_version` | 후보 자료의 domain/version 식별. 기존 `AMVP_CONTENT_2` 버전을 대체하지 않음 |
| `evidence_sha256` | 자기 필드를 제외한 근거 본문 전체의 기존 canonical UTF-8 SHA-256. 무결성일 뿐 권한/사실 검증 아님 |

Core는 실제 등록 채널/현재 요청자와 native 문서 provenance, 발급 원장·예약/Grant·원문을 별도로 대조한다. Content가 보낸 boolean/상태/hash·opaque ID를 곧 그 대조의 성공으로 인정하지 않는다. 신뢰된 source/profile의 실제 관측·원문이 없으면 미확인이다. 민감 DOM 원문·댓글·selector·raw URL·credential·다른 owner ID는 포함하지 않는다.

구조 검증은 허용된 필드/버전/타입만 수락하고 정수는 JS safe integer, 문자열/배열 크기는 기존 plan/RC2 및 실제 승인된 capacity를 넘어 확장하지 않는다. 본 fixture checker는 관련 예시의 관계 검사이며 이 일반 parser/크기/인증 검증의 제품 구현을 대신하지 않는다.

## 1. plan·claim·최종 Ledger cleanup 근거

후보 `IG04_CLAIM_CLEANUP_PROPOSAL_1`:

| 필드 | 타입·검증 의미 |
|---|---|
| `evidence_id`, `context_sha256`, `transport`, `cutoff_ref` | UUID/hash/원래 transport. cleanup 범위·원래 source를 결속 |
| `members[]` | `{identity,resource_ref,claim,application}`. application은 APPLIED/NOT_APPLIED/UNCONFIRMED로 분류하되 Core가 실제 원문과 대조 |
| `resources[]` | `{resource_ref,claim,properties[]}`. resource_ref는 원래 instance가 실제 같은 Element에 부여/등록한 안전한 불변 참조. body 문자열만으로 새 DOM 소유권을 만들지 않음 |
| property 결과 | `property`, `goal`, `observed`, `goal_basis`, `basis_ref`, `own_claim_remaining`, `pending_restore`, `other_claims_preserved` |
| `goal/observed` | display는 `{value,priority}`, inert는 `{value:boolean}`. **goal은 최종 유효 Ledger 목표이며 과거 plan.restore가 아님** |
| `goal_basis` | ORIGINAL/PAGE_EDIT/PENDING_RESTORE/OTHER_CLAIM의 후보 구분. basis_ref가 실제 유효 baseline/pending 또는 타 claim 보호 근거에 연결돼야 함 |
| `result`, `error_count` | RESTORED_LOCAL/PARTIAL_LOCAL/UNCONFIRMED 및 음이 아닌 정수. 로컬 정리 결과이며 Core terminal이 아님 |

원래 context·instance/문서/claim/resource/property·포함 identity 목록을 각각 결속한다. 계획 hash/Grant는 불변으로 유지한다. 최종 유효 goal이 계획 restore와 달라도 정당한 페이지 변경 provenance가 확인되면 허용하고, pending setter 중간값을 페이지 변경으로 채택하지 않는다.

RESTORED_LOCAL은 자기 property 잔여/고정 pending/오류가 없어야 한다. 다른 owner가 계속 보호하는 none/inert=true는 자기 claim 정리와 함께 성립할 수 있다. Core는 같은 evidence를 여러 예약에서 참조하더라도 예약별 Grant/op/receipt·적용 분류를 검증한다. NOT_APPLIED/UNCONFIRMED 멤버를 정상 적용/복원 성공으로 소급하지 않는다.

**해제 범위:** 첫 연결 후보는 기존 #87의 검증된 context/세션 종료 및 고정 cutoff 관련 전체 plan 범위를 사용한다. P1 Grant 하나로 같은 claim의 P2를 임의 종료하지 않는다. 현재 API에 독립 per-plan DOM release가 있다고 가정하지 않는다.

## 2. 불변 canonical planned footprint

기존 제안을 그대로 사용한다.

```text
["FOCURVE_IG04_PLAN_FOOTPRINT_1", context, completePlan, originalTransport]
```

completePlan은 기존 #88이 받는 exact plan과 reservation_identity다. context hash·plan hash 계산은 기존 것을 유지한다. Core/Content 기존 canonical의 키 정렬·공백 없음·배열 순서 유지·UTF-8/SHA-256, field별로 이미 검증된 문자열·safe integer를 사용한다. 추가 NFC/casefold·배열 정렬·중복 제거는 하지 않는다.

자기 footprint hash·plan별 Grant/예약 RELEASE op/receipt·terminal proof·새 credential은 위 배열에 넣지 않아 역참조를 만들지 않는다. context의 semantic hash는 원래 APPLY이며 RELEASE semantic과 섞지 않는다. originalTransport는 인수 때 새 Worker 값으로 교체하지 않는다.

`fixtures.json.footprints[]`는 canonical bytes의 UTF-8 문자열과 SHA를 담고, 두 plan의 current/restore가 grid→flex로 달라져도 두 원문을 모두 유지한다. 최종 Ledger goal은 별도 근거다. footprint hash·plan hash·최종 근거 hash를 서로 복사하지 않는다.

## 3. observer/plan0·dispatch·cutoff·재조회

### 세션 감시 종료 후보 `IG04_WATCH_CLEANUP_PROPOSAL_1`

`evidence_id/watch_ref/context_sha256/transport/cutoff_ref`, `observer_stopped`, `listeners_detached`, `scan_in_progress`, `scan_scheduled`, `scheduled_callbacks_fenced`, `future_effects_closed`, `accounted_dispatches[]`, `result`, `evidence_sha256`.

result 후보는 CLOSED_LOCAL/PARTIAL_LOCAL/UNCONFIRMED다. 첫 CLOSED_LOCAL 근거는 `scan_in_progress=false`와 `scan_scheduled=false`를 모두 요구한다. 자기 observer/listener 종료와 새 효과 차단 근거도 계속 필요하다. 예약 scan이 true이면 scheduled_callbacks_fenced=true여도 CLOSED_LOCAL을 허용하지 않으며, 종료 UNCONFIRMED와 예약 terminal 보류·기존 의무 보존으로 표현한다. 실제 drain 후 새 근거를 재검증하며 상태 flag를 강제로 0으로 만들지 않는다. 시작된 외부 dispatch는 cutoff 목록에서 여전히 설명해야 하며 scan0을 dispatch 완료로 해석하지 않는다.

감시-only 영속 의무는 plan0에도 존재한다. 생성 전 준비·재시작 조회·권한/종료 보장은 Core가 맡는다. 첫 구현안은 production verifyInput이 감시 준비를 영속 확인하고 true를 반환한 뒤 #87 adapter.start를 호출하는 경계다. 기존 admission이 이 commit을 이미 제공한다는 뜻은 아니다. 가짜 plan/Grant/terminal을 만들지 않는다.

### 호출/조회 후보 `IG04_DISPATCH_RECONCILIATION_PROPOSAL_1`

header `request_id/context_sha256/cutoff_ref/watch_ref`, entries의 `{local_plan_id,identity,dispatch_ref,call_state,lookup,result_ref,closure_ref,resolution}`.

- call_state: NOT_CALLED/CALLED/UNCONFIRMED. provider를 부르기 **직전부터** CALLED이며 sync throw도 NOT_CALLED로 되돌리지 않는다.
- identity는 hash 생성 전이면 null일 수 있다. CALLED에는 완전 identity와 dispatch_ref가 필요하다.
- lookup: FOUND/NOT_FOUND/UNCONFIRMED/CONFLICT. result_ref는 권한 있는 조회 원문 참조다.
- resolution: RESERVATION_CONFIRMED/LOCAL_UNCALLED_CLOSED/UNCONFIRMED. 단순 NOT_FOUND는 closure가 아니다.
- LOCAL_UNCALLED_CLOSED에는 실제 미호출 provenance, 후속 dispatch/동일 identity 유입 차단·다른 시도 배제와 필요한 최종 조회를 담은 Core closure_ref가 필요하다. 해당 참조의 진위를 실제 조회/검증해야 한다.

미호출 local record 종료는 별도 분기다. 영속 예약이 없는 record를 fake terminal proof로 기존 completeReservation에 통과시키지 않는다. M2/M4의 실제 cutoff·모든 writer 차단·최종 조회/CAS/private key는 여기서 정의하지 않는다.

## 4. 부분 진행·terminal·proof 조회·만료

후보 `IG04_COMPLETION_QUERY_PROPOSAL_1`:

`request_id/context_sha256/identity`, `cleanup_operation_id/cleanup_semantic_sha256/reserved_receipt_id`, `state/retry_hint/reason`, `terminal_kind/terminal_receipt_id/proof`, `claim_evidence_ref/watch_evidence_ref/terminal_basis_ref`.

| state 후보 | 결과와 소비자 동작 |
|---|---|
| IN_PROGRESS | 동일 operation의 부분 진행/남은 의무. proof/terminal_receipt_id/terminal_kind=null |
| NEEDS_REVALIDATION | Grant/채널/문서 재검증 필요. 자동 TTL 연장·새 슬롯·성공 처리 없음 |
| LOOKUP_UNCONFIRMED | 조회/원문/응답 미확인 또는 proof 소실. 미접수/완료로 변환하지 않음 |
| TERMINAL | 보호된 영속 원장의 실제 terminal을 검증한 결과. 동일 immutable receipt 재사용 |
| CONFLICT | 다른 scope/identity/목록/hash. 원래 의무 보존, foreign 원문 노출 금지 |

retry_hint 후보는 SAME_OPERATION_AFTER_FRESH_CHECK / SAME_OPERATION_AFTER_REVALIDATION / QUERY_ONLY / NONE이다. UI/스케줄러의 자동 실행 허가가 아니며 재시도 전 실제 권한 검증이 다시 필요하다. terminal은 QUERY_ONLY이며 새 효과·예약·receipt를 만들지 않는다.

proof는 기존 제안대로 해당 reserved_receipt_id UUID 조회 참조다. 미리 알려진 ID이므로 그 자체로 권한이 아니며, terminal_basis_ref의 실제 원장 commit·정확한 원래 identity/Grant/operation/hash 및 근거를 검증해야 한다. A1 write_id와 자동 동일시하지 않는다.

terminal_kind 제안은 RESTORED와 DOCUMENT_GONE의 구분이다. RESTORED는 J1/J2 근거와 해당 plan의 실제 적용/복원 범위를 대조한다. DOCUMENT_GONE은 별도 exact native 소멸 근거를 terminal_basis_ref에서 검증한 경우의 Core 조회 의미이며 **사라진 Content에 완료 hook을 호출하거나 restored=true를 생성하지 않는다**. 해당 종료 계약/근거가 확정되지 않으면 NEEDS_REVALIDATION/미확인으로 남긴다. 예약 확인 후 실제 효과 없음은 정상 적용/복원으로 소급하지 않고 별도 합의 분기 전 미확인 의무를 유지한다.

정상 순서는 Content cleanup 관측→Core 예약별 terminal 영속 확인→proof 전달→기존 verifyCompletion strict true·로컬 복원/수명 재검사다. hook 성공을 Core terminal 생성의 선행 조건으로 삼지 않는다. 세션 자원이 남아 있으면 plan terminal이 있어도 Content 완료를 보류한다.

**만료:** Grant ID가 바뀌면 RC2 RELEASE semantic도 달라질 수 있다. 같은 op/hash를 유지하는 재검증 authority 결속 절차의 선택은 별도 공동 확인이 필요하다. 이 후보는 임의 TTL 연장이나 lease 우회를 정의하지 않고 GRANT_EXPIRED·NEEDS_REVALIDATION·기존 의무 보존으로 표현한다. 보존 기간의 임의 숫자를 만들지 않으며 unresolved 원문/중복 제거 이력은 일반 cache TTL로 삭제하지 않는다.

## 5. Worker cleanup-only handshake·stale

요청 후보 `IG04_CLEANUP_TAKEOVER_REQUEST_PROPOSAL_1`:

`request_id`, `context`, `original_transport`, `new_worker_instance_id`, `channel_ref`, `challenge_id`, `expected_takeover_ref`, `cleanup_authorization_ref`, `identities[]`.

본문의 Worker ID·channel/challenge/ref는 모두 주장이다. 실제 새 Worker/등록 live 채널·pending 요청을 별도로 인증하고, cleanup_authorization_ref가 원래 old scope/Grant/footprint/예약에 어떤 권한을 주는지 보호된 source에서 검증한다. current APPLY가 아니라 old 의무 권한이다. private credential은 이 DTO/fixture에 넣지 않는다.

응답 후보 `IG04_CLEANUP_TAKEOVER_REPLY_PROPOSAL_1`:

`request_id/context_sha256/original_receiver_instance_id/new_worker_instance_id/channel_ref/challenge_id`, `takeover_ref/state`, `accepted_identities[]/pending_identities[]`, `allowed_operations[]`, `expires_at/reason`.

- state 후보: ACCEPTED/PARTIAL/REVALIDATION_REQUIRED/DENIED.
- 두 identity 목록은 요청 전체를 중복 없이 분할해야 한다. 응답 correlation·원래 instance·새 Worker/live channel/challenge가 모두 일치해야 한다.
- 허용 연산은 QUERY_OLD_SCOPE/RELEASE_OLD_SCOPE/COMPLETE_OLD_RESERVATION뿐이다. 직렬화된 목록이 그 자체로 권한이 되지 않으며 실제 제한 actor에서 원래 source/lease를 검증한다.
- PARTIAL은 전체 세션 RELEASE 권한이 아니다. 기존 #87 context 전체 release를 재사용하려면 모든 관련 의무·공통 자원의 정리 권한을 확인해야 한다. 단순 부분 목록으로 P2를 임의 해제하지 않는다.
- expected_takeover_ref는 Core의 현재 인수 원문과 대조할 opaque CAS 기대값이다. 같은 요청·원문 재생은 같은 결과를 재사용하고, 다른 의미/오래된 기대값은 stale/conflict로 거절한다. 내부 인수 번호/원장 키는 노출하지 않는다.
- DENIED/REVALIDATION_REQUIRED에는 인수 권한·허용 연산을 주지 않고 원래 의무를 남긴다. 실제 만료는 검증된 source 기한을 따르며 새 임의 TTL을 정의하지 않는다.

현재 #87 ordinary receiver의 Worker ID/lifetime을 덮어쓰지 않는다. 원래 Content/Element/복원 원본을 유지하는 별도 제한 seam에서만 이 인수를 처리한다. BFCache·문서 교체·실제 소멸은 기존 별도 의미를 유지한다.

## 기존 callback 대응·이번에 필요한 확인

| 기존 #87 seam | 재사용/추가 역할 |
|---|---|
| verifyInput | 실제 issued/native 검증과 감시-only 준비 완료 후 strict true. 현재 boolean 반환 형식 유지 |
| isCurrent/getGeneration/getWorkerInstance | 일반 APPLY 현재성 유지. cleanup 인수로 이 권한을 다시 열지 않음 |
| reserve(plan,{signal,transport}) | 기존 원문·hash→Core 실제 예약 commit·최종 검사→exact plan_id. 후보 DTO를 ACK 문자열로 오인하지 않음 |
| verifyRelease | 원래 context/고정 관련 목록과 각 cleanup 권한 검증. P1-only가 세션 범위를 허용하지 않으면 거절/대기 |
| evidenceSnapshot | 현 snapshot과 새 J1/J2 provenance 원문/ref는 구분. 기존 snapshot만으로 완성된 최종 근거가 된다고 주장하지 않음 |
| verifyCompletion/completeReservation | 후보 조회의 RESTORED terminal·실제 source 검증을 연결하되 기존 strict true/로컬 재검사 유지 |
| 별도 미호출 종료·인수 seam | 현재 없음. 지민이와 후보의 입력/결과를 수용할 최소 인터페이스만 공동 확정 |

지민이에게는 이 필드/관계로 원래 instance의 근거를 제공 가능한지와 새 seam 범위 확인을 요청한다. 다훈에게는 기존 RC2·권한/보존 의미와 충돌 여부를 요청한다. **숫자 상태/필드/fixtures가 공동 승인되기 전 실제 consumer나 계약 저장소에 반영하지 않는다. M1은 계속 BLOCKED다.**

## P1-R1: cleanup 관계 검사 보완 (이 절 우선)

1. 각 evidence member의 정확한 reservation identity로 원래 admitted plan을 찾고, `(resource_ref, claim)`별 원래 property 집합의 합집합을 필수 범위로 정한다. 결과 evidence가 필수 범위를 축소할 수 없다. 현재 원래 IG04 plan은 display·inert를 포함한다.
2. RESTORED_LOCAL은 원래 resource/claim 전체 및 각각의 필수 property 전체를 정확히 한 번씩 보고해야 한다. 빈 목록·누락·범위 밖 resource/property는 거절한다. 따라서 inert가 빠진 근거로 RESTORED terminal을 만들 수 없다.
3. `(resource_ref, claim)` 행은 한 번만 허용하며, 그 행 안에서 property 이름도 한 번만 허용한다. flex/block 상충과 값이 같은 중복 모두 거절한다. 분할 행을 암묵 합치거나 마지막 값을 채택하지 않는다.
4. PARTIAL_LOCAL은 확인되지 않은 property를 생략할 수 있지만, 원래 member/resource 결속을 보존하고 terminal receipt·proof·kind를 비워 진행 중 상태를 유지한다. 생략을 성공으로 인정하지 않으며 기존 cleanup 의무를 끝내지 않는다.
5. 값의 최종 목표는 계속 ClaimLedger의 유효 목표다. 오래된 plan.restore와 같아야 한다는 제약을 추가하지 않는다. plan별 Grant·terminal 검증과 다른 owner 보존도 유지한다.
6. property coverage·중복 검사와 canonical 함수·domain·hash 입력 배열·format_version은 P1-R1 그대로다. 이번 scan0 기준 fixture는 proposal_id 및 watch.scan_scheduled와 그 본문 evidence_sha256만 바뀐다. plan·context·footprint·Grant·RELEASE·claim_cleanup hash는 동일하다. 새 scan 반례도 evidence hash를 재계산한 뒤 관계 검사로 거절돼야 한다.
7. 이번 사용자 전달 합의에 따라 첫 CLOSED_LOCAL은 진행 scan·예약 scan 모두 0을 요구한다. fenced callback 예외는 제외한다. watch_ref 전달·미시작 closure·부분 takeover의 정확한 입력/출력 형식은 여전히 별도 공동 확정 대기이며, 위 관련 형식은 미승인 후보 그대로다. 실제 연결과 M1 해제는 포함하지 않는다.
