// Unapproved, synthetic shared-format proposal. NO product storage/authority/IO.
import {readFile,writeFile} from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
const core=process.env.IG04_CORE_ROOT||'/workspace/focurve-ig04-verification-lifetime';
const {canonical,digest}=await import(pathToFileURL(core+'/extension/a1/contract.mjs'));
const id=n=>`00000000-0000-4000-8000-${String(n).padStart(12,'0')}`;
const previous=JSON.parse(await readFile(new URL('seed-footprint.json',import.meta.url)));
const context=structuredClone(previous.envelope[1]),transport=previous.envelope[3];
context.scope.focus_ref={session_id:id(13),snapshot_id:id(14),snapshot_format:'1.2',snapshot_sha256:'c'.repeat(64),desired_revision:1};
const context_sha256=await digest(context),plans=[],footprints=[],grants=[],controls=[];
for(let i=0;i<2;i++){
 const plan=structuredClone(previous.envelope[2]);delete plan.reservation_identity;plan.plan_id=id(20+i);
 plan.properties[0].current.value=i?'flex':'grid';plan.properties[0].restore.value=i?'flex':'grid';
 plan.reservation_identity={gate_id:plan.gate_id,plan_id:plan.plan_id,context_sha256,plan_sha256:await digest({...plan,context_sha256}),operation_id:context.operation_id,generation:context.scope.generation};plans.push(plan);
 const input=['FOCURVE_IG04_PLAN_FOOTPRINT_1',context,plan,transport];
 const sha256=await digest(input);footprints.push({plan_id:plan.plan_id,canonical_utf8:canonical(input),sha256});
 const grant={grant_id:id(30+i),owner_binding_id:context.scope.owner_binding_id,binding_id:context.scope.binding_id,generation:1,footprint_sha256:sha256,reserved_operation_id:id(40+i),reserved_receipt_id:id(50+i),operation_slots:1,receipt_slots:1,expires_at:'2026-11-02T12:00:00.000Z',scope:context.scope};grants.push(grant);
 const payload={operation_id:grant.reserved_operation_id,scope:context.scope,channel_credential:'d'.repeat(64),control_seq:null,operation:'RELEASE',cleanup_grant_id:grant.grant_id,release_mode:'CLEANUP_ONLY',expected_footprint_sha256:sha256};
 const {channel_credential,...semantic}=payload;
 controls.push({type:'D06_ADDITIONAL_CONTROL',schema_version:'AMVP_CONTENT_2',request_id:id(60+i),payload:{...payload,semantic_sha256:await digest(semantic)},stream:'ADDITIONAL_CONTENT'});
}
const identities=plans.map(p=>p.reservation_identity),cutoff_ref=id(70),resource_ref=id(71),watch_ref=id(72);
const seal=async body=>({...body,evidence_sha256:await digest(body)});
const claims=await seal({format_version:'IG04_CLAIM_CLEANUP_PROPOSAL_1',evidence_id:id(80),context_sha256,transport,cutoff_ref,
 members:plans.map(p=>({identity:p.reservation_identity,resource_ref,claim:p.claim,application:'APPLIED'})),
 resources:[{resource_ref,claim:plans[0].claim,properties:[
  {property:'display',goal:{value:'flex',priority:''},observed:{value:'flex',priority:''},goal_basis:'PAGE_EDIT',basis_ref:id(73),own_claim_remaining:false,pending_restore:false,other_claims_preserved:true},
  {property:'inert',goal:{value:false},observed:{value:false},goal_basis:'ORIGINAL',basis_ref:id(74),own_claim_remaining:false,pending_restore:false,other_claims_preserved:true},
 ]}],result:'RESTORED_LOCAL',error_count:0});
const monitor=await seal({format_version:'IG04_WATCH_CLEANUP_PROPOSAL_1',evidence_id:id(81),watch_ref,context_sha256,transport,cutoff_ref,
 observer_stopped:true,listeners_detached:true,scan_in_progress:false,scan_scheduled:false,scheduled_callbacks_fenced:true,future_effects_closed:true,
 accounted_dispatches:identities,result:'CLOSED_LOCAL'});
const local_plan_id=id(90);
const dispatch={format_version:'IG04_DISPATCH_RECONCILIATION_PROPOSAL_1',request_id:id(91),context_sha256,cutoff_ref,watch_ref,
 entries:[...identities.map((identity,i)=>({local_plan_id:identity.plan_id,identity,dispatch_ref:id(92+i),call_state:'CALLED',lookup:'FOUND',result_ref:id(94+i),closure_ref:null,resolution:'RESERVATION_CONFIRMED'})),
 {local_plan_id,identity:null,dispatch_ref:null,call_state:'NOT_CALLED',lookup:'NOT_FOUND',result_ref:id(96),closure_ref:id(97),resolution:'LOCAL_UNCALLED_CLOSED'}]};
const progress=identities.map((identity,i)=>({format_version:'IG04_COMPLETION_QUERY_PROPOSAL_1',request_id:id(100+i),context_sha256,identity,
 cleanup_operation_id:grants[i].reserved_operation_id,cleanup_semantic_sha256:controls[i].payload.semantic_sha256,reserved_receipt_id:grants[i].reserved_receipt_id,
 state:'TERMINAL',retry_hint:'QUERY_ONLY',reason:null,terminal_kind:'RESTORED',terminal_receipt_id:grants[i].reserved_receipt_id,proof:grants[i].reserved_receipt_id,
 claim_evidence_ref:claims.evidence_id,watch_evidence_ref:monitor.evidence_id,terminal_basis_ref:id(102+i)}));
const takeover_request={format_version:'IG04_CLEANUP_TAKEOVER_REQUEST_PROPOSAL_1',request_id:id(110),context,original_transport:transport,
 new_worker_instance_id:'fixture-worker-2',channel_ref:id(111),challenge_id:id(112),expected_takeover_ref:null,cleanup_authorization_ref:id(113),identities};
const takeover_reply={format_version:'IG04_CLEANUP_TAKEOVER_REPLY_PROPOSAL_1',request_id:takeover_request.request_id,context_sha256,
 original_receiver_instance_id:transport.receiver_instance_id,new_worker_instance_id:takeover_request.new_worker_instance_id,channel_ref:takeover_request.channel_ref,
 challenge_id:takeover_request.challenge_id,takeover_ref:id(114),state:'ACCEPTED',accepted_identities:identities,pending_identities:[],
 allowed_operations:['QUERY_OLD_SCOPE','RELEASE_OLD_SCOPE','COMPLETE_OLD_RESERVATION'],expires_at:'2026-11-02T11:00:00.000Z',reason:null};
const data={proposal_id:'IG04-CORE-SHARED-FORMATS-20261102-P1-R2-SCAN0',status:'UNAPPROVED',synthetic:true,m1:'BLOCKED',context,transport,plans,footprints,grants,cleanup_controls:controls,
 claim_cleanup:claims,watch_cleanup:monitor,dispatch_reconciliation:dispatch,completion_queries:progress,takeover_request,takeover_reply};
await writeFile(new URL('fixtures.json',import.meta.url),JSON.stringify(data,null,2)+'\n');
console.log('Wrote unapproved synthetic format fixtures; no product operation performed.');
