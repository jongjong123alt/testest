다훈아, 지민아. 합의된 첫 CLOSED_LOCAL scan0 조건만 반영한 수정 자료 정리했어.

후보: **IG04-CORE-SHARED-FORMATS-20261102-P1-R2-SCAN0**

정상 watch는 진행 scan=false·예약 scan=false로 바꾸고 watch evidence hash를 다시 계산했어. 예약 scan=true는 fenced=true여도 CLOSED_LOCAL을 거절하며, UNCONFIRMED·IN_PROGRESS와 null terminal proof로 종료를 보류하는 예시를 추가했어. 진행 scan=true 거절과 두 값이 0인 새 근거 수락도 확인했어.

후보 관계 검사 **43/43**(기존 R1 37 + scan0 6), RC2 구조 **5/5** 통과야. 기존 property coverage·중복 검사·Ledger 목표·reserve exact plan_id·strict true·canonical/footprint hash 구조는 유지했고, 기준 fixture의 plan·footprint·Grant·RELEASE·claim 근거도 동일해. watch 본문 변경으로 watch evidence hash만 새 값이야.

첨부 SPEC §3·마지막 보완 절, scan0-fixtures.json·scan0-results.json 기준으로 이번 scan0 변경분만 확인 부탁해. scheduler/실제 Core 권한·영속 provider·MV3 제품 검증은 아니야.

watch_ref 전달·미시작 closure·부분 takeover의 정확한 입력/출력은 별도 공동 확정 대기로 유지했어. M1 BLOCKED이며 실제 연결·제품 코드·공용 Schema·PR 승인·병합은 변경하지 않았어.
