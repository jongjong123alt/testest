// Synthetic original snapshots are loaded separately before closure mutations; never a product authority.
import {readFile} from 'node:fs/promises';
const saved=JSON.parse(await readFile(new URL('fixtures/protected-originals.synthetic.json',import.meta.url)));
export function fixtureOriginLookup(name){
 if(name==='ORIGIN no injected provider is blocked'||name==='ORIGIN null without original provenance is blocked')return undefined;
 if(name==='ORIGIN provider exception is blocked')return async()=>{throw Error('synthetic source unavailable');};
 const records=structuredClone(saved.snapshots[name]??[]);
 return async({local_plan_id})=>structuredClone(records.find(r=>r.local_plan_id===local_plan_id)??null);
}
